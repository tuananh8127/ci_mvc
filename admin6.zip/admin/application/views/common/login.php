<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Login/Logout animation concept</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
     <script src="<?php echo base_url(); ?>public/js/jquery-3.1.0.min.js"></script>

    <link rel="stylesheet" href="<?php echo base_url(); ?>public/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>public/bootstrap/css/font-awesome.min.css">
    <script src="<?php echo base_url(); ?>public/bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="<?php echo base_url(); ?>public/plugins/pace/pace.min.css">
  <script src="<?php echo base_url(); ?>public/plugins/pace/pace.js"></script>
    <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Open+Sans'>
        <link rel="stylesheet" href="<?php echo base_url('public/css/style.css') ?>">
  </head>
  <body>
    <div class="cont">
  <div class="demo">
    <div class="login">
      <div class="login__check"></div>
      <div class="ajax-content">
            </div>
       <?php if($message) { ?>
    <div class="login-box-body">
      <div id="infoMessage" class="alert alert-danger"><?php echo $message;?></div>
    </div>
  <?php } ?>
     <!--   <?php echo form_open("common/login");?> -->
      <div class="login__form">
        <div class="login__row">
          <svg class="login__icon name svg-icon" viewBox="0 0 20 20">
            <path d="M0,20 a10,8 0 0,1 20,0z M10,0 a4,4 0 0,1 0,8 a4,4 0 0,1 0,-8" />
          </svg>
           <?php echo form_input($identity); ?>
        </div>
        <div class="login__row">
          <svg class="login__icon pass svg-icon" viewBox="0 0 20 20">
            <path d="M0,20 20,20 20,8 0,8z M10,13 10,16z M4,8 a6,8 0 0,1 12,0" />
          </svg>
           <?php echo form_input($password); ?>
         
        </div>
       <!--  <?php echo form_submit('submit', lang('login_submit_btn'), array('class'=> 'login__submit'));?> -->
            <label class="login__submit">Login</label>
        <p class="login__signup"><?php echo lang('login_heading');?> &nbsp;
          <?php echo lang('login_remember_label', 'remember');?>
          <?php echo form_checkbox('remember', '1', FALSE, 'id="remember"');?>
        </p>
      </div>
    </div>
    <div class="app">
      <div class="app__top">
        <div class="app__menu-btn">
          <span></span>
        </div>
        <svg class="app__icon search svg-icon" viewBox="0 0 20 20">
          <!-- yeap, its purely hardcoded numbers straight from the head :D (same for svg above) -->
          <path d="M20,20 15.36,15.36 a9,9 0 0,1 -12.72,-12.72 a 9,9 0 0,1 12.72,12.72" />
        </svg>
        <p class="app__hello">Login Error!</p>
        <div class="app__user">
         <img src="<?php echo base_url('public/images/profile-512_5.jpg'); ?>" alt="" class="app__user-photo" />
          <span class="app__user-notif">3</span>
        </div>
        <div class="app__month">
          <span class="app__month-btn left"></span>
          <p class="app__month-name">March</p>
          <span class="app__month-btn right"></span>
        </div>
      </div>
      <div class="app__bot">
        <div class="app__days">
          <div class="app__day weekday">Sun</div>
          <div class="app__day weekday">Mon</div>
          <div class="app__day weekday">Tue</div>
          <div class="app__day weekday">Wed</div>
          <div class="app__day weekday">Thu</div>
          <div class="app__day weekday">Fri</div>
          <div class="app__day weekday">Sad</div>
          <div class="app__day date">8</div>
          <div class="app__day date">9</div>
          <div class="app__day date">10</div>
          <div class="app__day date">11</div>
          <div class="app__day date">12</div>
          <div class="app__day date">13</div>
          <div class="app__day date">14</div>
        </div>
        <div class="app__meetings">
          <div class="app__meeting">
            <img src="<?php echo base_url('public/images/profile-80_5.jpg'); ?>" alt="" class="app__meeting-photo" />
            <p class="app__meeting-name">Feed the cat</p>
            <p class="app__meeting-info">
              <span class="app__meeting-time">8 - 10am</span>
              <span class="app__meeting-place">Real-life</span>
            </p>
          </div>
          <div class="app__meeting">
            <img src="<?php echo base_url('public/images/profile-512_5.jpg'); ?>" alt="" class="app__meeting-photo" />
            <p class="app__meeting-name">Feed the cat!</p>
            <p class="app__meeting-info">
              <span class="app__meeting-time">1 - 3pm</span>
              <span class="app__meeting-place">Real-life</span>
            </p>
          </div>
          <div class="app__meeting">
            <img src="<?php echo base_url('public/images/profile-512_5.jpg'); ?>" alt="" class="app__meeting-photo" />
            <p class="app__meeting-name">FEED THIS CAT ALREADY!!!</p>
            <p class="app__meeting-info">
              <span class="app__meeting-time">This button is just for demo ></span>
            </p>
          </div>
        </div>
      </div>
      <div class="app__logout">
        <svg class="app__logout-icon svg-icon" viewBox="0 0 20 20">
          <path d="M6,3 a8,8 0 1,0 8,0 M10,0 10,12"/>
        </svg>
      </div>
    </div>
  </div>
</div>
  </body>
</html>
<script type="text/javascript">


  var animating = false,
      submitPhase1 = 1100,
      submitPhase2 = 400,
      logoutPhase1 = 800,
      $login = $(".login"),
      $app = $(".app");
  
  function ripple(elem, e) {
    $(".ripple").remove();
    var elTop = elem.offset().top,
        elLeft = elem.offset().left,
        x = e.pageX - elLeft,
        y = e.pageY - elTop;
    var $ripple = $("<div class='ripple'></div>");
    $ripple.css({top: y, left: x});
    elem.append($ripple);
  };
  
  $(document).on("click", ".login__submit", function(e) {
    // if (animating) return;
    // animating = true;
    // var that = this;
    // ripple($(that), e);
    // $(that).addClass("processing");
    // setTimeout(function() {
    //   $(that).addClass("success");
    //   setTimeout(function() {
    //      $app.show();
    //     $app.css("top");
    //     $app.addClass("active");
    //   }, submitPhase2 - 70);
    //   setTimeout(function() {
    //     $login.hide();
    //      $login.addClass("inactive");
    //     animating = false;
    //     $(that).removeClass("success processing");
    //   }, submitPhase2);
    // }, submitPhase1);
  });
  

  


    $('.login__submit').on('click', function(e){
      var animating = false,
      submitPhase1 = 1100,
      submitPhase2 = 400,
      logoutPhase1 = 800,
      $login = $(".login"),
      $app = $(".app");

      function ripple(elem, e) {
    $(".ripple").remove();
    var elTop = elem.offset().top,
        elLeft = elem.offset().left,
        x = e.pageX - elLeft,
        y = e.pageY - elTop;
    var $ripple = $("<div class='ripple'></div>");
    $ripple.css({top: y, left: x});
    elem.append($ripple);
  };


      var identity = $('#identity').val();
      var password = $('#password').val();
  $.ajax({
      url: '<?php echo base_url('common/login/login'); ?>',
      type: 'post',
      data: {identity: identity, password: password},
      cache: false,
      success: function(json) {
        if (json == 'ok') {
         setTimeout(function(){
         window.location.href = window.location.href;
         },2000);

        } else {
           $app.show();
        $app.css("top");
        $app.addClass("active");
        $login.hide();
         $login.addClass("inactive");
        animating = false;
          // $('.ajax-content').html('<div class="alert alert-success">' + '</div>');
        }
     
      }
  });
  e.preventDefault();
});

$(document).ajaxStart(function(){
  Pace.restart();
});
$('.login__submit').click(function(){
      $.ajax({
        url: '<?php echo base_url('common/login/login'); ?>',
        success: function(result) {
          // $('.ajax-content').html('<hr>Ajax Request Completed !');
        }
      });
});
  $(document).on("click", ".app__logout", function(e) {
    if (animating) return;
    $(".ripple").remove();
    animating = true;
    var that = this;
    $(that).addClass("clicked");
    setTimeout(function() {
      $app.removeClass("active");
      $login.show();
      $login.css("top");
       $login.removeClass("inactive");
    }, logoutPhase1 - 120);
    setTimeout(function() {
      $app.hide();
      animating = false;
      $(that).removeClass("clicked");
    }, logoutPhase1);
  });
</script>