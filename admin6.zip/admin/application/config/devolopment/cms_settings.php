<?php 
$config['cms_title']  = 'cms setting';
$config['cms_dev']  = 'votuananh8127@gmail.com';
