<?php 
class User extends CI_Model{
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	public function index(){

	}
	public function login($query = array()){

		$data = array(
			'email' => $query['email'],
			'password' => md5($query['password']),
			);
		return $this->db->get_where('ci_user', $data)->row_array();
	}
	public function logOut(){
		$this->session->session_destroy();
		
	}
}