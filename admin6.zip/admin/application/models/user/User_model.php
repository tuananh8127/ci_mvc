<?php 
class User_model extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	public function getUsers(){
		$query = $this->db->get('ci_user');
		return $query->result_array();
	}	
	public function getTotalUser(){
		$query = $this->db->get('ci_user');
		return $query->num_nows(); 
	}
	public function adUsers($data){
		$this->db->insert('ci_user', $data);	
	}
///show user id
	function show_users(){
		$query = $this->db->get('ci_user');
		$query_result = $query->result();
		return $query_result;
		}
		// Function To Fetch Selected Student Record
		function show_users_id($data){
		$this->db->select('*');
		$this->db->from('ci_user');
		$this->db->where('user_id', $data);
		$query = $this->db->get();
		$result = $query->result();
		return $result;
		}
		// Update Query For Selected Student
		function update_users_id1($id,$data){
		$this->db->where('user_id', $id);
		$this->db->update('ci_user', $data);
		}
}