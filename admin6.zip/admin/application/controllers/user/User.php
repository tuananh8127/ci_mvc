<?php 
class User extends MY_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->library('ion_auth');
	}
	public function index(){

		

	}
	public function login(){

		$data['heading_title'] = 'User';
		if($this->input->post()){
			redirect('common/dashboard');

		} 
		$this->load->helper('form');
		$this->render('common/login', $data);

	}
	public function logOut(){

	}
}