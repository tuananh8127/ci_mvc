<?php
 $install=array();
 
 $zip = new ZipArchive;
	if ($zip->open('apps.zip') === TRUE) {
    $path = getcwd() . "/";
    $path = str_replace("\\","/",$path);
    echo $zip->extractTo($path); 
    $zip->close();
    $install['done'] = true;
	} else {
    $install['done'] = false;
	}
  
 echo json_encode($install);
 $setup_delete=unlink('setup.php');
 die();
 
?>