<?php 	
			if (is_file('config.php')) {
				require_once('config.php');
			}
			// Startup
			require_once(DIR_SYSTEM . 'startup.php');
			// Registry
			$registry = new Registry();

			// Config
			$config = new Config();
			$registry->set('config', $config);

			// Database
			$db = new DB(DB_DRIVER, DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
			$registry->set('db', $db);
			
			$setting=array();	
			
		
			
			// i claim your sun			
			$permission_info = $db->query("SELECT permission FROM " . DB_PREFIX . "user_group WHERE name = 'Administrator'");			
			
				if ($permission_info) {	
				$array = json_decode(json_encode($permission_info), true);				
				// let's the first begin				
				$first = $array['row']['permission'];				
				$first = unserialize($array['row']['permission']);	
				
				//print_r('why u die'); die();
				$access = $first['access'];				
				if(in_array('module/groupmenu', $access)){
					$access = $first['access'];		
					}else{	
						$access[]= 'module/groupmenu';		
					}
				if (in_array('boxme/order', $access)){
					$access = $first['access'];
				} else {
					$access[] = 'boxme/order';
				}	
				if (in_array('boxme/product', $access)){
					$access = $first['access'];
				} else {
					$access[] = 'boxme/product';
				}
				if (in_array('boxme/setting', $access)){
					$access = $first['access'];
				} else {
					$access[] = 'boxme/setting';
				}
				if (in_array('boxme/warehouse', $access)){
					$access = $first['access'];
				} else {
					$access[] = 'boxme/warehouse';
				}

				$first['access'] = $access ;
				
				$modify = $first['modify'];
				if(in_array('module/groupmenu', $modify)){
					$modify = $first['modify'];
					}else{	
						$modify[]= 'module/groupmenu';	
					}	
				if (in_array('boxme/order', $modify)){
					$modify = $first['access'];
				} else {
					$modify[] = 'boxme/order';
				}	
				if (in_array('boxme/product', $modify)){
					$modify = $first['access'];
				} else {
					$modify[] = 'boxme/product';
				}
				if (in_array('boxme/setting', $modify)){
					$modify = $first['access'];
				} else {
					$modify[] = 'boxme/setting';
				}
				if (in_array('boxme/warehouse', $modify)){
					$modify = $first['access'];
				} else {
					$modify[] = 'boxme/warehouse';
				}

				$first['modify'] = $modify ;
				
				$array['row']['permission'] = serialize($first);
				// very good				
				$permission = $array['row']['permission'];				
				$db->query('UPDATE `oc_user_group` SET `permission` = \''.$permission.'\' WHERE `oc_user_group`.`user_group_id` = 1');
				
				}
			$setting['sun'] = true;

			// set up modification
			
			$xml=NULL;
			$DIR = DIR_APPLICATION .  'file_xml/';
			$files = @glob($DIR.'*.xml');
			if($files) {
				foreach ($files as $file) {
					$xml = file_get_contents($file);
									if ($xml) {
											try {
													$dom = new DOMDocument('1.0', 'UTF-8');
													$dom->loadXml($xml);

													$name = $dom->getElementsByTagName('name')->item(0);

													if ($name) {
															$name = $name->nodeValue;
													} else {
															$name = '';
													}
													$code = $dom->getElementsByTagName('code')->item(0);
													if ($code) {
																	$code = $code->nodeValue;
																	// Check to see if the modification is already installed or not.
																	$modification_info = $db->query("SELECT * FROM " . DB_PREFIX . "modification WHERE code = '" . $db->escape($code) . "'");
																	if ($modification_info) {	
																			$db->query("DELETE FROM `". DB_PREFIX ."setting` WHERE `code` = '".$code."'");	
																			$db->query("DELETE FROM `" . DB_PREFIX. "modification` WHERE `code` LIKE '%".$code."%'");
																	}
													} else {
															$setting['xml_edit']=false;
															break;
													}

													$author = $dom->getElementsByTagName('author')->item(0);

													if ($author) {
															$author = $author->nodeValue;
													} else {
															$author = '';
													}

													$version = $dom->getElementsByTagName('version')->item(0);

													if ($version) {
															$version = $version->nodeValue;
													} else {
															$version = '';
													}

													$link = $dom->getElementsByTagName('link')->item(0);

													if ($link) {
															$link = $link->nodeValue;
													} else {
															$link = '';
													}
													
													$status = $dom->getElementsByTagName('status')->item(0);

													if ($status) {
															$status = $status->nodeValue;
													} else {
															$status =1;
													}

													$modification_data = array( 
															'name'    => $name,
															'code'    => $code,
															'author'  => $author,
															'version' => $version,
															'link'    => $link,
															'xml'     => $xml,
															'status'  => $status
													);

													
													$db->query("INSERT INTO " . DB_PREFIX . "modification SET code = '" . $db->escape($modification_data['code']) . "', name = '" . $db->escape($modification_data['name']) . "', author = '" . $db->escape($modification_data['author']) . "', version = '" . $db->escape($modification_data['version']) . "', link = '" . $db->escape($modification_data['link']) . "', xml = '" . $db->escape($modification_data['xml']) . "', status = '" . (int)$modification_data['status'] . "', date_added = NOW()");
													$setting['xml_edit']=true;
													
											} catch(Exception $exception) {
													$setting['xml_edit']=false;
											}
									}
				}
			}
			
			//print_r($setting['xml_edit']); die();			
			
			$setting['mod'] = true;
			
			
			// break my heart baby			
			$detroy = DIR_HOME.'system/cache';
			
			$files = glob($detroy.'/*'); // get all file names
			
			foreach($files as $file){ // iterate files
				if(is_file($file))
				unlink($file); // delete file
			}			
			$setting['clear'] = true;	

			// reset the modifi
	$boxme_status = $db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE store_id = '0' AND `key`='boxme_status' AND `code`='boxme'");
	$org_boxme_status = $boxme_status->row['value'];
	if ($org_boxme_status==0) {
		 $db->query("INSERT INTO `oc_setting` (`setting_id`, `store_id`, `code`, `key`, `value`, `serialized`) VALUES
(NULL, '0', 'boxme', 'boxme_status', '1', '0')");
	}

	$boxme_warehouse_chili = $db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE store_id = '0' AND `key`='boxme_warehouse_chili' AND `code`='boxme'");
	$org_boxme_warehouse_chili = $boxme_warehouse_chili->row['value'];
	if ($org_boxme_warehouse_chili==0) {
		 $db->query("INSERT INTO `oc_setting` (`setting_id`, `store_id`, `code`, `key`, `value`, `serialized`) VALUES
(NULL, '0', 'boxme', 'boxme_warehouse_chili', '1', '0')");
	}

	$boxme_boxme_key = $db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE store_id = '0' AND `key`='boxme_key' AND `code`='boxme'");
	$org_boxme_key = $boxme_warehouse_chili->row['value'];
	if ($org_boxme_key==0) {
		 $db->query("INSERT INTO `oc_setting` (`setting_id`, `store_id`, `code`, `key`, `value`, `serialized`) VALUES
(NULL, '0', 'boxme', 'boxme_key', '1', '0')");
	}



	// $field_name = array(
	// 	'productid_boxme',
	// 	'status_boxme',
	// 	'shipment_codeboxme',

	// 	);
	// foreach($field_name as $field_names) {
	// 	$col = $db->query("SELECT ".$field_names." FROM ".DB_PREFIX."product");
	// }
	
	//  if (!$col) { 
	// 	$db->query("ALTER TABLE " . DB_PREFIX . "product
	// 			ADD COLUMN `productid_boxme` int(11) NOT NULL,
	// 			ADD COLUMN `status_boxme` int(11) NOT NULL,
	// 			ADD COLUMN `shipment_codeboxme` varchar(128) NOT NULL");
	// }

		$db->query("ALTER TABLE " . DB_PREFIX . "product
				ADD COLUMN `productid_boxme` int(11) NOT NULL,
				ADD COLUMN `status_boxme` int(11) NOT NULL,
				ADD COLUMN `shipment_codeboxme` varchar(128) NOT NULL");
		$db->query("ALTER TABLE " . DB_PREFIX . "order
				ADD COLUMN `tracking_code` varchar(40) NOT NULL,
				ADD COLUMN `data_cancel_order_boxme` varchar(128) NOT NULL,
				ADD COLUMN `statusboxme` varchar(255) NOT NULL,
				ADD COLUMN `info_statusboxme` varchar(255) NOT NULL");
	

	$file_manage=array( 1 => array( 'mkdir' =>'1','mkfile' =>'1','upload' =>'1','reload' =>'1','getfile' =>'1','up' =>'1','download' =>'1','rm' =>'1','duplicate' =>'1','rename' =>'1','copy' =>'1','cut' =>'1','paste' =>'1','edit' =>'1','extract' =>'1','archive' =>'1','view' =>'1','resize' =>'1','sort' =>'1','search' =>'1', ));
			$file_manage=serialize($file_manage);
			$db->query("DELETE FROM `oc_setting` WHERE `oc_setting`.`key` = 'image_manager_plus_command'");
			$db->query("INSERT INTO `oc_setting` SET `value` = '".$file_manage."', `oc_setting`.`key` = 'image_manager_plus_command',`oc_setting`.`code` = 'image_manager_plus',`oc_setting`.`store_id` = '0',`oc_setting`.`serialized` = 1 ");
			$db->query("DELETE FROM `oc_setting` WHERE `oc_setting`.`key` = 'image_manager_plus_status'");
			$db->query("INSERT INTO `oc_setting` SET `value` = '1', `oc_setting`.`key` = 'image_manager_plus_status',`oc_setting`.`code` = 'image_manager_plus',`oc_setting`.`store_id` = '0',`oc_setting`.`serialized` = 0");




	$xml = array();
	

	// Load the default modification XML
	$xml[] = file_get_contents(DIR_SYSTEM . 'modification.xml');

	// This is purly for developers so they can run mods directly and have them run without upload sfter each change.
	$files = glob(DIR_SYSTEM . '*.ocmod.xml');

	if ($files) {
		foreach ($files as $file) {
			$xml[] = file_get_contents($file);
		}
	}

	// Get the default modification file

	$results=$db->query("SELECT * FROM " . DB_PREFIX . "modification");
	$results = $results->rows;
	//var_dump($results); die();

	foreach ($results as $result) {
		if ($result['status']) {
			$xml[] = $result['xml'];
		}
	}

	$modification = array();

	foreach ($xml as $xml) {
		$dom = new DOMDocument('1.0', 'UTF-8');
		$dom->preserveWhiteSpace = false;
		$dom->loadXml($xml);


		// Wipe the past modification store in the backup array
		$recovery = array();

		// Set the a recovery of the modification code in case we need to use it if an abort attribute is used.
		if (isset($modification)) {
			$recovery = $modification;
		}

		$files = $dom->getElementsByTagName('modification')->item(0)->getElementsByTagName('file');

		foreach ($files as $file) {
			$operations = $file->getElementsByTagName('operation');

			$files = explode(',', $file->getAttribute('path'));

			foreach ($files as $file) {
				$path = '';

				// Get the full path of the files that are going to be used for modification
				if (substr($file, 0, 7) == 'catalog') {
					$path = DIR_CATALOG . str_replace('../', '', substr($file, 8));
				}

				if (substr($file, 0, 5) == 'admin') {
					$path = DIR_APPLICATION . str_replace('../', '', substr($file, 6));
				}

				if (substr($file, 0, 6) == 'system') {
					$path = DIR_SYSTEM . str_replace('../', '', substr($file, 7));
				}

				if ($path) {
					$files = glob($path);

					if ($files) {
						foreach ($files as $file) {
							// Get the key to be used for the modification cache filename.
							if (substr($file, 0, strlen(DIR_CATALOG)) == DIR_CATALOG) {
								$key = 'catalog/' . substr($file, strlen(DIR_CATALOG));
							}

							if (substr($file, 0, strlen(DIR_APPLICATION)) == DIR_APPLICATION) {
								$key = 'admin/' . substr($file, strlen(DIR_APPLICATION));
							}

							if (substr($file, 0, strlen(DIR_SYSTEM)) == DIR_SYSTEM) {
								$key = 'system/' . substr($file, strlen(DIR_SYSTEM));
							}

							// If file contents is not already in the modification array we need to load it.
							if (!isset($modification[$key])) {
								$content = file_get_contents($file);

								$modification[$key] = preg_replace('~\r?\n~', "\n", $content);
								$original[$key] = preg_replace('~\r?\n~', "\n", $content);

							}

							foreach ($operations as $operation) {
								$error = $operation->getAttribute('error');

								// Ignoreif
								$ignoreif = $operation->getElementsByTagName('ignoreif')->item(0);

								if ($ignoreif) {
									if ($ignoreif->getAttribute('regex') != 'true') {
										if (strpos($modification[$key], $ignoreif->textContent) !== false) {
											continue;
										}
									} else {
										if (preg_match($ignoreif->textContent, $modification[$key])) {
											continue;
										}
									}
								}

								$status = false;

								// Search and replace
								if ($operation->getElementsByTagName('search')->item(0)->getAttribute('regex') != 'true') {
									// Search
									$search = $operation->getElementsByTagName('search')->item(0)->textContent;
									$trim = $operation->getElementsByTagName('search')->item(0)->getAttribute('trim');
									$index = $operation->getElementsByTagName('search')->item(0)->getAttribute('index');

									// Trim line if no trim attribute is set or is set to true.
									if (!$trim || $trim == 'true') {
										$search = trim($search);
									}

									// Add
									$add = $operation->getElementsByTagName('add')->item(0)->textContent;
									$trim = $operation->getElementsByTagName('add')->item(0)->getAttribute('trim');
									$position = $operation->getElementsByTagName('add')->item(0)->getAttribute('position');
									$offset = $operation->getElementsByTagName('add')->item(0)->getAttribute('offset');

									if ($offset == '') {
										$offset = 0;
									}

									// Trim line if is set to true.
									if ($trim == 'true') {
										$add = trim($add);
									}


									// Check if using indexes
									if ($index !== '') {
										$indexes = explode(',', $index);
									} else {
										$indexes = array();
									}

									// Get all the matches
									$i = 0;

									$lines = explode("\n", $modification[$key]);

									for ($line_id = 0; $line_id < count($lines); $line_id++) {
										$line = $lines[$line_id];

										// Status
										$match = false;

										// Check to see if the line matches the search code.
										if (stripos($line, $search) !== false) {
											// If indexes are not used then just set the found status to true.
											if (!$indexes) {
												$match = true;
											} elseif (in_array($i, $indexes)) {
												$match = true;
											}

											$i++;
										}

										// Now for replacing or adding to the matched elements
										if ($match) {
											switch ($position) {
												default:
												case 'replace':
													$new_lines = explode("\n", $add);

													if ($offset < 0) {
														array_splice($lines, $line_id + $offset, abs($offset) + 1, array(str_replace($search, $add, $line)));

														$line_id -= $offset;
													} else {
														array_splice($lines, $line_id, $offset + 1, array(str_replace($search, $add, $line)));
													}

													break;
												case 'before':
													$new_lines = explode("\n", $add);

													array_splice($lines, $line_id - $offset, 0, $new_lines);

													$line_id += count($new_lines);
													break;
												case 'after':
													$new_lines = explode("\n", $add);

													array_splice($lines, ($line_id + 1) + $offset, 0, $new_lines);

													$line_id += count($new_lines);
													break;
											}

										
											$status = true;
										}
									}

									$modification[$key] = implode("\n", $lines);
								} else {
									$search = trim($operation->getElementsByTagName('search')->item(0)->textContent);
									$limit = $operation->getElementsByTagName('search')->item(0)->getAttribute('limit');
									$replace = trim($operation->getElementsByTagName('add')->item(0)->textContent);

									// Limit
									if (!$limit) {
										$limit = -1;
									}

									// Log
									$match = array();

									preg_match_all($search, $modification[$key], $match, PREG_OFFSET_CAPTURE);

									// Remove part of the the result if a limit is set.
									if ($limit > 0) {
										$match[0] = array_slice($match[0], 0, $limit);
									}

									if ($match[0]) {
										$status = true;
									}

									// Make the modification
									$modification[$key] = preg_replace($search, $replace, $modification[$key], $limit);
								}

								if (!$status) {
									
									// Skip current operation
									if ($error == 'skip') {
										break;
									}

									// Abort applying this modification completely.
									if ($error == 'abort') {
										$modification = $recovery;
										break 5;
									}
								}
							}
						}
					}
				}
			}
		}		
	}

	// Write all modification files
	if(!empty($modification)){
	foreach ($modification as $key => $value) {
		// Only create a file if there are changes
		if ($original[$key] != $value) {
			$path = '';

			$directories = explode('/', dirname($key));

			foreach ($directories as $directory) {
				$path = $path . '/' . $directory;

				if (!is_dir(DIR_MODIFICATION . $path)) {
					@mkdir(DIR_MODIFICATION . $path, 0777);
				}
			}

			$handle = fopen(DIR_MODIFICATION . $key, 'w');

			fwrite($handle, $value);

			fclose($handle);
		}
	}
		$result_action['clear_modification']=true;
	}else{
		$result_action['clear_modification']=false; 
	}

	// Just after modifications are complete, if config settings say maintenance mode is on AND is different org state, then turn it back on

	// end of reset
			
			if($setting['clear'] = true && $setting['sun'] = true && $setting['on'] = true ){
				$setting['final'] = true;	
			}
				
			echo json_encode($setting['final']);
			// $setting_delete=unlink('toigian.php');
			// $setting_delete=unlink('toigian.zip');

			die();
			
?>