<?php
$_['heading_title']="Chili dashboard";
$_['text_infomation']="Information Services";
$_['text_limit_data']="Limit Data";

$_['text_limit_data_max']="Max Limit";
$_['text_limit_data_use']="Using";
$_['text_limit_data_remaining']="Remaining";
$_['text_info_start']="Start Day";
$_['text_info_use']="Use Day";
$_['text_info_end']="End Day";
$_['text_upgrade_now']="Upgrade now";
$_['text_extend']="Extend Service";
$_['text_emtry']="No data";

$_['text_app_need']="Can to need apps";