<?php
// Heading
$_['heading_title']       = 'Thay đổi ngôn ngữ';
$_['text_edit']       = 'Chỉnh sửa trạng thái thay đổi ngôn ngữ';
// Text
$_['text_module']         = 'Chức năng';
$_['text_success']        = 'Thành công:Bạn đã sửa đổi thành công';


$_['entry_status']        = 'Trạng thái:'; 

// Error
$_['error_permission']    = 'Cảnh báo: bạn không có quyền chỉnh sửa';
?>