<?php
// Heading
$_['heading_title']       = 'Logo';
$_['text_edit']       = 'Edit status';
// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'success';

$_['error_image']        = 'Plase link for logo';
$_['entry_image']        = 'Logo';
$_['entry_name']         = 'Enter logo name';
$_['error_name']        = 'form 3 -> 64';
$_['error_size']        = 'Enter width and height';


$_['entry_size_default']        = 'Default of logo';
$_['entry_size_user']        = 'User';
$_['entry_size']        = 'Option logo size';


$_['entry_status']        = 'status:';
$_['entry_width']        = 'Width:';
$_['entry_height']        = 'Height:';
$_['entry_show_text']        = 'Show name and description of shop';
$_['entry_show']        = 'Show';
$_['entry_hidden']        = 'Not show';

// Error
$_['error_permission']    = 'Warning: not permission';
?>