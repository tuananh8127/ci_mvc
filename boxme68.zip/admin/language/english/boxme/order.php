<?php
// Heading
$_['heading_title']         = 'Boxme Order Management';

// Text
$_['text_add']                 = 'Add new order';
$_['text_create_order']                 = 'Create Boxme Orders';
$_['text_back']                 = 'Return';

$_['text_form']                 = 'Sender information';
$_['text_toboxme']                 = 'Receiver"s information';
$_['text_items']                 = 'Products';
$_['text_orders']                 = 'Information order';
$_['text_config']                 = 'Configure Boxme';

$_['text_domain']                 = 'Website Path';
$_['text_city']                 = 'City';
$_['text_province']                 = 'District';
$_['text_ward']                 = 'Wards';
$_['text_stock']                 = 'Warehouse address';
$_['text_address']                 = 'Address';
$_['text_example_address']                 = 'Sender address eg number 123 - Alley 231 - Nguyen Phong Den';
$_['text_phone']                 = 'Phone number of the sender';
$_['text_name']                 = 'Sender"s name';
$_['text_trackingcode']                 = 'Boxme order code';
$_['text_domain']                 = 'Sender information';
$_['text_city']                 = 'Receiver"s information';
$_['text_province']                 = 'Products';
$_['text_ward']                 = 'Order info';
$_['text_stock']                 = 'Configure the Boxme Order Method';
$_['text_countryboxme']                 = 'Coutry';

$_['text_nameproduct']                 = 'Name product';
$_['text_price']                 = 'Price';
$_['text_quantity']                 = 'Number';
$_['text_weight']                 = 'Weight';
$_['text_sku']                 = 'Sku code';
$_['text_collect']                 = 'Total order amount';
$_['text_nameorder']                 = 'Order name';

$_['text_service']                 = 'Boxme Delivery Service';
$_['text_protected']                 = 'Cargo insurance';
$_['text_checking']                 = 'Show customers';
$_['text_fragile']                 = 'Commodities';
$_['text_cod']                 = 'Delivery of money (COD)';
$_['text_payment']                 = 'Payment options';
$_['text_autoaccept']                 = 'Create an order with an available balance';

$_['text_fatslow']                 = 'Slow delivery';
$_['text_fast']                 = 'Express
';
$_['text_yes']                 = 'Yes';
$_['text_no']                 = 'No';
$_['text_normal']                 = 'Normal goods';
$_['text_fragile']                 = 'Fragile
';
$_['text_customerpay']                 = 'Paid customers (Only available if needed)';
$_['text_impay']                 = 'I pay a fee';
$_['text_dontapproval']                 = 'Create an order that has not yet been approved';
$_['text_approval']                 = 'Browse orders as soon as the balance in the account';





