<?php
// Heading
$_['heading_title']    = 'Boxme storage system';
$_['text_config']    = 'Configure access :';
$_['text_select_warehouse'] = 'Select your warehouse';
$_['text_warehouseshop'] = 'Your warehouse';
$_['text_warehouseboxme'] = 'Boxmes warehouse';
$_['text_selectdefault'] = 'The default store you are selecting';
$_['text_functional'] = 'Configuration function:';
$_['text_warehousedefault'] = 'The default store you are selecting';
$_['text_object']      = 'Warehouse Boxme';
$_['text_edit']      = 'Set up boxme';
$_['text_success']     = 'Success: You have modified the account functionality!';
$_['text_savesuccess']     = 'Information saved successfully!';
$_['text_validation']     = 'Please check the missing information!';
// Entry
$_['entry_status']     = 'Status';
$_['entry_key']     = 'Api Key';

// Error
$_['error_permission'] = 'Warning: You do not have permission to edit account functionality!';
$_['text_none'] = 'Choose';
$_['text_errorkey'] = 'Boxme Warehouse API Error, Please check the key code or technical contact CHILI - Sorry for the inconvenience.';
$_['text_city'] = 'City';
$_['text_code'] = 'Code';
$_['text_wareHous'] = 'Name';
$_['text_district'] = 'District';
$_['text_phone'] = 'Phone';
$_['text_inventoryid'] = 'InventoryId';
$_['text_addressLine'] = 'AddressLine';
$_['text_type'] = 'Type';
$_['text_infoboxme'] = 'Boxme address information';
$_['text_infoyour'] = 'Update your warehouse address';
$_['text_createwarehous'] = 'Create your server';
$_['text_namewarehous'] = 'Treasure Name';
$_['text_username'] = 'Username';
$_['text_phone'] = 'Phone';
$_['text_city'] = 'City Province';
$_['text_district'] = 'District';
$_['text_ward'] = 'Ward';
$_['text_address'] = 'Address';