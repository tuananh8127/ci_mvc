<?php
// Heading
$_['heading_title']    = 'Bản điều khiển hệ thống kho Boxme';

$_['text_object']      = 'Kho Boxme';
$_['text_edit']      = 'Thiết lập boxme';
$_['text_success']     = 'Thành công: BẠn đã chỉnh sửa chức năng tài khoản!';

// Entry
$_['entry_status']     = 'Trạng thái';
$_['entry_key']     = 'Api Key';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền chỉnh sửa chức năng tài khoản!';