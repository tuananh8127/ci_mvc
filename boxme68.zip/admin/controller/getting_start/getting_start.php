<?php
class ControllerGettingStartGettingStart extends Controller {
	private $error = array();
        public function index() {
            $this->load->language('getting_start/getting_start');
            $this->document->addStyle('view/stylesheet/getting_start/stylesheet/style.css');
            $data["token"]=$this->session->data['token'];
            $data["step_1"]=$this->language->get('step_1');
            $data["step_2"]=$this->language->get('step_2');
            $data["step_3"]=$this->language->get('step_3');
            $data["step_4"]=$this->language->get('step_4');

            $data["text_title_main_basic_info"]=$this->language->get('text_title_main_basic_info');

            $data["text_title_basic_info"] = $this->language->get('text_title_main_basic_info');
            $data["link_post_info"] = $this->url->link('catalog/information', 'token=' . $this->session->data['token'], 'SSL');
            $data["link_add_product"] = $this->url->link('catalog/product/add', 'token=' . $this->session->data['token'], 'SSL');
            $data["link_list_product"] = $this->url->link('catalog/product', 'token=' . $this->session->data['token'], 'SSL');
            
            
			
            $data['header']  					 = $this->load->controller('common/header');
            $data['column_left']				= $this->load->controller('common/column_left');
            $data['footer']					 = $this->load->controller('common/footer');
            $this->response->setOutput($this->load->view('getting_start/getting_start.tpl', $data));
        }
}