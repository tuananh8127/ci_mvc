<?php
class ControllerModuleModuleCol extends Controller {
	private $error = array();
	public function index() {
		$this->load->language('module/module_col');

		$this->document->setTitle("Dv-Builder");

		$this->load->model('extension/module');

		$this->document->addScript('view/javascript/dv-builder/jquery-ui.js');
		$this->document->addStyle('view/stylesheet/dv-builder/dv-builder.css');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			if (!isset($this->request->get['module_id'])) {
				$id_module=$this->model_extension_module->addModule('module_col', $this->request->post);
			} else {
				$id_module=$this->model_extension_module->editModule($this->request->get['module_id'], $this->request->post);
			}
                        $all_module_child=$this->model_extension_module->getModulesByCode("module_col");
                        $module_child_current=array('module_id'=>0);
                        foreach ($all_module_child as $key_module_child=>$item_module_child){
                            if($module_child_current['module_id']<$item_module_child['module_id'])
                                    $module_child_current=$item_module_child;
                        }
                        if(!empty($this->request->get['module_id']))
                            $module_child_current['module_id']=$this->request->get["module_id"];
			$this->session->data['success']= $this->language->get('text_success');
			$this->response->redirect($this->url->link('module/module_col', 'token=' . $this->session->data['token']."&module_id=".$module_child_current['module_id'], 'SSL'));
		}
                if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');

		$data['entry_title'] = $this->language->get('entry_title');
		$data['entry_title_show'] = $this->language->get('entry_title_show');
		$data['entry_show'] = $this->language->get('entry_show');
		$data['entry_hide'] = $this->language->get('entry_hide');
		$data['entry_edit_module_custom'] = $this->language->get('entry_edit_module_custom');
		$data['entry_alert_choose_col'] = $this->language->get('entry_alert_choose_col');
		$data['entry_alert_input_col'] = $this->language->get('entry_alert_input_col');
		$data['entry_add'] = $this->language->get('entry_add');
		$data['entry_status'] = $this->language->get('entry_status');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['entry_module'] = $this->language->get('entry_module');
		$data['entry_class'] = $this->language->get('entry_class');
		$data['entry_class_placehoder'] = $this->language->get('entry_class_placehoder');
		$data['entry_class_des'] = $this->language->get('entry_class_des');
		$data['entry_title_bootstrap_des'] = $this->language->get('entry_title_bootstrap_des');
		$data['entry_title_bootstrap'] = $this->language->get('entry_title_bootstrap');
		$data['entry_hide_show'] = $this->language->get('entry_hide_show');
		$data['entry_active'] = $this->language->get('entry_active');
		$data['entry_full'] = $this->language->get('entry_full');
		$data['entry_not_full'] = $this->language->get('entry_not_full');
		$data['entry_title_full'] = $this->language->get('entry_title_full');
		$data['entry_id_dv'] = $this->language->get('entry_id_dv');
		$data['entry_id_placehoder'] = $this->language->get('entry_id_placehoder');
		$data['text_module'] = $this->language->get('text_module');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}
                
		if (isset($this->error['module'])) {
			$data['error_module'] = $this->error['module'];
		} else {
			$data['error_module'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_module'),
			'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
		);

		if (!isset($this->request->get['module_id'])) {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('module/module_col', 'token=' . $this->session->data['token'], 'SSL')
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('module/module_col', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], 'SSL')
			);
		}

		if (!isset($this->request->get['module_id'])) {
			$data['action'] = $this->url->link('module/module_col', 'token=' . $this->session->data['token'], 'SSL');
		} else {
			$data['action'] = $this->url->link('module/module_col', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], 'SSL');
		}

		$data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

		if (isset($this->request->get['module_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$module_info = $this->model_extension_module->getModule($this->request->get['module_id']);
		}

		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($module_info)) {
			$data['name'] = $module_info['name'];
		} else {
			$data['name'] = '';
		}
                
                if (isset($this->request->post['title'])) {
			$data['title'] = $this->request->post['title'];
		} elseif (!empty($module_info)) {
			$data['title'] = $module_info['title'];
		} else {
			$data['title'] = '';
		}
                
                if (isset($this->request->post['class'])) {
			$data['class'] = $this->request->post['class'];
		} elseif (!empty($module_info['class'])) {
			$data['class'] = $module_info['class'];
		} else {
			$data['class'] = '';
		}
                if (isset($this->request->post['id_dv'])) {
			$data['id_dv'] = preg_replace(array("/\s+/","/-+/"),"_", trim($this->request->post['id_dv'])); 
		} elseif (!empty($module_info['id_dv'])) {
			$data['id_dv'] = preg_replace(array("/\s+/","/-+/"),"_", trim($module_info['id_dv']));
		} else {
			$data['id_dv'] = '';
		}
                
                if (isset($this->request->post['col_ms'])) {
			$data['col_ms'] = $this->request->post['col_ms'];
		} elseif (!empty($module_info)) {
			$data['col_ms'] = $module_info['col_ms'];
		} else {
			$data['col_ms'] = 1;
		}
                
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($module_info)) {
			$data['status'] = $module_info['status'];
		} else {
			$data['status'] = '';
		}
		if (isset($this->request->post['width_full'])) {
			$data['width_full'] = $this->request->post['width_full'];
		} elseif (!empty($module_info)) {
			$data['width_full'] = $module_info['width_full'];
		} else {
			$data['width_full'] = 0;
		}
		if (isset($this->request->post['title_show'])) {
			$data['show_title'] = $this->request->post['show_title'];
		} elseif (!empty($module_info)) {
			$data['show_title'] = $module_info['show_title'];
		} else {
			$data['show_title'] = 1;
		}
		if (isset($this->request->post['module'])) {
			$data['module'] = $this->request->post['module'];
		} elseif (!empty($module_info)) {
			$data['module'] = $module_info['module'];
		} else {
			$data['module'] = '';
		}
                $data['modules']=array();
                if(!empty($data['module'])){
                    foreach ($data['module'] as $keys=>$items){
                        $item_setting=explode("quocdvowow",$items);
                        // item_setting[0]: L� s? chi?u r?ng c?a c?t
                        // item_setting[1]: t�n
                        // item_setting[0]: code
                        
                        if(!empty($item_setting) && $item_setting['2']!=1){
                            $data['modules'][$keys][0]=$item_setting[0];
                            $modules_code=explode("quocdvkaka",$item_setting[2]);                            
                            $modules_name=explode("quocdvkaka",$item_setting[1]);
                            foreach($modules_code as $key=>$item_module){
                                $part=explode(".",$item_module);
                                if(isset($part[1])){
                                        $module=$this->model_extension_module->getModule($part[1]);
                                        $data['modules'][$keys][1][$key]=$module['name']; // Name
                                        $data['modules'][$keys][2][$key]=$item_module; // code
                                        $data['modules'][$keys][3][$key]=html_entity_decode($this->url->link('module/'.$part[0], 'token=' . $this->session->data['token']."&module_id=".$part[1], 'SSL'));
                                        $data['modules'][$keys][4][$key]=$module['status']; // Name
                                }
                                else{
                                    $this->load->language('module/' . $item_module);
                                    $data['modules'][$keys][1][$key]=$this->language->get('heading_title'); // Name
                                    $data['modules'][$keys][2][$key]=$item_module; // code
                                    $data['modules'][$keys][3][$key]=  html_entity_decode($this->url->link('module/'.$item_module, 'token=' . $this->session->data['token'], 'SSL'));
                                    $data['modules'][$keys][4][$key]=$this->config->get($item_module . '_status');
                                }
                            }
                        }
                    }
                }
                //var_dump($data['modules']);
                $this->load->model('extension/extension');
                $extensions = $this->model_extension_extension->getInstalled('module');
                $module_data=array();
		$id_module_current=-1;
		if(!empty($this->request->get['module_id']))
                $id_module_current=$this->request->get['module_id'];
                foreach ($extensions as $key_module=>$item_module){
                    $this->load->language('module/' . $item_module);
                    $modules = $this->model_extension_module->getModulesByCode($item_module);
                    $module_child = array();
                    foreach ($modules as $module) {
						if($module['module_id']!=$id_module_current) {
							$module_child[] = array(
									'name' => $module['name'],
									'module' => $item_module . "." . $module['module_id'],
									'edit_link' => $this->url->link('module/'.$item_module, 'token=' . $this->session->data['token']."&module_id=".$module['module_id'], 'SSL')
							);
						}
                    }
                    if (($this->config->has($item_module . '_status') || $module_child) && $item_module!="module_col") {
                    $module_data[]=array(
                        'name'  => $this->language->get('heading_title'),
                        'module'  =>$item_module,
                        'module_child'=>$module_child,
			'edit_link' => $this->url->link('module/'.$item_module, 'token=' . $this->session->data['token'], 'SSL')
                    );
                    }
                }
        $data['module_active']=$module_data;
		$this->load->model('localisation/language');
		$data['languages'] = $this->model_localisation_language->getLanguages();
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('module/module_col.tpl', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'module/module_col')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
                if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 64)) {
                        $this->error['name'] = $this->language->get('error_name');
                }
		if (empty($this->request->post['module'])) {
			$this->error['module'] = $this->language->get('error_module');
		}

		return !$this->error;
	}
}