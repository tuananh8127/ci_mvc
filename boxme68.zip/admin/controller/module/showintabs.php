<?php 
class ControllerModuleShowintabs extends Controller {
	private $error = array(); 

	public function index() {
		$this->load->language('module/showintabs');

		$this->document->setTitle($this->language->get('heading_title'));
		$this->document->addStyle('view/stylesheet/tabs.css');
		$this->document->addScript('view/javascript/jquery/jquery.color-2.1.2.min.js');
		
		$this->load->model('extension/module');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			if (!isset($this->request->get['module_id'])) {
				$this->model_extension_module->addModule('showintabs', $this->request->post['mod_conf']);
			} else {
				$this->model_extension_module->editModule($this->request->get['module_id'], $this->request->post['mod_conf']);
			}
	
			$this->session->data['success'] = $this->language->get('text_success');

			if(isset( $this->request->post['exit'])){
				$this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));
			}else{
				$this->response->redirect($this->url->link('module/showintabs', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'] , 'SSL'));
			}
		}

		//Textos
		$data['heading_title'] = $this->language->get('heading_title');
		$data['heading_title_url'] = $this->language->get('heading_title_url');
		$data['header_tabs'] = $this->language->get('header_tabs');
		
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');

		$data['text_tab'] = $this->language->get('text_tab');

		$data['entry_name'] = $this->language->get('entry_name');
		$data['entry_tabs'] = $this->language->get('entry_tabs');
		$data['entry_limit'] = $this->language->get('entry_limit');
		$data['entry_image'] = $this->language->get('entry_image');
		$data['entry_image_W'] = $this->language->get('entry_image_W');
		$data['entry_image_H'] = $this->language->get('entry_image_H');		
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_width'] = $this->language->get('entry_width');
		$data['entry_height'] = $this->language->get('entry_height');
		$data['entry_carousel'] = $this->language->get('entry_carousel');
		$data['entry_link'] = $this->language->get('entry_link');
		$data['placeholder_type'] = $this->language->get('placeholder_type');
		$data['placeholder_limit'] = $this->language->get('placeholder_limit');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_save_keep'] = $this->language->get('button_save_keep');

		//Comprobacion de errores
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->error['error_name'])) {
			$data['error_name'] = $this->error['error_name'];
		} else {
			$data['error_name'] = '';
		}

		if (isset($this->error['error_width'])) {
			$data['error_width'] = $this->error['error_width'];
		} else {
			$data['error_width'] = '';
		}

		if (isset($this->error['error_height'])) {
			$data['error_height'] = $this->error['error_height'];
		} else {
			$data['error_height'] = '';
		}
		
		if (isset($this->error['error_limit'])) {
			$data['error_limit'] = $this->error['error_limit'];
		} else {
			$data['error_limit'] = '';
		}
		

		//Camino de migas de pan
  		$data['breadcrumbs'] = array();
   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL')
   		);
   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_module'),
			'href'      => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
   		);

   		if (!isset($this->request->get['module_id'])) {
	   		$data['breadcrumbs'][] = array(
	       		'text'      => $this->language->get('heading_title'),
				'href'      => $this->url->link('module/showintabs', 'token=' . $this->session->data['token'], 'SSL')
	   		);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('module/showintabs', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], 'SSL')
			);
		}

		if (!isset($this->request->get['module_id'])) {
			$data['action'] = $this->url->link('module/showintabs', 'token=' . $this->session->data['token'], 'SSL');
		} else {
			$data['action'] = $this->url->link('module/showintabs', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], 'SSL');
		}

				
		//Links y actions
		$data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');
		$data['go_tab'] = $this->url->link('module/showinconfig', 'token=' . $this->session->data['token'], 'SSL');
		$data['token'] = $this->session->data['token'];

		//Datos de configuracion
		$data['module_id'] = 0;

		if (isset($this->request->get['module_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$module_info = $this->model_extension_module->getModule($this->request->get['module_id']);	
		}

		if (isset($this->request->get['module_id'])){
			$data['module_id'] = $this->request->get['module_id'];
		}

		//Seleted tabs
		if (isset($this->request->post['mod_conf']['tabs'])) {
			$data['tabs'] = $this->request->post['mod_conf']['tabs'];
		} elseif (!empty($module_info) && isset($module_info['tabs'])) {
			$data['tabs'] = $module_info['tabs'];
		} else {
			$data['tabs'] = array();
		}

		//Get tabs confg
		$this->load->model('setting/setting');
		$setting = $this->model_setting_setting->getSetting('showinconfig');
		$tab_config = (isset($setting['showinconfig_tab'])) ? $setting['showinconfig_tab'] : array();

		//Array con resultados
		$data['resultArray'] = array();
		$selectedSize = sizeof($data['tabs']);

		//Completamos info de pestañas de cada pestaña
		foreach( $tab_config as $keyTab => $tab ){
			
			$tab_info = array('tab_id' => $keyTab);

			//Preparamos title de pestañas
			if(isset($tab_config[$keyTab]['title'][$this->config->get('config_language_id')]) && $tab_config[$keyTab]['title'][$this->config->get('config_language_id')] != ''){
				$tab_info['tab_title'] = $tab_config[$keyTab]['title'][$this->config->get('config_language_id')];
			}else{
				$tab_info['tab_title'] = $this->language->get('text_tab') . $keyTab . $this->language->get('text_notitle');
			}

			$key = array_search($keyTab, $data['tabs']);

			if($key !== false ){
				$data['resultArray'][$key] = $tab_info;
			}else{
				$data['resultArray'][$selectedSize++] = $tab_info;
			}
		}

		ksort($data['resultArray']);
		//$this->log->write(print_r($data['resultArray'],true));

		if (isset($this->request->post['mod_conf']['name'])) {
			$data['name'] = $this->request->post['mod_conf']['name'];
		} elseif (!empty($module_info)) {
			$data['name'] = $module_info['name'];
		} else {
			$data['name'] = '';
		}

		if (isset($this->request->post['mod_conf']['limit'])) {
			$data['limit'] = $this->request->post['mod_conf']['limit'];
		} elseif (!empty($module_info)) {
			$data['limit'] = $module_info['limit'];
		} else {
			$data['limit'] = '';
		}

		if (isset($this->request->post['mod_conf']['width'])) {
			$data['width'] = $this->request->post['mod_conf']['width'];
		} elseif (!empty($module_info)) {
			$data['width'] = $module_info['width'];
		} else {
			$data['width'] = '';
		}

		if (isset($this->request->post['mod_conf']['height'])) {
			$data['height'] = $this->request->post['mod_conf']['height'];
		} elseif (!empty($module_info)) {
			$data['height'] = $module_info['height'];
		} else {
			$data['height'] = '';
		}

		if (isset($this->request->post['mod_conf']['status'])) {
			$data['status'] = $this->request->post['mod_conf']['status'];
		} elseif (!empty($module_info)) {
			$data['status'] = $module_info['status'];
		} else {
			$data['status'] = '';
		}

		if (isset($this->request->post['mod_conf']['carousel'])) {
			$data['carousel'] = $this->request->post['mod_conf']['carousel'];
		} elseif (!empty($module_info)) {
			$data['carousel'] = $module_info['carousel'];
		} else {
			$data['carousel'] = '';
		}

		if (isset($this->request->post['mod_conf']['show_link'])) {
			$data['show_link'] = $this->request->post['mod_conf']['show_link'];
		} elseif (!empty($module_info)) {
			$data['show_link'] = $module_info['show_link'];
		} else {
			$data['show_link'] = '';
		}

		//idiomas
		$this->load->model('localisation/language');
		
		$data['languages'] = $this->model_localisation_language->getLanguages();

		//idioma del admin
		$data['language_admin_id']  = $this->config->get('config_language_id');

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('module/showintabs.tpl', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'module/showintabs')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ( !isset($this->request->post['mod_conf']['name']) || (utf8_strlen($this->request->post['mod_conf']['name']) < 3) || (utf8_strlen($this->request->post['mod_conf']['name']) > 64)) {
			$this->error['error_name'] = $this->language->get('error_name');
		}

		if ( !$this->request->post['mod_conf']['width']) {
			$this->error['error_width'] = $this->language->get('error_width');
		}

		if ( !$this->request->post['mod_conf']['height']) {
			$this->error['error_height'] = $this->language->get('error_height');
		}

		if ( !$this->request->post['mod_conf']['limit']) {
			$this->error['error_limit'] = $this->language->get('error_limit');
		}

		return !$this->error;
	}

	public function uninstall(){
		//Uninstall the other mod also
		$mod_cod = 'showinconfig';
			
		$this->load->model('extension/extension');
		$this->load->model('extension/module');
		$this->load->model('setting/setting');

		$this->model_extension_extension->uninstall('module', $mod_cod);

		$this->model_extension_module->deleteModulesByCode($mod_cod);

		$this->model_setting_setting->deleteSetting($mod_cod);
	}

	public function install(){
		//Uninstall the other mod also
		$mod_cod = 'showinconfig';
			
		$this->load->model('extension/extension');
		$this->load->model('extension/module');
		$this->load->model('user/user_group');
			
		$this->model_extension_extension->install('module', $mod_cod);
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'module/' . $mod_cod);
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'module/' . $mod_cod);
	}

}
?>