<?php
if (is_file('config_boxme.php')) {
    require_once('config_boxme.php');
}
class ControllerBoxmeWarehouse extends Controller {
	public $url_boxme=URL_API;  
    public $url_shipchung = URL_SHIPCHUNG;
    public $client_secret = CLIENT_SECRET; 
	private $error = array();
	private $action_api=array( 
            'warehouse'=>'list_inventory-sdk',
            'addProduct'=>'product-sdk',
            'editProduct'=>'edit-product-sdk',
            'shipment'=>'shipment-sdk',
    );
    private function getAPI($url){
		$curl = curl_init();
	    curl_setopt_array($curl, array(
	      CURLOPT_URL => $url,
	      CURLOPT_RETURNTRANSFER => true,
	      CURLOPT_ENCODING => "",
	      CURLOPT_MAXREDIRS => 10,
	      CURLOPT_TIMEOUT => 30,
	      CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false, //open ssl
	      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	      CURLOPT_CUSTOMREQUEST => "GET",
	      CURLOPT_POSTFIELDS => "{}",
	      CURLOPT_HTTPHEADER => array(
	        "content-type: application/json"
	      ),
	    ));
	    $response = curl_exec($curl);
	    $err = curl_error($curl);
	    curl_close($curl);
	    if ($err) {
	      echo "cURL Error #:" . $err;
	    } else {
	      echo $response;
	    }
	}
	private function postAPI($url,$data){
			$curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => $url,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false, //open ssl
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => json_encode($data),
              CURLOPT_HTTPHEADER => array(
                "content-type: application/json"
              ),
            ));
            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              echo $response;
            }
	}
	public function index() { 

        } 
    public function createWarehouse(){
          $this->load->model("setting/setting");
            if($this->request->post['name']) {
              $data['name'] = $this->request->post['name'];
            } else {
              $data['name'] = "";
            }
            if($this->request->post['user_name']) {
              $data['user_name'] = $this->request->post['user_name'];
            } else {
              $data['user_name'] = "";
            }
            if($this->request->post['phone']) {
              $data['phone'] = $this->request->post['phone'];
            } else {
              $data['phone'] = "";
            }
            if($this->request->post['city_id']) {
              $data['city_id'] = $this->request->post['city_id'];
            } else {
              $data['city_id'] = "";
            }
            if($this->request->post['province_id']) {
              $data['province_id'] = $this->request->post['province_id'];
            } else {
              $data['province_id'] = "";
            }
            if($this->request->post['ward_id']) {
              $data['ward_id'] = $this->request->post['ward_id'];
            } else {
              $data['ward_id'] = "";
            }
             if($this->request->post['address']) {
              $data['address'] = $this->request->post['address'];
            } else {
              $data['address'] = "";
            }
            if ($this->request->server['REQUEST_METHOD'] == 'POST') {
            $data['MerchantKey'] = $this->config->get('boxme_key');
            $data['name'] = $data['name'];
            $data['user_name'] = $data['user_name'];
            $data['phone'] = $data['phone'];
            $data['city_id'] = (int)$data['city_id'];
            $data['province_id'] = (int)$data['province_id'];
            $data['ward_id'] = (int)$data['ward_id'];
            $data['address'] = (int)$data['address'];
            $url = $this->url_shipchung."api/merchant/rest/lading/create-inventory";
            $this->postAPI($url,$data);
          } else {
            echo json_encode($json = false);
          }
        }
        
	public function getWareHouse(){  
	    $data=array('ApiKey'=>$this->config->get('boxme_key'));
	    $reponse=$this->sendGetToBoxme($this->url_boxme.'bxapi/'.$this->action_api['warehouse'], $data);
	    echo $reponse['result'];
	    die(); 
	}
	 public function getWareHous2(){
	    $url = $this->url_boxme.'bxapi/'.$this->action_api['warehouse']."?ApiKey=".$this->config->get('boxme_key');
	    $this->getAPI($url);
	}
	 ///Get danh sách kho hàng boxme///
    public function getListsInventory(){
    	$url = $this->url_boxme."bxapi/list_inventory-sdk?ApiKey=".$this->config->get('boxme_key');
        $this->getAPI($url);
    }
    
}
