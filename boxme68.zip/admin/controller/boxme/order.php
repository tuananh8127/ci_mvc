<?php
if (is_file('config_boxme.php')) {
		    require_once('config_boxme.php');
}

class ControllerBoxmeOrder extends Controller {
	public $url_boxme = URL_API;
	public $url_shipchung = URL_SHIPCHUNG;
	public $client_secret = CLIENT_SECRET; 
	private $error = array();

	public function index() {
		$this->load->language('boxme/order');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('boxme/order');

		$this->getList();
	}
	protected function validateForm() {
            if ((utf8_strlen($this->request->post['domainShop']) < 1) || (utf8_strlen($this->request->post['domainShop']) > 64)) {
               $json['error_domainShop'] = true;
            }
             if ((utf8_strlen($this->request->post['from_city']) < 1) || (utf8_strlen($this->request->post['from_city']) > 64)) {
               $json['error_from_city'] = true;
            }
            if ((utf8_strlen($this->request->post['from_ward']) < 1) || (utf8_strlen($this->request->post['from_ward']) > 64)) {
               $json['error_from_ward'] = true;
            }
            if ((utf8_strlen($this->request->post['from_address']) < 1) || (utf8_strlen($this->request->post['from_address']) > 64)) {
               $json['error_from_address'] = true;
            }
            if ((utf8_strlen($this->request->post['to_city']) < 1) || (utf8_strlen($this->request->post['to_city']) > 64)) {
               $json['error_to_city'] = true;
            }
            if ((utf8_strlen($this->request->post['to_province']) < 1) || (utf8_strlen($this->request->post['to_province']) > 64)) {
               $json['error_to_province'] = true;
            }
            if ((utf8_strlen($this->request->post['to_address']) < 1) || (utf8_strlen($this->request->post['to_address']) > 64)) {
               $json['error_to_address'] = true;
            }
            if ((utf8_strlen($this->request->post['to_phone']) < 1) || (utf8_strlen($this->request->post['to_phone']) > 64)) {
               $json['error_to_phone'] = true;
            }
            if ((utf8_strlen($this->request->post['to_name']) < 1) || (utf8_strlen($this->request->post['to_name']) > 64)) {
               $json['error_to_name'] = true;
            }
            if ((utf8_strlen($this->request->post['to_name']) < 1) || (utf8_strlen($this->request->post['to_name']) > 64)) {
               $json['error_to_name'] = true;
            }

            if ((utf8_strlen($this->request->post['config_service']) < 1) || (utf8_strlen($this->request->post['config_service']) > 64)) {
               $json['error_config_service'] = true;
            }
            if ((utf8_strlen($this->request->post['config_protected']) < 1) || (utf8_strlen($this->request->post['config_protected']) > 64)) {
               $json['error_config_protected'] = true;
            }
            if ((utf8_strlen($this->request->post['config_checking']) < 1) || (utf8_strlen($this->request->post['config_checking']) > 64)) {
               $json['error_config_checking'] = true;
            }
            if ((utf8_strlen($this->request->post['config_fragile']) < 1) || (utf8_strlen($this->request->post['config_fragile']) > 64)) {
               $json['error_config_fragile'] = true;
            }
            if ((utf8_strlen($this->request->post['config_cod']) < 1) || (utf8_strlen($this->request->post['config_cod']) > 64)) {
               $json['error_config_cod'] = true;
            }
            if ((utf8_strlen($this->request->post['config_payment']) < 1) || (utf8_strlen($this->request->post['config_payment']) > 64)) {
               $json['error_config_payment'] = true;
            }
            if ((utf8_strlen($this->request->post['config_autoaccept']) < 1) || (utf8_strlen($this->request->post['config_autoaccept']) > 64)) {
               $json['error_config_autoaccept'] = true;
            }
            if(isset($json)){
                 $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode($json));
                }
             return !$json;
        }
	 public function createOrderBoxme(){
            $this->load->model('boxme/order');
            if (isset($this->request->get['order_id'])) {
                $order_id = $this->request->get['order_id'];
            } else {
                $order_id = 0;
            }
            $data['token'] = $this->session->data['token'];
            $order_info = $this->model_boxme_order->getOrder($order_id);
            if ($order_info) {
            $data['order_id'] = $this->request->get['order_id'];
            $data['products'] = array();
            $products = $this->model_boxme_order->getOrderProducts($this->request->get['order_id']);
            $this->load->model('catalog/product');
                foreach ($products as $product) {
                    $product_info = $this->model_catalog_product->getProduct($product['product_id']);
                    $data['response_item'][] = array(
                        'Name'             => $product['name'],
                        'Price'            => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
                        'Quantity'         => (int)$product['quantity'],
                        'Weight' => (float)$product_info['weight'],
                        'BSIN' => $product_info['sku'],
                    );
                }
            }
                $data['response_from'] = array(
                     'City' => (int) $this->request->post['from_city'],  //Thành phố
                    'Province' => (int) $this->request->post['from_province'], //Mã quận huyện
                    'Stock' => $this->request->post['from_stock'], //Kho Hàng
                    'Ward' => (int) $this->request->post['from_ward'], //Mã phường xã
                    'Address' => $this->request->post['from_address'], // Địa chỉ
                    'Phone' => $this->request->post['from_phone'], //Phone
                    'Name'      => $this->request->post['from_name'], //Tên người gửi
                );
                //Đơn hàng được gửi từ
                $data['response_to'] = array(
                     'City' => (int) $this->request->post['to_city'], //Thành phố
                    'Province' => (int) $this->request->post['to_province'], ///Mã quận huyện
                    'Address' => $this->request->post['to_address'], //Địa chỉ
                    'Country' => 237,//Quốc gia
                    'Ward' => (int)$this->request->post['to_ward'], // Mã phường xã
                    'Phone' => $this->request->post['to_phone'],///phone
                    'PhoneCode' => $this->request->post['to_phonecode'], // Mã đầu số
                    'Name'      => $this->request->post['to_name'], //Người nhận
                );
                ///Thông tin đơn hàng
             $data['response_order'] = array(
                    'Weight'               => (int) $this->request->post['order_weight'], //Cân nặng
                    'Amount'              => (int) $this->request->post['order_amount'], ///Số tiền trên 1 sản phẩm
                    'Quantity'         => (int) $this->request->post['order_quantity'], //Số lượng
                    'Collect' => (int) $this->request->post['order_collect'], ///Tổng tiền thu hộ
                    'ProductName' => $this->request->post['order_productname'], //Tên Đơn hàng (Tên sản phẩm)
                );
             ///Cấu hình kết nối
                $data['response_config'] = array(
                    'Service'  =>  (int)$this->request->post['config_service'],
                    'Protected'  =>  (int)$this->request->post['config_protected'],
                    'Checking'  => (int)$this->request->post['config_checking'],
                    'Fragile'  =>  (int)$this->request->post['config_fragile'],
                     'CoD'  =>  (int)$this->request->post['config_cod'],
                    'Payment'  =>  (int)$this->request->post['config_payment'],
                    'AutoAccept'  =>  (int)$this->request->post['config_autoaccept'],
                );
                //Trả về data json
               $response_create_order = array(
                    "Domain"  => $this->request->post['domainShop'], //domain
                    "MerchantKey" => $this->config->get('boxme_key'),/// api key
                    "From" => $data['response_from'],  //add from
                    "Courier" => 1,
                    "To" => $data['response_to'],
                    "Items" =>  $data['response_item'],
                    "Order" => $data['response_order'],
                    "Config" => $data['response_config'],
                );  
                if(($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) { 
                          $url = $this->url_boxme."api/public/api/rest/courier/create";
                          $curl = curl_init();
                          curl_setopt_array($curl, array(
                          CURLOPT_URL => $url,
                          CURLOPT_RETURNTRANSFER => true,
                          CURLOPT_ENCODING => "",
                          CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                          CURLOPT_MAXREDIRS => 10,
                          CURLOPT_TIMEOUT => 30,
                          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                          CURLOPT_CUSTOMREQUEST => "POST",
                          CURLOPT_POSTFIELDS => json_encode($response_create_order),
                          CURLOPT_HTTPHEADER => array(
                            "content-type: application/json"
                          ),
                        ));
                        $response = curl_exec($curl);
                        $err = curl_error($curl);
                        curl_close($curl);
                        if ($err) {
                          echo "cURL Error #:" . $err;
                        } else {
                          echo $response;
                        }
                }
    }
    public function acceptOrderBoxme(){
        if ($this->request->server['REQUEST_METHOD'] == 'POST') {
            $url = $this->url_boxme."api/public/api/merchant/rest/lading/accept";
            $data =array();
            $data['TrackingCode'] = $this->request->post['TrackingCode'];
            $data['MerchantKey'] = $this->config->get('boxme_key');
            $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => $url,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => json_encode($data),
              CURLOPT_HTTPHEADER => array(
                "content-type: application/json"
              ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              echo $response;
            }
        }
    }
     public function cancelOrderBoxme($sbc){
            $url = $this->url_boxme."api/public/api/rest/lading/cancel";
            $data =array();
            $data['TrackingCode'] = $this->request->post['tracking_code'];
            $data['MerchantKey'] =  $this->config->get('boxme_key');
            $curl = curl_init();
                curl_setopt_array($curl, array(
                  CURLOPT_URL => $url,
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => "",
                  CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 30,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => "POST",
                  CURLOPT_POSTFIELDS => json_encode($data),
                  CURLOPT_HTTPHEADER => array(
                    "content-type: application/json"
                  ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);

                curl_close($curl);

                if ($err) {
                  echo "cURL Error #:" . $err;
                } else {
                  echo $response;
                }
    }
	public function updateCheckCodeInfoBoxme($order_id, $data){
		$this->load->model('boxme/order');
		if($this->request->server['REQUEST_METHOD'] == 'POST') { 
			$this->model_boxme_order->updateCheckCodeInfoBoxme($this->request->get['order_id'], json_encode($this->request->post));
			$json['error_tracking_code']  = false;
		}  else {
			$json['error_tracking_code'] = true;
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	
	}
	public function updateCheckCodeBoxme($order_id, $data){
		$this->load->model('boxme/order');
		if($this->request->server['REQUEST_METHOD'] == 'POST') { 
			$this->model_boxme_order->updateCheckCodeBoxme($this->request->get['order_id'], $this->request->post);
			$json['error_tracking_code']  = false;
		}  else {
			$json['error_tracking_code'] = true;
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	protected function validateCheckcodeBoxme(){
		 if ((utf8_strlen($this->request->post['tracking_code']) < 1) || (utf8_strlen($this->request->post['tracking_code']) > 64)) {
               $json['error_tracking_code'] = false;
            }
            return !$json;
	}
	public function updateTTCancelOrderBoxme($order_id, $data){
		$this->load->model('boxme/order');
		if($this->request->server['REQUEST_METHOD'] == 'POST') {
		$this->model_boxme_order->updateTTCancelOrderBoxme($this->request->post['order_id'],$this->request->post);
		
			$json['updatettcancelorderboxme']  = true;
		}  
		else {
			$json['updatettcancelorderboxme'] = false;
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function statusOrderBoxme(){
		$this->load->model('boxme/order');
		if(isset($this->request->post['selected'])) {
			 foreach ($this->request->post['selected'] as $order_id) { 
			 	$result = $this->model_boxme_order->getOrderId($order_id);
			 	foreach ($result as $results) {	
			 	$tracking_code = $results['tracking_code'];
				$order_id  = $results['order_id'];
				$curl = curl_init();
				curl_setopt_array($curl, array(
				  CURLOPT_URL => $this->url_shipchung."api/rest/lading/order-status?tracking_code=".$tracking_code,
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_FOLLOWLOCATION => TRUE,
				  CURLOPT_SSL_VERIFYPEER => false,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "GET",
				  CURLOPT_POSTFIELDS => "{}",
				));
				$response = curl_exec($curl);
				$err = curl_error($curl);
				curl_close($curl);

				if ($err) {
				  echo "cURL Error #:" . $err;
				} else {
				  	$yummy = json_decode($response);
				  	$statusboxme =	$yummy->data->$tracking_code->GroupName;
				  	if($statusboxme) {
				  	$this->updateStatusBoxme($order_id,$response);
				  	}
				}
				
			}

			}
			$json['success'] = true;
		} else {
			$json['success'] = false;
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
		}

		public function statusOrderBoxmeAll(){
		$this->load->model('boxme/order');
		$result = $this->model_boxme_order->getOrders();
		if($this->request->server['REQUEST_METHOD'] == 'POST') {
			foreach ($result as $results) {
				$tracking_code = $results['tracking_code'];
				$order_id  = $results['order_id'];
				$curl = curl_init();
				curl_setopt_array($curl, array(
				  CURLOPT_URL => $this->url_shipchung."api/rest/lading/order-status?tracking_code=".$tracking_code,
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "GET",
				  CURLOPT_POSTFIELDS => "{}",
				));
				$response = curl_exec($curl);
				$err = curl_error($curl);
				curl_close($curl);
				if ($err) {
				  echo "cURL Error #:" . $err;
				} else {
					$yummy = json_decode($response);
			  		$statusboxme = $yummy->data->$tracking_code->GroupName;
					if($statusboxme) {
				  	$this->updateStatusBoxme($order_id,$response);
				  	}
				}
			}
			$json['success'] = true;
		} else {
			$json['success'] = false;
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
		}
	private function updateStatusBoxme($order_id, $statusboxme){
		$this->load->model('boxme/order');
			$this->model_boxme_order->updateStatusBoxme($order_id,$statusboxme);
			$json['error_tracking_code']  = false;
	}
    


	public function getOrderBoxme(){
     	$this->load->language('boxme/order');
			$this->document->addScript('https://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular.js');
			$data['button_cancel'] = $this->language->get('button_cancel');
			$data['breadcrumbs'] = array();
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
			);
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('boxme/order', 'token=' . $this->session->data['token'] . $url, 'SSL')
			);
			$data['text_form'] = $this->language->get('text_form');
			$data['text_toboxme'] =$this->language->get('text_toboxme');
			$data['text_items'] = $this->language->get('text_items');
			$data['text_orders'] = $this->language->get('text_orders');
			$data['text_config'] = $this->language->get('text_config');
			$data['text_domain'] = $this->language->get('text_domain');
			$data['text_city'] =$this->language->get('text_city');
			$data['text_province'] = $this->language->get('text_province');
			$data['text_ward'] = $this->language->get('text_ward');
			$data['text_stock'] = $this->language->get('text_stock');
			$data['text_address'] = $this->language->get('text_address');
			$data['text_example_address'] = $this->language->get('text_example_address');
			$data['text_phone'] =$this->language->get('text_phone');
			$data['text_name'] = $this->language->get('text_name');
			$data['text_countryboxme'] = $this->language->get('text_countryboxme');
			$data['text_trackingcode'] = $this->language->get('text_trackingcode');
			$data['text_nameproduct'] = $this->language->get('text_nameproduct');
			$data['text_price'] = $this->language->get('text_price');
			$data['text_price'] = $this->language->get('text_price');
			$data['text_quantity'] = $this->language->get('text_quantity');
			$data['text_weight'] = $this->language->get('text_weight');
			$data['text_sku'] = $this->language->get('text_sku');
			$data['text_collect'] = $this->language->get('text_collect');
			$data['text_nameorder'] = $this->language->get('text_nameorder');
			$data['text_service'] = $this->language->get('text_service');
			$data['text_protected'] = $this->language->get('text_protected');
			$data['text_checking'] = $this->language->get('text_checking');
			$data['text_fragile'] = $this->language->get('text_fragile');
			$data['text_cod'] = $this->language->get('text_cod');
			$data['text_payment'] = $this->language->get('text_payment');
			$data['text_autoaccept'] = $this->language->get('text_autoaccept');
			$data['text_fatslow'] = $this->language->get('text_fatslow');
			$data['text_fast'] = $this->language->get('text_fast');
			$data['text_yes'] = $this->language->get('text_yes');
			$data['text_no'] = $this->language->get('text_no');
			$data['text_fragile'] = $this->language->get('text_fragile');
			$data['text_normal'] = $this->language->get('text_normal');
			$data['text_customerpay'] = $this->language->get('text_customerpay');
			$data['text_impay'] = $this->language->get('text_impay');
			$data['text_dontapproval'] = $this->language->get('text_dontapproval');
			$data['text_approval'] = $this->language->get('text_approval');
			$data['text_create_order'] = $this->language->get('text_create_order');
			$data['text_back'] = $this->language->get('text_back');







			if($this->url_shipchung){
				$data['services_shipchung'] = $this->url_shipchung;
			} else {
				$data['services_shipchung'] = "Không tìn thấy đường dẫn";
			}
			
			$data['cancel'] = $this->url->link('sale/order', 'token=' . $this->session->data['token'] . $url, 'SSL');
			$this->load->model('boxme/order');
			if (isset($this->request->get['order_id'])) {
				$order_id = $this->request->get['order_id'];
				} else {
				$order_id = 0;
			}
			$order_info = $this->model_boxme_order->getOrder($order_id);
			if ($order_info) {
				$data['token'] = $this->session->data['token'];
			
			$data['order_id'] = $this->request->get['order_id'];
			$this->load->model('sale/customer_group');
			$customer_group_info = $this->model_sale_customer_group->getCustomerGroup($order_info['customer_group_id']);
			if ($customer_group_info) {
				$data['customer_group'] = $customer_group_info['name'];
				} else {
				$data['customer_group'] = '';
			}
			$data['store_url'] = $order_info['store_url'];
			$data['email'] = $order_info['email'];
			$data['telephone'] = $order_info['telephone'];
			$data['fax'] = $order_info['fax'];
			$data['account_custom_field'] = $order_info['custom_field'];
			

			// Uploaded files
			$this->load->model('tool/upload');
			// Custom Fields
			$this->load->model('sale/customer');
			$data['reward'] = $order_info['reward'];
			$data['reward_total'] = $this->model_sale_customer->getTotalCustomerRewardsByOrderId($this->request->get['order_id']);
			$this->load->model('marketing/affiliate');

			$data['commission_total'] = $this->model_marketing_affiliate->getTotalTransactionsByOrderId($this->request->get['order_id']);

			$this->load->model('localisation/order_status');

			$order_status_info = $this->model_localisation_order_status->getOrderStatus($order_info['order_status_id']);

			if ($order_status_info) {
			$data['order_status'] = $order_status_info['name'];
				} else {
				$data['order_status'] = '';
			}
			// Custom fields
			$data['products'] = array();
			$products = $this->model_boxme_order->getOrderProducts($this->request->get['order_id']);
			$this->load->model('catalog/product');
			foreach ($products as $product) {
				$option_data = array();
				$product_info = $this->model_catalog_product->getProduct($product['product_id']);
				$data['totals'] = array();
				$data['totals'] = $this->model_boxme_order->getOrderTotals($this->request->get['order_id']);
				
				$total_weight += $product_info['weight'];
				$data['orders_boxme'] = array(
					'to_city' => $order_info['shipping_city'],
					'to_province' => $order_info['shipping_city'],
					'to_address' => $order_info['shipping_address_1'],
					'to_country' => $order_info['shipping_country'],
					'to_ward' => $order_info['shipping_city'],
					'to_phone' => $order_info['telephone'],
					'to_phonecode' => '84',
					'to_name'		=> $order_info['shipping_lastname'],
					"from_city"   	=> $order_info['shipping_city'],
					"from_province"  => $order_info['shipping_city'],
					"from_stock"   	=> $order_info['store_name'],	
					"from_ward"		=> $order_info['shipping_address_1'],
					"from_address"   => $order_info['shipping_address_1'],
					"from_phone"   	=> $order_info['telephone'],
					"from_name"   	=> $order_info['store_name'],
					'order_weight'    	 	   => $total_weight,
					'order_amount'    		  => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
					'order_quantity'		   => $product['quantity'],
					'order_collect' =>  $product['total'],

				);
				$data['response_item'][] = array(
					'name'    	 	   => $product['name'],
					'price'    		   => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
					'quantity'		   => $product['quantity'],
					'weight' => (float)$product_info['weight'],
					'bsin' => $product_info['sku'],
				);
			}
			$data['tracking_code'] = $order_info['tracking_code'];
			$data['order_id'] = $this->request->get['order_id'];
			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');
			$this->response->setOutput($this->load->view('boxme/getorderboxme.tpl', $data));
			}
     }


	

	
	
}