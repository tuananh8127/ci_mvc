 <?php 
 class ControllerCommonSetting extends Controller {
	function export(){
		$export_file =  DIR_CACHE.'download.zip';
		$res = $this->Zip(dirname(dirname(dirname(dirname(__FILE__)))), $export_file);
                if($res==true){
                    header('Cache-control: private');
                    header('Content-Type: application/octet-stream');
                    header('Content-Length: '.filesize($export_file));
                    header('Content-Disposition: filename='.'download.zip');
                    ob_clean();
                    flush();
                    @readfile($export_file);
                }
    }
 function Zip($source, $destination)
{
    if (!extension_loaded('zip') || !file_exists($source)) {
        return false;
    }
    $zip = new ZipArchive();
    if (!$zip->open($destination, ZIPARCHIVE::CREATE)) {
        return false;
    }
    if (is_dir($source) === true)
    {
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source), RecursiveIteratorIterator::LEAVES_ONLY);
        foreach ($files as $key=>$file)
        { 
            // Ignore "." and ".." folders
            if( in_array(substr($key, strrpos($key, '\\')+1), array('.', '..')) )
                continue;
            if (is_file($key) === true)
              {
                   $paths=str_replace($source."\\", '', $key);
                   $zip->addFromString($paths,file_get_contents($key));
              }
        }          
    }
    return $zip->close();
}
public function backup() {
		$this->load->language('tool/backup');
                $this->load->model('tool/backup');
                $data['tables'] = $this->model_tool_backup->getTables();
                foreach ($data['tables'] as $item){
                    $this->request->post['backup'][]=$item;
                }
		if (!isset($this->request->post['backup'])) {
			$this->session->data['error'] = $this->language->get('error_backup');

			$this->response->redirect($this->url->link('tool/backup', 'token=' . $this->session->data['token'], 'SSL'));
		} elseif ($this->user->hasPermission('modify', 'tool/backup')) {
			$this->response->addheader('Pragma: public');
			$this->response->addheader('Expires: 0');
			$this->response->addheader('Content-Description: File Transfer');
			$this->response->addheader('Content-Type: application/octet-stream');
			$this->response->addheader('Content-Disposition: attachment; filename=' . DB_DATABASE . '_' . date('Y-m-d_H-i-s', time()) . '_backup.sql');
			$this->response->addheader('Content-Transfer-Encoding: binary');

			$this->load->model('tool/backup');

			$this->response->setOutput($this->model_tool_backup->backup($this->request->post['backup']));
		} else {
			$this->session->data['error'] = $this->language->get('error_permission');

			$this->response->redirect($this->url->link('tool/backup', 'token=' . $this->session->data['token'], 'SSL'));
		}
	}
}