<?php
class ControllerCommonChiliSetting extends Controller {
    private $error=array();
    public function index(){
            $this->load->language('common/chili_setting');
            $data['heading_title'] = $this->language->get('heading_title');
            $data["entry_name_domain"]=$this->language->get('entry_name_domain');
            $data["text_edit"]=$this->language->get('text_edit');
            $data["button_save"]=$this->language->get('button_save');
            $this->load->model('setting/setting');
            if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
                $this->model_setting_setting->editSetting('chili_setting', $this->request->post);
                $this->session->data['success'] = $this->language->get('text_success');
            }
            $data['action']=$this->url->link('common/chili_setting', 'token=' . $this->session->data['token'], 'SSL');
            
            $get_domain=$this->config->get("chili_setting_domain");
            if(isset($this->request->post['chili_setting_domain'])){
                $data["chili_setting_domain"]=$this->request->post['chili_setting_domain'];
            }
            elseif(!empty($get_domain)){
                $data["chili_setting_domain"]=$get_domain;
            }else{
                $data["chili_setting_domain"]="";
            }
            if(isset($this->error['chili_setting_domain'])){
                $data['error_domain_chili']=$this->error['chili_setting_domain'];
            }
            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');
            $this->response->setOutput($this->load->view('common/chili_setting.tpl', $data));
        }
		
    function limit_record(){
                $data_domain="";
                $get_domain=$this->config->get("chili_setting_domain");
                if(!empty($get_domain)){
                    $data_domain=$this->config->get("chili_setting_domain");
                }
                $data_chili= @file_get_contents("http://api.chiliweb.management/Api/Values?domain=".$data_domain);
                $data_chili=json_decode($data_chili);
                if(!empty($data_chili)){ 
                    $this->load->model('catalog/product');
                    $data['product_total'] = $this->model_catalog_product->getTotalProducts(array());
                    $data['dinhmuc']=$data_chili->DanhSachDinhMucDuLieu->DanhSachDinhMucDuLieus[0]->Value;
                    if($data['product_total']>=$data['dinhmuc'] && $data['dinhmuc']){
                       $this->response->redirect($this->url->link('common/chili_setting/templat'.'e_limit', 'token=' . $this->session->data['token']."&limit=".$data['dinhmuc'], 'SSL'));
                    }
                }
               
    }   

    function template_limit(){
		if($this->request->get['limit']){
			$product_of='chili';
			$action='setting';
			$this->load->language($product_of.'/lang_'.$action.'_'.$product_of);
			$data['text_limit_data']=$this->language->get('text_limit_data');
			$data['text_warning']=$this->language->get('text_warning');
			$data['text_upgrade_now']=$this->language->get('text_upgrade_now');
			$data['limit']= $this->request->get['limit'];
			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');
			$this->response->setOutput($this->load->view('common/chili_limit.tpl', $data));
		}
	}
		
	function removeLimit(){
            $this->load->model('extension/event');
            $this->model_extension_event->deleteEvent('Limit_record');
            $this->model_extension_event->deleteEvent('Limit_record_free');
        }
        
        protected function validate() {
		if (!$this->user->hasPermission('modify', 'common/chili_setting')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ((utf8_strlen($this->request->post['chili_setting_domain']) < 1) || (utf8_strlen($this->request->post['chili_setting_domain']) > 100)) {
			$this->error['chili_setting_domain'] = $this->language->get('error_chili_setting_domain');
		}
		return !$this->error;
	}
}