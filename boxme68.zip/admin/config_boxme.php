<?php
//define('URL_API','http://prod.boxme.vn/bxapi/'); 
// define('URL_API','http://prod.boxme.vn/bxapi/'); 
define('URL_API','https://seller.shipchung.vn/'); 
define('URL_SHIPCHUNG','http://services.shipchung.vn/');
define('CLIENT_SECRET', 'N2ZkZWZlYzI4Mjc0YzA0M2U4OTM5NGM4ZDFmYjIyYTE=');


