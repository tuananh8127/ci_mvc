<?php $this->load->view('common/header'); ?>
<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">
  <!-- Left side column. contains the logo and sidebar -->
<?php $this->load->view('common/menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <section class="content-header">
      
      <h1>
        General Form Elements
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
      </ol>
      <div class="ajax-content">
            </div>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
         

            <h1><?php echo lang('create_user_heading');?></h1>
            <p><?php echo lang('create_user_subheading');?></p>

            <div id="infoMessage"><?php echo $message;?></div>


            </div>
            <?php // echo form_open("common/login/create_user");?>
              <div class="box-body">
                <div class="form-group">
                <?php echo lang('create_user_fname_label', 'first_name');?>
               <?php echo form_input($first_name);?>
                </div>

                <div class="form-group">
                <?php echo lang('create_user_lname_label', 'last_name');?> <br />
                <?php echo form_input($last_name);?>
                </div>

                <div class="form-group">
                <?php
                  if($identity_column!=='email') {
                      echo '<p>';
                      echo lang('create_user_identity_label', 'identity');
                      echo '<br />';
                      echo form_error('identity');
                      echo form_input($identity);
                      echo '</p>';
                  }
                  ?>
                </div>

                <div class="form-group">
               <?php echo lang('create_user_company_label', 'company');?>
                 <?php echo form_input($company);?>
                </div>

                <div class="form-group">
                <?php echo lang('create_user_email_label', 'email');?>
                <?php echo form_input($email);?>
                </div>

                
                


              
                
                
          </div>
          </div>
        </div>
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-6">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Horizontal Form</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
 
              <div class="box-body">
               <div class="form-group">
                <?php echo lang('create_user_phone_label', 'phone');?>
                <?php echo form_input($phone);?>
                </div>




                <div class="form-group">
                <?php echo lang('create_user_password_label', 'password');?>
                <?php echo form_input($password);?>
                </div>
                <div class="form-group">
               <?php echo lang('create_user_password_confirm_label', 'password_confirm');?> <br />
               <?php echo form_input($password_confirm);?>
                </div>
              <div class="form-group">
                  <label for="exampleInputFile">File input</label>
                  <input type="file" id="exampleInputFile">

                  <p class="help-block">Example block-level help text here.</p>
                </div>
            
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
               <p> <i class="fa fa-spin fa-refresh"></i>&nbsp;<?php echo form_submit('submit', lang('create_user_submit_btn'), array('class'=> 'ajax btn btn-info', 'title' => 'Ajax Request','type'=>'button' ));?></p>
              <?php echo form_close();?>
              </div>
              <!-- /.box-footer -->
         
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
          
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

</div>
<!-- ./wrapper -->
<?php $this->load->view('common/footer'); ?>

<script type="text/javascript">
  // To make Pace works on Ajax calls

  $('.ajax').click(function(){
    var acce_text = "<?php echo $message; ?>";
    var form_data =  {
      first_name: $('#first_name').val(),
      last_name: $('#last_name').val(),
      company: $('#company').val(),
      email: $('#email').val(),
      phone: $('#phone').val(),
      password: $('#password').val(),
      password_confirm: $('#password_confirm').val()
    }
      $.ajax({
          url: '<?php echo base_url('common/login/create_user'); ?>',
          type: 'POST',
          data: form_data,
          cache:  false,
          success: function(json){
              if (form_data !== '') {
                alert('success');
               // $('.ajax-content').html('<div class="alert alert-success">' + '<i class="fa fa-check-circle"></i>' + acce_text + '<button type="button" class="close" data-dismiss="alert">' + '×' + '</button>' + '</div>' );
               // $('.ajax-content').fadeIn('slow').delay(6000).fadeOut('slow');
             } else {
              alert('error');
               // $('.ajax-content').html('<div class="alert alert-danger">'  + acce_text + '<button type="button" class="close" data-dismiss="alert">' + '×' + '</button>' + '</div>' );
               // $('.ajax-content').fadeIn('slow').delay(6000).fadeOut('slow');
             }
       
          }
      });
  }); 

  $(document).ajaxStart(function() { Pace.restart(); });
    $('.ajax').click(function(){
        $.ajax({url: '#', success: function(result){
            // $('.ajax-content').html('<hr>Ajax Request Completed !');
        }});
    });
</script>
