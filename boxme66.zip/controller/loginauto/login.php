<?php
class ControllerLoginautoLogin extends Controller { 
    private $error = array();
    public function index() {  
        $this->load->language('common/login');
		$this->document->setTitle($this->language->get('heading_title'));
        $data['heading_title'] = $this->language->get('heading_title');
		$data['text_login'] = $this->language->get('text_login');
		$data['text_forgotten'] = $this->language->get('text_forgotten');
		$data['entry_username'] = $this->language->get('entry_username');
		$data['entry_password'] = $this->language->get('entry_password');
		$data['button_login'] = $this->language->get('button_login');
                $data['text_bglogin'] = $this->language->get('text_bglogin');
                $keyauto=$this->config->get('keyauto'); // get keyauto;
                $keyauto_admin=$this->config->get('keyauto_admin'); // get keyauto admin;
                if(!empty($keyauto) || !empty($keyauto_admin)){
                if($this->request->get['key']==$keyauto || $this->request->get['key_admin']==$keyauto_admin){ 
                    $loginauto=$this->user->loginauto();
                    if($loginauto){
                        $this->session->data['token'] = md5(mt_rand());
                         if (isset($this->request->post['redirect']) && (strpos($this->request->post['redirect'], HTTP_SERVER) === 0 || strpos($this->request->post['redirect'], HTTPS_SERVER) === 0 )) {
				$this->redirect($this->request->post['redirect'] . '&token=' . $this->session->data['token']);
			} else {
				$this->response->redirect($this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL'));
			}
                    }
                }else{
                    $this->error['warning'] = "Key auto incorrect. Review!";
                }
               }else{
                   $this->error['warning'] = "Unable to login. Let's create a new login session";
               }
               
               if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['action'] = $this->url->link('common/login', '', 'SSL');

		if (isset($this->request->post['username'])) {
			$data['username'] = $this->request->post['username'];
		} else {
			$data['username'] = '';
		}

		if (isset($this->request->post['password'])) {
			$data['password'] = $this->request->post['password'];
		} else {
			$data['password'] = '';
		}

		if (isset($this->request->get['route'])) {
			$route = $this->request->get['route'];

			unset($this->request->get['route']);
			unset($this->request->get['token']);

			$url = '';

			if ($this->request->get) {
				$url .= http_build_query($this->request->get);
			}

			$data['redirect'] = $this->url->link('common/login', '', 'SSL');
		} else {
			$data['redirect'] = '';
		}

		if ($this->config->get('config_password')) {
			$data['forgotten'] = $this->url->link('common/forgotten', '', 'SSL');
		} else {
			$data['forgotten'] = '';
		}
		$data['header'] = $this->load->controller('common/header');
		$data['footer'] = $this->load->controller('common/footer');
                if(file_exists(DIR_TEMPLATE.'common/login_custom.tpl'))
                    $this->response->setOutput($this->load->view('common/login_custom.tpl', $data));
                else
                    $this->response->setOutput($this->load->view('common/login.tpl', $data));
        }
}

