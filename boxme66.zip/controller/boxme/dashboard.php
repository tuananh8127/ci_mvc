<?php
class ControllerBoxmeDashboard extends Controller {
	private $error = array();

	public function index() {
            $this->getDashBoard();
        }
        protected function getDashBoard() { 
                // Data config
                if (isset($this->request->post['boxme_url'])) {
			$data['boxme_url'] = $this->request->post['boxme_url'];
		} else {
			$data['boxme_url'] = $this->config->get('boxme_url');
		}
                if (isset($this->request->post['boxme_client_id'])) {
			$data['boxme_client_id'] = $this->request->post['boxme_client_id'];
		} else {
			$data['boxme_client_id'] = $this->config->get('boxme_client_id');
		}
                if (isset($this->request->post['boxme_token_api'])) {
			$data['boxme_token_api'] = $this->request->post['boxme_token_api'];
		} else {
			$data['boxme_token_api'] = $this->config->get('boxme_token_api');
		}
                if (isset($this->request->post['boxme_url'])) {
			$data['boxme_url'] = $this->request->post['boxme_url'];
		} else {
			$data['boxme_url'] = $this->config->get('boxme_url');
		}
		if (isset($this->request->post['boxme_status'])) {
			$data['boxme_status'] = $this->request->post['boxme_status'];
		} else {
			$data['boxme_status'] = $this->config->get('boxme_status');
		}
            
                // Check config; 
                $data['config_boxme']=$this->config->get("boxme_status");
                if(empty($data['config_boxme']))
                    $data['config_boxme']=false; 
                else
                    $data['config_boxme']=true; 
                
                $data['heading_title']='Chilishop - boxme'; 
                $data['disable_connect']='Ngắt kết nối'; 
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);
		$data['breadcrumbs'][] = array(
			'text' => 'Chili shop - boxme',
			'href' => $this->url->link('api_boxme/list_product', 'token=' . $this->session->data['token'], 'SSL')
		);
                // Đường dẫn Dashboard
                $data['shop_dashboard']=html_entity_decode($this->url->link('api_boxme/list_product', 'token=' . $this->session->data['token'].$token, 'SSL'));
                
                // Đường dẫn thiết lập cấu hình
                $data['config_boxme_url']=html_entity_decode($this->url->link('module/boxme', 'token=' . $this->session->data['token'], 'SSL'));
                $data['config_boxme']=html_entity_decode($this->url->link('api_boxme/list_product/config_boxme', 'token=' . $this->session->data['token'], 'SSL'));
                
                // Đường dẫn đăng nhập
                $data['login_boxme_url']=html_entity_decode($this->url->link('api_boxme/list_product/loginboxme', 'token=' . $this->session->data['token'], 'SSL'));
                
                // Đường dẫn Thoát
                $data['logout_boxme_url']=html_entity_decode($this->url->link('api_boxme/list_product/logoutboxme', 'token=' . $this->session->data['token'], 'SSL'));
                
                // Đồng bộ sản phẩm; 
                $data['shop_to_boxme_url']=html_entity_decode($this->url->link('api_boxme/list_product/shopToboxme', 'token=' . $this->session->data['token'], 'SSL'));
                $data['boxme_shop_url']=html_entity_decode($this->url->link('api_boxme/list_product/boxmeProduct', 'token=' . $this->session->data['token'], 'SSL'));
                
                // Đồng bộ danh mục tới Shop
                $data['shopCategoryToboxme']=html_entity_decode($this->url->link('api_boxme/list_product/shopCategoryToboxme', 'token=' . $this->session->data['token'], 'SSL'));
                $data['boxmeCategory']=html_entity_decode($this->url->link('api_boxme/list_product/boxmeCategory', 'token=' . $this->session->data['token'], 'SSL'));
                
                // Đồng bộ Đơn hàng tới boxme
                $data['shopOrderToboxme']=html_entity_decode($this->url->link('api_boxme/list_product/addOrder', 'token=' . $this->session->data['token'], 'SSL'));
                $data['boxmeOrderToShop']=html_entity_decode($this->url->link('api_boxme/list_product/boxmeOrder', 'token=' . $this->session->data['token'], 'SSL'));
                // Chech system
                $data['check_system']=html_entity_decode($this->url->link('api_boxme/list_product/checkSytem', 'token=' . $this->session->data['token'], 'SSL'));
                // Xem lịch sử; 
                $data['check_history']=html_entity_decode($this->url->link('api_boxme/list_product/historyShop', 'token=' . $this->session->data['token'], 'SSL'));
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('boxme/dashboard.tpl', $data));
	}
}
