<?php 
class ControllerBoxmeProductboxme extends Controller {
	
	public function index(){
		echo "getProduct";
	}

}