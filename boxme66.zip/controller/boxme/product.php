<?php
class ControllerBoxmeProduct extends Controller {
	private $error = array();



	public function shipmentCodeBoxme($product_id, $shipment_codeboxme){
		$this->load->model('catalog/product');
		if($this->request->server['REQUEST_METHOD'] == 'POST') { 
			$this->model_catalog_product->shipmentCodeBoxme($this->request->post['product_id'], $this->request->post['shipment_codeboxme']);
			$json['error_shipment_codeboxme']  = false;
		}  
		else {
			$json['error_shipment_codeboxme'] = true;
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
		
	}
	public function updateProductIdBoxme($product_id, $productid_boxme){
		$this->load->model('catalog/product');
		if($this->request->server['REQUEST_METHOD'] == 'POST') { 
			$this->model_catalog_product->updateProductIdBoxme($this->request->post['product_id'], $this->request->post['productid_boxme']);
			$json['error_productid_boxme']  = false;
		}  
		else {
			$json['error_productid_boxme'] = true;
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
		
	}

	public function updateProductDefault(){
		$this->load->model('catalog/product');
		if(($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateFormDefault()) { 
			$this->model_catalog_product->updateProductDefault($this->request->post);
			$json['error_productdefault']  = false;
		}  
		else {
			$json['error_productdefault'] = true;
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	protected function validateFormDefault() {

		if ((utf8_strlen($this->request->post['location']) < 1) || (utf8_strlen($this->request->post['location']) > 64)) {
			$this->error['location'] = $this->language->get('error_location');
		}
		if ((utf8_strlen($this->request->post['product_description']) < 1) || (utf8_strlen($this->request->post['product_description']) > 64)) {
			$this->error['product_description'] = $this->language->get('error_product_description');
		}
		if ((utf8_strlen($this->request->post['price']) < 1) || (utf8_strlen($this->request->post['price']) > 64)) {
			$this->error['price'] = $this->language->get('error_price');
		}
		if ((utf8_strlen($this->request->post['sku']) < 1) || (utf8_strlen($this->request->post['sku']) > 64)) {
			$this->error['sku'] = $this->language->get('error_sku');
		}
		if ((utf8_strlen($this->request->post['product_special']) < 1) || (utf8_strlen($this->request->post['product_special']) > 64)) {
			$this->error['product_special'] = $this->language->get('error_product_special');
		}
		if ((utf8_strlen($this->request->post['weight']) < 1) || (utf8_strlen($this->request->post['weight']) > 64)) {
			$this->error['weight'] = $this->language->get('error_weight');
		}

		return !$this->error;
	}
	public function editAngular(){
		$this->load->model('catalog/product');
		$this->model_catalog_product->editProduct($this->request->get['product_id'], $this->request->post);
		$json['status'] = true;
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}


	

	public function getJsonAngularListProduct(){
		$this->load->model('catalog/product');
		$data['products'] = array();
		$filter_data = array(
			'filter_name'	  => $filter_name,
			'filter_model'	  => $filter_model,
			'filter_price'	  => $filter_price,
			'filter_quantity' => $filter_quantity,
			'filter_status'   => $filter_status,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'           => $this->config->get('config_limit_admin')
			);

		$this->load->model('tool/image');


		$results = $this->model_catalog_product->getProducts();
		
		foreach ($results as $result) {
			if (is_file(DIR_IMAGE . $result['image'])) {
				$image = $this->model_tool_image->resize($result['image'], 40, 40);
			} else {
				$image = $this->model_tool_image->resize('no_image.png', 40, 40);
			}

			$special = false;

			$product_specials = $this->model_catalog_product->getProductSpecials($result['product_id']);

			foreach ($product_specials  as $product_special) {
				if (($product_special['date_start'] == '0000-00-00' || strtotime($product_special['date_start']) < time()) && ($product_special['date_end'] == '0000-00-00' || strtotime($product_special['date_end']) > time())) {
					$special = $product_special['price'];

					break;
				}
			}
			$data['products'][] = array(
				'product_id' => $result['product_id'],
				'image'      => $image,
				'name'       => $result['name'],
				'weight_class_id' =>  $result['weight_class_id'],
				'model'      => $result['model'],
				'weight'      =>substr($result['weight'] , 0, -9),
				'length'	=>  substr($result['length'] , 0, -9),
				'width'	=>  	substr($result['width'] , 0, -9),
				'height'	=>  substr($result['height'] , 0, -9),
				'token'	=>  $this->session->data['token'],
				'location'	=>  $result['location'],
				// 'description'	=>  utf8_substr(strip_tags(html_entity_decode($result['description'])),0,200),
				'shipment_codeboxme'	=>  $result['shipment_codeboxme'],
				'sku'      => $result['sku'],
				'price'      => $this->currency->format($result['price']),
				'special'    => $special,
				'productid_boxme' => $result['productid_boxme'],
				'quantity'   => $result['quantity'],
				'status'     => ($result['status']) ? $this->language->get('text_enabled') : $this->language->get('text_disabled'),
				'edit'       => $this->url->link('catalog/product/edit')
				);
			
		}

		
		echo json_encode($data['products']);
		

	}





}
