<?php
class ControllerBoxmeWarehouse extends Controller {
	private $error = array();

	public function index() { 
        } 
}
