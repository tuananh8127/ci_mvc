<?php
if (is_file('config_boxme.php')) {
    require_once('config_boxme.php');
}
class ControllerBoxmeSetting extends Controller { 
    private $error = array();
    private $error_list = array();
    public $url_boxme=URL_API;  
    public $url_shipchung = URL_SHIPCHUNG;
    public $client_secret = CLIENT_SECRET; 
        private $action_api=array( 
            'warehouse'=>'list_inventory-sdk',
            'addProduct'=>'product-sdk',
            'editProduct'=>'edit-product-sdk',
            'shipment'=>'shipment-sdk',
        );
        
       
        
        public function index() {
            $this->document->addScript('https://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular.js');
            $this->document->addScript('https://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-route.min.js');
            $this->language->load("boxme/setting");
            $this->load->model("setting/setting");
            $data=array();
            $data['text_none'] = $this->language->get('text_none');
            $data['token'] = $this->session->data['token'];
            $data['heading_title']=$this->language->get("heading_title");
            $data['text_edit']=$this->language->get("text_edit");
            $data['text_disabled']=$this->language->get("text_disabled");
            $data['text_enabled']=$this->language->get("text_enabled");
            $data['entry_status']=$this->language->get("entry_status");
            $data['entry_key']=$this->language->get("entry_key");
            $data['text_config']=$this->language->get("text_config");
            $data['text_select_warehouse']=$this->language->get("text_select_warehouse");
            $data['text_warehouseshop']=$this->language->get("text_warehouseshop");
            $data['text_warehouseboxme']=$this->language->get("text_warehouseboxme");
            $data['text_warehousedefault']=$this->language->get("text_warehousedefault");
            $data['text_selectdefault']=$this->language->get("text_selectdefault"); 
            $data['text_functional']=$this->language->get("text_functional");  
            $data['text_errorkey']=$this->language->get("text_errorkey");
            $data['text_savesuccess']=$this->language->get("text_savesuccess");
            $data['text_validation']=$this->language->get("text_validation");            
            $data['breadcrumbs'] = array();

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_object'),
                'href' => $this->url->link('boxme/dashboard', 'token=' . $this->session->data['token'], 'SSL')
            );
            $data['listProductBoxme'] = $this->url->link('boxme/setting/getListProductBoxme', 'token=' . $this->session->data['token'], 'SSL');
            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('boxme/setting', 'token=' . $this->session->data['token'], 'SSL')
            );
            
            if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) { 
            $this->model_setting_setting->editSetting('boxme', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('boxme/setting', 'token=' . $this->session->data['token'], 'SSL'));
        }
            
            $data['getwarehouse']=$this->url->link('boxme/setting/getWareHouse', 'token=' . $this->session->data['token'], 'SSL');
            
            if (isset($this->request->post['boxme_status'])) {
            $data['boxme_status'] = $this->request->post['boxme_status'];
            } else {
            $data['boxme_status'] = $this->config->get('boxme_status');
            }
            if (isset($this->request->post['boxme_key'])) {
                    $data['boxme_key'] = $this->request->post['boxme_key'];
            } else {
                    $data['boxme_key'] = $this->config->get('boxme_key');
            }
           
            
            if (isset($this->request->post['boxme_default_input_boxme'])) {
                    $data['boxme_default_input_boxme'] = $this->request->post['boxme_default_input_boxme'];
            } else {
                    $data['boxme_default_input_boxme'] = $this->config->get('boxme_default_input_boxme');
            }
            
            if (isset($this->request->post['boxme_warehouse_chili'])) {
                    $data['boxme_warehouse_chili'] = $this->request->post['boxme_warehouse_chili'];
            } else {
                    $data['boxme_warehouse_chili'] = $this->config->get('boxme_warehouse_chili');
            }
            if (isset($this->request->post['boxme_warehouse_boxme'])) {
                    $data['boxme_warehouse_boxme'] = $this->request->post['boxme_warehouse_boxme'];
            } else {
                    $data['boxme_warehouse_boxme'] = $this->config->get('boxme_warehouse_boxme');
            }
           
            $data['button_save']=  $this->language->get('button_save');
            $data['action']=  $this->url->link('boxme/setting','token='.$this->session->data['token'], 'SSL'); 
            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');

            $this->response->setOutput($this->load->view('boxme/setting.tpl', $data));
        }
         public function createProvince(){
          $this->load->model("setting/setting");
            if($this->request->post['name']) {
              $data['name'] = $this->request->post['name'];
            } else {
              $data['name'] = "";
            }
            if($this->request->post['user_name']) {
              $data['user_name'] = $this->request->post['user_name'];
            } else {
              $data['user_name'] = "";
            }
            if($this->request->post['phone']) {
              $data['phone'] = $this->request->post['phone'];
            } else {
              $data['phone'] = "";
            }
            if($this->request->post['city_id']) {
              $data['city_id'] = $this->request->post['city_id'];
            } else {
              $data['city_id'] = "";
            }
            if($this->request->post['province_id']) {
              $data['province_id'] = $this->request->post['province_id'];
            } else {
              $data['province_id'] = "";
            }
            if($this->request->post['ward_id']) {
              $data['ward_id'] = $this->request->post['ward_id'];
            } else {
              $data['ward_id'] = "";
            }
             if($this->request->post['address']) {
              $data['address'] = $this->request->post['address'];
            } else {
              $data['address'] = "";
            }
            if ($this->request->server['REQUEST_METHOD'] == 'POST') {
            $data['MerchantKey'] = $this->config->get('boxme_key');
            $data['name'] = $data['name'];
            $data['user_name'] = $data['user_name'];
            $data['phone'] = $data['phone'];
            $data['city_id'] = (int)$data['city_id'];
            $data['province_id'] = (int)$data['province_id'];
            $data['ward_id'] = (int)$data['ward_id'];
            $data['address'] = (int)$data['address'];
            $url = "http://services.shipchung.vn/api/merchant/rest/lading/create-inventory";
            $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => $url,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false, //open ssl
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => json_encode($data),
              CURLOPT_HTTPHEADER => array(
                "content-type: application/json"
              ),
            ));
            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              echo $response;
            }
          } else {
            echo json_encode($json = false);
          }
        }
        public function settingBoxme() {
            $this->load->model("setting/setting"); 
            if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateSettingBoxme()) { 
            $this->model_setting_setting->editSetting('boxme', $this->request->post);
             $json['success'] = true;
            } else {
                $json['success'] = false;
            }
            $this->response->addHeader('Content-Type: application/json');
             $this->response->setOutput(json_encode($json));
          
        }
        protected function validateSettingBoxme() {
            if ((utf8_strlen($this->request->post['boxme_key']) < 1) || (utf8_strlen($this->request->post['boxme_key']) > 64)) {
              $json['error_setting'] = true;
            } 
             return !$json;
        }
        public function getWareHouse(){  
            $data=array('ApiKey'=>$this->request->get['apiKey']);
            $reponse=$this->sendGetToBoxme($this->url_boxme.'bxapi/'.$this->action_api['warehouse'], $data);
            echo $reponse['result'];
            die(); 
        }
         public function getWareHous2(){
            $url = $this->url_boxme.'bxapi/'.$this->action_api['warehouse']."?ApiKey=".$this->config->get('boxme_key');
            $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => $url,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false, //open ssl
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "GET",
              CURLOPT_POSTFIELDS => "{}",
              CURLOPT_HTTPHEADER => array(
                "content-type: application/json"
              ),
            ));
            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              echo $response;
            }
        }
       

        protected function validate() { 
        
        if (!$this->user->hasPermission('modify', 'boxme/setting')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }
        function installBoxme(){
            $this->load->model('extension/event');
            $this->model_extension_event->addEvent('boxme_after_add_product', 'post.admin.product.add', 'boxme/setting/addproduct');
            $this->model_extension_event->addEvent('boxme_after_edit_product','post.admin.product.edit', 'boxme/setting/editproduct');
        }
        function unstallBoxme(){ 
            $this->load->model('extension/event');
            $this->model_extension_event->deleteEvent('boxme_after_add_product');
            $this->model_extension_event->deleteEvent('boxme_after_edit_product');
        }
        // Add product
        function addproductSSS(){
             $this->load->model('catalog/product');
             $this->load->model('catalog/manufacturer');
            $product=$this->model_catalog_product->getProduct(339);
            $manufacturer_info = $this->model_catalog_manufacturer->getManufacturer($product['manufacturer_id']);
            
           echo $manufacturer_info['name'];
        }
           function addproduct($id){
           
            $data['boxme_status'] = $this->config->get('boxme_status');
            $this->load->model('catalog/product');
            $this->load->model('catalog/manufacturer');
            $product=$this->model_catalog_product->getProduct($id);
            $product_specials = $this->model_catalog_product->getProductSpecials($id);
            foreach ($product_specials  as $product_special) {
                if (($product_special['date_start'] == '0000-00-00' || strtotime($product_special['date_start']) < time()) && ($product_special['date_end'] == '0000-00-00' || strtotime($product_special['date_end']) > time())) {
                    $special = $product_special['price'];

                    break;
                }
            }
            $product_des=$this->model_catalog_product->getProductDescriptions($id);
            $product_boxme=array();
            $manufacturer_info = $this->model_catalog_manufacturer->getManufacturer($product['manufacturer_id']);
            if($product['location']){
                 $product_boxme['InventoryId']= $product['location'];
             } else {
                $product_boxme['InventoryId'] = $this->config->get('boxme_warehouse_chili');
             }
            // $product_boxme['InventoryId']= $product['location'];
            $product_boxme['ApiKey']=$this->config->get('boxme_key');
            $product_boxme['SellerSKU']=$product['sku'];
            $product_boxme['Name']=$product['name'];
            $product_boxme['CategoryName']= $product['name'];
            $product_boxme['SupplierName']= 'CHILI'; //Nhà cung cấp
            $product_boxme['BrandName']= $manufacturer_info['name'];//Thương hiệu
            $product_boxme['Description']= '';
            $product_boxme['ProductTags']='CHILI,'.$product['tag'];
            $product_boxme['Quantity']=(int) $product['quantity'];
            $product_boxme['BasePrice']=(int) $product['price'];
            $product_boxme['SalePrice']=(int) $product_special['price'];
            $product_boxme['BarcodeManufacturer']="CHILI Manufacturer";
            $product_boxme['ModelName']=$product['model'];
            $product_boxme['Weight']=(int) $product['weight'];
            $product_boxme['Volume']=$product['length'].'x'.$product['width'].'x'.$product['height'];
            $product_boxme['ProductImages']= $product['image'];
            if($data['boxme_status'] == 1 && $product['status_boxme'] == 1) {
                $curl = curl_init();
                curl_setopt_array($curl, array(
                  CURLOPT_URL => $this->url_boxme."bxapi/product-sdk",
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => "",
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false, ///ext openssl
                  CURLOPT_TIMEOUT => 30,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => "POST",
                  CURLOPT_POSTFIELDS => json_encode($product_boxme),
                  CURLOPT_HTTPHEADER => array(
                    "content-type: application/json"
                  ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);

                curl_close($curl);

                if ($err) {
                  echo "cURL Error #:" . $err;
                } else {
                  $result= json_decode($response);
                   $ProductId =  $result->ProductId;
                    $this->updateProductidBoxme($id,$ProductId);
                }
            }
            
        }
        // input into warehoures. Nhập kho tuan anh
        function shipment($data){
            $this->load->model('setting/setting');
            $data_shipment=array();
            $data_shipment['ApiKey']= $this->config->get('boxme_key');
            if(isset($this->request->post['boxme_warehouse_boxme'])){
                $data['boxme_warehouse_boxme'] = $this->request->post['boxme_warehouse_boxme'];
            } else {
                $data['boxme_warehouse_boxme'] = "";
            }
            if(isset($this->request->post['volume'])){
                $data['Volume'] = $this->request->post['volume'];
            } else {
                $data['Volume'] = "0x0x0";
            }
            if(isset($this->request->post['typetransport'])){
                $data['TypeTransport'] = $this->request->post['typetransport'];
            } else {
                $data['TypeTransport'] = "1";
            }
             if(isset($this->request->post['weight'])){
                $data['Weight'] = (int)$this->request->post['weight'];
            } else {
                $data['Weight'] = 0;
            }
             if(isset($this->request->post['sku'])){
                $data['SellerSKU'] = $this->request->post['sku'];
            } else {
                $data['SellerSKU'] = "SP-224";
            }
             if(isset($this->request->post['quantity'])){
                $data['Quantity'] = $this->request->post['quantity'];
            } else {
                $data['Quantity'] = "10";
            }
             if(isset($this->request->post['boxme_mothed_shipping'])){
                $data['boxme_mothed_shipping'] = $this->request->post['boxme_mothed_shipping'];
            } else {
                $data['boxme_mothed_shipping'] = "BOXME";
            }
            if(isset($this->request->post['boxme_mothed_shipping'])){
                $data['shippingmethod'] = $this->request->post['shippingmethod'];
            } else {
                $data['shippingmethod'] = $data['boxme_mothed_shipping'];
            }
            $data_shipment['ShipToAddress']=array('InventoryId'=>$data['boxme_warehouse_boxme']); //@TODO: For customer option Boxme warehouse.
            $data_shipment['ShipFromAddress']=array('InventoryId'=>$this->config->get('boxme_warehouse_chili'));
            $data_shipment['TypeTransport']= $data['TypeTransport'];
            $data_shipment['ShipmentStatus']="ReadyToShip";
            $data_shipment['Volumes']= $data['Volume'];
            $data_shipment['Weight']=$data['Weight'];
            // $data_shipment['ShippingMethod']= $this->config->get('boxme_mothed_shipping'); //@TODO: for setting at the editing page and setting page
            $data_shipment['ShippingMethod']= $data['shippingmethod']; //@TODO: for setting at the editing page and setting page

            $data_shipment['ShipmentItems']=array(
                array(
                    'SKU'=>$data['SellerSKU'],
                    'QuantityShipped'=>$data['Quantity'], 
                    
            ));
            
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $this->url_boxme."bxapi/shipment-sdk",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => json_encode($data_shipment), 
                CURLOPT_HTTPHEADER => array(
                    "authorization: Basic ZHZxdW9jOjEyMzQ1Njc=",
                    "cache-control: no-cache",
                    "content-type: application/json",
                ),
            ));
            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              echo $response;
            }

            //return if success -> json {"status": 200, "code": "BX163263DD59", "validation_messages": {"Messages": "Create shipment sucess."}}//
             //{"status": 442, "message": "Sku is not exist !"}//
        }
  


        //Thêm sản phẩm vào boxme
        function inputShipmentBoxme(){
            // $this->load->model('catalog/product');
            // var_dump($this->model_catalog_product->getProduct(362));
            if(isset($this->request->post['selected'])) {
                        $json=array();
                        $this->load->model('catalog/product');
                         foreach ($this->request->post['selected'] as $product_id) {
                            $product=$this->model_catalog_product->getProduct($product_id);
                            $product_des=$this->model_catalog_product->getProductDescriptions($product_id);
                            $product_boxme=array();
                            $product_boxme['InventoryId']=$this->config->get('boxme_warehouse_chili');  
                            $product_boxme['ApiKey']=$this->config->get('boxme_key');
                            $product_boxme['SellerSKU']=$product['sku'];
                            $product_boxme['Name']=$product['name'];
                            $product_boxme['CategoryName']= $product['category'];
                           $product_boxme['SupplierName']=$product['manufacturer']; //Nhà cung cấp
                            $product_boxme['BrandName']=$product['manufacturer']; //Thương hiệu
                            $product_boxme['Description']= '';
                            $product_boxme['ProductTags']='CHILI,'.$product['tag'];
                            $product_boxme['Quantity']=(int) $product['quantity'];
                            $product_boxme['BasePrice']=(int) $product['price'];
                            $product_boxme['SalePrice']=(int) $product['price'];
                            $product_boxme['BarcodeManufacturer']= "CHILI Manufacturer";
                            $product_boxme['ModelName']=$product['model'];
                            $product_boxme['Weight']=(int) $product['weight'];
                            $product_boxme['Volume']=$product['length'].'x'.$product['width'].'x'.$product['height'];
                            $product_boxme['ProductImages']=$product['image'];
                            // Add product to Boxme
                            $result=$this->sendPostToBoxme($this->url_boxme.'bxapi/'.$this->action_api['addProduct'],$product_boxme);
                            // $this->printBoxme($result); 
                            $productidboxme =  $result['result']->ProductId;
                            if($productidboxme == 0) {
                                $this->updateProductidBoxme($product_id, $product['productid_boxme']);
                            } elseif($productidboxme != 0) {
                                $this->updateProductidBoxme($product_id, $productidboxme);
                            }


                            // echo json_encode($result);
                            $json[$product_id]['addproduct']['name']=$product['name'];
                            $json[$product_id]['addproduct']['id']=$product_id;
                            if($result['error']==FALSE && $result['code']==200){ 
                                $json[$product_id]['addproduct']['sucess']=TRUE;
                                // Shipment product to Boxme.
                                $result=$this->sendPostToBoxme($this->url_boxme.'bxapi/'.$this->action_api['shipment'],$product_boxme);
                                $json[$product_id]['shipment']['name']=$product['name'];
                                $json[$product_id]['shipment']['id']=$product_id;
                                if($result['error']==FALSE && $result['code']==200){
                                    $json[$product_id]['shipment']['sucess']=TRUE;
                                }else{
                                    $json[$product_id]['shipment']['sucess']=false;
                                }
                            }else{
                                $json[$product_id]['addproduct']['sucess']=FALSE;
                                $json[$product_id]['shipment']['name']=$product['name'];
                                $json[$product_id]['shipment']['id']=$product_id;
                                $json[$product_id]['shipment']['sucess']=false;
                            }
            }
                        $this->error_list=$json;
                        $this->error_boxme();
            }else{
                $this->error[]="Không có sản phẩm nào được chọn";
                $this->error_boxme();
            }
        }
        
        function inputShipmentBoxme2(){
            if(isset($this->request->post['selected'])) {
                        $json=array();
                        $this->load->model('catalog/product');
                         foreach ($this->request->post['selected'] as $product_id) {
                            $product=$this->model_catalog_product->getProduct($product_id);
                            $product_des=$this->model_catalog_product->getProductDescriptions($product_id);
                            $product_boxme=array();
                            $product_boxme['InventoryId']=$this->config->get('boxme_warehouse_chili');  
                            $product_boxme['ApiKey']=$this->config->get('boxme_key');
                            $product_boxme['SellerSKU']=$product['sku'];
                            $product_boxme['Name']=$product['name'];
                            $product_boxme['CategoryName']= $product['category'];
                            $product_boxme['SupplierName']=$product['manufacturer'];
                            $product_boxme['BrandName']=$product['manufacturer'];
                            $product_boxme['Description']= '';
                            $product_boxme['ProductTags']='CHILI,'.$product['tag'];
                            $product_boxme['Quantity']=(int) $product['quantity'];
                            $product_boxme['BasePrice']=(int) $product['price'];
                            $product_boxme['SalePrice']=(int) $product['price'];
                            $product_boxme['BarcodeManufacturer']="CHILI Manufacturer";
                            $product_boxme['ModelName']=$product['model'];
                            $product_boxme['Weight']=(int) $product['weight'];
                            $product_boxme['Volume']=$product['length'].'x'.$product['width'].'x'.$product['height'];
                            $product_boxme['ProductImages']=$product['image'];
                            // Add product to Boxme
                            // $result=$this->sendPostToBoxme($this->url_boxme.$this->action_api['addProduct'],$product_boxme);
                            $curl = curl_init();
                            curl_setopt_array($curl, array(
                              CURLOPT_URL => $this->url_boxme."bxapi/product-sdk",
                              CURLOPT_RETURNTRANSFER => true,
                              CURLOPT_ENCODING => "",
                              CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                              CURLOPT_MAXREDIRS => 10,
                              CURLOPT_TIMEOUT => 30,
                              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                              CURLOPT_CUSTOMREQUEST => "POST",
                              CURLOPT_POSTFIELDS => json_encode($product_boxme),
                              CURLOPT_HTTPHEADER => array(
                                "content-type: application/json"
                              ),
                            ));

                            $response = curl_exec($curl);
                            $err = curl_error($curl);

                            curl_close($curl);

                            if ($err) {
                              echo "cURL Error #:" . $err;
                            } else {
                              $yummy = json_decode($response);
                            $productid_boxme =  $yummy->ProductId;
                            $this->updateProductidBoxme($product_id,$productid_boxme);
                            // if($productid_boxme == null){
                            //     $json['success'] == false;
                            //   // $this->updateProductidBoxme();
                            // } elseif($productid_boxme != null) {
                            //     $json['success'] == true;
                            // }
                            $json[$product_id]['success'] = $productid_boxme;

                            }
                            
                           
            }
                      
            }else{
                $json['success'] = false;
            }
            $this->response->addHeader('Content-Type: application/json');
             $this->response->setOutput(json_encode($json));
        }
        private function updateProductidBoxme($product_id, $productid_boxme){
            $this->load->model('catalog/product');
            $this->model_catalog_product->updateProductidBoxme($product_id,$productid_boxme);
           
   
        }
       
         function addProductBoxme(){
            // if(isset($this->request->post['abcd'])) {
                        $json=array();
                        $this->load->model('catalog/product');
                         // foreach ($this->request->post['abcd'] as $product_id) {
                            $product=$this->model_catalog_product->getProduct($this->request->post['product_id']);
                            $product_des=$this->model_catalog_product->getProductDescriptions($this->request->post['abcd']);
                            $product_boxme=array();
                            $product_boxme['InventoryId']=$this->config->get('boxme_warehouse_chili');  
                            $product_boxme['ApiKey']=$this->config->get('boxme_key');
                            $product_boxme['SellerSKU']=$product['sku'];
                            $product_boxme['Name']= $product['name'];
                            $product_boxme['CategoryName']= $product['category'];
                            $product_boxme['SupplierName']= $product['manufacturer'];
                            $product_boxme['BrandName']=$product['manufacturer'];
                            $product_boxme['Description']= '';
                            $product_boxme['ProductTags']='CHILI,'.$product['tag'];
                            $product_boxme['Quantity']=(int) $product['quantity'];
                            $product_boxme['BasePrice']=(int) $product['price'];
                            $product_boxme['SalePrice']=(int) $product['price'];
                            $product_boxme['BarcodeManufacturer']= "CHILI Manufacturer";
                            $product_boxme['ModelName']=$product['model'];
                            $product_boxme['Weight']=(int) $product['weight'];
                            $product_boxme['Volume']=$product['length'].'x'.$product['width'].'x'.$product['height'];
                            $product_boxme['ProductImages']=$product['image'];
                            // Add product to Boxme
                            $json=$this->sendPostToBoxme($this->url_boxme.'bxapi/'.$this->action_api['addProduct'],$product_boxme);
                            // $this->printBoxme($result); 

                           
                            $json[$product_id]['addproduct']['name']=$product['name'];
                            $json[$product_id]['addproduct']['id']=$product_id;
                            if($result['error']==FALSE && $result['code']==200){ 
                                $json[$product_id]['addproduct']['sucess']=TRUE;
                                // Shipment product to Boxme.
                                $result=$this->sendPostToBoxme($this->url_boxme.'bxapi/'.$this->action_api['shipment'],$product_boxme);
                                $json[$product_id]['shipment']['name']=$product['name'];
                                $json[$product_id]['shipment']['id']=$product_id;
                                if($result['error']==FALSE && $result['code']==200){
                                    $json[$product_id]['shipment']['sucess']=TRUE;
                                }else{
                                    $json[$product_id]['shipment']['sucess']=false;
                                }
                            }else{
                                $json[$product_id]['addproduct']['sucess']=FALSE;
                                $json[$product_id]['shipment']['name']=$product['name'];
                                $json[$product_id]['shipment']['id']=$product_id;
                                $json[$product_id]['shipment']['sucess']=false;
                            }
            // }
                        // $this->error_list=$json;
                        // $this->error_boxme();
           
            // }else{
            //    $json['success'] = 'notfound';
            // }
            $this->response->addHeader('Content-Type: application/json');
             $this->response->setOutput(json_encode($json));
        }


        private function sendPostToBoxme($url,$data){
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_FOLLOWLOCATION => TRUE, //Open ssl
                CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => array(
                    "authorization: Basic ZHZxdW9jOjEyMzQ1Njc=",
                    "cache-control: no-cache",
                    "content-type: application/json",
                ),
            ));
            $response = curl_exec($curl);
            $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            $result=json_decode($response);
            curl_close($curl);
            $json=array();
            $json['code']=$httpcode;
            $json['result']=$result;
            if ($httpcode!=200) {
                 $json['error']=TRUE;
            } else {
                $json['error']=FALSE;
            }
            return $json;
        }


        public function getJsonListProduct(){
            $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => $this->url_boxme.'bxapi/'."list_product-sdk?ApiKey=".$this->config->get('boxme_key'),
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "GET",
              CURLOPT_POSTFIELDS => "{}",
              CURLOPT_HTTPHEADER => array(
                "content-type: application/json"
              ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
         echo $response;
            }
        }
       protected function validateForm() {
            if ((utf8_strlen($this->request->post['domainShop']) < 1) || (utf8_strlen($this->request->post['domainShop']) > 64)) {
               $json['error_domainShop'] = true;
            }
             if ((utf8_strlen($this->request->post['from_city']) < 1) || (utf8_strlen($this->request->post['from_city']) > 64)) {
               $json['error_from_city'] = true;
            }
            if ((utf8_strlen($this->request->post['from_ward']) < 1) || (utf8_strlen($this->request->post['from_ward']) > 64)) {
               $json['error_from_ward'] = true;
            }
            if ((utf8_strlen($this->request->post['from_address']) < 1) || (utf8_strlen($this->request->post['from_address']) > 64)) {
               $json['error_from_address'] = true;
            }
            if ((utf8_strlen($this->request->post['to_city']) < 1) || (utf8_strlen($this->request->post['to_city']) > 64)) {
               $json['error_to_city'] = true;
            }
            if ((utf8_strlen($this->request->post['to_province']) < 1) || (utf8_strlen($this->request->post['to_province']) > 64)) {
               $json['error_to_province'] = true;
            }
            if ((utf8_strlen($this->request->post['to_address']) < 1) || (utf8_strlen($this->request->post['to_address']) > 64)) {
               $json['error_to_address'] = true;
            }
            if ((utf8_strlen($this->request->post['to_phone']) < 1) || (utf8_strlen($this->request->post['to_phone']) > 64)) {
               $json['error_to_phone'] = true;
            }
            if ((utf8_strlen($this->request->post['to_name']) < 1) || (utf8_strlen($this->request->post['to_name']) > 64)) {
               $json['error_to_name'] = true;
            }
            
            if ((utf8_strlen($this->request->post['to_name']) < 1) || (utf8_strlen($this->request->post['to_name']) > 64)) {
               $json['error_to_name'] = true;
            }


            if ((utf8_strlen($this->request->post['config_service']) < 1) || (utf8_strlen($this->request->post['config_service']) > 64)) {
               $json['error_config_service'] = true;
            }
            if ((utf8_strlen($this->request->post['config_protected']) < 1) || (utf8_strlen($this->request->post['config_protected']) > 64)) {
               $json['error_config_protected'] = true;
            }
            if ((utf8_strlen($this->request->post['config_checking']) < 1) || (utf8_strlen($this->request->post['config_checking']) > 64)) {
               $json['error_config_checking'] = true;
            }
            if ((utf8_strlen($this->request->post['config_fragile']) < 1) || (utf8_strlen($this->request->post['config_fragile']) > 64)) {
               $json['error_config_fragile'] = true;
            }
            if ((utf8_strlen($this->request->post['config_cod']) < 1) || (utf8_strlen($this->request->post['config_cod']) > 64)) {
               $json['error_config_cod'] = true;
            }
            if ((utf8_strlen($this->request->post['config_payment']) < 1) || (utf8_strlen($this->request->post['config_payment']) > 64)) {
               $json['error_config_payment'] = true;
            }
            if ((utf8_strlen($this->request->post['config_autoaccept']) < 1) || (utf8_strlen($this->request->post['config_autoaccept']) > 64)) {
               $json['error_config_autoaccept'] = true;
            }

            if(isset($json)){
                 $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode($json));
                 // return !$json;
                }
            //  } 
            //  else  {
            //      $success['success']  =  true;
            //      $this->response->addHeader('Content-Type: application/json');
            //     $this->response->setOutput(json_encode($success));
            //     return !$success;
            //      // echo json_encode($success['success']);
            //  }
              
             return !$json;
        }
         public function createOrderBoxme(){
            $this->load->model('sale/order');
            if (isset($this->request->get['order_id'])) {
                $order_id = $this->request->get['order_id'];
                } else {
                $order_id = 0;
            }
             $data['token'] = $this->session->data['token'];
            $order_info = $this->model_sale_order->getOrder($order_id);
            if ($order_info) {
            $data['order_id'] = $this->request->get['order_id'];
            $data['products'] = array();
            $products = $this->model_sale_order->getOrderProducts($this->request->get['order_id']);
            $this->load->model('catalog/product');
            foreach ($products as $product) {
                $product_info = $this->model_catalog_product->getProduct($product['product_id']);
                $data['response_item'][] = array(
                    'Name'             => $product['name'],
                    'Price'            => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
                    'Quantity'         => (int)$product['quantity'],
                    'Weight' => (float)$product_info['weight'],
                    'BSIN' => $product_info['sku'],
                );
            }
            }
                $data['response_from'] = array(
                     'City' => (int) $this->request->post['from_city'],  //Thành phố
                    'Province' => (int) $this->request->post['from_province'], //Mã quận huyện
                    'Stock' => $this->request->post['from_stock'], //Kho Hàng
                    'Ward' => (int) $this->request->post['from_ward'], //Mã phường xã
                    'Address' => $this->request->post['from_address'], // Địa chỉ
                    'Phone' => $this->request->post['from_phone'], //Phone
                    'Name'      => $this->request->post['from_name'], //Tên người gửi
                );

                //Đơn hàng được gửi từ
                $data['response_to'] = array(
                     'City' => (int) $this->request->post['to_city'], //Thành phố
                    'Province' => (int) $this->request->post['to_province'], ///Mã quận huyện
                    'Address' => $this->request->post['to_address'], //Địa chỉ
                    'Country' => 237,//Quốc gia
                    'Ward' => (int)$this->request->post['to_ward'], // Mã phường xã
                    'Phone' => $this->request->post['to_phone'],///phone
                    'PhoneCode' => $this->request->post['to_phonecode'], // Mã đầu số
                    'Name'      => $this->request->post['to_name'], //Người nhận
                );
                ///Thông tin đơn hàng
             $data['response_order'] = array(
                    'Weight'               => (int) $this->request->post['order_weight'], //Cân nặng
                    'Amount'              => (int) $this->request->post['order_amount'], ///Số tiền trên 1 sản phẩm
                    'Quantity'         => (int) $this->request->post['order_quantity'], //Số lượng
                    'Collect' => (int) $this->request->post['order_collect'], ///Tổng tiền thu hộ
                    'ProductName' => $this->request->post['order_productname'], //Tên Đơn hàng (Tên sản phẩm)
                );

             ///Cấu hình kết nối
                $data['response_config'] = array(
                    'Service'  =>  (int)$this->request->post['config_service'],
                    'Protected'  =>  (int)$this->request->post['config_protected'],
                    'Checking'  => (int)$this->request->post['config_checking'],
                    'Fragile'  =>  (int)$this->request->post['config_fragile'],
                     'CoD'  =>  (int)$this->request->post['config_cod'],
                    'Payment'  =>  (int)$this->request->post['config_payment'],
                    'AutoAccept'  =>  (int)$this->request->post['config_autoaccept'],
                );
                //Trả về data json
               $response_create_order = array(
                    "Domain"  => $this->request->post['domainShop'], //domain
                     "MerchantKey" => $this->config->get('boxme_key'),/// api key
                      "From" => $data['response_from'],  //add from
                      "Courier" => 1,
                      "To" => $data['response_to'],
                      "Items" =>  $data['response_item'],
                      "Order" => $data['response_order'],
                      "Config" => $data['response_config'],
                );  


                // $order_boxme = array();
                if(($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) { 
                         // http://prod.boxme.vn/api/public/api/rest/courier/create
                          $url = $this->url_boxme."api/public/api/rest/courier/create";
                          $curl = curl_init();
                          curl_setopt_array($curl, array(
                          CURLOPT_URL => $url,
                          CURLOPT_RETURNTRANSFER => true,
                          CURLOPT_ENCODING => "",
                          CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                          CURLOPT_MAXREDIRS => 10,
                          CURLOPT_TIMEOUT => 30,
                          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                          CURLOPT_CUSTOMREQUEST => "POST",
                          CURLOPT_POSTFIELDS => json_encode($response_create_order),
                          CURLOPT_HTTPHEADER => array(
                            "content-type: application/json"
                          ),
                        ));
                        $response = curl_exec($curl);
                        $err = curl_error($curl);
                        curl_close($curl);
                        if ($err) {
                          echo "cURL Error #:" . $err;
                        } else {
                          echo $response;
                        }
                }
    }

   

    ///Get danh sách kho hàng boxme///
    public function GetListsInventory(){
        $curl = curl_init();

            curl_setopt_array($curl, array(
              CURLOPT_URL => $this->url_boxme."bxapi/list_inventory-sdk?ApiKey=".$this->config->get('boxme_key'),
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "GET",
              CURLOPT_POSTFIELDS => "{}",
              CURLOPT_HTTPHEADER => array(
                "content-type: application/json"
              ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              echo $response;
            }
    }
    public function GetListProductToCreateOrder(){
        $curl = curl_init();

            curl_setopt_array($curl, array(
              CURLOPT_URL => $this->url_boxme."bxapi/get_list_products_create_order?sellerSKU=SPT12&inventory_id=92932&ApiKey=".$this->config->get('boxme_key'),
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "GET",
              CURLOPT_POSTFIELDS => "{}",
              CURLOPT_HTTPHEADER => array(
                "content-type: application/json"
              ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              echo $response;
            }
    }
    // public function orderStatusBoxme(){
    //         $url = $this->url_boxme.'api/public/api/rest/lading/order-status?tracking_code=SC51327644994';
    //         $curl = curl_init();
    //         curl_setopt_array($curl, array(
    //           // CURLOPT_URL => "http://prod.boxme.vn/api/public/api/rest/lading/order-status?tracking_code=SC51327644994",
    //           CURLOPT_URL => $url,
    //           CURLOPT_RETURNTRANSFER => true,
    //           CURLOPT_ENCODING => "",
    //           CURLOPT_MAXREDIRS => 10,
    //           CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
    //           CURLOPT_TIMEOUT => 30,
    //           CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    //           CURLOPT_CUSTOMREQUEST => "GET",
    //           CURLOPT_POSTFIELDS => "{}",
    //         ));

    //         $response = curl_exec($curl);
    //         $err = curl_error($curl);

    //         curl_close($curl);

    //         if ($err) {
    //           echo "cURL Error #:" . $err;
    //         } else {
    //           echo $response;
    //         }
    //     }
   
    public function cancelOrderBoxme($sbc){
            $url = $this->url_boxme."api/public/api/rest/lading/cancel";
            $data =array();
            $data['TrackingCode'] = $this->request->post['tracking_code'];
            $data['MerchantKey'] =  $this->config->get('boxme_key');
            $curl = curl_init();
                curl_setopt_array($curl, array(
                  CURLOPT_URL => $url,
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => "",
                  CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 30,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => "POST",
                  // CURLOPT_POSTFIELDS => "{\"TrackingCode\":\"SC5659175344\",\"MerchantKey\":\"7e4e80c6bdb03c5a2d639c4828bcf156\"}",
                  CURLOPT_POSTFIELDS => json_encode($data),
                  CURLOPT_HTTPHEADER => array(
                    "content-type: application/json"
                  ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);

                curl_close($curl);

                if ($err) {
                  echo "cURL Error #:" . $err;
                } else {
                  echo $response;
                }
    }
    //  public function cancelOrderBoxmeDemo(){
    //   $url = $this->url_boxme."api/public/api/rest/lading/cancel";
    //         $curl = curl_init();
    //             curl_setopt_array($curl, array(
    //               CURLOPT_URL => $url,
    //               CURLOPT_RETURNTRANSFER => true,
    //               CURLOPT_ENCODING => "",
    //               CURLOPT_MAXREDIRS => 10,
    //                CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
    //               CURLOPT_TIMEOUT => 30,
    //               CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    //               CURLOPT_CUSTOMREQUEST => "POST",
    //               CURLOPT_POSTFIELDS => "{\"TrackingCode\":\"SC5781120433\",\"MerchantKey\":\"c333e43500c3a0a4df7c4b47b6cc35df\"}",
    //               CURLOPT_HTTPHEADER => array(
    //                 "content-type: application/json"
    //               ),
    //             ));

    //             $response = curl_exec($curl);
    //             $err = curl_error($curl);

    //             curl_close($curl);

    //             if ($err) {
    //               echo "cURL Error #:" . $err;
    //             } else {
    //               echo $response;
    //             }
    // }
    public function acceptOrderBoxme(){

        if ($this->request->server['REQUEST_METHOD'] == 'POST') {

            $url = $this->url_boxme."api/public/api/merchant/rest/lading/accept";
            // var_dump($url);
            // die();
            $data =array();
            $data['TrackingCode'] = $this->request->post['TrackingCode'];
            // $data['TrackingCode']  = "";
            $data['MerchantKey'] = $this->config->get('boxme_key');
            $curl = curl_init();
            curl_setopt_array($curl, array(
              // CURLOPT_URL => "http://prod.boxme.vn/api/public/api/merchant/rest/lading/accept",
              CURLOPT_URL => $url,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => json_encode($data),
              // CURLOPT_POSTFIELDS => "{\"TrackingCode\":\"SC5112046532\",\"MerchantKey\":\"7e4e80c6bdb03c5a2d639c4828bcf156\"}",
              CURLOPT_HTTPHEADER => array(
                "content-type: application/json"
              ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              echo $response;
            }
        }
    }
  
        function editproduct($id){
            $this->load->model('catalog/product');
            if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateFormEdit()) {
                $product_boxme=array();
                $product_boxme['InventoryId']= $this->request->post['inventoryid'];
                $product_boxme['ApiKey']= $this->config->get('boxme_key');
                $product_boxme['SellerSKU']= $this->request->post['sku'];
                $product_boxme['Name']= $this->request->post['name'];
                $product_boxme['Description']= '';
                $product_boxme['BasePrice']= (int) $this->request->post['price'];
                $product_boxme['SalePrice']= (int) $this->request->post['product_special'];
                $product_boxme['Weight']= (int) $this->request->post['weight'];
                $product_boxme['Volume']=$this->request->post['length'].'x'.$this->request->post['width'].'x'.$this->request->post['height'];
                $product_boxme['ProductImages']  = $this->request->post['images'];
                $curl = curl_init();
                curl_setopt_array($curl, array( 
                    CURLOPT_URL => $this->url_boxme.'bxapi/'.$this->action_api['editProduct'],
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => json_encode($product_boxme),
                    CURLOPT_HTTPHEADER => array(
                        "authorization: Basic ZHZxdW9jOjEyMzQ1Njc=",
                        "cache-control: no-cache",
                        "content-type: application/json",
                    ),
                ));
                $response = curl_exec($curl);
                    $err = curl_error($curl);

                    curl_close($curl);

                    if ($err) {
                      echo "cURL Error #:" . $err;
                    } else {
                      echo $response;
                    }
            } else {
                $json['editproduct'] = false;
                $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode($json));
            }
        }
        private function validateFormEdit(){
          
                if ((utf8_strlen($this->request->post['inventoryid']) < 1) || (utf8_strlen($this->request->post['inventoryid']) > 64)) {
                    $json['inventoryid'] = 'error_inventoryid';
                }
                if ((utf8_strlen($this->request->post['sku']) < 1) || (utf8_strlen($this->request->post['sku']) > 64)) {
                    $json['sku'] = 'error_sku';
                }
                if ((utf8_strlen($this->request->post['name']) < 1) || (utf8_strlen($this->request->post['name']) > 64)) {
                    $json['name'] = 'error_name';
                }
                if ((utf8_strlen($this->request->post['price']) < 1) || (utf8_strlen($this->request->post['price']) > 64)) {
                    $json['price'] = 'error_price';
                }
                if ((utf8_strlen($this->request->post['weight']) < 1) || (utf8_strlen($this->request->post['weight']) > 64)) {
                    $json['weight'] = 'error_weight';
                }
            
               return !$json;
        }
        public function getCityBoxme(){

            $curl = curl_init();

                curl_setopt_array($curl, array(
                  CURLOPT_URL => $this->url_shipchung."api/merchant/rest/lading/city",
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => "",
                  CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 30,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => "GET",
                  CURLOPT_POSTFIELDS => "",
                  CURLOPT_HTTPHEADER => array(
                    "content-type: application/x-www-form-urlencoded",
                    "headers: {'content-type': 'application/x-www-form-urlencoded'}"
                  ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);

                curl_close($curl);

                if ($err) {
                  echo "cURL Error #:" . $err;
                } else {
                  echo $response;
                }
        }
        public function getWard(){
            $curl = curl_init();

                curl_setopt_array($curl, array(
                  CURLOPT_URL => $this->url_shipchung."api/merchant/rest/lading/ward/52",
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => "",
                  CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 30,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => "GET",
                  CURLOPT_POSTFIELDS => "",
                  CURLOPT_HTTPHEADER => array(
                    "content-type: application/x-www-form-urlencoded",
                    "headers: {'content-type': 'application/x-www-form-urlencoded'}"
                  ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);

                curl_close($curl);

                if ($err) {
                  echo "cURL Error #:" . $err;
                } else {
                  echo $response;
                }
        }
        public function getListProductBoxme(){  
        $this->document->addScript('http://ajax.googleapis.com/ajax/libs/angularjs/1.0.4/angular.min.js');
        $this->document->addScript('http://ajax.googleapis.com/ajax/libs/angularjs/1.0.4/angular-resource.min.js');
        $this->document->addScript('view/javascript/boxme/ui-bootstrap-tpls-0.10.0.min.js');
        $this->document->addStyle('https://cdn.gitcdn.link/cdn/angular/bower-material/v1.1.3/angular-material.css');
        $data['header'] = $this->load->controller('common/header');
        $data['footer'] = $this->load->controller('common/footer');
        $data['token'] = $this->session->data['token'];
        $data['column_left']  = $this->load->controller('common/column_left'); 
            $this->response->setOutput($this->load->view('boxme/getlistproductboxme.tpl',$data));
        }
        // public function getListProductInventory(){
        //     $curl = curl_init();

        //         curl_setopt_array($curl, array(
        //           CURLOPT_URL => $this->url_boxme."bxapi/get_list_products_create_order?sellerSKU=SPT82&inventory_id=132123&ApiKey=".$this->config->get('boxme_key'),
        //           CURLOPT_RETURNTRANSFER => true,
        //           CURLOPT_ENCODING => "",
        //           CURLOPT_MAXREDIRS => 10,
        //           CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
        //           CURLOPT_FOLLOWLOCATION => TRUE, //open ssl
        //           CURLOPT_SSL_VERIFYPEER => false, //open ssl
        //           CURLOPT_TIMEOUT => 30,
        //           CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        //           CURLOPT_CUSTOMREQUEST => "GET",
        //           CURLOPT_POSTFIELDS => "{}",
        //           CURLOPT_HTTPHEADER => array(
        //             "content-type: application/json"
        //           ),
        //         ));

        //         $response = curl_exec($curl);
        //         $err = curl_error($curl);

        //         curl_close($curl);

        //         if ($err) {
        //           echo "cURL Error #:" . $err;
        //         } else {
        //           echo $response;
        //         }
        // }
        private function sendGetToBoxme($url,$data){
            $data=http_build_query($data);
            $CurlStart = curl_init(); 
            curl_setopt ($CurlStart, CURLOPT_URL,$url."?".$data);
            curl_setopt ($CurlStart, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE); // openssl
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // openssl
            curl_setopt ($CurlStart, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.1; nl; rv:1.9.1.11) Gecko/20100701 Firefox/3.5.11");
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Connection: Keep-Alive'
            ));
            $header_size = curl_getinfo($CurlStart, CURLINFO_HEADER_SIZE);
            $source = curl_exec ($CurlStart);
            $json=array();
            $json['code']=$httpcode;
            $json['result']=$source;
            if ($httpcode!=200) {
                 $json['error']=TRUE;
            } else {
                $json['error']=FALSE;
            }
            return $json;
        }
        private function error_boxme(){
            $data['errors']=$this->error;
            $data['error_list']=$this->error_list;
            $data['breadcrumbs'] = array();
            //$this->language->set('heading_title','Báo lỗi boxme');
            $data['breadcrumbs'][] = array(
                    'text' => $this->language->get('text_home'),
                    'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL'),
                
            );

            $data['breadcrumbs'][] = array(
                    'text' => 'Thêm sản phẩm vào kho hàng Boxme',
                    'href' => $this->url->link('catalog/product', 'token=' . $this->session->data['token'] . $url, 'SSL')
            );

            $data['commeback'] = $this->url->link('catalog/product', 'token=' . $this->session->data['token'] . $url, 'SSL');
           $data['header'] = $this->load->controller('common/header');
           $data['column_left'] = $this->load->controller('common/column_left');
           $data['footer'] = $this->load->controller('common/footer');
           $this->response->setOutput($this->load->view('boxme/error_boxme.tpl', $data));
        }
        
        
        private function printBoxme($data,$stop=FALSE){
            // echo "<pre>";
           
           //  // echo json_encode($data);
           $data['ProductId'] =  $data['result']->ProductId;

            // echo "</pre>";
            if($stop)
                die();
        }


}
