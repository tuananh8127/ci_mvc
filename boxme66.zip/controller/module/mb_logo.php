<?php
class ControllerModuleMbLogo extends Controller {
	private $error = array();
	public function index() {
		$this->load->language('module/mb_logo');
		$this->document->setTitle($this->language->get('heading_title_detail'));
		$this->load->model('setting/setting');
                $this->load->model('extension/module');
                $this->load->model('tool/image');
		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_edit'] = $this->language->get('text_edit');
		$data['entry_name'] = $this->language->get('entry_name');
		$data['entry_image'] = $this->language->get('entry_image');
		$data['entry_size'] = $this->language->get('entry_size');
		$data['entry_size_default'] = $this->language->get('entry_size_default');
		$data['entry_size_user'] = $this->language->get('entry_size_user');
		$data['error_name'] = $this->language->get('error_name');
		$data['error_image'] = $this->language->get('error_image');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_show_text'] = $this->language->get('entry_show_text');
		$data['entry_show'] = $this->language->get('entry_show');
		$data['entry_hidden'] = $this->language->get('entry_hidden');
		$data['entry_width'] = $this->language->get('entry_width');
		$data['entry_height'] = $this->language->get('entry_height');
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_module'),
			'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('module/mb_logo', 'token=' . $this->session->data['token'], 'SSL')
		);
                if (!empty($this->request->get['module_id'])) {
                    $data['action'] = $this->url->link('module/mb_logo', 'token=' . $this->session->data['token']."&module_id=".$this->request->get['module_id'], 'SSL');
                }else{
                    $data['action'] = $this->url->link('module/mb_logo', 'token=' . $this->session->data['token'], 'SSL');
                }
                
		$data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');
                
                if (isset($this->request->get['module_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$module_info = $this->model_extension_module->getModule($this->request->get['module_id']);
		}
                
                
                if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		}  
                elseif (!empty($module_info)) {
			$data['name'] = $module_info['name'];
		} else {
			$data['name'] ='';
		}
                if (isset($this->request->post['image'])) {
			$data['image'] = $this->request->post['image'];
		}  
                elseif (!empty($module_info)) {
			$data['image'] = $module_info['image'];
		} else {
			$data['image'] ='no_image.png';
		}
                
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		}  
                elseif (!empty($module_info)) {
			$data['status'] = $module_info['status'];
		} else {
			$data['status'] = 1;
		}
                if (isset($this->request->post['logo_text'])) {
			$data['logo_text'] = $this->request->post['logo_text'];
		} elseif (!empty($module_info)) {
			$data['logo_text'] = $module_info['logo_text'];
		} else {
			$data['logo_text'] =1;
		}
                
                if (isset($this->request->post['size'])) {
			$data['size'] = $this->request->post['size'];
		} elseif (!empty($module_info)) {
			$data['size'] = $module_info['size'];
		} else {
			$data['size'] =1;
		}
                
                list($width, $height, $type, $attr) = @getimagesize(DIR_IMAGE.$data['image']);
                
                if (!empty($this->request->post['width'])) {
			$data['width'] = $this->request->post['width'];
		} elseif (!empty($module_info)) {
			$data['width'] = $module_info['width'];
		} else {
			$data['width'] = $width;
		}
                $this->request->post['width']=$data['width'];
                
                if (!empty($this->request->post['height'])) {
			$data['height'] = $this->request->post['height'];
		} elseif (!empty($module_info)) {
			$data['height'] = $module_info['height'];
		} else {
			$data['height'] = $height;
		}
                
                
                
                $this->request->post['height']=$data['height'];
                
                $data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);
                
                if (isset($this->request->post['image']) && is_file(DIR_IMAGE . $this->request->post['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($this->request->post['image'], 100, 100);
		} elseif (!empty($module_info['image']) && is_file(DIR_IMAGE . $module_info['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($module_info['image'], 100, 100);
		} else {
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		}
                
                
                if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
                        if (!isset($this->request->get['module_id'])) {
                                $id_module=$this->model_extension_module->addModule('mb_logo', $this->request->post);
                        } else {
                                $id_module=$this->model_extension_module->editModule($this->request->get['module_id'], $this->request->post);
                        }
                        $all_module_child=$this->model_extension_module->getModulesByCode("mb_logo");
                        $module_child_current=array('module_id'=>0);
                        foreach ($all_module_child as $key_module_child=>$item_module_child){
                            if($module_child_current['module_id']<$item_module_child['module_id'])
                                    $module_child_current=$item_module_child;
                        }
                        if(!empty($this->request->get['module_id']))
                            $module_child_current['module_id']=$this->request->get["module_id"];
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('module/mb_logo', 'token=' . $this->session->data['token']."&module_id=".$module_child_current['module_id'], 'SSL'));
                }
                if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}
                if (isset($this->error['image'])) {
			$data['error_image'] = $this->error['image'];
		} else {
			$data['error_image'] = '';
		}
                if (isset($this->error['size'])) {
			$data['error_size'] = $this->error['size'];
		} else {
			$data['error_size'] = '';
		}
                if (isset($this->error['warning'])) {
                        $data['error_warning'] = $this->error['warning'];
                } else {
                        $data['error_warning'] = '';
                }
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('module/mb_logo.tpl', $data));
	}
	protected function validate() {
		if (!$this->user->hasPermission('modify', 'module/mb_logo')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
                if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 64)) {
			$this->error['name'] = $this->language->get('error_name');
		}
                if (empty($this->request->post['image'])) {
			$this->error['image'] = $this->language->get('error_image');
		}
                if ($this->request->post['size']==1) {
                        if(empty($this->request->post['width']) || empty($this->request->post['height'])){
                            $this->error['size'] = $this->language->get('error_size');
                        }
		}
		return !$this->error;
	}
}