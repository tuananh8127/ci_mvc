<?php

define('URL_HOME','http://localhost/app/boxme/');
define('DIR_HOME','http://localhost/app/boxme/');
// HTTP
define('HTTP_SERVER', URL_HOME.'admin/');
define('HTTP_CATALOG', URL_HOME);

// HTTPS
define('HTTPS_SERVER', URL_HOME.'admin/');
define('HTTPS_CATALOG', URL_HOME);
// HTTPS


// DIR
define('DIR_APPLICATION', 'D:/ANHVT/wamp64/www/app/boxme/admin/');
define('DIR_SYSTEM', 'D:/ANHVT/wamp64/www/app/boxme/system/');
define('DIR_LANGUAGE', 'D:/ANHVT/wamp64/www/app/boxme/admin/language/');
define('DIR_TEMPLATE', 'D:/ANHVT/wamp64/www/app/boxme/admin/view/template/');
define('DIR_CONFIG', 'D:/ANHVT/wamp64/www/app/boxme/system/config/');
define('DIR_IMAGE', 'D:/ANHVT/wamp64/www/app/boxme/image/');
define('DIR_CACHE', 'D:/ANHVT/wamp64/www/app/boxme/system/cache/');
define('DIR_DOWNLOAD', 'D:/ANHVT/wamp64/www/app/boxme/system/download/');
define('DIR_UPLOAD', 'D:/ANHVT/wamp64/www/app/boxme/system/upload/');
define('DIR_LOGS', 'D:/ANHVT/wamp64/www/app/boxme/system/logs/');
define('DIR_MODIFICATION', 'D:/ANHVT/wamp64/www/app/boxme/system/modification/');
define('DIR_CATALOG', 'D:/ANHVT/wamp64/www/app/boxme/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'boxme');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');