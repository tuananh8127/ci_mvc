<?php 
$_["getting_start"]="Setting start";
$_["step_1"]="Step 1";
$_["step_2"]="Step 2";
$_["step_3"]="Step 3";
$_["step_4"]="Step 4";
$_["text_title_main_basic_info"]="Basic infomation";
$_["text_title_basic_info"]="Enter basic information";



