<?php
$_['heading_title']="Thiết lập cài đặt Chili Shop";
$_['text_edit']="Quản lý tên miền";
$_['entry_name_domain']="Nhập tên miền quản lý";
$_['error_chili_setting_domain']="Tên miền quản lý phải từ 1 -> 100 ký tự";
$_['button_save']="Lưu thiết lập";
