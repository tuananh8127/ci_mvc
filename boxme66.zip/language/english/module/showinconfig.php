<?php
// Heading
$_['heading_title']      = 'Show it on tabs! <span class="text-primary">[<i class="fa fa-cogs"></i> Config]</span> ';

?>