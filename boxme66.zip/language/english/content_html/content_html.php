<?php
$_["heading_title"]="Module text";
$_["text_action"]="Action";
$_["text_status"]="Status";