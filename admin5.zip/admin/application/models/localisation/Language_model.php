<?php 
class Language_model extends CI_Model {
	public function __construct(){
		parent::__construct();
	}
	public function index(){
		
	}
	public function getAll($where = NULL){
		if(isset($where)){
			$this->db->where($where);
		}
		 $this->db->order_by('language_name', 'ASC');
		$query = $this->db->get('ci_languages');
		if ($query->num_rows() > 0){
			return $query->result();
		}
		return FALSE;
	}
	public function getById(){



	}	
	public function createLanguage($data){

		if($data['default'] == '1'){
			$this->db->where('language_default', '1');
			$this->db->update('ci_languages', array('default' => '0'));
		} 
		return $this->db->insert('ci_languages', $data);

	}
	public function updateLanguage(){

	}
	public function deleteLanguage(){

	}
}