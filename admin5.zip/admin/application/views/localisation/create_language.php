<?php $this->load->view('common/header'); ?>
<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">
  <!-- Left side column. contains the logo and sidebar -->
<?php $this->load->view('common/menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        General Form Elements
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
      </ol>
      <div class="ajax-content">
            </div>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-pencil"></i> Thêm Ngôn ngữ</h3>
      </div>
      <div class="panel-body">
      <?php echo form_open('', array('class'=>'form-horizontal')); ?>
      <!--   <form id="form-language" class="form-horizontal"> -->
          <div class="form-group required">
              <?php echo form_label('Language name', 'language_name', array('class'=> 'col-sm-2 control-label')); ?>
            <div class="col-sm-10">
            <?php echo form_input('language_name', set_value('language_name'), 'class="form-control"') ?>
            <div class="text-danger"><?php echo form_error('language_name'); ?></div>
            </div>
          </div>
           <div class="form-group required">
              <?php echo form_label('Language slug', 'language_slug', array('class'=> 'col-sm-2 control-label')); ?>
             
            <div class="col-sm-10">
            <?php echo form_input('language_slug', set_value('language_slug'), 'class="form-control"') ?>
            <div class="text-danger"> <?php echo form_error('language_slug'); ?></div>
          </div>
          </div>

         
          <div class="form-group required">
              <?php echo form_label('Language directory', 'language_directory', array('class'=> 'col-sm-2 control-label')); ?>
              
            <div class="col-sm-10">
            <?php echo form_input('language_directory', set_value('language_directory'), 'class="form-control"') ?>
            <div class="text-danger"><?php echo form_error('language_directory'); ?></div>
          </div>
          </div>

          <div class="form-group required">
              <?php echo form_label('Language code', 'language_code', array('class'=> 'col-sm-2 control-label')); ?>
              
            <div class="col-sm-10">
            <?php echo form_input('language_code', set_value('language_code'), 'class="form-control"') ?>
             <div class="text-danger"><?php echo form_error('language_code'); ?></div>
          </div>
          </div>

           <div class="form-group required">
            <?php echo form_label('Default language','language_default', array('class'=> 'col-sm-2 control-label')); ?>
            <div class="col-sm-10">
            <?php echo form_dropdown('language_default',array('0' => 'Not default', '1'=>'Language Default'),set_value('default',0),'class="form-control"');
            ?>
            </div>
        </div>
           <div class="box-footer">
              <p> <i class="fa fa-spin fa-refresh"></i>&nbsp;<input type="submit" name="submit" value="Create User" class="ajax btn btn-info" title="Ajax Request">
            </p>
              <?php echo form_close();?>
          </div>
     
      </div>
    </div>
  </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

</div>
<!-- ./wrapper -->
<?php $this->load->view('common/footer'); ?>

