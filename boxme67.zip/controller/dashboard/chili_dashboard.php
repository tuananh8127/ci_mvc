<?php
class ControllerDashboardChiliDashboard extends Controller {
	public function index() {
		$this->load->language('dashboard/chili_dashboard');
		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_limit_data'] = $this->language->get('text_limit_data');
		$data['text_infomation'] = $this->language->get('text_infomation');
                
		$data['text_limit_data_max'] = $this->language->get('text_limit_data_max');
		$data['text_limit_data_use'] = $this->language->get('text_limit_data_use');
		$data['text_limit_data_remaining'] = $this->language->get('text_limit_data_remaining');
                
		$data['text_info_start'] = $this->language->get('text_info_start');
		$data['text_info_use'] = $this->language->get('text_info_use');
		$data['text_info_end'] = $this->language->get('text_info_end');
                
		$data['text_upgrade_now'] = $this->language->get('text_upgrade_now');
		$data['text_extend'] = $this->language->get('text_extend');
		$data['text_product'] = $this->language->get('text_product');
		$data['text_emtry'] = $this->language->get('text_emtry');
                
		$data['text_app_need'] = $this->language->get('text_app_need');
                
                $data_domain="";
                $get_domain=$this->config->get("chili_setting_domain");
                if(!empty($get_domain)){
                    $data_domain=$this->config->get("chili_setting_domain");
                }
                $data_chili= @file_get_contents("http://api.chiliweb.management/Api/Values?domain=".$data_domain);
                $data_chili=json_decode($data_chili);
                if(!empty($data_chili)){ 
                    $this->load->model('catalog/product');
                    $data['product_total'] = $this->model_catalog_product->getTotalProducts(array());
                    $data['dinhmuc']=$data_chili->DanhSachDinhMucDuLieu;
                    $data['DanhSachCacUngDungBanCoTheCan']=$data_chili->DanhSachCacUngDungBanCoTheCan;
                    $data['DanhSachThongTinDichVu']=$data_chili->DanhSachThongTinDichVu;
                    $data['DanhSachCacUngDungDaMua']=$data_chili->DanhSachCacUngDungDaMua;
                    $data['DanhSachCacTinMoiTuMatBao']=$data_chili->DanhSachCacTinMoiTuMatBao;
                    $data['flag']=true;
                }else{
                    $data['flag']=false;
                }
               return $this->load->view('dashboard/chili_dashboard.tpl', $data);
	}
}