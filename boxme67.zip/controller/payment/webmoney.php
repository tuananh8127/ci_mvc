<?php
class ControllerPaymentWebMoney extends Controller {
        private $error = array(); 
        public function index() {
        $this->load->language('payment/webmoney');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
                  $this->model_setting_setting->editSetting('webmoney', $this->request->post);				
                  $this->session->data['success'] = $this->language->get('text_success');
                  $this->response->redirect($this->url->link('payment/webmoney', 'token=' . $this->session->data['token'], 'SSL'));
          }
        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['entry_passcode'] = $this->language->get('entry_passcode');
        $data['entry_passcode_help'] = $this->language->get('entry_passcode_help');
        $data['entry_secretkey'] = $this->language->get('entry_secretkey');
        $data['entry_secretkey_help'] = $this->language->get('entry_secretkey_help');
        $data['entry_merchant_code'] = $this->language->get('entry_merchant_code');
        $data['entry_merchant_code_help'] = $this->language->get('entry_merchant_code_help');
        $data['entry_order_status_start'] = $this->language->get('entry_order_status_start');
        $data['entry_order_status_start_help'] = $this->language->get('entry_order_status_start_help');
        $data['entry_order_status_end'] = $this->language->get('entry_order_status_end');
        $data['entry_order_status_end_help'] = $this->language->get('entry_order_status_end_help');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_sort_order'] = $this->language->get('entry_sort_order');
        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');
        $data['tab_general'] = $this->language->get('tab_general');
        $data['entry_order_notify'] = $this->language->get('entry_order_notify');
        $data['entry_order_des_notify'] = $this->language->get('entry_order_des_notify');
        $data['text_yes'] = $this->language->get('text_yes');
        $data['text_no'] = $this->language->get('text_no');
        
        // Set Error
        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }
        
        if (isset($this->error['passcode'])) {
            $data['error_passcode'] = $this->error['passcode'];
        } else {
            $data['error_passcode'] = '';
        }
        if (isset($this->error['secretkey'])) {
            $data['error_secretkey'] = $this->error['secretkey'];
        } else {
            $data['error_secretkey'] = '';
        }
        if (isset($this->error['merchant_code'])) {
            $data['error_merchant_code'] = $this->error['merchant_code'];
        } else {
            $data['error_merchant_code'] = '';
        }
        
        // Breadcrumbs 
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => false
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_payment'),
            'href' => $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => ' :: '
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('payment/webmoney', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => ' :: '
        );
        
        // Set button 
        $data['action'] = $this->url->link('payment/webmoney', 'token=' . $this->session->data['token'], 'SSL');
        $data['cancel'] = $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL');

        // Set Attribute field
        if (isset($this->request->post['webmoney_passcode'])) {
            $data['webmoney_passcode'] = $this->request->post['webmoney_passcode'];
        } else {
            $data['webmoney_passcode'] = $this->config->get('webmoney_passcode');
        }
        if (isset($this->request->post['webmoney_secretkey'])) {
            $data['webmoney_secretkey'] = $this->request->post['webmoney_secretkey'];
        } else {
            $data['webmoney_secretkey'] = $this->config->get('webmoney_secretkey');
        }
        if (isset($this->request->post['webmoney_merchant_code'])) {
            $data['webmoney_merchant_code'] = $this->request->post['webmoney_merchant_code'];
        } else {
            $data['webmoney_merchant_code'] = $this->config->get('webmoney_merchant_code');
        }
        
        if (isset($this->request->post['webmoney_order_status_start'])) {
            $data['webmoney_order_status_start'] = $this->request->post['webmoney_order_status_start'];
        } else {
            $data['webmoney_order_status_start'] = $this->config->get('webmoney_order_status_start');
        }
        if (isset($this->request->post['webmoney_order_status_end'])) {
            $data['webmoney_order_status_end'] = $this->request->post['webmoney_order_status_end'];
        } else {
            $data['webmoney_order_status_end'] = $this->config->get('webmoney_order_status_end');
        }
        if (isset($this->request->post['webmoney_status'])) {
            $data['webmoney_status'] = $this->request->post['webmoney_status'];
        } else {
            $data['webmoney_status'] = $this->config->get('webmoney_status');
        }
        if (isset($this->request->post['webmoney_sort_order'])) {
            $data['webmoney_sort_order'] = $this->request->post['webmoney_sort_order'];
        } else {
            $data['webmoney_sort_order'] = $this->config->get('webmoney_sort_order');
        }
        if (isset($this->request->post['webmoney_order_notify'])) {
            $data['webmoney_order_notify'] = $this->request->post['webmoney_order_notify'];
        } else if($this->config->get('webmoney_order_notify')){
            $data['webmoney_order_notify'] = $this->config->get('webmoney_order_notify');
        }
        // Get status order
        $this->load->model('localisation/order_status');
        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
        
        // Get layout
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        // render template
        $this->response->setOutput($this->load->view('payment/webmoney.tpl', $data));
    }
function checkauthor($apiKey){	
    return $apiKey;
}
private function validate() {
        if (!$this->user->hasPermission('modify', 'payment/webmoney')) {
        $this->error['warning'] = $this->language->get('error_permission');
        }	
        if (!$this->request->post['webmoney_passcode']) {
        $this->error['passcode'] = $this->language->get('error_passcode');
        }
        if (!$this->request->post['webmoney_secretkey']) {
        $this->error['secretkey'] = $this->language->get('error_secretkey');
        }
        if (!$this->request->post['webmoney_merchant_code']) {
        $this->error['merchant_code'] = $this->language->get('error_merchant_code');
        }
	if (!$this->error) {
            return true;
        } else {
            return false;
        }		
  }
public function install() {   

}
public function uninstall() {

  }
}
?>