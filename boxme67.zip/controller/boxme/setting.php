<?php
if (is_file('config_boxme.php')) {
    require_once('config_boxme.php');
}
class ControllerBoxmeSetting extends Controller { 
    private $error = array();
    private $error_list = array();
    public $url_boxme=URL_API;  
    public $url_shipchung = URL_SHIPCHUNG;
    public $client_secret = CLIENT_SECRET; 
        private $action_api=array( 
            'warehouse'=>'list_inventory-sdk',
            'addProduct'=>'product-sdk',
            'editProduct'=>'edit-product-sdk',
            'shipment'=>'shipment-sdk',
        );
        
        public function index() {
            $this->document->addScript('https://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular.js');
            $this->document->addScript('https://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-route.min.js');
            $this->language->load("boxme/setting");
            $this->load->model("setting/setting");
            $data=array();
            $data['text_none'] = $this->language->get('text_none');
            $data['token'] = $this->session->data['token'];
            $data['heading_title']=$this->language->get("heading_title");
            $data['text_edit']=$this->language->get("text_edit");
            $data['text_disabled']=$this->language->get("text_disabled");
            $data['text_enabled']=$this->language->get("text_enabled");
            $data['entry_status']=$this->language->get("entry_status");
            $data['entry_key']=$this->language->get("entry_key");
            $data['text_config']=$this->language->get("text_config");
            $data['text_select_warehouse']=$this->language->get("text_select_warehouse");
            $data['text_warehouseshop']=$this->language->get("text_warehouseshop");
            $data['text_warehouseboxme']=$this->language->get("text_warehouseboxme");
            $data['text_warehousedefault']=$this->language->get("text_warehousedefault");
            $data['text_selectdefault']=$this->language->get("text_selectdefault"); 
            $data['text_functional']=$this->language->get("text_functional");  
            $data['text_errorkey']=$this->language->get("text_errorkey");
            $data['text_savesuccess']=$this->language->get("text_savesuccess");
            $data['text_validation']=$this->language->get("text_validation");            
            $data['breadcrumbs'] = array();

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_object'),
                'href' => $this->url->link('boxme/dashboard', 'token=' . $this->session->data['token'], 'SSL')
            );
            $data['listProductBoxme'] = $this->url->link('boxme/product/getListProductBoxme', 'token=' . $this->session->data['token'], 'SSL');
            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('boxme/setting', 'token=' . $this->session->data['token'], 'SSL')
            );
            
            if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) { 
            $this->model_setting_setting->editSetting('boxme', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('boxme/setting', 'token=' . $this->session->data['token'], 'SSL'));
        }
            
            $data['getwarehouse']=$this->url->link('boxme/setting/getWareHouse', 'token=' . $this->session->data['token'], 'SSL');
            
            if (isset($this->request->post['boxme_status'])) {
            $data['boxme_status'] = $this->request->post['boxme_status'];
            } else {
            $data['boxme_status'] = $this->config->get('boxme_status');
            }
            if (isset($this->request->post['boxme_key'])) {
                    $data['boxme_key'] = $this->request->post['boxme_key'];
            } else {
                    $data['boxme_key'] = $this->config->get('boxme_key');
            }
           
            
            if (isset($this->request->post['boxme_default_input_boxme'])) {
                    $data['boxme_default_input_boxme'] = $this->request->post['boxme_default_input_boxme'];
            } else {
                    $data['boxme_default_input_boxme'] = $this->config->get('boxme_default_input_boxme');
            }
            
            if (isset($this->request->post['boxme_warehouse_chili'])) {
                    $data['boxme_warehouse_chili'] = $this->request->post['boxme_warehouse_chili'];
            } else {
                    $data['boxme_warehouse_chili'] = $this->config->get('boxme_warehouse_chili');
            }
            if (isset($this->request->post['boxme_warehouse_boxme'])) {
                    $data['boxme_warehouse_boxme'] = $this->request->post['boxme_warehouse_boxme'];
            } else {
                    $data['boxme_warehouse_boxme'] = $this->config->get('boxme_warehouse_boxme');
            }
           
            $data['button_save']=  $this->language->get('button_save');
            $data['action']=  $this->url->link('boxme/setting','token='.$this->session->data['token'], 'SSL'); 
            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');

            $this->response->setOutput($this->load->view('boxme/setting.tpl', $data));
        }
         public function createProvince(){
          $this->load->model("setting/setting");
            if($this->request->post['name']) {
              $data['name'] = $this->request->post['name'];
            } else {
              $data['name'] = "";
            }
            if($this->request->post['user_name']) {
              $data['user_name'] = $this->request->post['user_name'];
            } else {
              $data['user_name'] = "";
            }
            if($this->request->post['phone']) {
              $data['phone'] = $this->request->post['phone'];
            } else {
              $data['phone'] = "";
            }
            if($this->request->post['city_id']) {
              $data['city_id'] = $this->request->post['city_id'];
            } else {
              $data['city_id'] = "";
            }
            if($this->request->post['province_id']) {
              $data['province_id'] = $this->request->post['province_id'];
            } else {
              $data['province_id'] = "";
            }
            if($this->request->post['ward_id']) {
              $data['ward_id'] = $this->request->post['ward_id'];
            } else {
              $data['ward_id'] = "";
            }
             if($this->request->post['address']) {
              $data['address'] = $this->request->post['address'];
            } else {
              $data['address'] = "";
            }
            if ($this->request->server['REQUEST_METHOD'] == 'POST') {
            $data['MerchantKey'] = $this->config->get('boxme_key');
            $data['name'] = $data['name'];
            $data['user_name'] = $data['user_name'];
            $data['phone'] = $data['phone'];
            $data['city_id'] = (int)$data['city_id'];
            $data['province_id'] = (int)$data['province_id'];
            $data['ward_id'] = (int)$data['ward_id'];
            $data['address'] = (int)$data['address'];
            $url = "http://services.shipchung.vn/api/merchant/rest/lading/create-inventory";
            $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => $url,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false, //open ssl
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => json_encode($data),
              CURLOPT_HTTPHEADER => array(
                "content-type: application/json"
              ),
            ));
            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              echo $response;
            }
          } else {
            echo json_encode($json = false);
          }
        }
        public function settingBoxme() {
            $this->load->model("setting/setting"); 
            if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateSettingBoxme()) { 
            $this->model_setting_setting->editSetting('boxme', $this->request->post);
             $json['success'] = true;
            } else {
                $json['success'] = false;
            }
            $this->response->addHeader('Content-Type: application/json');
             $this->response->setOutput(json_encode($json));
          
        }
        protected function validateSettingBoxme() {
            if ((utf8_strlen($this->request->post['boxme_key']) < 1) || (utf8_strlen($this->request->post['boxme_key']) > 64)) {
              $json['error_setting'] = true;
            } 
             return !$json;
        }
        
       

        protected function validate() { 
        
        if (!$this->user->hasPermission('modify', 'boxme/setting')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }
        function installBoxme(){
            $this->load->model('extension/event');
            $this->model_extension_event->addEvent('boxme_after_add_product', 'post.admin.product.add', 'boxme/setting/addproduct');
            $this->model_extension_event->addEvent('boxme_after_edit_product','post.admin.product.edit', 'boxme/setting/editproduct');
        }
        function unstallBoxme(){ 
            $this->load->model('extension/event');
            $this->model_extension_event->deleteEvent('boxme_after_add_product');
            $this->model_extension_event->deleteEvent('boxme_after_edit_product');
        }
        // Add product
       
           function addproduct($id){
           
            $data['boxme_status'] = $this->config->get('boxme_status');
            $this->load->model('catalog/product');
            $this->load->model('catalog/manufacturer');
            $product=$this->model_catalog_product->getProduct($id);
            $product_specials = $this->model_catalog_product->getProductSpecials($id);
            foreach ($product_specials  as $product_special) {
                if (($product_special['date_start'] == '0000-00-00' || strtotime($product_special['date_start']) < time()) && ($product_special['date_end'] == '0000-00-00' || strtotime($product_special['date_end']) > time())) {
                    $special = $product_special['price'];

                    break;
                }
            }
            $product_des=$this->model_catalog_product->getProductDescriptions($id);
            $product_boxme=array();
            $manufacturer_info = $this->model_catalog_manufacturer->getManufacturer($product['manufacturer_id']);
            if($product['location']){
                 $product_boxme['InventoryId']= $product['location'];
             } else {
                $product_boxme['InventoryId'] = $this->config->get('boxme_warehouse_chili');
             }
            $product_boxme['ApiKey']=$this->config->get('boxme_key');
            $product_boxme['SellerSKU']=$product['sku'];
            $product_boxme['Name']=$product['name'];
            $product_boxme['CategoryName']= $product['name'];
            $product_boxme['SupplierName']= 'CHILI'; //Nhà cung cấp
            $product_boxme['BrandName']= $manufacturer_info['name'];//Thương hiệu
            $product_boxme['Description']= '';
            $product_boxme['ProductTags']='CHILI,'.$product['tag'];
            $product_boxme['Quantity']=(int) $product['quantity'];
            $product_boxme['BasePrice']=(int) $product['price'];
            $product_boxme['SalePrice']=(int) $product_special['price'];
            $product_boxme['BarcodeManufacturer']="CHILI Manufacturer";
            $product_boxme['ModelName']=$product['model'];
            $product_boxme['Weight']=(int) $product['weight'];
            $product_boxme['Volume']=$product['length'].'x'.$product['width'].'x'.$product['height'];
            $product_boxme['ProductImages']= $product['image'];
            if($data['boxme_status'] == 1 && $product['status_boxme'] == 1) {
                $curl = curl_init();
                curl_setopt_array($curl, array(
                  CURLOPT_URL => $this->url_boxme."bxapi/product-sdk",
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => "",
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false, ///ext openssl
                  CURLOPT_TIMEOUT => 30,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => "POST",
                  CURLOPT_POSTFIELDS => json_encode($product_boxme),
                  CURLOPT_HTTPHEADER => array(
                    "content-type: application/json"
                  ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);

                curl_close($curl);

                if ($err) {
                  echo "cURL Error #:" . $err;
                } else {
                  $result= json_decode($response);
                   $ProductId =  $result->ProductId;
                    $this->updateProductidBoxme($id,$ProductId);
                }
            }
        }
        // input into warehoures. Nhập kho tuan anh
        function shipment($data){
            $this->load->model('setting/setting');
            $data_shipment=array();
            $data_shipment['ApiKey']= $this->config->get('boxme_key');
            if(isset($this->request->post['boxme_warehouse_boxme'])){
                $data['boxme_warehouse_boxme'] = $this->request->post['boxme_warehouse_boxme'];
            } else {
                $data['boxme_warehouse_boxme'] = "";
            }
            if(isset($this->request->post['volume'])){
                $data['Volume'] = $this->request->post['volume'];
            } else {
                $data['Volume'] = "0x0x0";
            }
            if(isset($this->request->post['typetransport'])){
                $data['TypeTransport'] = $this->request->post['typetransport'];
            } else {
                $data['TypeTransport'] = "1";
            }
             if(isset($this->request->post['weight'])){
                $data['Weight'] = (int)$this->request->post['weight'];
            } else {
                $data['Weight'] = 0;
            }
             if(isset($this->request->post['sku'])){
                $data['SellerSKU'] = $this->request->post['sku'];
            } else {
                $data['SellerSKU'] = "SP-224";
            }
             if(isset($this->request->post['quantity'])){
                $data['Quantity'] = $this->request->post['quantity'];
            } else {
                $data['Quantity'] = "10";
            }
             if(isset($this->request->post['boxme_mothed_shipping'])){
                $data['boxme_mothed_shipping'] = $this->request->post['boxme_mothed_shipping'];
            } else {
                $data['boxme_mothed_shipping'] = "BOXME";
            }
            if(isset($this->request->post['boxme_mothed_shipping'])){
                $data['shippingmethod'] = $this->request->post['shippingmethod'];
            } else {
                $data['shippingmethod'] = $data['boxme_mothed_shipping'];
            }
            $data_shipment['ShipToAddress']=array('InventoryId'=>$data['boxme_warehouse_boxme']); //@TODO: For customer option Boxme warehouse.
            $data_shipment['ShipFromAddress']=array('InventoryId'=>$this->config->get('boxme_warehouse_chili'));
            $data_shipment['TypeTransport']= $data['TypeTransport'];
            $data_shipment['ShipmentStatus']="ReadyToShip";
            $data_shipment['Volumes']= $data['Volume'];
            $data_shipment['Weight']=$data['Weight'];
            $data_shipment['ShippingMethod']= $data['shippingmethod']; //@TODO: for setting at the editing page and setting page

            $data_shipment['ShipmentItems']=array(
                array(
                    'SKU'=>$data['SellerSKU'],
                    'QuantityShipped'=>$data['Quantity'], 
                    
            ));
            
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $this->url_boxme."bxapi/shipment-sdk",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => json_encode($data_shipment), 
                CURLOPT_HTTPHEADER => array(
                    "authorization: Basic ZHZxdW9jOjEyMzQ1Njc=",
                    "cache-control: no-cache",
                    "content-type: application/json",
                ),
            ));
            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              echo $response;
            }
        }

        //Thêm sản phẩm vào boxme
        function inputShipmentBoxme(){
            if(isset($this->request->post['selected'])) {
                        $json=array();
                        $this->load->model('catalog/product');
                         foreach ($this->request->post['selected'] as $product_id) {
                            $product=$this->model_catalog_product->getProduct($product_id);
                            $product_des=$this->model_catalog_product->getProductDescriptions($product_id);
                            $product_boxme=array();
                            $product_boxme['InventoryId']=$this->config->get('boxme_warehouse_chili');  
                            $product_boxme['ApiKey']=$this->config->get('boxme_key');
                            $product_boxme['SellerSKU']=$product['sku'];
                            $product_boxme['Name']=$product['name'];
                            $product_boxme['CategoryName']= $product['category'];
                            $product_boxme['SupplierName']=$product['manufacturer']; //Nhà cung cấp
                            $product_boxme['BrandName']=$product['manufacturer']; //Thương hiệu
                            $product_boxme['Description']= '';
                            $product_boxme['ProductTags']='CHILI,'.$product['tag'];
                            $product_boxme['Quantity']=(int) $product['quantity'];
                            $product_boxme['BasePrice']=(int) $product['price'];
                            $product_boxme['SalePrice']=(int) $product['price'];
                            $product_boxme['BarcodeManufacturer']= "CHILI Manufacturer";
                            $product_boxme['ModelName']=$product['model'];
                            $product_boxme['Weight']=(int) $product['weight'];
                            $product_boxme['Volume']=$product['length'].'x'.$product['width'].'x'.$product['height'];
                            $product_boxme['ProductImages']=$product['image'];
                            // Add product to Boxme
                            $result=$this->sendPostToBoxme($this->url_boxme.'bxapi/'.$this->action_api['addProduct'],$product_boxme);
                            $productidboxme =  $result['result']->ProductId;
                            if($productidboxme == 0) {
                                $this->updateProductidBoxme($product_id, $product['productid_boxme']);
                            } elseif($productidboxme != 0) {
                                $this->updateProductidBoxme($product_id, $productidboxme);
                            }
                            $json[$product_id]['addproduct']['name']=$product['name'];
                            $json[$product_id]['addproduct']['id']=$product_id;
                            if($result['error']==FALSE && $result['code']==200){ 
                                $json[$product_id]['addproduct']['sucess']=TRUE;
                                // Shipment product to Boxme.
                                $result=$this->sendPostToBoxme($this->url_boxme.'bxapi/'.$this->action_api['shipment'],$product_boxme);
                                $json[$product_id]['shipment']['name']=$product['name'];
                                $json[$product_id]['shipment']['id']=$product_id;
                                if($result['error']==FALSE && $result['code']==200){
                                    $json[$product_id]['shipment']['sucess']=TRUE;
                                }else{
                                    $json[$product_id]['shipment']['sucess']=false;
                                }
                            }else{
                                $json[$product_id]['addproduct']['sucess']=FALSE;
                                $json[$product_id]['shipment']['name']=$product['name'];
                                $json[$product_id]['shipment']['id']=$product_id;
                                $json[$product_id]['shipment']['sucess']=false;
                            }
            }
                        $this->error_list=$json;
                        $this->error_boxme();
            }else{
                $this->error[]="Không có sản phẩm nào được chọn";
                $this->error_boxme();
            }
        }
        
        function inputShipmentBoxme2(){
            if(isset($this->request->post['selected'])) {
                        $json=array();
                        $this->load->model('catalog/product');
                         foreach ($this->request->post['selected'] as $product_id) {
                            $product=$this->model_catalog_product->getProduct($product_id);
                            $product_des=$this->model_catalog_product->getProductDescriptions($product_id);
                            $product_boxme=array();
                            $product_boxme['InventoryId']=$this->config->get('boxme_warehouse_chili');  
                            $product_boxme['ApiKey']=$this->config->get('boxme_key');
                            $product_boxme['SellerSKU']=$product['sku'];
                            $product_boxme['Name']=$product['name'];
                            $product_boxme['CategoryName']= $product['category'];
                            $product_boxme['SupplierName']=$product['manufacturer'];
                            $product_boxme['BrandName']=$product['manufacturer'];
                            $product_boxme['Description']= '';
                            $product_boxme['ProductTags']='CHILI,'.$product['tag'];
                            $product_boxme['Quantity']=(int) $product['quantity'];
                            $product_boxme['BasePrice']=(int) $product['price'];
                            $product_boxme['SalePrice']=(int) $product['price'];
                            $product_boxme['BarcodeManufacturer']="CHILI Manufacturer";
                            $product_boxme['ModelName']=$product['model'];
                            $product_boxme['Weight']=(int) $product['weight'];
                            $product_boxme['Volume']=$product['length'].'x'.$product['width'].'x'.$product['height'];
                            $product_boxme['ProductImages']=$product['image'];
                            $curl = curl_init();
                            curl_setopt_array($curl, array(
                              CURLOPT_URL => $this->url_boxme."bxapi/product-sdk",
                              CURLOPT_RETURNTRANSFER => true,
                              CURLOPT_ENCODING => "",
                              CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                              CURLOPT_MAXREDIRS => 10,
                              CURLOPT_TIMEOUT => 30,
                              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                              CURLOPT_CUSTOMREQUEST => "POST",
                              CURLOPT_POSTFIELDS => json_encode($product_boxme),
                              CURLOPT_HTTPHEADER => array(
                                "content-type: application/json"
                              ),
                            ));

                            $response = curl_exec($curl);
                            $err = curl_error($curl);

                            curl_close($curl);

                            if ($err) {
                              echo "cURL Error #:" . $err;
                            } else {
                              $yummy = json_decode($response);
                            $productid_boxme =  $yummy->ProductId;
                            $this->updateProductidBoxme($product_id,$productid_boxme);
                            $json[$product_id]['success'] = $productid_boxme;

                            }  
            }
                      
            }else{
                $json['success'] = false;
            }
            $this->response->addHeader('Content-Type: application/json');
             $this->response->setOutput(json_encode($json));
        }
        private function updateProductidBoxme($product_id, $productid_boxme){
            $this->load->model('boxme/product');
            $this->model_boxme_product->updateProductidBoxme($product_id,$productid_boxme);
        }
       
         function addProductBoxme(){
                        $json=array();
                        $this->load->model('catalog/product');
                            $product=$this->model_catalog_product->getProduct($this->request->post['product_id']);
                            $product_des=$this->model_catalog_product->getProductDescriptions($this->request->post['abcd']);
                            $product_boxme=array();
                            $product_boxme['InventoryId']=$this->config->get('boxme_warehouse_chili');  
                            $product_boxme['ApiKey']=$this->config->get('boxme_key');
                            $product_boxme['SellerSKU']=$product['sku'];
                            $product_boxme['Name']= $product['name'];
                            $product_boxme['CategoryName']= $product['category'];
                            $product_boxme['SupplierName']= $product['manufacturer'];
                            $product_boxme['BrandName']=$product['manufacturer'];
                            $product_boxme['Description']= '';
                            $product_boxme['ProductTags']='CHILI,'.$product['tag'];
                            $product_boxme['Quantity']=(int) $product['quantity'];
                            $product_boxme['BasePrice']=(int) $product['price'];
                            $product_boxme['SalePrice']=(int) $product['price'];
                            $product_boxme['BarcodeManufacturer']= "CHILI Manufacturer";
                            $product_boxme['ModelName']=$product['model'];
                            $product_boxme['Weight']=(int) $product['weight'];
                            $product_boxme['Volume']=$product['length'].'x'.$product['width'].'x'.$product['height'];
                            $product_boxme['ProductImages']=$product['image'];
                            // Add product to Boxme
                            $json=$this->sendPostToBoxme($this->url_boxme.'bxapi/'.$this->action_api['addProduct'],$product_boxme);
                            $json[$product_id]['addproduct']['name']=$product['name'];
                            $json[$product_id]['addproduct']['id']=$product_id;
                            if($result['error']==FALSE && $result['code']==200){ 
                                $json[$product_id]['addproduct']['sucess']=TRUE;
                                // Shipment product to Boxme.
                                $result=$this->sendPostToBoxme($this->url_boxme.'bxapi/'.$this->action_api['shipment'],$product_boxme);
                                $json[$product_id]['shipment']['name']=$product['name'];
                                $json[$product_id]['shipment']['id']=$product_id;
                                if($result['error']==FALSE && $result['code']==200){
                                    $json[$product_id]['shipment']['sucess']=TRUE;
                                }else{
                                    $json[$product_id]['shipment']['sucess']=false;
                                }
                            }else{
                                $json[$product_id]['addproduct']['sucess']=FALSE;
                                $json[$product_id]['shipment']['name']=$product['name'];
                                $json[$product_id]['shipment']['id']=$product_id;
                                $json[$product_id]['shipment']['sucess']=false;
                            }
            $this->response->addHeader('Content-Type: application/json');
             $this->response->setOutput(json_encode($json));
        }

        private function sendPostToBoxme($url,$data){
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_FOLLOWLOCATION => TRUE, //Open ssl
                CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => array(
                    "authorization: Basic ZHZxdW9jOjEyMzQ1Njc=",
                    "cache-control: no-cache",
                    "content-type: application/json",
                ),
            ));
            $response = curl_exec($curl);
            $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            $result=json_decode($response);
            curl_close($curl);
            $json=array();
            $json['code']=$httpcode;
            $json['result']=$result;
            if ($httpcode!=200) {
                 $json['error']=TRUE;
            } else {
                $json['error']=FALSE;
            }
            return $json;
        }
        public function getJsonListProduct(){
            $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => $this->url_boxme.'bxapi/'."list_product-sdk?ApiKey=".$this->config->get('boxme_key'),
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "GET",
              CURLOPT_POSTFIELDS => "{}",
              CURLOPT_HTTPHEADER => array(
                "content-type: application/json"
              ),
            ));
            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
         echo $response;
            }
        }
        public function getCityBoxme(){
            $curl = curl_init();
                curl_setopt_array($curl, array(
                  CURLOPT_URL => $this->url_shipchung."api/merchant/rest/lading/city",
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => "",
                  CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 30,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => "GET",
                  CURLOPT_POSTFIELDS => "",
                  CURLOPT_HTTPHEADER => array(
                    "content-type: application/x-www-form-urlencoded",
                    "headers: {'content-type': 'application/x-www-form-urlencoded'}"
                  ),
                ));
                $response = curl_exec($curl);
                $err = curl_error($curl);
                curl_close($curl);
                if ($err) {
                  echo "cURL Error #:" . $err;
                } else {
                  echo $response;
                }
        }
        public function getWard(){
            $curl = curl_init();
                curl_setopt_array($curl, array(
                  CURLOPT_URL => $this->url_shipchung."api/merchant/rest/lading/ward/52",
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => "",
                  CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 30,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => "GET",
                  CURLOPT_POSTFIELDS => "",
                  CURLOPT_HTTPHEADER => array(
                    "content-type: application/x-www-form-urlencoded",
                    "headers: {'content-type': 'application/x-www-form-urlencoded'}"
                  ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);

                curl_close($curl);

                if ($err) {
                  echo "cURL Error #:" . $err;
                } else {
                  echo $response;
                }
        }
        private function sendGetToBoxme($url,$data){
            $data=http_build_query($data);
            $CurlStart = curl_init(); 
            curl_setopt ($CurlStart, CURLOPT_URL,$url."?".$data);
            curl_setopt ($CurlStart, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE); // openssl
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // openssl
            curl_setopt ($CurlStart, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.1; nl; rv:1.9.1.11) Gecko/20100701 Firefox/3.5.11");
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Connection: Keep-Alive'
            ));
            $header_size = curl_getinfo($CurlStart, CURLINFO_HEADER_SIZE);
            $source = curl_exec ($CurlStart);
            $json=array();
            $json['code']=$httpcode;
            $json['result']=$source;
            if ($httpcode!=200) {
                 $json['error']=TRUE;
            } else {
                $json['error']=FALSE;
            }
            return $json;
        }
        private function error_boxme(){
            $data['errors']=$this->error;
            $data['error_list']=$this->error_list;
            $data['breadcrumbs'] = array();
            $data['breadcrumbs'][] = array(
                    'text' => $this->language->get('text_home'),
                    'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL'),
                
            );
            $data['breadcrumbs'][] = array(
                    'text' => 'Thêm sản phẩm vào kho hàng Boxme',
                    'href' => $this->url->link('catalog/product', 'token=' . $this->session->data['token'] . $url, 'SSL')
            );

            $data['commeback'] = $this->url->link('catalog/product', 'token=' . $this->session->data['token'] . $url, 'SSL');
           $data['header'] = $this->load->controller('common/header');
           $data['column_left'] = $this->load->controller('common/column_left');
           $data['footer'] = $this->load->controller('common/footer');
           $this->response->setOutput($this->load->view('boxme/error_boxme.tpl', $data));
        }
        
        private function printBoxme($data,$stop=FALSE){
           $data['ProductId'] =  $data['result']->ProductId;
            if($stop)
                die();
        }


}
