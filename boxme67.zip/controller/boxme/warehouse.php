<?php
if (is_file('config_boxme.php')) {
    require_once('config_boxme.php');
}
class ControllerBoxmeWarehouse extends Controller {
	public $url_boxme=URL_API;  
    public $url_shipchung = URL_SHIPCHUNG;
    public $client_secret = CLIENT_SECRET; 
	private $error = array();
	private $action_api=array( 
            'warehouse'=>'list_inventory-sdk',
            'addProduct'=>'product-sdk',
            'editProduct'=>'edit-product-sdk',
            'shipment'=>'shipment-sdk',
    );
	public function index() { 

        } 
	public function getWareHouse(){  
	    $data=array('ApiKey'=>$this->config->get('boxme_key'));
	    $reponse=$this->sendGetToBoxme($this->url_boxme.'bxapi/'.$this->action_api['warehouse'], $data);
	    echo $reponse['result'];
	    die(); 
	}
	 public function getWareHous2(){
	    $url = $this->url_boxme.'bxapi/'.$this->action_api['warehouse']."?ApiKey=".$this->config->get('boxme_key');
	    $curl = curl_init();
	    curl_setopt_array($curl, array(
	      CURLOPT_URL => $url,
	      CURLOPT_RETURNTRANSFER => true,
	      CURLOPT_ENCODING => "",
	      CURLOPT_MAXREDIRS => 10,
	      CURLOPT_TIMEOUT => 30,
	      CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false, //open ssl
	      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	      CURLOPT_CUSTOMREQUEST => "GET",
	      CURLOPT_POSTFIELDS => "{}",
	      CURLOPT_HTTPHEADER => array(
	        "content-type: application/json"
	      ),
	    ));
	    $response = curl_exec($curl);
	    $err = curl_error($curl);
	    curl_close($curl);
	    if ($err) {
	      echo "cURL Error #:" . $err;
	    } else {
	      echo $response;
	    }
	}
	 ///Get danh sách kho hàng boxme///
    public function getListsInventory(){
        $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => $this->url_boxme."bxapi/list_inventory-sdk?ApiKey=".$this->config->get('boxme_key'),
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "GET",
              CURLOPT_POSTFIELDS => "{}",
              CURLOPT_HTTPHEADER => array(
                "content-type: application/json"
              ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              echo $response;
            }
    }
    
}
