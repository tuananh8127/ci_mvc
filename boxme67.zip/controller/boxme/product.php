<?php
if (is_file('config_boxme.php')) {
    require_once('config_boxme.php');
}
class ControllerBoxmeProduct extends Controller {
	private $error = array();
    public $url_boxme=URL_API;  
    public $url_shipchung = URL_SHIPCHUNG;
    public $client_secret = CLIENT_SECRET; 
	 private $action_api=array( 
            'warehouse'=>'list_inventory-sdk',
            'addProduct'=>'product-sdk',
            'editProduct'=>'edit-product-sdk',
            'shipment'=>'shipment-sdk',
        );
	public function shipmentCodeBoxme($product_id, $shipment_codeboxme){
		$this->load->model('boxme/product');
		if($this->request->server['REQUEST_METHOD'] == 'POST') { 
			$this->model_boxme_product->shipmentCodeBoxme($this->request->post['product_id'], $this->request->post['shipment_codeboxme']);
			$json['error_shipment_codeboxme']  = false;
		}  
		else {
			$json['error_shipment_codeboxme'] = true;
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
		
	}
	public function updateProductIdBoxme($product_id, $productid_boxme){
		$this->load->model('boxme/product');
		if($this->request->server['REQUEST_METHOD'] == 'POST') { 
			$this->model_boxme_product->updateProductIdBoxme($this->request->post['product_id'], $this->request->post['productid_boxme']);
			$json['error_productid_boxme']  = false;
		}  
		else {
			$json['error_productid_boxme'] = true;
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
		
	}

	public function updateProductDefault(){
		$this->load->model('boxme/product');
		if(($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateFormDefault()) { 
			$this->model_boxme_product->updateProductDefault($this->request->post);
			$json['error_productdefault']  = false;
		}  
		else {
			$json['error_productdefault'] = true;
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	protected function validateFormDefault() {

		if ((utf8_strlen($this->request->post['location']) < 1) || (utf8_strlen($this->request->post['location']) > 64)) {
			$this->error['location'] = $this->language->get('error_location');
		}
		if ((utf8_strlen($this->request->post['product_description']) < 1) || (utf8_strlen($this->request->post['product_description']) > 64)) {
			$this->error['product_description'] = $this->language->get('error_product_description');
		}
		if ((utf8_strlen($this->request->post['price']) < 1) || (utf8_strlen($this->request->post['price']) > 64)) {
			$this->error['price'] = $this->language->get('error_price');
		}
		if ((utf8_strlen($this->request->post['sku']) < 1) || (utf8_strlen($this->request->post['sku']) > 64)) {
			$this->error['sku'] = $this->language->get('error_sku');
		}
		if ((utf8_strlen($this->request->post['product_special']) < 1) || (utf8_strlen($this->request->post['product_special']) > 64)) {
			$this->error['product_special'] = $this->language->get('error_product_special');
		}
		if ((utf8_strlen($this->request->post['weight']) < 1) || (utf8_strlen($this->request->post['weight']) > 64)) {
			$this->error['weight'] = $this->language->get('error_weight');
		}

		return !$this->error;
	}
	public function editAngular(){
		$this->load->model('catalog/product');
		$this->model_catalog_product->editProduct($this->request->get['product_id'], $this->request->post);
		$json['status'] = true;
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function getJsonAngularListProduct(){
		$this->load->model('catalog/product');
		$data['products'] = array();
		$filter_data = array(
			'filter_name'	  => $filter_name,
			'filter_model'	  => $filter_model,
			'filter_price'	  => $filter_price,
			'filter_quantity' => $filter_quantity,
			'filter_status'   => $filter_status,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'           => $this->config->get('config_limit_admin')
			);

		$this->load->model('tool/image');


		$results = $this->model_catalog_product->getProducts();
		
		foreach ($results as $result) {
			if (is_file(DIR_IMAGE . $result['image'])) {
				$image = $this->model_tool_image->resize($result['image'], 40, 40);
			} else {
				$image = $this->model_tool_image->resize('no_image.png', 40, 40);
			}

			$special = false;

			$product_specials = $this->model_catalog_product->getProductSpecials($result['product_id']);

			foreach ($product_specials  as $product_special) {
				if (($product_special['date_start'] == '0000-00-00' || strtotime($product_special['date_start']) < time()) && ($product_special['date_end'] == '0000-00-00' || strtotime($product_special['date_end']) > time())) {
					$special = $product_special['price'];

					break;
				}
			}
			$data['products'][] = array(
				'product_id' => $result['product_id'],
				'image'      => $image,
				'name'       => $result['name'],
				'weight_class_id' =>  $result['weight_class_id'],
				'model'      => $result['model'],
				'weight'      =>substr($result['weight'] , 0, -9),
				'length'	=>  substr($result['length'] , 0, -9),
				'width'	=>  	substr($result['width'] , 0, -9),
				'height'	=>  substr($result['height'] , 0, -9),
				'token'	=>  $this->session->data['token'],
				'location'	=>  $result['location'],
				// 'description'	=>  utf8_substr(strip_tags(html_entity_decode($result['description'])),0,200),
				'shipment_codeboxme'	=>  $result['shipment_codeboxme'],
				'sku'      => $result['sku'],
				'price'      => $this->currency->format($result['price']),
				'special'    => $special,
				'productid_boxme' => $result['productid_boxme'],
				'quantity'   => $result['quantity'],
				'status'     => ($result['status']) ? $this->language->get('text_enabled') : $this->language->get('text_disabled'),
				'edit'       => $this->url->link('catalog/product/edit')
				);
			
		}		
		echo json_encode($data['products']);

	}
	public function editproduct($id){
            $this->load->model('catalog/product');
            if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateFormEdit()) {
                $product_boxme=array();
                $product_boxme['InventoryId']= $this->request->post['inventoryid'];
                $product_boxme['ApiKey']= $this->config->get('boxme_key');
                $product_boxme['SellerSKU']= $this->request->post['sku'];
                $product_boxme['Name']= $this->request->post['name'];
                $product_boxme['Description']= '';
                $product_boxme['BasePrice']= (int) $this->request->post['price'];
                $product_boxme['SalePrice']= (int) $this->request->post['product_special'];
                $product_boxme['Weight']= (int) $this->request->post['weight'];
                $product_boxme['Volume']=$this->request->post['length'].'x'.$this->request->post['width'].'x'.$this->request->post['height'];
                $product_boxme['ProductImages']  = $this->request->post['images'];
                $curl = curl_init();
                curl_setopt_array($curl, array( 
                    CURLOPT_URL => $this->url_boxme.'bxapi/'.$this->action_api['editProduct'],
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_FOLLOWLOCATION => TRUE,CURLOPT_SSL_VERIFYPEER => false,//Open ssl
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => json_encode($product_boxme),
                    CURLOPT_HTTPHEADER => array(
                        "authorization: Basic ZHZxdW9jOjEyMzQ1Njc=",
                        "cache-control: no-cache",
                        "content-type: application/json",
                    ),
                ));
                $response = curl_exec($curl);
                    $err = curl_error($curl);

                    curl_close($curl);

                    if ($err) {
                      echo "cURL Error #:" . $err;
                    } else {
                      echo $response;
                    }
            } else {
                $json['editproduct'] = false;
                $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode($json));
            }
        }
        private function validateFormEdit(){
          
                if ((utf8_strlen($this->request->post['inventoryid']) < 1) || (utf8_strlen($this->request->post['inventoryid']) > 64)) {
                    $json['inventoryid'] = 'error_inventoryid';
                }
                if ((utf8_strlen($this->request->post['sku']) < 1) || (utf8_strlen($this->request->post['sku']) > 64)) {
                    $json['sku'] = 'error_sku';
                }
                if ((utf8_strlen($this->request->post['name']) < 1) || (utf8_strlen($this->request->post['name']) > 64)) {
                    $json['name'] = 'error_name';
                }
                if ((utf8_strlen($this->request->post['price']) < 1) || (utf8_strlen($this->request->post['price']) > 64)) {
                    $json['price'] = 'error_price';
                }
                if ((utf8_strlen($this->request->post['weight']) < 1) || (utf8_strlen($this->request->post['weight']) > 64)) {
                    $json['weight'] = 'error_weight';
                }
            
               return !$json;
        }

        // public function getListProductBoxme(){
	       //  $this->document->addScript('http://ajax.googleapis.com/ajax/libs/angularjs/1.0.4/angular.min.js');
	       //  $this->document->addScript('http://ajax.googleapis.com/ajax/libs/angularjs/1.0.4/angular-resource.min.js');
	       //  $this->document->addScript('view/javascript/boxme/ui-bootstrap-tpls-0.10.0.min.js');
	       //  $this->document->addStyle('https://cdn.gitcdn.link/cdn/angular/bower-material/v1.1.3/angular-material.css');
	       //  $data['header'] = $this->load->controller('common/header');
	       //  $data['footer'] = $this->load->controller('common/footer');
	       //  $data['token'] = $this->session->data['token'];
	       //  $data['column_left']  = $this->load->controller('common/column_left'); 
	       //      $this->response->setOutput($this->load->view('boxme/getlistproductboxme.tpl',$data));
        // }


}
