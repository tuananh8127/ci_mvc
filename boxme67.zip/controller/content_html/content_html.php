<?php
class ControllerContentHtmlContentHtml extends Controller
{
    public function index(){
      $this->load->language('content_html/content_html');
      $data["heading_title"]= $this->language->get('heading_title');
      $data['button_edit'] = $this->language->get('button_edit');
      $data['button_delete'] = $this->language->get('button_delete');
      $data['text_confirm'] = $this->language->get('text_confirm');
      $data['text_status'] = $this->language->get('text_status');
      $data['text_action'] = $this->language->get('text_action');
      $data['tab_module'] = $this->language->get('tab_module');
      $data['tab_module'] = $this->language->get('tab_module');
      $data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('content_html/content_html', 'token=' . $this->session->data['token'], 'SSL')
		);
                $this->load->model('extension/module');
                
                $modules = $this->model_extension_module->getModulesByCode('html');
               
                foreach($modules as $key=>$item){
                    $setting_info = $this->model_extension_module->getModule($item['module_id']);
                    $data["item_html"][$key]=$item;
                    $data["item_html"][$key]['item_status']=($setting_info['status']==1) ?$this->language->get('text_enabled'): $this->language->get("text_disabled");
                    $data["item_html"][$key]['link']=$this->url->link('module/html', 'token=' . $this->session->data['token'] . '&module_id=' . $item['module_id'], 'SSL');
                    $data["item_html"][$key]['delete']=$this->url->link('extension/module/delete', 'token=' . $this->session->data['token'] . '&module_id=' . $item['module_id'], 'SSL');
                }
                
                $data['refesh'] = html_entity_decode($this->url->link('content_html/content_html', 'token=' . $this->session->data['token'], 'SSL'));
                $data['header'] = $this->load->controller('common/header');
				$data['column_left'] = $this->load->controller('common/column_left');
				$data['footer'] = $this->load->controller('common/footer');
                $this->response->setOutput($this->load->view('content_html/content_html.tpl', $data));
    }
}
