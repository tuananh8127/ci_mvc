<?php 
class ControllerModuleshowinconfig extends Controller {
	private $error = array(); 

	public function index() {
		$this->load->language('module/showintabs');

		$this->document->setTitle($this->language->get('heading_title_config'));
		$this->document->addStyle('view/stylesheet/tabs.css');
		
		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			
			$this->model_setting_setting->editSetting('showinconfig',$this->request->post);
	
			$this->session->data['success'] = $this->language->get('text_success');

			if( isset($this->request->post['exit']) ){
				$this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));
			}else{
				$this->response->redirect($this->url->link('module/showinconfig', 'token=' . $this->session->data['token'], 'SSL'));
			}
		}

		//Textos
		$data['heading_title'] = $this->language->get('heading_title_config');
		$data['heading_title_url'] = $this->language->get('heading_title_url_config');
		$data['header_tabs'] = $this->language->get('header_tabs');
		
		$data['text_best_seller'] = $this->language->get('text_best_seller');
		$data['text_latest_products'] = $this->language->get('text_latest_products');
		$data['text_special_products'] = $this->language->get('text_special_products');
		$data['text_popular_products'] = $this->language->get('text_popular_products');
		$data['text_all_categories'] = $this->language->get('text_all_categories');
		$data['text_all_manufacturer'] = $this->language->get('text_all_manufacturer');
		$data['text_sort_name'] = $this->language->get('text_sort_name');
		$data['text_sort_rating'] = $this->language->get('text_sort_rating');
		$data['text_sort_sort_order'] = $this->language->get('text_sort_sort_order');
		$data['text_sort_price'] = $this->language->get('text_sort_price');
		$data['text_sort_added'] = $this->language->get('text_sort_added');
		$data['text_category'] = $this->language->get('text_category');
		$data['text_manufacturer'] = $this->language->get('text_manufacturer');
		$data['text_add_tabs'] = $this->language->get('text_add_tabs');
		$data['text_empty_tab'] = $this->language->get('text_empty_tab');
		$data['text_tab'] = $this->language->get('text_tab');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_save_keep'] = $this->language->get('button_save_keep');

		$data['header_tabs'] = $this->language->get('header_tabs');
		$data['header_products_select'] = $this->language->get('header_products_select');
		$data['header_predefined_groups'] = $this->language->get('header_predefined_groups');
		$data['header_custom_query'] = $this->language->get('header_custom_query');

		$data['entry_title'] = $this->language->get('entry_title');
		$data['entry_products'] = $this->language->get('entry_products');
		$data['entry_filter'] = $this->language->get('entry_filter');
		$data['entry_sort_query'] = $this->language->get('entry_sort_query');
		$data['entry_group'] = $this->language->get('entry_group');
		$data['entry_source'] = $this->language->get('entry_source');


		//Comprobacion de errores
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->error['titles'])) {
			$data['error_titles'] = $this->error['titles'];
			$data['error_title'] = $this->language->get('error_title');
		} else {
			$data['error_titles'] = '';
			$data['error_title'] = '';
		}
	
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		//Camino de migas de pan
  		$data['breadcrumbs'] = array();
   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL')
   		);
   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_module'),
			'href'      => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
   		);
   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title_config'),
			'href'      => $this->url->link('module/showinconfig', 'token=' . $this->session->data['token'], 'SSL')
   		);
				
		$module_id = '';

		if (isset($this->request->post['showinconfig_tab'])) {
			$data['tab_config'] = $this->request->post['showinconfig_tab'];
		} else { 
			$setting = $this->model_setting_setting->getSetting('showinconfig');
			$data['tab_config'] = (isset($setting['showinconfig_tab'])) ? $setting['showinconfig_tab'] : array();
		}
		
		//Links y actions
		$data['action'] = $this->url->link('module/showinconfig', 'token=' . $this->session->data['token'], 'SSL');
		$data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');
		$data['token'] = $this->session->data['token'];

		$this->load->model('catalog/product');
		
		//Ordenamos las pestañas 
		ksort($data['tab_config']);

		//Completamos info de pestañas de cada pestaña
		foreach( $data['tab_config'] as $keyTab => $tab ){
			
			//Preparamos title de pestañas
			if(isset($data['tab_config'][$keyTab]['title'][$this->config->get('config_language_id')]) && $data['tab_config'][$keyTab]['title'][$this->config->get('config_language_id')] != ''){
				$data['tab_config'][$keyTab]['tab_title'] = $data['tab_config'][$keyTab]['title'][$this->config->get('config_language_id')];
			}else{
				$data['tab_config'][$keyTab]['tab_title'] = $this->language->get('text_tab') . '#'. $keyTab;
			}
			//Preparamos datos productos
			if(isset($tab['products'])){
				foreach ( $tab['products'] as $value ) {
					$product_info = $this->model_catalog_product->getProduct($value['product_id']);
					
					if ($product_info) {			
						$data['tab_config'][$keyTab]['products'][$value['product_id']] = array(
							'product_id'    => $value['product_id'],
							'name'          => $product_info['name'],
							'model'         => $product_info['model'],
						);
					}
				}
			}
		}

		//idiomas
		$this->load->model('localisation/language');
		
		$data['languages'] = $this->model_localisation_language->getLanguages();

		//idioma del admin
		$data['language_admin_id']  = $this->config->get('config_language_id');

		//Categoriess
		$this->load->model('catalog/category');

		$data['categories'] = $this->model_catalog_category->getCategories(array());

		//Manufacturers
		$this->load->model('catalog/manufacturer');

		$data['manufacturers'] = $this->model_catalog_manufacturer->getManufacturers(array());

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('module/showinconfig.tpl', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'module/showinconfig')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		$error_titles = array();
		foreach ($this->request->post['showinconfig_tab'] as $keyTab => $tab) {
			foreach ($tab['title'] as $keyLang => $title) {
				if(utf8_strlen($title) < 3){
					$error_titles[$keyTab][$keyLang] = $this->language->get('error_titles');
				}
			}
		}

		if( sizeof($error_titles) ){
			$this->error['titles'] = $error_titles;
		}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}	
	}

	public function uninstall(){
		//Uninstall the other mod also
		$mod_cod = 'showintabs';
			
		$this->load->model('extension/extension');
		$this->load->model('extension/module');
		$this->load->model('setting/setting');

		$this->model_extension_extension->uninstall('module', $mod_cod);

		$this->model_extension_module->deleteModulesByCode($mod_cod);

		$this->model_setting_setting->deleteSetting($mod_cod);
	}

	public function install(){
		//Uninstall the other mod also
		$mod_cod = 'showintabs';
			
		$this->load->model('extension/extension');
		$this->load->model('extension/module');
		$this->load->model('user/user_group');
			
		$this->model_extension_extension->install('module', $mod_cod);
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'module/' . $mod_cod);
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'module/' . $mod_cod);
	}



}
?>