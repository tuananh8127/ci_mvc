<?php
// Text
$_['text_footer'] 	= '';
$_['text_version'] 	= '<div style="font-family:\'arial\', sans-serif;"><a href="https://www.chili.vn/" target="_blank">CHILI web design</a></div>';