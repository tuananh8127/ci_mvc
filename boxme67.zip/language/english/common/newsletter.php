<?php
$_['heading_title']     = 'List email';
$_['heading_edit_title']     = 'Edit email';
$_['text_edit']     = 'edit';
$_['text_error_mail']     = 'not empty email';
$_['text_success']     = 'Success !';
$_['text_cancel']     = 'Close';
$_['text_header_action']     = 'Action';