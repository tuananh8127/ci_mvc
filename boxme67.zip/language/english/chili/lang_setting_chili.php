<?php 
$_['text_getting_start']='Getting start';
$_['text_visual_builder']='Setting layout';
$_['text_content_html']='Content HTML';
$_['text_slider']='Setting slider';
$_['text_slider_out']='Output slider';
$_['text_product_tab_setting']='Show it on tabs (config)';
$_['text_product_tab']='Show it on tabs';
$_['text_manager_image']='Image Manager';
$_['text_manager_content']='Content manager';

$_['text_add_product']='Add product';
$_['text_list_product']='Category';

$_['text_limit_data']='Limit data is <b style="font-size: 16px; color: red; ">%s</b> product, customer is prevented, upgrade now !';
$_['text_warning']='Warning';
$_['text_upgrade_now']="upgrade now";