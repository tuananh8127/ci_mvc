<?php
// Heading 
$_['heading_title']      = 'Trình đơn nhanh';

// Text
$_['text_module']       = 'chức năng';
$_['entry_status']       = 'Trạng thái';
$_['text_my_orders']     = 'Đơn hàng của tôi';
$_['text_my_newsletter'] = 'Thư thông báo';
$_['text_edit']          = 'Thiết lập trình đơn nhanh';
$_['text_password']      = 'Thay đổi mật khẩu';
$_['text_address']       = 'Cập nhật địa chỉ';
$_['text_wishlist']      = 'Danh sách yêu thích';
$_['text_order']         = 'Xem lịch sử Đặt hàng';
$_['text_download']      = 'Tải về';
$_['text_reward']        = 'Điểm Thưởng'; 
$_['text_return']        = 'Đôi / Trả hàng'; 
$_['text_transaction']   = 'Lịch sử Giao dịch'; 
$_['text_newsletter']    = 'Đăng ký / Hủy đăng ký thông báo';
$_['text_recurring']     = 'Thanh toán Định kỳ';
?>