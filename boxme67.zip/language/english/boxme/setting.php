<?php
// Heading
$_['heading_title']    = 'Hệ thống kho Boxme';
$_['text_config']    = 'Cấu hình truy cập :';
$_['text_select_warehouse'] = 'Lựa chọn kho hàng của bạn';
$_['text_warehouseshop'] = 'Kho hàng của bạn';
$_['text_warehouseboxme'] = 'Kho hàng Boxme';
$_['text_selectdefault'] = 'Kho hàng mặc định bạn đang chọn';
$_['text_functional'] = 'Cấu hình chức năng:';
$_['text_warehousedefault'] = 'Kho hàng mặc định bạn đang chọn';
$_['text_object']      = 'Kho Boxme';
$_['text_edit']      = 'Thiết lập boxme';
$_['text_success']     = 'Thành công: BẠn đã chỉnh sửa chức năng tài khoản!';
$_['text_savesuccess']     = 'Thông tin đã lưu thành công!';
$_['text_validation']     = 'Vui lòng kiểm tra lại thông tin còn thiếu!';
// Entry
$_['entry_status']     = 'Trạng thái';
$_['entry_key']     = 'Api Key';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền chỉnh sửa chức năng tài khoản!';
$_['text_none'] = 'Lựa chọn';
$_['text_errorkey'] = 'Lỗi kết nối API kho hàng Boxme, Vui lòng kiểm tra lại mã key hoặc liên hệ kỹ thuật CHILI - Xin lỗi bạn vì sự bất tiện này';