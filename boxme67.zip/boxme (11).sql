-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2017 at 11:23 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `boxme`
--

-- --------------------------------------------------------

--
-- Table structure for table `oc_address`
--

CREATE TABLE `oc_address` (
  `address_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `company` varchar(40) NOT NULL,
  `address_1` varchar(128) NOT NULL,
  `address_2` varchar(128) NOT NULL,
  `city` varchar(128) NOT NULL,
  `postcode` varchar(10) NOT NULL,
  `country_id` int(11) NOT NULL DEFAULT '0',
  `zone_id` int(11) NOT NULL DEFAULT '0',
  `custom_field` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_address`
--

INSERT INTO `oc_address` (`address_id`, `customer_id`, `firstname`, `lastname`, `company`, `address_1`, `address_2`, `city`, `postcode`, `country_id`, `zone_id`, `custom_field`) VALUES
(2, 2, 'vi', 'nguyen ', '', 'abc', '', 'hcm', '', 230, 3756, 'a:0:{}'),
(5, 5, 'demo', 'demo', '', 'aaa', '', 'ABC', '', 230, 3780, ''),
(6, 6, 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo@gmail', 237, 3814, ''),
(7, 7, 'aaa', 'aaa', '', 'aaaa', '', 'aaaa', '', 230, 3780, 'a:0:{}'),
(9, 5, ' ', 'demo', '', ' aaa', '', ' ', 'aaa', 230, 3780, ''),
(10, 8, 'aaa', 'aaa', '', 'aaa', '', 'aaa', '', 230, 3780, 'a:0:{}'),
(11, 9, 'aaa', 'aaa', '', 'sss', '', 'sss', '', 230, 3780, ''),
(12, 1, 'Tuấn', 'Anh', 'Mắt Bão', '10/6/27 Đường số 9 - Phường Linh Trung ', '', 'Thủ Đức', '70000', 230, 3780, ''),
(13, 2, 'aaa', 'aaa', '', 'aaa', '', 'aaa', '', 230, 3780, ''),
(14, 1, 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 230, 4231, '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_affiliate`
--

CREATE TABLE `oc_affiliate` (
  `affiliate_id` int(11) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(96) NOT NULL,
  `telephone` varchar(32) NOT NULL,
  `fax` varchar(32) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(9) NOT NULL,
  `company` varchar(40) NOT NULL,
  `website` varchar(255) NOT NULL,
  `address_1` varchar(128) NOT NULL,
  `address_2` varchar(128) NOT NULL,
  `city` varchar(128) NOT NULL,
  `postcode` varchar(10) NOT NULL,
  `country_id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL,
  `code` varchar(64) NOT NULL,
  `commission` decimal(4,2) NOT NULL DEFAULT '0.00',
  `tax` varchar(64) NOT NULL,
  `payment` varchar(6) NOT NULL,
  `cheque` varchar(100) NOT NULL,
  `paypal` varchar(64) NOT NULL,
  `bank_name` varchar(64) NOT NULL,
  `bank_branch_number` varchar(64) NOT NULL,
  `bank_swift_code` varchar(64) NOT NULL,
  `bank_account_name` varchar(64) NOT NULL,
  `bank_account_number` varchar(64) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `approved` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_affiliate_activity`
--

CREATE TABLE `oc_affiliate_activity` (
  `activity_id` int(11) NOT NULL,
  `affiliate_id` int(11) NOT NULL,
  `key` varchar(64) NOT NULL,
  `data` text NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_affiliate_login`
--

CREATE TABLE `oc_affiliate_login` (
  `affiliate_login_id` int(11) NOT NULL,
  `email` varchar(96) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `total` int(4) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_affiliate_transaction`
--

CREATE TABLE `oc_affiliate_transaction` (
  `affiliate_transaction_id` int(11) NOT NULL,
  `affiliate_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_api`
--

CREATE TABLE `oc_api` (
  `api_id` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  `firstname` varchar(64) NOT NULL,
  `lastname` varchar(64) NOT NULL,
  `password` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_api`
--

INSERT INTO `oc_api` (`api_id`, `username`, `firstname`, `lastname`, `password`, `status`, `date_added`, `date_modified`) VALUES
(1, 'P4oEVabHAtkFhRc4P8iaissLHcmJFoQmR3WFp0c6H9Ep6d4HxIU8a16Id6T5fRqw', '', '', 'hhcx17poi5EsqOEQbJVUO2TOvqv6TIS4iZyFolF8QiZuiU1Ka0TquIiKhesGRIGtmNQ278jDD6VfNcElHRstZhBYBibErjTLPEvA8z5GHnSIGLgS3XMKvBJaewgVQQBW1z3HStAZeWKIdx2WvX8fh3QmUQgMH3Dv3M23Poq5u4V4khskYommJfP9gca0JMH1BUTkuP7OSyJVQCJYqRuB1UzYXFx0fdEGfhVuo4y0FF5XfSpd1ZXKwjazyvHGVO1T', 1, '2015-12-17 14:11:36', '2015-12-17 14:11:36'),
(2, 'admin', '', '', 'NcP2I4GC3fCSyPfRJD6zeRIPF5vjRgKI1GAb3V0SgCe0tCUJ0hvHj8drMvsjqEAg4KyYbVZjwiJhlAvlPEZRZaNHjxtsOVznryVA6J4AYxUCdyzuQwVTKM3s6wZRpt2Tl7Gahy3Dh63bufj8zwAwjHMR07tWcGm6Va4JSbxz44LmwgDxrwnVlnIcnsJxOvJ3d1SDRo7sRJBuL61Z3XfUOzdkIYSUVHkT3ELPPs1q5p2JxHPsBGWMF7LU5jhvnNDt', 1, '2017-04-12 11:19:29', '2017-04-12 11:19:29');

-- --------------------------------------------------------

--
-- Table structure for table `oc_attribute`
--

CREATE TABLE `oc_attribute` (
  `attribute_id` int(11) NOT NULL,
  `attribute_group_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_attribute_description`
--

CREATE TABLE `oc_attribute_description` (
  `attribute_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_attribute_group`
--

CREATE TABLE `oc_attribute_group` (
  `attribute_group_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_attribute_group_description`
--

CREATE TABLE `oc_attribute_group_description` (
  `attribute_group_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_attribute_relative`
--

CREATE TABLE `oc_attribute_relative` (
  `relative_ID` int(11) NOT NULL,
  `relative_name` varchar(225) NOT NULL,
  `language_id` int(3) NOT NULL,
  `sort_order` int(3) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_attribute_relative`
--

INSERT INTO `oc_attribute_relative` (`relative_ID`, `relative_name`, `language_id`, `sort_order`, `status`) VALUES
(1, 'Khích thước', 2, 0, 1),
(2, 'Màu sắc', 2, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_banner`
--

CREATE TABLE `oc_banner` (
  `banner_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_banner`
--

INSERT INTO `oc_banner` (`banner_id`, `name`, `status`) VALUES
(7, 'Home Page Slideshow', 1),
(8, 'Manufacturers', 1),
(11, 'Banner cột trái', 1),
(10, 'Banner 1 trang chủ', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_banner_image`
--

CREATE TABLE `oc_banner_image` (
  `banner_image_id` int(11) NOT NULL,
  `banner_id` int(11) NOT NULL,
  `link` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_banner_image`
--

INSERT INTO `oc_banner_image` (`banner_image_id`, `banner_id`, `link`, `image`, `sort_order`) VALUES
(173, 8, '', 'catalog/banner/logo/4.jpg', 17),
(171, 8, '', 'catalog/banner/logo/6.jpg', 15),
(99, 7, 'index.php?route=product/product&amp;path=57&amp;product_id=49', 'catalog/demo/banners/iPhone6.jpg', 0),
(172, 8, '', 'catalog/banner/logo/3.jpg', 16),
(169, 8, '', 'catalog/banner/logo/4.jpg', 13),
(100, 7, '', 'catalog/demo/banners/MacBookAir.jpg', 0),
(188, 11, 'gia-dinh', 'catalog/banner/Banner2.jpg', 0),
(170, 8, '', 'catalog/banner/logo/5.jpg', 14),
(187, 10, 'chuyen-khoan-ngan-hang', 'catalog/banner/Banner1.jpg', 0),
(168, 8, '', 'catalog/banner/logo/3.jpg', 12),
(167, 8, '', 'catalog/banner/logo/2.jpg', 11),
(166, 8, '', 'catalog/banner/logo/1.jpg', 10);

-- --------------------------------------------------------

--
-- Table structure for table `oc_banner_image_description`
--

CREATE TABLE `oc_banner_image_description` (
  `banner_image_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `banner_id` int(11) NOT NULL,
  `title` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_banner_image_description`
--

INSERT INTO `oc_banner_image_description` (`banner_image_id`, `language_id`, `banner_id`, `title`) VALUES
(100, 2, 7, 'MacBookAir'),
(173, 2, 8, 'Manufacturers'),
(172, 2, 8, 'Manufacturers'),
(99, 2, 7, 'iPhone 6'),
(171, 2, 8, 'Manufacturers'),
(170, 2, 8, 'Manufacturers'),
(169, 2, 8, 'Manufacturers'),
(188, 2, 11, 'Banner 2 trang chủ'),
(187, 2, 10, 'Banner 1 trang chủ'),
(168, 2, 8, 'Manufacturers'),
(167, 2, 8, 'Manufacturers'),
(166, 2, 8, 'Manufacturers');

-- --------------------------------------------------------

--
-- Table structure for table `oc_category`
--

CREATE TABLE `oc_category` (
  `category_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `top` tinyint(1) NOT NULL,
  `column` int(3) NOT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_category`
--

INSERT INTO `oc_category` (`category_id`, `image`, `parent_id`, `top`, `column`, `sort_order`, `status`, `date_added`, `date_modified`) VALUES
(85, '', 0, 0, 1, 4, 1, '2016-11-16 13:49:33', '2016-11-16 13:49:33'),
(83, '', 0, 0, 1, 2, 1, '2016-11-16 13:41:07', '2016-11-16 13:41:07'),
(84, '', 0, 0, 1, 3, 1, '2016-11-16 13:43:25', '2016-11-16 13:43:25'),
(80, '', 0, 0, 1, 1, 1, '2016-11-16 13:38:21', '2016-11-16 13:38:21'),
(81, '', 80, 0, 1, 1, 1, '2016-11-16 13:38:42', '2016-11-16 13:38:42'),
(82, '', 80, 0, 1, 2, 1, '2016-11-16 13:39:07', '2016-11-16 13:39:07'),
(86, '', 83, 0, 1, 1, 1, '2016-11-16 13:57:51', '2016-11-16 13:57:51'),
(87, '', 83, 0, 1, 2, 1, '2016-11-16 13:58:59', '2016-11-16 13:58:59'),
(88, '', 0, 0, 1, 5, 1, '2016-11-16 14:09:43', '2016-11-16 14:09:43');

-- --------------------------------------------------------

--
-- Table structure for table `oc_category_description`
--

CREATE TABLE `oc_category_description` (
  `category_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_category_description`
--

INSERT INTO `oc_category_description` (`category_id`, `language_id`, `name`, `description`, `meta_title`, `meta_description`, `meta_keyword`) VALUES
(86, 2, 'Làm đẹp', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Làm đẹp', '', ''),
(80, 2, 'Gia đình', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Gia đình', '', ''),
(81, 2, 'Nam', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Nam', '', ''),
(82, 2, 'Nữ', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Nữ ', '', ''),
(83, 2, 'Dược phẩm &amp; sức khỏe', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Dược phẩm &amp; sức khỏe', '', ''),
(84, 2, 'Mẹ &amp; bé', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Mẹ &amp; bé', '', ''),
(85, 2, 'Dinh dưỡng thể thao', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Dinh dưỡng thể thao', '', ''),
(87, 2, 'Vitamin', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Vitamin', '', ''),
(88, 2, 'Mỹ phẩm thiên nhiên', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Mỹ phẩm thiên nhiên', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_category_filter`
--

CREATE TABLE `oc_category_filter` (
  `category_id` int(11) NOT NULL,
  `filter_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_category_path`
--

CREATE TABLE `oc_category_path` (
  `category_id` int(11) NOT NULL,
  `path_id` int(11) NOT NULL,
  `level` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_category_path`
--

INSERT INTO `oc_category_path` (`category_id`, `path_id`, `level`) VALUES
(81, 80, 0),
(88, 88, 0),
(80, 80, 0),
(81, 81, 1),
(87, 87, 1),
(87, 83, 0),
(86, 86, 1),
(86, 83, 0),
(85, 85, 0),
(84, 84, 0),
(83, 83, 0),
(82, 82, 1),
(82, 80, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_category_to_layout`
--

CREATE TABLE `oc_category_to_layout` (
  `category_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_category_to_layout`
--

INSERT INTO `oc_category_to_layout` (`category_id`, `store_id`, `layout_id`) VALUES
(88, 0, 0),
(81, 0, 0),
(87, 0, 0),
(83, 0, 0),
(80, 0, 0),
(82, 0, 0),
(84, 0, 0),
(85, 0, 0),
(86, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_category_to_store`
--

CREATE TABLE `oc_category_to_store` (
  `category_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_category_to_store`
--

INSERT INTO `oc_category_to_store` (`category_id`, `store_id`) VALUES
(80, 0),
(81, 0),
(82, 0),
(83, 0),
(84, 0),
(85, 0),
(86, 0),
(87, 0),
(88, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_country`
--

CREATE TABLE `oc_country` (
  `country_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `iso_code_2` varchar(2) NOT NULL,
  `iso_code_3` varchar(3) NOT NULL,
  `address_format` text NOT NULL,
  `postcode_required` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_country`
--

INSERT INTO `oc_country` (`country_id`, `name`, `iso_code_2`, `iso_code_3`, `address_format`, `postcode_required`, `status`) VALUES
(1, 'Afghanistan', 'AF', 'AFG', '', 0, 1),
(2, 'Albania', 'AL', 'ALB', '', 0, 1),
(3, 'Algeria', 'DZ', 'DZA', '', 0, 1),
(4, 'American Samoa', 'AS', 'ASM', '', 0, 1),
(5, 'Andorra', 'AD', 'AND', '', 0, 1),
(6, 'Angola', 'AO', 'AGO', '', 0, 1),
(7, 'Anguilla', 'AI', 'AIA', '', 0, 1),
(8, 'Antarctica', 'AQ', 'ATA', '', 0, 1),
(9, 'Antigua and Barbuda', 'AG', 'ATG', '', 0, 1),
(10, 'Argentina', 'AR', 'ARG', '', 0, 1),
(11, 'Armenia', 'AM', 'ARM', '', 0, 1),
(12, 'Aruba', 'AW', 'ABW', '', 0, 1),
(13, 'Australia', 'AU', 'AUS', '', 0, 1),
(14, 'Austria', 'AT', 'AUT', '', 0, 1),
(15, 'Azerbaijan', 'AZ', 'AZE', '', 0, 1),
(16, 'Bahamas', 'BS', 'BHS', '', 0, 1),
(17, 'Bahrain', 'BH', 'BHR', '', 0, 1),
(18, 'Bangladesh', 'BD', 'BGD', '', 0, 1),
(19, 'Barbados', 'BB', 'BRB', '', 0, 1),
(20, 'Belarus', 'BY', 'BLR', '', 0, 1),
(21, 'Belgium', 'BE', 'BEL', '{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{postcode} {city}\r\n{country}', 0, 1),
(22, 'Belize', 'BZ', 'BLZ', '', 0, 1),
(23, 'Benin', 'BJ', 'BEN', '', 0, 1),
(24, 'Bermuda', 'BM', 'BMU', '', 0, 1),
(25, 'Bhutan', 'BT', 'BTN', '', 0, 1),
(26, 'Bolivia', 'BO', 'BOL', '', 0, 1),
(27, 'Bosnia and Herzegovina', 'BA', 'BIH', '', 0, 1),
(28, 'Botswana', 'BW', 'BWA', '', 0, 1),
(29, 'Bouvet Island', 'BV', 'BVT', '', 0, 1),
(30, 'Brazil', 'BR', 'BRA', '', 0, 1),
(31, 'British Indian Ocean Territory', 'IO', 'IOT', '', 0, 1),
(32, 'Brunei Darussalam', 'BN', 'BRN', '', 0, 1),
(33, 'Bulgaria', 'BG', 'BGR', '', 0, 1),
(34, 'Burkina Faso', 'BF', 'BFA', '', 0, 1),
(35, 'Burundi', 'BI', 'BDI', '', 0, 1),
(36, 'Cambodia', 'KH', 'KHM', '', 0, 1),
(37, 'Cameroon', 'CM', 'CMR', '', 0, 1),
(38, 'Canada', 'CA', 'CAN', '', 0, 1),
(39, 'Cape Verde', 'CV', 'CPV', '', 0, 1),
(40, 'Cayman Islands', 'KY', 'CYM', '', 0, 1),
(41, 'Central African Republic', 'CF', 'CAF', '', 0, 1),
(42, 'Chad', 'TD', 'TCD', '', 0, 1),
(43, 'Chile', 'CL', 'CHL', '', 0, 1),
(44, 'China', 'CN', 'CHN', '', 0, 1),
(45, 'Christmas Island', 'CX', 'CXR', '', 0, 1),
(46, 'Cocos (Keeling) Islands', 'CC', 'CCK', '', 0, 1),
(47, 'Colombia', 'CO', 'COL', '', 0, 1),
(48, 'Comoros', 'KM', 'COM', '', 0, 1),
(49, 'Congo', 'CG', 'COG', '', 0, 1),
(50, 'Cook Islands', 'CK', 'COK', '', 0, 1),
(51, 'Costa Rica', 'CR', 'CRI', '', 0, 1),
(52, 'Cote D\'Ivoire', 'CI', 'CIV', '', 0, 1),
(53, 'Croatia', 'HR', 'HRV', '', 0, 1),
(54, 'Cuba', 'CU', 'CUB', '', 0, 1),
(55, 'Cyprus', 'CY', 'CYP', '', 0, 1),
(56, 'Czech Republic', 'CZ', 'CZE', '', 0, 1),
(57, 'Denmark', 'DK', 'DNK', '', 0, 1),
(58, 'Djibouti', 'DJ', 'DJI', '', 0, 1),
(59, 'Dominica', 'DM', 'DMA', '', 0, 1),
(60, 'Dominican Republic', 'DO', 'DOM', '', 0, 1),
(61, 'East Timor', 'TL', 'TLS', '', 0, 1),
(62, 'Ecuador', 'EC', 'ECU', '', 0, 1),
(63, 'Egypt', 'EG', 'EGY', '', 0, 1),
(64, 'El Salvador', 'SV', 'SLV', '', 0, 1),
(65, 'Equatorial Guinea', 'GQ', 'GNQ', '', 0, 1),
(66, 'Eritrea', 'ER', 'ERI', '', 0, 1),
(67, 'Estonia', 'EE', 'EST', '', 0, 1),
(68, 'Ethiopia', 'ET', 'ETH', '', 0, 1),
(69, 'Falkland Islands (Malvinas)', 'FK', 'FLK', '', 0, 1),
(70, 'Faroe Islands', 'FO', 'FRO', '', 0, 1),
(71, 'Fiji', 'FJ', 'FJI', '', 0, 1),
(72, 'Finland', 'FI', 'FIN', '', 0, 1),
(74, 'France, Metropolitan', 'FR', 'FRA', '{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{postcode} {city}\r\n{country}', 1, 1),
(75, 'French Guiana', 'GF', 'GUF', '', 0, 1),
(76, 'French Polynesia', 'PF', 'PYF', '', 0, 1),
(77, 'French Southern Territories', 'TF', 'ATF', '', 0, 1),
(78, 'Gabon', 'GA', 'GAB', '', 0, 1),
(79, 'Gambia', 'GM', 'GMB', '', 0, 1),
(80, 'Georgia', 'GE', 'GEO', '', 0, 1),
(81, 'Germany', 'DE', 'DEU', '{company}\r\n{firstname} {lastname}\r\n{address_1}\r\n{address_2}\r\n{postcode} {city}\r\n{country}', 1, 1),
(82, 'Ghana', 'GH', 'GHA', '', 0, 1),
(83, 'Gibraltar', 'GI', 'GIB', '', 0, 1),
(84, 'Greece', 'GR', 'GRC', '', 0, 1),
(85, 'Greenland', 'GL', 'GRL', '', 0, 1),
(86, 'Grenada', 'GD', 'GRD', '', 0, 1),
(87, 'Guadeloupe', 'GP', 'GLP', '', 0, 1),
(88, 'Guam', 'GU', 'GUM', '', 0, 1),
(89, 'Guatemala', 'GT', 'GTM', '', 0, 1),
(90, 'Guinea', 'GN', 'GIN', '', 0, 1),
(91, 'Guinea-Bissau', 'GW', 'GNB', '', 0, 1),
(92, 'Guyana', 'GY', 'GUY', '', 0, 1),
(93, 'Haiti', 'HT', 'HTI', '', 0, 1),
(94, 'Heard and Mc Donald Islands', 'HM', 'HMD', '', 0, 1),
(95, 'Honduras', 'HN', 'HND', '', 0, 1),
(96, 'Hong Kong', 'HK', 'HKG', '', 0, 1),
(97, 'Hungary', 'HU', 'HUN', '', 0, 1),
(98, 'Iceland', 'IS', 'ISL', '', 0, 1),
(99, 'India', 'IN', 'IND', '', 0, 1),
(100, 'Indonesia', 'ID', 'IDN', '', 0, 1),
(101, 'Iran (Islamic Republic of)', 'IR', 'IRN', '', 0, 1),
(102, 'Iraq', 'IQ', 'IRQ', '', 0, 1),
(103, 'Ireland', 'IE', 'IRL', '', 0, 1),
(104, 'Israel', 'IL', 'ISR', '', 0, 1),
(105, 'Italy', 'IT', 'ITA', '', 0, 1),
(106, 'Jamaica', 'JM', 'JAM', '', 0, 1),
(107, 'Japan', 'JP', 'JPN', '', 0, 1),
(108, 'Jordan', 'JO', 'JOR', '', 0, 1),
(109, 'Kazakhstan', 'KZ', 'KAZ', '', 0, 1),
(110, 'Kenya', 'KE', 'KEN', '', 0, 1),
(111, 'Kiribati', 'KI', 'KIR', '', 0, 1),
(112, 'North Korea', 'KP', 'PRK', '', 0, 1),
(113, 'Korea, Republic of', 'KR', 'KOR', '', 0, 1),
(114, 'Kuwait', 'KW', 'KWT', '', 0, 1),
(115, 'Kyrgyzstan', 'KG', 'KGZ', '', 0, 1),
(116, 'Lao People\'s Democratic Republic', 'LA', 'LAO', '', 0, 1),
(117, 'Latvia', 'LV', 'LVA', '', 0, 1),
(118, 'Lebanon', 'LB', 'LBN', '', 0, 1),
(119, 'Lesotho', 'LS', 'LSO', '', 0, 1),
(120, 'Liberia', 'LR', 'LBR', '', 0, 1),
(121, 'Libyan Arab Jamahiriya', 'LY', 'LBY', '', 0, 1),
(122, 'Liechtenstein', 'LI', 'LIE', '', 0, 1),
(123, 'Lithuania', 'LT', 'LTU', '', 0, 1),
(124, 'Luxembourg', 'LU', 'LUX', '', 0, 1),
(125, 'Macau', 'MO', 'MAC', '', 0, 1),
(126, 'FYROM', 'MK', 'MKD', '', 0, 1),
(127, 'Madagascar', 'MG', 'MDG', '', 0, 1),
(128, 'Malawi', 'MW', 'MWI', '', 0, 1),
(129, 'Malaysia', 'MY', 'MYS', '', 0, 1),
(130, 'Maldives', 'MV', 'MDV', '', 0, 1),
(131, 'Mali', 'ML', 'MLI', '', 0, 1),
(132, 'Malta', 'MT', 'MLT', '', 0, 1),
(133, 'Marshall Islands', 'MH', 'MHL', '', 0, 1),
(134, 'Martinique', 'MQ', 'MTQ', '', 0, 1),
(135, 'Mauritania', 'MR', 'MRT', '', 0, 1),
(136, 'Mauritius', 'MU', 'MUS', '', 0, 1),
(137, 'Mayotte', 'YT', 'MYT', '', 0, 1),
(138, 'Mexico', 'MX', 'MEX', '', 0, 1),
(139, 'Micronesia, Federated States of', 'FM', 'FSM', '', 0, 1),
(140, 'Moldova, Republic of', 'MD', 'MDA', '', 0, 1),
(141, 'Monaco', 'MC', 'MCO', '', 0, 1),
(142, 'Mongolia', 'MN', 'MNG', '', 0, 1),
(143, 'Montserrat', 'MS', 'MSR', '', 0, 1),
(144, 'Morocco', 'MA', 'MAR', '', 0, 1),
(145, 'Mozambique', 'MZ', 'MOZ', '', 0, 1),
(146, 'Myanmar', 'MM', 'MMR', '', 0, 1),
(147, 'Namibia', 'NA', 'NAM', '', 0, 1),
(148, 'Nauru', 'NR', 'NRU', '', 0, 1),
(149, 'Nepal', 'NP', 'NPL', '', 0, 1),
(150, 'Netherlands', 'NL', 'NLD', '', 0, 1),
(151, 'Netherlands Antilles', 'AN', 'ANT', '', 0, 1),
(152, 'New Caledonia', 'NC', 'NCL', '', 0, 1),
(153, 'New Zealand', 'NZ', 'NZL', '', 0, 1),
(154, 'Nicaragua', 'NI', 'NIC', '', 0, 1),
(155, 'Niger', 'NE', 'NER', '', 0, 1),
(156, 'Nigeria', 'NG', 'NGA', '', 0, 1),
(157, 'Niue', 'NU', 'NIU', '', 0, 1),
(158, 'Norfolk Island', 'NF', 'NFK', '', 0, 1),
(159, 'Northern Mariana Islands', 'MP', 'MNP', '', 0, 1),
(160, 'Norway', 'NO', 'NOR', '', 0, 1),
(161, 'Oman', 'OM', 'OMN', '', 0, 1),
(162, 'Pakistan', 'PK', 'PAK', '', 0, 1),
(163, 'Palau', 'PW', 'PLW', '', 0, 1),
(164, 'Panama', 'PA', 'PAN', '', 0, 1),
(165, 'Papua New Guinea', 'PG', 'PNG', '', 0, 1),
(166, 'Paraguay', 'PY', 'PRY', '', 0, 1),
(167, 'Peru', 'PE', 'PER', '', 0, 1),
(168, 'Philippines', 'PH', 'PHL', '', 0, 1),
(169, 'Pitcairn', 'PN', 'PCN', '', 0, 1),
(170, 'Poland', 'PL', 'POL', '', 0, 1),
(171, 'Portugal', 'PT', 'PRT', '', 0, 1),
(172, 'Puerto Rico', 'PR', 'PRI', '', 0, 1),
(173, 'Qatar', 'QA', 'QAT', '', 0, 1),
(174, 'Reunion', 'RE', 'REU', '', 0, 1),
(175, 'Romania', 'RO', 'ROM', '', 0, 1),
(176, 'Russian Federation', 'RU', 'RUS', '', 0, 1),
(177, 'Rwanda', 'RW', 'RWA', '', 0, 1),
(178, 'Saint Kitts and Nevis', 'KN', 'KNA', '', 0, 1),
(179, 'Saint Lucia', 'LC', 'LCA', '', 0, 1),
(180, 'Saint Vincent and the Grenadines', 'VC', 'VCT', '', 0, 1),
(181, 'Samoa', 'WS', 'WSM', '', 0, 1),
(182, 'San Marino', 'SM', 'SMR', '', 0, 1),
(183, 'Sao Tome and Principe', 'ST', 'STP', '', 0, 1),
(184, 'Saudi Arabia', 'SA', 'SAU', '', 0, 1),
(185, 'Senegal', 'SN', 'SEN', '', 0, 1),
(186, 'Seychelles', 'SC', 'SYC', '', 0, 1),
(187, 'Sierra Leone', 'SL', 'SLE', '', 0, 1),
(188, 'Singapore', 'SG', 'SGP', '', 0, 1),
(189, 'Slovak Republic', 'SK', 'SVK', '{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{city} {postcode}\r\n{zone}\r\n{country}', 0, 1),
(190, 'Slovenia', 'SI', 'SVN', '', 0, 1),
(191, 'Solomon Islands', 'SB', 'SLB', '', 0, 1),
(192, 'Somalia', 'SO', 'SOM', '', 0, 1),
(193, 'South Africa', 'ZA', 'ZAF', '', 0, 1),
(194, 'South Georgia &amp; South Sandwich Islands', 'GS', 'SGS', '', 0, 1),
(195, 'Spain', 'ES', 'ESP', '', 0, 1),
(196, 'Sri Lanka', 'LK', 'LKA', '', 0, 1),
(197, 'St. Helena', 'SH', 'SHN', '', 0, 1),
(198, 'St. Pierre and Miquelon', 'PM', 'SPM', '', 0, 1),
(199, 'Sudan', 'SD', 'SDN', '', 0, 1),
(200, 'Suriname', 'SR', 'SUR', '', 0, 1),
(201, 'Svalbard and Jan Mayen Islands', 'SJ', 'SJM', '', 0, 1),
(202, 'Swaziland', 'SZ', 'SWZ', '', 0, 1),
(203, 'Sweden', 'SE', 'SWE', '{company}\r\n{firstname} {lastname}\r\n{address_1}\r\n{address_2}\r\n{postcode} {city}\r\n{country}', 1, 1),
(204, 'Switzerland', 'CH', 'CHE', '', 0, 1),
(205, 'Syrian Arab Republic', 'SY', 'SYR', '', 0, 1),
(206, 'Taiwan', 'TW', 'TWN', '', 0, 1),
(207, 'Tajikistan', 'TJ', 'TJK', '', 0, 1),
(208, 'Tanzania, United Republic of', 'TZ', 'TZA', '', 0, 1),
(209, 'Thailand', 'TH', 'THA', '', 0, 1),
(210, 'Togo', 'TG', 'TGO', '', 0, 1),
(211, 'Tokelau', 'TK', 'TKL', '', 0, 1),
(212, 'Tonga', 'TO', 'TON', '', 0, 1),
(213, 'Trinidad and Tobago', 'TT', 'TTO', '', 0, 1),
(214, 'Tunisia', 'TN', 'TUN', '', 0, 1),
(215, 'Turkey', 'TR', 'TUR', '', 0, 1),
(216, 'Turkmenistan', 'TM', 'TKM', '', 0, 1),
(217, 'Turks and Caicos Islands', 'TC', 'TCA', '', 0, 1),
(218, 'Tuvalu', 'TV', 'TUV', '', 0, 1),
(219, 'Uganda', 'UG', 'UGA', '', 0, 1),
(220, 'Ukraine', 'UA', 'UKR', '', 0, 1),
(221, 'United Arab Emirates', 'AE', 'ARE', '', 0, 1),
(222, 'United Kingdom', 'GB', 'GBR', '', 1, 1),
(223, 'United States', 'US', 'USA', '{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{city}, {zone} {postcode}\r\n{country}', 0, 1),
(224, 'United States Minor Outlying Islands', 'UM', 'UMI', '', 0, 1),
(225, 'Uruguay', 'UY', 'URY', '', 0, 1),
(226, 'Uzbekistan', 'UZ', 'UZB', '', 0, 1),
(227, 'Vanuatu', 'VU', 'VUT', '', 0, 1),
(228, 'Vatican City State (Holy See)', 'VA', 'VAT', '', 0, 1),
(229, 'Venezuela', 'VE', 'VEN', '', 0, 1),
(230, 'Việt Nam', 'VN', 'VNM', '', 0, 1),
(231, 'Virgin Islands (British)', 'VG', 'VGB', '', 0, 1),
(232, 'Virgin Islands (U.S.)', 'VI', 'VIR', '', 0, 1),
(233, 'Wallis and Futuna Islands', 'WF', 'WLF', '', 0, 1),
(234, 'Western Sahara', 'EH', 'ESH', '', 0, 1),
(235, 'Yemen', 'YE', 'YEM', '', 0, 1),
(237, 'Democratic Republic of Congo', 'CD', 'COD', '', 0, 1),
(238, 'Zambia', 'ZM', 'ZMB', '', 0, 1),
(239, 'Zimbabwe', 'ZW', 'ZWE', '', 0, 1),
(242, 'Montenegro', 'ME', 'MNE', '', 0, 1),
(243, 'Serbia', 'RS', 'SRB', '', 0, 1),
(244, 'Aaland Islands', 'AX', 'ALA', '', 0, 1),
(245, 'Bonaire, Sint Eustatius and Saba', 'BQ', 'BES', '', 0, 1),
(246, 'Curacao', 'CW', 'CUW', '', 0, 1),
(247, 'Palestinian Territory, Occupied', 'PS', 'PSE', '', 0, 1),
(248, 'South Sudan', 'SS', 'SSD', '', 0, 1),
(249, 'St. Barthelemy', 'BL', 'BLM', '', 0, 1),
(250, 'St. Martin (French part)', 'MF', 'MAF', '', 0, 1),
(251, 'Canary Islands', 'IC', 'ICA', '', 0, 1),
(252, 'Ascension Island (British)', 'AC', 'ASC', '', 0, 1),
(253, 'Kosovo, Republic of', 'XK', 'UNK', '', 0, 1),
(254, 'Isle of Man', 'IM', 'IMN', '', 0, 1),
(255, 'Tristan da Cunha', 'TA', 'SHN', '', 0, 1),
(256, 'Guernsey', 'GG', 'GGY', '', 0, 1),
(257, 'Jersey', 'JE', 'JEY', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_coupon`
--

CREATE TABLE `oc_coupon` (
  `coupon_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `code` varchar(10) NOT NULL,
  `type` char(1) NOT NULL,
  `discount` decimal(15,4) NOT NULL,
  `logged` tinyint(1) NOT NULL,
  `shipping` tinyint(1) NOT NULL,
  `total` decimal(15,4) NOT NULL,
  `date_start` date NOT NULL DEFAULT '0000-00-00',
  `date_end` date NOT NULL DEFAULT '0000-00-00',
  `uses_total` int(11) NOT NULL,
  `uses_customer` varchar(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_coupon`
--

INSERT INTO `oc_coupon` (`coupon_id`, `name`, `code`, `type`, `discount`, `logged`, `shipping`, `total`, `date_start`, `date_end`, `uses_total`, `uses_customer`, `status`, `date_added`) VALUES
(4, 'Giảm -10% ', '2222', 'P', '10.0000', 0, 0, '0.0000', '2014-01-01', '2020-01-01', 10, '10', 1, '2009-01-27 13:55:03'),
(5, 'Miễn phí vận chuyển', '3333', 'P', '0.0000', 0, 1, '100.0000', '2014-01-01', '2014-02-01', 10, '10', 1, '2009-03-14 21:13:53'),
(6, 'Giảm 300.000 VNĐ', '1111', 'F', '300.0000', 0, 0, '10.0000', '2014-01-01', '2020-01-01', 100000, '10000', 1, '2009-03-14 21:15:18');

-- --------------------------------------------------------

--
-- Table structure for table `oc_coupon_category`
--

CREATE TABLE `oc_coupon_category` (
  `coupon_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_coupon_history`
--

CREATE TABLE `oc_coupon_history` (
  `coupon_history_id` int(11) NOT NULL,
  `coupon_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_coupon_product`
--

CREATE TABLE `oc_coupon_product` (
  `coupon_product_id` int(11) NOT NULL,
  `coupon_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_currency`
--

CREATE TABLE `oc_currency` (
  `currency_id` int(11) NOT NULL,
  `title` varchar(32) NOT NULL,
  `code` varchar(3) NOT NULL,
  `symbol_left` varchar(12) NOT NULL,
  `symbol_right` varchar(12) NOT NULL,
  `decimal_place` char(1) NOT NULL,
  `value` float(15,8) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_currency`
--

INSERT INTO `oc_currency` (`currency_id`, `title`, `code`, `symbol_left`, `symbol_right`, `decimal_place`, `value`, `status`, `date_modified`) VALUES
(2, 'VNĐ', 'VND', '', ' VNĐ', '', 1.00000000, 1, '2017-04-20 10:33:50');

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer`
--

CREATE TABLE `oc_customer` (
  `customer_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(96) NOT NULL,
  `telephone` varchar(32) NOT NULL,
  `fax` varchar(32) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(9) NOT NULL,
  `cart` text,
  `wishlist` text,
  `newsletter` tinyint(1) NOT NULL DEFAULT '0',
  `address_id` int(11) NOT NULL DEFAULT '0',
  `custom_field` text NOT NULL,
  `ip` varchar(40) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `approved` tinyint(1) NOT NULL,
  `safe` tinyint(1) NOT NULL,
  `token` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_customer`
--

INSERT INTO `oc_customer` (`customer_id`, `customer_group_id`, `store_id`, `firstname`, `lastname`, `email`, `telephone`, `fax`, `password`, `salt`, `cart`, `wishlist`, `newsletter`, `address_id`, `custom_field`, `ip`, `status`, `approved`, `safe`, `token`, `date_added`) VALUES
(1, 0, 0, 'Tuấn', 'Anh', 'votuananh8127@gmail.com', '0983492410', '0983492410', '837558c24b5808b9caaa35c5e8303f60d7f57769', '927769a25', 'a:1:{s:40:"YToxOntzOjEwOiJwcm9kdWN0X2lkIjtpOjM2Nzt9";i:10;}', '', 1, 14, '', '::1', 1, 1, 0, '', '2017-03-28 09:05:50');

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_activity`
--

CREATE TABLE `oc_customer_activity` (
  `activity_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `key` varchar(64) NOT NULL,
  `data` text NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_customer_activity`
--

INSERT INTO `oc_customer_activity` (`activity_id`, `customer_id`, `key`, `data`, `ip`, `date_added`) VALUES
(1, 0, 'order_guest', 'a:2:{s:4:"name";s:11:"CHILI CHILI";s:8:"order_id";i:3;}', '::1', '2017-03-13 13:54:10'),
(2, 0, 'order_guest', 'a:2:{s:4:"name";s:15:"CHILI 2 CHILI 2";s:8:"order_id";i:4;}', '::1', '2017-03-13 16:48:13'),
(3, 0, 'order_guest', 'a:2:{s:4:"name";s:11:"CHILI CHILI";s:8:"order_id";i:5;}', '::1', '2017-03-14 11:19:47'),
(4, 0, 'order_guest', 'a:2:{s:4:"name";s:25:"Võ Tuấn Anh Tuấn Anh";s:8:"order_id";i:6;}', '::1', '2017-03-14 16:14:03'),
(5, 0, 'order_guest', 'a:2:{s:4:"name";s:21:"Hùng Nguyễn Hùngq";s:8:"order_id";i:8;}', '::1', '2017-03-21 14:29:46'),
(6, 0, 'order_guest', 'a:2:{s:4:"name";s:22:"Hoàng Anh Hùng Hùng";s:8:"order_id";i:9;}', '::1', '2017-03-21 15:22:39'),
(7, 0, 'order_guest', 'a:2:{s:4:"name";s:17:"Anh Tuấn Tuấn";s:8:"order_id";i:10;}', '::1', '2017-03-22 16:20:25'),
(8, 0, 'order_guest', 'a:2:{s:4:"name";s:11:"CHILI CHILI";s:8:"order_id";i:11;}', '::1', '2017-03-22 17:02:00'),
(9, 0, 'order_guest', 'a:2:{s:4:"name";s:8:"tuan anh";s:8:"order_id";i:12;}', '::1', '2017-03-23 11:24:08'),
(10, 0, 'order_guest', 'a:2:{s:4:"name";s:11:"CHILI CHILI";s:8:"order_id";i:13;}', '::1', '2017-03-23 16:29:39'),
(11, 0, 'order_guest', 'a:2:{s:4:"name";s:8:"tuan anh";s:8:"order_id";i:14;}', '::1', '2017-03-24 01:45:54'),
(12, 0, 'order_guest', 'a:2:{s:4:"name";s:9:"Anh  Tuan";s:8:"order_id";i:15;}', '::1', '2017-03-24 01:56:11'),
(13, 0, 'order_guest', 'a:2:{s:4:"name";s:8:"Tuan Anh";s:8:"order_id";i:16;}', '::1', '2017-03-24 02:01:13'),
(14, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:17;}', '::1', '2017-03-28 09:05:55'),
(15, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:18;}', '::1', '2017-04-04 12:40:23'),
(16, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:19;}', '::1', '2017-04-05 11:29:19'),
(17, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:20;}', '::1', '2017-04-07 08:31:01'),
(18, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:21;}', '::1', '2017-04-07 09:09:11'),
(19, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:22;}', '::1', '2017-04-07 09:20:05'),
(20, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:23;}', '::1', '2017-04-07 15:53:41'),
(21, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:24;}', '::1', '2017-04-08 08:54:57'),
(22, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:25;}', '::1', '2017-04-08 12:28:25'),
(23, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:26;}', '::1', '2017-04-08 13:59:12'),
(24, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:27;}', '::1', '2017-04-08 14:02:28'),
(25, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:28;}', '::1', '2017-04-10 00:40:11'),
(26, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:29;}', '::1', '2017-04-10 01:04:34'),
(27, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:30;}', '::1', '2017-04-10 01:09:24'),
(28, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:31;}', '::1', '2017-04-10 01:44:29'),
(29, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";s:8:"order_id";i:32;}', '::1', '2017-04-10 01:46:21'),
(30, 1, 'edit', 'a:2:{s:11:"customer_id";s:1:"1";s:4:"name";s:8:"tuan anh";}', '112.78.13.106', '2017-04-10 12:27:14'),
(31, 1, 'address_edit', 'a:2:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";}', '112.78.13.106', '2017-04-10 12:28:11'),
(32, 1, 'address_edit', 'a:2:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";}', '112.78.13.106', '2017-04-10 12:29:16'),
(33, 1, 'address_edit', 'a:2:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";}', '112.78.13.106', '2017-04-10 12:29:54'),
(34, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:33;}', '112.78.13.106', '2017-04-10 12:30:15'),
(35, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:34;}', '112.78.13.106', '2017-04-10 12:36:55'),
(36, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:35;}', '112.78.13.106', '2017-04-10 13:53:57'),
(37, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:37;}', '::1', '2017-04-11 08:40:33'),
(38, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:38;}', '::1', '2017-04-11 10:57:04'),
(39, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:39;}', '::1', '2017-04-11 11:14:38'),
(40, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:40;}', '::1', '2017-04-11 11:31:21'),
(41, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:41;}', '::1', '2017-04-12 00:49:44'),
(42, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:42;}', '112.78.13.106', '2017-04-13 15:28:46'),
(43, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:43;}', '112.78.13.106', '2017-04-13 16:55:28'),
(44, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:44;}', '112.78.13.106', '2017-04-14 10:12:11'),
(45, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:45;}', '112.78.13.106', '2017-04-14 10:21:57'),
(46, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:46;}', '112.78.13.106', '2017-04-14 11:37:43'),
(47, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:47;}', '112.78.13.106', '2017-04-14 11:45:52'),
(48, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:48;}', '112.78.13.106', '2017-04-14 12:13:31'),
(49, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:49;}', '112.78.13.106', '2017-04-14 13:40:57'),
(50, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:50;}', '112.78.13.106', '2017-04-14 13:41:12'),
(51, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:51;}', '112.78.13.106', '2017-04-14 14:17:13'),
(52, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:52;}', '112.78.13.106', '2017-04-14 14:24:05'),
(53, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:53;}', '112.78.13.106', '2017-04-14 14:38:13'),
(54, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:54;}', '112.78.13.106', '2017-04-14 14:43:04'),
(55, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:55;}', '112.78.13.106', '2017-04-14 15:00:15'),
(56, 0, 'order_guest', 'a:2:{s:4:"name";s:21:"Võ Tuấn Anh Tuấn";s:8:"order_id";i:56;}', '::1', '2017-04-20 09:50:07'),
(57, 1, 'order_account', 'a:3:{s:11:"customer_id";s:1:"1";s:4:"name";s:10:"Tuấn Anh";s:8:"order_id";i:57;}', '::1', '2017-04-20 11:09:25');

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_ban_ip`
--

CREATE TABLE `oc_customer_ban_ip` (
  `customer_ban_ip_id` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_group`
--

CREATE TABLE `oc_customer_group` (
  `customer_group_id` int(11) NOT NULL,
  `approval` int(1) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_group_description`
--

CREATE TABLE `oc_customer_group_description` (
  `customer_group_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_history`
--

CREATE TABLE `oc_customer_history` (
  `customer_history_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_ip`
--

CREATE TABLE `oc_customer_ip` (
  `customer_ip_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_customer_ip`
--

INSERT INTO `oc_customer_ip` (`customer_ip_id`, `customer_id`, `ip`, `date_added`) VALUES
(1, 1, '::1', '2017-03-28 09:05:52'),
(2, 1, '112.78.13.106', '2017-04-10 12:26:16'),
(3, 1, '112.78.1.239', '2017-04-10 13:02:58');

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_login`
--

CREATE TABLE `oc_customer_login` (
  `customer_login_id` int(11) NOT NULL,
  `email` varchar(96) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `total` int(4) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_online`
--

CREATE TABLE `oc_customer_online` (
  `ip` varchar(40) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `url` text NOT NULL,
  `referer` text NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_customer_online`
--

INSERT INTO `oc_customer_online` (`ip`, `customer_id`, `url`, `referer`, `date_added`) VALUES
('::1', 0, 'http://localhost/app/boxme/', 'http://localhost/app/boxme/admin/index.php?route=sale/order&amp;token=8d8712e65c7274196c412e4fb26ba196', '2017-04-20 04:01:18');

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_reward`
--

CREATE TABLE `oc_customer_reward` (
  `customer_reward_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `order_id` int(11) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `points` int(8) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_transaction`
--

CREATE TABLE `oc_customer_transaction` (
  `customer_transaction_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_custom_field`
--

CREATE TABLE `oc_custom_field` (
  `custom_field_id` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `value` text NOT NULL,
  `location` varchar(7) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_custom_field_customer_group`
--

CREATE TABLE `oc_custom_field_customer_group` (
  `custom_field_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_custom_field_description`
--

CREATE TABLE `oc_custom_field_description` (
  `custom_field_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_custom_field_value`
--

CREATE TABLE `oc_custom_field_value` (
  `custom_field_value_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_custom_field_value_description`
--

CREATE TABLE `oc_custom_field_value_description` (
  `custom_field_value_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_download`
--

CREATE TABLE `oc_download` (
  `download_id` int(11) NOT NULL,
  `filename` varchar(128) NOT NULL,
  `mask` varchar(128) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_download_description`
--

CREATE TABLE `oc_download_description` (
  `download_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_event`
--

CREATE TABLE `oc_event` (
  `event_id` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `trigger` text NOT NULL,
  `action` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_event`
--

INSERT INTO `oc_event` (`event_id`, `code`, `trigger`, `action`) VALUES
(41, 'limit_record', 'pre.admin.product.add', 'common/chili_setting/limit_record'),
(45, 'boxme_after_edit_product', 'post.admin.product.edit', 'boxme/setting/editproduct'),
(44, 'boxme_after_add_product', 'post.admin.product.add', 'boxme/setting/addproduct');

-- --------------------------------------------------------

--
-- Table structure for table `oc_extension`
--

CREATE TABLE `oc_extension` (
  `extension_id` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `code` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_extension`
--

INSERT INTO `oc_extension` (`extension_id`, `type`, `code`) VALUES
(22, 'total', 'shipping'),
(57, 'total', 'sub_total'),
(58, 'total', 'tax'),
(59, 'total', 'total'),
(576, 'module', 'mb_mini_cart'),
(426, 'module', 'carousel'),
(390, 'total', 'credit'),
(387, 'shipping', 'flat'),
(349, 'total', 'handling'),
(350, 'total', 'low_order_fee'),
(389, 'total', 'coupon'),
(413, 'module', 'category'),
(408, 'module', 'account'),
(393, 'total', 'reward'),
(398, 'total', 'voucher'),
(604, 'module', 'revslideropencart'),
(599, 'module', 'module_col'),
(608, 'module', 'special'),
(431, 'module', 'menu'),
(432, 'module', 'd_quickcheckout'),
(433, 'module', 'google_maps'),
(605, 'module', 'affiliate'),
(435, 'module', 'information'),
(590, 'payment', 'cod'),
(440, 'module', 'showintabs'),
(441, 'module', 'showinconfig'),
(610, 'feed', 'image_manager_plus'),
(575, 'module', 'mb_search'),
(526, 'module', 'html'),
(527, 'module', 'visualbuilder'),
(574, 'module', 'language_switch'),
(591, 'module', 'revslideroutput'),
(609, 'module', 'newsletters'),
(606, 'module', 'latest'),
(607, 'module', 'mb_logo'),
(602, 'module', 'bestseller'),
(611, 'feed', 'google_sitemap'),
(612, 'module', 'content_info'),
(614, 'payment', 'bank_transfer'),
(615, 'payment', 'cheque'),
(616, 'module', 'banner'),
(617, 'module', 'featured');

-- --------------------------------------------------------

--
-- Table structure for table `oc_filter`
--

CREATE TABLE `oc_filter` (
  `filter_id` int(11) NOT NULL,
  `filter_group_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_filter_description`
--

CREATE TABLE `oc_filter_description` (
  `filter_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `filter_group_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_filter_group`
--

CREATE TABLE `oc_filter_group` (
  `filter_group_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_filter_group_description`
--

CREATE TABLE `oc_filter_group_description` (
  `filter_group_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_fraudlabspro`
--

CREATE TABLE `oc_fraudlabspro` (
  `order_id` varchar(11) NOT NULL,
  `is_country_match` char(2) NOT NULL,
  `is_high_risk_country` char(2) NOT NULL,
  `distance_in_km` varchar(10) NOT NULL,
  `distance_in_mile` varchar(10) NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `ip_country` varchar(2) NOT NULL,
  `ip_continent` varchar(20) NOT NULL,
  `ip_region` varchar(21) NOT NULL,
  `ip_city` varchar(21) NOT NULL,
  `ip_latitude` varchar(21) NOT NULL,
  `ip_longitude` varchar(21) NOT NULL,
  `ip_timezone` varchar(10) NOT NULL,
  `ip_elevation` varchar(10) NOT NULL,
  `ip_domain` varchar(50) NOT NULL,
  `ip_mobile_mnc` varchar(100) NOT NULL,
  `ip_mobile_mcc` varchar(100) NOT NULL,
  `ip_mobile_brand` varchar(100) NOT NULL,
  `ip_netspeed` varchar(10) NOT NULL,
  `ip_isp_name` varchar(50) NOT NULL,
  `ip_usage_type` varchar(30) NOT NULL,
  `is_free_email` char(2) NOT NULL,
  `is_new_domain_name` char(2) NOT NULL,
  `is_proxy_ip_address` char(2) NOT NULL,
  `is_bin_found` char(2) NOT NULL,
  `is_bin_country_match` char(2) NOT NULL,
  `is_bin_name_match` char(2) NOT NULL,
  `is_bin_phone_match` char(2) NOT NULL,
  `is_bin_prepaid` char(2) NOT NULL,
  `is_address_ship_forward` char(2) NOT NULL,
  `is_bill_ship_city_match` char(2) NOT NULL,
  `is_bill_ship_state_match` char(2) NOT NULL,
  `is_bill_ship_country_match` char(2) NOT NULL,
  `is_bill_ship_postal_match` char(2) NOT NULL,
  `is_ip_blacklist` char(2) NOT NULL,
  `is_email_blacklist` char(2) NOT NULL,
  `is_credit_card_blacklist` char(2) NOT NULL,
  `is_device_blacklist` char(2) NOT NULL,
  `is_user_blacklist` char(2) NOT NULL,
  `fraudlabspro_score` char(3) NOT NULL,
  `fraudlabspro_distribution` char(3) NOT NULL,
  `fraudlabspro_status` char(10) NOT NULL,
  `fraudlabspro_id` char(15) NOT NULL,
  `fraudlabspro_error` char(3) NOT NULL,
  `fraudlabspro_message` varchar(50) NOT NULL,
  `fraudlabspro_credits` varchar(10) NOT NULL,
  `api_key` char(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_geo_zone`
--

CREATE TABLE `oc_geo_zone` (
  `geo_zone_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date_modified` datetime NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_geo_zone`
--

INSERT INTO `oc_geo_zone` (`geo_zone_id`, `name`, `description`, `date_modified`, `date_added`) VALUES
(3, 'Vùng tính phí', 'Sẽ tính phí với các địa điểm được liệt kê', '2015-12-17 15:42:02', '2009-01-06 23:26:25'),
(4, 'Vùng miễn phí', 'Sẽ miễn phí đối  với các địa điểm liệt kê', '2015-12-17 15:41:53', '2009-06-23 01:14:53'),
(5, 'Tất cả các vùng', 'Áp dụng cho tất cả các vùng', '0000-00-00 00:00:00', '2015-12-17 15:42:38');

-- --------------------------------------------------------

--
-- Table structure for table `oc_globalpay_order`
--

CREATE TABLE `oc_globalpay_order` (
  `globalpay_order_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_ref` char(50) NOT NULL,
  `order_ref_previous` char(50) NOT NULL,
  `pasref` varchar(50) NOT NULL,
  `pasref_previous` varchar(50) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `capture_status` int(1) DEFAULT NULL,
  `void_status` int(1) DEFAULT NULL,
  `settle_type` int(1) DEFAULT NULL,
  `rebate_status` int(1) DEFAULT NULL,
  `currency_code` char(3) NOT NULL,
  `authcode` varchar(30) NOT NULL,
  `account` varchar(30) NOT NULL,
  `total` decimal(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_globalpay_order_transaction`
--

CREATE TABLE `oc_globalpay_order_transaction` (
  `globalpay_order_transaction_id` int(11) NOT NULL,
  `globalpay_order_id` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `type` enum('auth','payment','rebate','void') DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_globalpay_remote_order`
--

CREATE TABLE `oc_globalpay_remote_order` (
  `globalpay_remote_order_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_ref` char(50) NOT NULL,
  `order_ref_previous` char(50) NOT NULL,
  `pasref` varchar(50) NOT NULL,
  `pasref_previous` varchar(50) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `capture_status` int(1) DEFAULT NULL,
  `void_status` int(1) DEFAULT NULL,
  `settle_type` int(1) DEFAULT NULL,
  `rebate_status` int(1) DEFAULT NULL,
  `currency_code` char(3) NOT NULL,
  `authcode` varchar(30) NOT NULL,
  `account` varchar(30) NOT NULL,
  `total` decimal(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_globalpay_remote_order_transaction`
--

CREATE TABLE `oc_globalpay_remote_order_transaction` (
  `globalpay_remote_order_transaction_id` int(11) NOT NULL,
  `globalpay_remote_order_id` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `type` enum('auth','payment','rebate','void') DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_information`
--

CREATE TABLE `oc_information` (
  `information_id` int(11) NOT NULL,
  `bottom` int(1) NOT NULL DEFAULT '0',
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_information`
--

INSERT INTO `oc_information` (`information_id`, `bottom`, `sort_order`, `status`) VALUES
(3, 0, 0, 1),
(4, 1, 1, 1),
(5, 1, 4, 1),
(7, 0, 0, 1),
(8, 0, 0, 1),
(9, 0, 0, 1),
(10, 0, 0, 1),
(11, 0, 0, 1),
(12, 0, 0, 1),
(13, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_information_description`
--

CREATE TABLE `oc_information_description` (
  `information_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `title` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_information_description`
--

INSERT INTO `oc_information_description` (`information_id`, `language_id`, `title`, `description`, `meta_title`, `meta_description`, `meta_keyword`) VALUES
(3, 2, 'Chính sách riêng tư', '&lt;h4&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;1. CHÍNH SÁCH BẢO MẬT&lt;/span&gt;&lt;/h4&gt;\r\n&lt;p&gt;Khi khách hàng sử dụng dịch vụ tại website TÊNWEBSITE, chúng tôi sẽ đảm bảo quyền riêng tư của người dùng theo những điều khoản dưới đây.&lt;/p&gt;\r\n&lt;h4&gt;&lt;br&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;2. SỬ DỤNG THÔNG TIN&lt;/span&gt;&lt;/h4&gt;\r\n&lt;p&gt;TÊNWEBSITE chỉ dùng thông tin của người dùng để phục vụ cho chính Người dùng khi bạn sử dụng dịch vụ tại DOMAINWEBSITE. Vì vậy chúng tôi sẽ dùng thông tin cá nhân của bạn để:&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Xác minh danh tính của người sử dụng dịch vụ&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Xác nhận thanh toán&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Những hình thức sử dụng &amp;nbsp;để chia sẻ thông tin của bạn với các công ty khác bao gồm (nhưng không giới hạn) như công ty thẻ tín dụng hoặc tổ chức ngân hàng... nhằm mục đích phục vụ giao dịch của bạn&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Cung cấp các dịch vụ hỗ trợ &amp;amp; chăm sóc khách hàng. Nâng cấp dịch vụ của chúng tôi;&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Thực hiện giao dịch thanh toán &amp;amp; gửi các thông báo trong quá trình giao dịch;&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Xử lý khiếu nại, thu phí &amp;amp; giải quyết sự cố;&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Gửi bạn các thông tin về chương trình Marketing, các thông báo &amp;amp; chương trình khuyến mại;&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;So sánh độ chính xác của thông tin cá nhân của bạn trong quá trình kiểm tra với bên thứ ba.&lt;br&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h4&gt;&lt;br&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;3. HẠN CHẾ CÔNG BỐ THÔNG TIN&lt;/span&gt;&lt;/h4&gt;\r\n&lt;p&gt;Chúng tôi sẽ không bán, tiết lộ hoặc cho thuê cho bên thứ ba nhận dạng cá nhân người sử dụng có thông tin thu thập tại trang web của chúng tôi, thông qua các máy chủ của chúng tôi, ngoài việc cung cấp dịch vụ của chúng tôi và như trong chính sách bảo mật.&lt;/p&gt;\r\n&lt;h4&gt;&lt;br&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;4. MẬT KHẨU VÀ THÔNG TIN BÍ MẬT CỦA CHÚNG TÔI&lt;/span&gt;&lt;/h4&gt;\r\n&lt;p&gt;Chúng tôi yêu cầu bạn không tiết lộ hoặc chia sẻ mật khẩu hoặc các thông tin nhận dạng khác mà chúng tôi cung cấp cho bạn với bất cứ một ai khác, kể cả nhân viên của TÊNWEBSITE. Mật khẩu và thông tin là tài sản của chúng tôi và việc sử dụng của bạn có thể bị thu hồi theo quyết định của chúng tôi. Bạn cũng bị cấm sử dụng bất kỳ mật khẩu nào khác mà nó không phải là mật khẩu tài khoản của bạn.&lt;/p&gt;\r\n&lt;h4&gt;&lt;br&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;5. THU THẬP THÔNG TIN&lt;/span&gt;&lt;/h4&gt;\r\n&lt;p&gt;TÊNWEBSITE sẽ thu thập các thông tin bao gồm (nhưng không giới hạn) sau đây để đảm bảo an toàn cho giao dịch: địa chỉ IP, loại trình duyệt web, các trang bạn truy cập trong quá trình sử dụng dịch vụ tại TÊNWEBSITE, thông tin về máy tính, thiết bị mạng, ...&lt;/p&gt;\r\n&lt;p&gt;Trong một số dịch vụ, chúng tôi sẽ yêu cầu bạn cung cấp trung thực và chính xác những thông tin sau:&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Thông tin nhân thân và liên hệ (đối với tổ chức và &amp;nbsp;cá nhân) như: tên, ngày sinh, giới tính, địa chỉ, điện thoại, địa chỉ thư trực tuyến (email), giấy tờ hợp pháp (như Chứng minh nhân dân, Giấy phép kinh doanh, mã số thuế, ...)&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Thông tin tài chính như số tài khoản ngân hàng, số thẻ ghi n\n', 'Chính sách riêng tư', '', ''),
(7, 2, 'Hướng dẫn đặt hàng', '&lt;h4&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;HƯỚNG DẪN ĐẶT HÀNG&lt;/span&gt;&lt;/h4&gt;\r\n\r\n\r\n&lt;p&gt;Quý khách có thể thao tác đặt hàng theo các bước sau&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;→ Bước 1: Xem thông tin sản phẩm.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;→ Bước 2: Chọn số lượng sản phẩm muốn mua.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;→ Bước 3: Chọn thêm vào giỏ.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;→ Bước 4: Chọn icon giỏ hàng.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;→ Bước 5: Chọn xem giỏ hàng.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;→ Bước 6: Tại trang giỏ hàng , quý khách có thể điều chỉnh số lượng sản phẩm, thêm mã coupon, voucher nếu có cũng như phí vận chuyển ,…&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;img src=&quot;http://js.chili.vn/Img/hdoc3/1.png&quot; class=&quot;img-responsive&quot;&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p style=&quot;margin-bottom: 20px; padding: 0px;&quot;&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;&lt;img src=&quot;http://js.chili.vn/Img/hdoc3/2.png&quot; class=&quot;img-responsive&quot;&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p style=&quot;margin-bottom: 20px; padding: 0px;&quot;&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;&lt;img src=&quot;http://js.chili.vn/Img/hdoc3/3.png&quot; class=&quot;img-responsive&quot;&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p style=&quot;margin-bottom: 20px; padding: 0px;&quot;&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;&lt;img src=&quot;http://js.chili.vn/Img/hdoc3/4.png&quot; class=&quot;img-responsive&quot;&gt;&lt;/p&gt;', 'huong-dan-dat-hang', '', ''),
(8, 2, 'Hướng dẫn thanh toán qua Ngân Lượng', '&lt;h4&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;Thanh toán trực tuyến an toàn với ví NganLuong.vn&lt;/span&gt;&lt;/h4&gt;&lt;p&gt;Khi chọn hình thức thanh toán này quý khách vui lòng nhấn vào link được khoanh đỏ trong hình để thao tác được thuận tiện hơn.&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;http://js.chili.vn/Img/hdoc3/25.png&quot; class=&quot;img-responsive&quot;&gt;&lt;/p&gt;', 'Hướng dẫn thanh toán qua Ngân Lượng', '', ''),
(9, 2, 'Hướng dẫn thanh toán qua Paypal', '&lt;h4&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;PayPal Express (Bao gồm thẻ tín dụng và thẻ ghi nợ)&lt;/span&gt;&lt;/h4&gt;\r\n\r\n&lt;p&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Chấp nhận thanh toán qua PayPal.&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp; • Khi chọn PayPal, Quý khách sẽ được đưa đến một trang đăng nhập của PayPal, tại đây Quý khách điền địa chỉ email và mật khẩu để đăng nhập tài khoản Paypal của Quý khách.&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp; • Sau khi đăng nhập, tại trang tiếp theo Quý khách sẽ thấy rõ: giá, số lượng và tổng cộng số tiền dịch vụ mà Quý khách sắp thanh toán, hãy xem kĩ trước khi chấp nhận thanh toán.&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp; • Thực hiện giao dịch thanh toán hoàn toàn trực tuyến, đơn giản thuận tiện cho khách hàng.&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp; • An toàn bảo mật cho khách hàng trong thanh toán.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Để đảm bảo quyền lợi khách hàng, khách hàng cần lưu ý.&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp; • Tên miền là loại tài nguyên đặc biệt vì vậy sau khi tên miền đăng ký thành công sẽ không hoàn phí.&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp; • Thời hạn để Quý khách thực hiện khiếu nại là 45 ngày kể từ ngày giao dịch.&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp; • Các thông tin thanh toán của Quý khách sẽ được bảo mật và được xác nhận với PayPal.&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp; • Dịch vụ chỉ được đăng ký/gia hạn khi nhận được thanh toán và thông tin chính xác đầy đủ.&lt;/p&gt;\r\n\r\n&lt;div&gt;&lt;br&gt;&lt;/div&gt;', 'Hướng dẫn thanh toán qua Paypal', '', ''),
(10, 2, 'Chuyển khoản ngân hàng', '&lt;p&gt;Khi nhấn chọn phương thức thanh toán này, quý khách vui lòng xem thông tin tài khoản ngân hàng bên dưới vài thực hiện giao dịch tại ngân hàng. Ví dụ vị trí tài khoản ngân hàng và thực hiện giao dịch tại ngân hàng.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;&lt;img src=&quot;http://js.chili.vn/Img/hdoc3/10.png&quot; class=&quot;img-responsive&quot; style=&quot;display: inline-block;&quot;&gt;&lt;/p&gt;', 'Chuyển khoản ngân hàng', '', ''),
(11, 2, 'Hướng dẫn thanh toán qua Bảo Kim', '&lt;p&gt;&lt;img src=&quot;http://js.chili.vn/Img/hdoc3/11.png&quot; class=&quot;img-responsive&quot; style=&quot;display: inline-block;&quot;&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Sau khi chọn phương thức thanh toán trực truyến bảo kim, quý khách có thể làm theo các bước &quot;Hướng dẫn mua hàng&quot; trực tiếp tại trang thanh toán của baokim.vn.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;img src=&quot;http://js.chili.vn/Img/hdoc3/9.png&quot; class=&quot;img-responsive&quot; style=&quot;display: inline-block;&quot;&gt;&lt;br&gt;&lt;/p&gt;', 'Hướng dẫn thanh toán qua Bảo Kim', '', ''),
(12, 2, 'Hướng dẫn thanh toán', '&lt;p&gt;Sau khi tới trang thanh toán, quý khách có thể dễ dàng thanh toán bằng cách đăng ký tài khoản mới để đảm bảo các quyền lợi tối ưu nhất dành cho quý khách theo các thao tác sau.&lt;/p&gt;\r\n\r\n&lt;h4&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;A.Hướng dẫn thanh toán bằng cách đăng ký tài khoản&lt;/span&gt;&lt;/h4&gt;\r\n\r\n&lt;p&gt;→ Bước 1: Quý khách vui lòng nhấn vào thẻ “Đăng ký tài khoản”.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 2: Điền thông tin đăng ký tài khoản.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 3: Chọn phương thức vận chuyển phù hợp.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 4: Chọn phương thức thanh toán.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 5: Xem lại thông tin giỏ hàng.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 6: Đồng ý với các điều khoản.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 7: Nhấn “Xác nhận đơn hàng”.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;img src=&quot;http://js.chili.vn/Img/hdoc3/5.png&quot; class=&quot;img-responsive&quot; style=&quot;display: inline-block;&quot;&gt;&lt;/p&gt;\r\n\r\n&lt;h4&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;B.Hướng dẫn thanh toán bằng khách thanh toán&lt;/span&gt;&lt;/h4&gt;\r\n\r\n&lt;p&gt;Tại trang thanh toán khi quý khách muốn thực hiện thanh toán mà không cần đăng ký tài khoản mới, quý khách có thể thanh toán dưới tài khoản “Khách thanh toán” bằng những thao tác dưới đây.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 1: Quý khách vui lòng nhấn vào thẻ “Khách thanh toán”.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 2: Điền thông tin tài khoản.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 3: Chọn phương thức vận chuyển phù hợp.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 4: Chọn phương thức thanh toán.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 5: Xem lại thông tin giỏ hàng.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 6: Đồng ý với các điều khoản và Nhấn “Xác nhận đơn hàng”.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;img src=&quot;http://js.chili.vn/Img/hdoc3/6.png&quot; class=&quot;img-responsive&quot; style=&quot;display: inline-block;&quot;&gt;&lt;/p&gt;\r\n\r\n&lt;h4&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;C.Hướng dẫn thanh toán bằng cách đăng nhập&lt;/span&gt;&lt;/h4&gt;\r\n\r\n&lt;p&gt;Khi quý khách đã có tài khoản tại trang web của chúng tôi, tại trang thanh toán quý khách có thể dễ dàng thanh toán theo các bước sau:&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 1: Quý khách vui lòng nhấn vào thẻ “ Đăng nhập”.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 2: Điền thông tin đăng nhập và nhấn “Đăng nhập”.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 3: Chọn địa chỉ quý khách mong muốn thanh toán và giao hàng.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 4: Chọn phương thức thanh toán.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 5: Xem lại thông tin giỏ hàng.&lt;/p&gt;\r\n\r\n&lt;p&gt;→ Bước 6: Đồng ý với các điều khoản và Nhấn “Xác nhận đơn hàng”.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;img src=&quot;http://js.chili.vn/Img/hdoc3/7.png&quot; class=&quot;img-responsive&quot; style=&quot;display: inline-block;&quot;&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;img src=&quot;http://js.chili.vn/Img/hdoc3/8.png&quot; class=&quot;img-responsive&quot; style=&quot;display: inline-block;&quot;&gt;&lt;/p&gt;', 'Hướng dẫn thanh toán', '', '');
INSERT INTO `oc_information_description` (`information_id`, `language_id`, `title`, `description`, `meta_title`, `meta_description`, `meta_keyword`) VALUES
(13, 2, 'Thỏa thuận người dùng', '&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;Chào mừng bạn đến CHILI!&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;VUI LÒNG ĐỌC KỸ NHỮNG ĐIỀU KHOẢN DỊCH VỤ. KHI TRUY CẬP HAY SỬ DỤNG TRANG WEB NÀY, BẠN ĐỒNG Ý VỚI NHỮNG RÀNG BUỘC CỦA CÁC ĐIỀU KHOẢN VÀ ĐIỀU KIỆN MÔ TẢ Ở ĐÂY VÀ TẤT CẢ CÁC ĐIỀU KHOẢN được quy chiếu. NẾU BẠN KHÔNG ĐỒNG Ý VỚI TẤT CẢ NHỮNG ĐIỀU KHOẢN, KHÔNG SỬ DỤNG TRANG WEB NÀY. Những điều khoản của dịch vụ (&quot;Điều khoản&quot;) áp dụng cho người dùng truy cập và sử dụng các trang web của CHILI (“Dịch vụ”), một dịch vụ của công ty Cổ phần Mắt Bão (gọi chung là &quot;CHILI&quot;), được đặt tại www.CHILI.vn và www.chiliweb.org (&quot;Trang web&quot;). CHILI có thể rà soát lại các Điều khoản của Thỏa thuận này, bao gồm bất cứ thay đổi nào được cập nhật tại bất kỳ thời điểm nào, với điều khoản sửa đổi có hiệu lực cho tất cả người sử dụng kể từ ngày được ghi nhận trên Trang web. Bạn có thể nhận được thông báo cụ thể về những thay đổi hoặc sửa đổi. Do đó Người dùng nên tham khảo các Điều khoản thường xuyên. Việc tiếp tục sử dụng của bạn đối với trang web này, sau khi những thay đổi hoặc sửa đổi được công bố, sẽ xác nhận sự đồng ý của bạn về những thay đổi hoặc sửa đổi. Nếu bạn không đồng ý với các điều khoản sửa đổi, bạn phải ngừng sử dụng các trang web của CHILI.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;1. MÔ TẢ DỊCH VỤ&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Các dịch vụ bao gồm các công cụ phát triển web trực tuyến và các ứng dụng web được lưu trữ và tổ chức hoạt động bởi CHILI cho phép bạn tạo và xuất bản các trang web sau đây gọi tắt là &quot;Ứng dụng CHILI web&quot;. Người dùng / khách hàng của “Ứng dụng CHILI web” sẽ được gọi là &quot;bạn&quot;. Dịch vụ cũng bao gồm dịch vụ lưu trữ web cho các trang web mà bạn tạo ra thông qua trang web.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;2. NGƯỜI SỬ DỤNG TRANG WEB&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;CHILI cho phép người dùng tạo và hoạt động các trang web được lưu trữ bởi CHILI (&quot;Trang web thành viên&quot;). CHILI không phê duyệt hoặc kiểm soát các trang web của thành viên. Ngoài ra, bạn hiểu và thừa nhận rằng các giao dịch kinh doanh của bạn, thư từ hoặc tương tác với bất cứ trang web thành viên nào và với bất kỳ điều khoản, điều kiện nào là hoàn toàn giữa bạn và nhà điều hành của trang web thành viên đó. Do đó, bạn thừa nhận và đồng ý rằng CHILI không chịu trách nhiệm hoặc bảo đảm nào về nội dung, chức năng, kinh doanh, tính hợp pháp, chính xác, hoàn thiện, chất lượng, sự tin cậy, an ninh, hữu dụng hoặc sự thực hành của bất kỳ người dùng nào hoặc vì bất cứ thỏa thuận, giao dịch nào được thực hiện hoặc liên quan với bất kỳ người dùng nào của CHILI. Nội dung lưu trữ của bất kỳ Trang web thành viên không bao hàm sự chứng thực hoặc tài trợ của CHILI hoặc bất cứ tổ chức nào với hoạt động của nó hoặc những nội dung, kinh doanh, hoặc hoạt động của các trang web thành viên, và nếu bạn tạo ra bất kỳ trang web thành viên nào, bạn không được phép làm bất cứ điều gì để bao hàm bất kỳ chứng thực, tài trợ, liên kết, liên kết, mối quan hệ với CHILI như mô tả. Bạn sử dụng và tương tác với người dùng là bạn chịu những rủi ro của riêng bạn. Bạn không thể sử dụng tên, biểu tượng hoặc nhãn hiệu khác của CHILI để ngụ ý bất kỳ tài trợ, liên kết hay mối quan hệ giữa bạn và CHILI.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;3. GIẤY PHÉP&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Bạn được cấp phép để truy cập và sử dụng Trang web và Ứng dụng CHILI web. Trang web và Ứng dụng CHILI web được cấp phép bởi chủ sở hữu CHILI, Công ty Cổ phần Mắt Bão trụ sở tại Tầng 3-Toà nhà Anna, Công viên phần mềm Quang Trung, số 49 Tô Ký, P. Tân Chánh Hiệp, Q. 12, Tp.HCM. Giấy phép này bắt buộc tuân theo các Điều khoản.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Bạn chịu trách nhiệm cho việc lựa chọn của Trang web và “Ứng dụng CHILI web” để đạt được kết quả dự định của bạn, và để cài đặt, sử dụng, và kết quả thu được từ đó. CHILI có quyền sửa đổi, đình chỉ các trang web hoặc “Ứng dụng CHILI web” bất cứ lúc nào mà CHILI có hoặc không có thông báo và không có bất kỳ trách nhiệm với bạn.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Bạn phải có ít nhất 13 năm tuổi để tạo ra một tài khoản và sử dụng Trang web và Ứng dụng CHILI web. Bằng cách đăng ký, bạn đại diện và bảo đảm với chúng tôi rằng bạn là 13 tuổi hoặc hơn. CHILI có quyền chấm dứt tài khoản của bạn và giấy phép này và từ chối phục vụ bạn bất cứ lúc nào mà CHILI có hoặc không thông báo. CHILI giữ quyền từ chối phục vụ cho bất cứ ai bất cứ lúc nào mà không cần thông báo vì bất cứ lý do gì.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;4. ID NGƯỜI DÙNG VÀ TÊN MIỀN PHỤ&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Để truy cập Ứng dụng CHILI web và chức năng của Ứng dụng CHILI web và để tạo ra một trang web của người dùng, bạn sẽ được yêu cầu để đăng ký một ID truy cập và mật khẩu. ID truy cập và mật khẩu chỉ có thể được sử dụng bởi bạn. Bạn sẽ chịu trách nhiệm cho tất cả các hoạt động diễn ra dựa trên ID truy cập của bạn và giữ an toàn mật khẩu của bạn.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Là một phần của Ứng dụng CHILI web, CHILI cũng cung cấp cho người dùng, đã đăng ký, sử dụng miễn phí tên miền phụ của CHILI (ví dụ: [tên miền phụ].chiliweb.org) (“Tên miền phụ”) cho mục đích duy nhất là lưu trữ các trang web của họ. CHILI giữ lại tất cả các quyền đối với bất kỳ Tên miền phụ nào và có quyền thu hồi hoặc đình chỉ việc sử dụng của bất kỳ Tên miền phụ bất cứ lúc nào mà không có lý do.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Bạn đồng ý rằng tất cả các Tên miền phụ của CHILI được sở hữu bởi CHILI, không thể chuyển nhượng và CHILI có thể vì lý do nào, hoặc không có lý do, tùy theo quyết định của mình và không có thông báo hay có trách nhiệm với bạn hoặc bất kỳ bên thứ ba, ngay lập tức chấm dứt hoặc đình chỉ tài khoản của bạn, Tên đăng nhập và Tên miền phụ, và loại bỏ bất kỳ nội dung liên quan đến tài khoản và tên người dùng của bạn.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;5. LIÊN KẾT ĐẾN TRANG WEB CỦA BÊN THỨ BA&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Trang web, Ứng dụng CHILI web và Trang web thành viên (kể cả dưới Tên miền phụ CHILI) có thể chứa liên kết đến các trang web của bên thứ ba, bao gồm cả liên kết tới Trang web thành viên, văn bản; đoạn video được nhúng vào; mẫu chào hàng; và các ứng dụng phần mềm (bao gồm cả các tiện ích hỗ về thời tiết; tỷ giá; tán gẫu) (gọi chung là &quot;Trang Liên Kết&quot;). Những Trang Liên Kết và các bên thứ ba không được kiểm soát và / hoặc thuộc sở hữu của CHILI và CHILI không chịu trách nhiệm về nội dung của bất kỳ Trang Liên Kết nào, bao gồm nhưng không giới hạn bất kỳ nội dung nào bên trong mỗi Trang Liên Kết. CHILI không chịu trách nhiệm cho bất kỳ một sự chuyển giao nào từ bất kỳ một Trang Liên Kết. Những Trang Liên Kết đều là tài sản của bên thứ ba tương ứng và có thể được bảo vệ bởi bản quyền hoặc pháp luật sở hữu trí tuệ và các điều ước quốc tế. CHILI cung cấp những liên kết này đến bạn chỉ như là một tiện nghi và không phê duyệt và không chịu trách nhiệm về nội dung, bảo mật, chức năng, hoặc sự thực hành của các bên thứ ba. Bạn thừa nhận và đồng ý rằng CHILI có thể vô hiệu hóa việc sử dụng của bạn hoặc loại bỏ bất kỳ Trang liên kết nào trên CHILI hoặc Tên miền phụ mà họ vi phạm các Điều khoản này.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Ứng dụng CHILI web có thể dựa vào các bên thứ ba để cung cấp một số chức năng. Chức năng này có thể làm cho một tính năng đặc biệt của Ứng dụng CHILI web phụ thuộc vào thành phần bên ngoài để hoạt động. Trong bất kỳ trường hợp nào, CHILI không bảo đảm, tuyên bố, hoặc phân phối cho bất kỳ thành phần nào của bên thứ ba.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Bạn có trách nhiệm với bất kỳ nhà cung cấp thứ ba nào bên ngoài về các thủ tục liên quan mà mà họ đại diện cho Tên miền phụ của bạn.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;6. ĐIỀU KHOẢN NGƯỜI DÙNG&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Bạn đồng ý rằng bạn có trách nhiệm về việc sử dụng của bạn trên trang web, các Dịch vụ và Ứng dụng CHILI web, cho bất kỳ trang web thành viên nào mà bạn tạo ra hoặc hoạt động trên đó, cho bất kỳ bài viết nào bạn thực hiện và cho bất kỳ hậu quả. Bạn đồng ý rằng bạn sẽ sử dụng các trang web, Dịch vụ và Ứng dụng CHILI web và tạo ra và hoạt động bất kỳ trang web thành viên nào phù hợp với các quy tắc được quy định trong các Điều khoản này (bao gồm nhưng không giới hạn Chính sách Nội dung được trình bày dưới đây).&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Như là một điều kiện của việc sử dụng của bạn trên Trang web, Ứng dụng CHILI web, và các Dịch vụ, bạn bảo đảm với CHILI rằng bạn sẽ không sử dụng Trang web, Ứng dụng CHILI web hoặc trang web thành viên mà bạn tạo ra vì bất kỳ mục đích trái pháp luật, lừa đảo hoặc bị cấm bởi những Điều khoản này. Bạn không thể sử dụng các trang web, Ứng dụng CHILI web hoặc Trang web thành viên mà bạn tạo ra trong bất kỳ cách thức nào mà chúng có thể gây tổn hại, vô hiệu hóa, quá tải, hoặc làm suy yếu các Trang web hoặc Ứng dụng CHILI web hoặc can thiệp việc sử dụng của những người khác. Bạn không được lấy hoặc cố lấy bất kỳ thành phần hoặc thông tin nào thông qua các phương tiện bất hợp pháp hoặc thông qua Trang web hoặc Ứng dụng CHILI web. Các Trang web hoặc các trang web thành viên mà bạn tạo ra có thể chứa những dịch vụ thông báo, khu vực tán gẫu, nhóm tin, diễn đàn, cộng đồng, các trang web cá nhân và thương mại, lịch, bưu thiếp, và / hoặc tin nhắn hoặc các phương tiện thông tin khác được thiết kế để cho phép bạn hoặc người khác có thể giao tiếp với công chúng hoặc một nhóm (gọi chung là &quot;Dịch vụ tương tác&quot;), bạn đồng ý sử dụng các Dịch vụ tương tác chỉ để thông báo, gửi và nhận tin nhắn phù hợp với các Chính sách Nội dung, các Điều khoản và pháp luật.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Phần lớn các Dịch vụ tương tác được tìm thấy trên Trang web và Trang web thành viên được cung cấp bởi, và là trách nhiệm của người hoặc những người đã đăng. CHILI không thường xuyên theo dõi các Dịch vụ tương tác hoặc Trang web Thành viên và không chịu trách nhiệm cho nội dung đó (bao gồm nhưng không giới hạn, bất kỳ vi rút hoặc các tính năng vô hiệu hóa khác). CHILI chỉ đơn thuần là cung cấp truy cập và lưu trữ các nội dung như một dịch vụ cho khách hàng của mình. CHILI không xác nhận, hỗ trợ, đại diện hoặc đảm bảo tính trung thực, chính xác, chức năng, bảo mật, tính hợp pháp, chất lượng, độ tin cậy của bất kỳ thông tin liên lạc hoặc nội dung được đăng qua Trang web hoặc các Trang web Thành viên. Bạn thừa nhận rằng bất kỳ sự tín nhiệm nào vào những gì được đăng tải qua Dịch vụ sẽ là nguy cơ của riêng bạn.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Mặc dù CHILI không bị bắt buộc và không thường xuyên sàng lọc hoặc giám sát bất kỳ nội dung của người sử dụng hoặc tin nhắn hoặc các Trang web Thành viên, CHILI có quyền làm như vậy vào bất kỳ thời điểm nào để loại bỏ, ngăn chặn truy cập hoặc từ chối đăng tải, hiển thị hoặc phân phối bất kỳ nội dung hoặc tài liệu hoặc bất kỳ Trang web Thành viên nào vì bất kỳ lý do nào hoặc không có lý do. CHILI có quyền chấm dứt sự truy cập của bạn đến các Trang web, Trang web Thành viên và bất kỳ hoặc tất cả các Dịch vụ Tương tác, và loại bỏ hoặc vô hiệu hóa truy cập vào bất kỳ Trang web Thành viên hoặc các nội dung người dùng, bất kỳ lúc nào mà không cần thông báo vì bất kỳ lý do gì hoặc cho không có lý do. CHILI có quyền vào mọi lúc tiết lộ bất kỳ thông tin nào được cho là cần thiết để (a) đáp ứng luật pháp, quy định, yêu cầu của chính phủ, (b) thi hành các Điều khoản này, (c) phát hiện, ngăn chặn gian lận, bảo mật, hoặc các vấn đề kỹ thuật, (d) trả lời các yêu cầu hỗ trợ người dùng hoặc (e) bảo vệ quyền, tài sản hoặc sự an toàn của CHILI, người sử dụng và công chúng. Luôn luôn cẩn thận khi đưa ra bất kỳ thông tin nhận dạng cá nhân về bản thân hoặc con cái của bạn ở bất kỳ Dịch vụ Tương tác nào, hoặc trên bất kỳ Trang web Thành viên nào. Thông tin cá nhân được cung cấp trong các kết nối với bất kỳ Trang web Thành viên được thu thập bởi các bên thứ ba mà họ đang điều hành Trang web Thành viên đó, không phải bởi CHILI. Chính sách Bảo mật của CHILI không áp dụng cho, và chúng tôi không chịu trách nhiệm dưới bất kỳ hình thức nào, bất kỳ thông tin mà bạn cung cấp cho bên thứ ba khi kết nối với Trang web Thành viên hoặc các bên thứ ba điều hành Trang web Thành viên, họ có thể sử dụng thông tin cá nhân mà bạn cung cấp cho họ. CHILI không kiểm soát hay chứng thực nội dung, các thông điệp hoặc thông tin được tìm thấy ở bất kỳ Dịch vụ tương tác hoặc Trang web Thành viên nào, và do đó, CHILI từ chối bất kỳ trách nhiệm pháp lý nào đối với các Dịch vụ Tương tác và bất kỳ hành động nào gây nên hệ quả từ sự tham gia của bạn trong bất kỳ Dịch vụ Tương tác hoặc việc sử dụng của bạn trên bất kỳ Trang web Thành viên. Người quản lý lưu trữ web không được uỷ quyền là người phát ngôn của CHILI, vì thế quan điểm của họ không nhất thiết là sự phản ánh của CHILI.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;7. CHÍNH SÁCH NỘI DUNG&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Trang web và Dịch vụ của Chli là để cung cấp cho các doanh nghiệp, tổ chức và cá nhân để tạo ra và phát triển một sự hiện diện trực tuyến chuyên nghiệp. CHILI tôn trọng các quyền của bạn và không muốn kiểm duyệt bất kỳ văn bản, hình ảnh, dữ liệu, thông tin, video âm nhạc, đồ họa, tin nhắn hoặc các mục hoặc các dữ liệu khác (gọi chung là &quot;Nội dung&quot;) mà chúng được chứa trong những gì mà bạn đăng tải trên Trang web hoặc trong bất kỳ Trang web Thành viên. Tuy nhiên để cho phép tiếp tục đăng tải các nội dung, CHILI đã thiết lập các quy tắc về một số loại nội dung nhất định không được lưu trữ bởi CHILI và / hoặc tạo ra bằng cách sử dụng Ứng dụng CHILI web được quy định trong chính sách này (&quot;Chính sách Nội dung&quot;). Những quy định này không tạo ra bất kỳ quyền của bên thứ ba nào, nhưng có thể chỉ được thi hành bởi CHILI.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;8. BẰNG CÁCH SỬ DỤNG CÁC DỊCH VỤ, BẠN ĐỒNG Ý RẰNG:&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Bạn sẽ sử dụng các dịch vụ cho mục đích tạo ra và phát triển sự hiện diện trực tuyến chuyên nghiệp.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể tải lên, xuất bản, gửi, phân phối, phổ biến bất kỳ tài liệu phỉ báng, lạm dụng, quấy rối, đe dọa hoặc vi phạm các quyền hợp pháp (như quyền riêng tư và công khai) của người khác.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể tải lên, xuất bản, gửi, phân phối, phổ biến bất kỳ nội dung được coi là khiêu dâm và / hoặc khiêu dâm bằng CHILI.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể tải lên, xuất bản, gửi, phân phối, phổ biến bất kỳ tài liệu gây nên sự thù hận đối với các nhóm dựa trên chủng tộc hoặc nguồn gốc dân tộc, tôn giáo, khuyết tật, giới tính, tuổi tác, khuynh hướng tình dục / giới tính.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể tải lên, xuất bản, gửi, phân phối, phổ biến bất kỳ tài liệu tạo thành một mối đe dọa bạo lực trực tiếp đối với bất kỳ người hoặc nhóm người nào.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể tải lên, xuất bản, gửi, phân phối, phổ biến bất kỳ tài liệu mạo danh hoặc có ý định mạo danh người khác mà chúng có thể được dùng để đánh lừa hoặc gây nhầm lẫn cho người khác.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể tải lên, xuất bản, gửi, phân phối, phổ biến các tập tin bất kỳ của bên thứ ba hoặc nội dung có chứa tài liệu, dưới bất kỳ hình thức nào, được bảo vệ bởi luật sở hữu trí tuệ (hoặc bởi quyền riêng tư và / hoặc công khai) trừ khi bạn sở hữu hoặc kiểm soát các quyền hoặc đã nhận được sự đồng ý cần thiết. Bạn không thể gửi thông tin riêng tư của cá nhân hoặc công ty mà không được phép của các bên liên quan.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể cố ý vi phạm quyền sở hữu trí tuệ của bên thứ ba trên bất kỳ Trang web Thành viên.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể tải lên, xuất bản, gửi, phân phối, phổ biến bất kỳ tập tin có chứa virus, phần mềm độc hại, mã độc hại, tập tin lỗi, hoặc bất kỳ phần mềm hoặc các chương trình tương tự khác có thể gây hại cho hoạt động của máy tính của khác.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể sử dụng Ứng dụng CHILI web cho việc truyền tải của thư rác và / hoặc bất kỳ loại hình tiếp thị lan truyền, loại hình đa cấp và / hoặc âm mưu lừa đảo.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không có thể tải về, tải lên, xuất bản, gửi, phân phối, phổ biến bất kỳ tập tin nào được đăng bởi người sử dụng khác của Ứng dụng CHILI web và Dịch vụ Thông tin khác mà bạn biết hoặc đáng lẽ phải biết.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể làm giả hoặc xoá thẩm quyền tác giả, các thông báo thích hợp hoặc hợp pháp, sở hữu hoặc nhãn mác xuất xứ hoặc nguồn gốc của phần mềm hoặc nội dung khác chứa đựng bên trong một file được tải lên, tải về, được công bố, được đăng, phân phối, phổ biến bằng cách sử dụng các Ứng dụng CHILI web.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể sử dụng Ứng dụng CHILI web để thu hoạch hoặc thu thập thông tin về những người khác, bao gồm cả e-mail, địa chỉ, mà không có sự đồng ý của họ.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể tải lên, xuất bản, gửi, phân phối, phổ biến bất kỳ thông tin trái phép mang tính riêng tư, bí mật và cá nhân về những người khác.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể tải lên, xuất bản, gửi, phân phối, phổ biến bất kỳ tài liệu được sử dụng cho các mục đích trái pháp luật hoặc để đề xướng các hoạt động nguy hiểm và bất hợp pháp.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn không thể tải lên các tài liệu, tập tin mà chúng không phục vụ cho nội dung của website của bạn được tạo ra từ Ứng dụng CHILI web.&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;CHILI không chịu trách nhiệm cho bất kỳ Nội dung được đăng tải, lưu trữ hoặc tải lên của bạn hoặc bất kỳ bên thứ ba, hoặc cho bất kỳ sự bổ tổn thất hoặc thiệt hại nào, CHILI cũng không chịu trách nhiệm đối với bất kỳ sai lầm, nói xấu, vu khống, phỉ báng, thiếu sót, sai lầm, khiêu dâm, nội dung khiêu dâm, thô tục hoặc nội dung gây khó chịu, mà bạn có thể gặp trên Trang web hoặc trong bất kỳ Trang web Thành viên nào. Việc bạn sử dụng các Vùng tương tác và các Trang web Thành viên là nguy cơ của riêng bạn. Là một nhà cung cấp dịch vụ tương tác, CHILI không chịu trách nhiệm về bất kỳ sự xác nhận nào, đại diện hoặc nội dung được cung cấp bởi Người dùng hoặc các Bên thứ ba khác. Mặc dù CHILI không có nghĩa vụ phải theo dõi, chỉnh sửa hoặc giám sát bất kỳ Nội Dung được đăng bởi các Bên thứ ba, CHILI có quyền và có toàn quyền quyết định, để loại bỏ, theo dõi hoặc chỉnh sửa bất kỳ nội dung nào được đăng tải hoặc được lưu trữ trên Trang web vào bất kỳ lúc nào và bất kỳ Lý do nào mà không cần thông báo, và bạn hoàn toàn chịu trách nhiệm cho việc tạo bản sao lưu dự phòng và thay thế cho bất kỳ Nội dung bạn đăng hoặc lưu trữ trên Trang web với chi phí của bạn. Vi phạm bất kỳ phần nào của Chính sách nội dung có thể dẫn đến chấm dứt ngay lập tức hoặc đình chỉ tài khoản của bạn và/hoặc xóa các nội dung của bạn và/hoặc bạn có thể được báo cáo cho các cơ quan có thẩm quyền thích hợp mà CHILI có hoặc không thông báo cho bạn.&lt;br&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;/p&gt;\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;9. SỬ DỤNG VÀ LƯU TRỮ&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Những gì được đăng tải lên Dịch vụ Tương tác có thể bị giới hạn sao chép, sử dụng và/hoặc phổ biến. CHILI giữ lại quyền để tạo ra và/hoặc thay đổi những giới hạn về sử dụng và lưu trữ bất kỳ lúc nào có hoặc không có thông báo. Bạn có trách nhiệm tôn trọng những giới hạn đó.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Bạn đồng ý rằng CHILI không có trách nhiệm đối với việc xóa Nội dung hoặc sự thất bại khi lưu trữ Nội dung hoặc truyền tải bất kỳ Nội dung hoặc Dịch vụ Tương tác nào được duy trì bởi CHILI và bạn hoàn toàn chịu trách nhiệm cho việc tạo bản sao lưu dự phòng và thay thế bất kỳ Nội dung nào mà bạn đăng tải hoặc lưu trữ trên Trang web với chi phí là của bạn.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Bạn hiểu và đồng ý rằng mọi dịch vụ đều có thể chứa lỗi gây rối, sai sót, lỗi và các vấn đề khác có thể làm hư hỏng hệ thống, dữ liệu. Do đó bạn có trách nhiệm thực hiện việc sao lưu tất cả dữ liệu lưu trữ trên website của bạn. Mọi mất mát , hư hỏng, lỗi về dữ liệu phát sinh trong suốt thời gian duy trì dịch vụ CHILI, chúng tôi không thể và sẽ không chịu trách nhiệm pháp lý và bồi thường đối với bất kỳ tổn thất hoặc thiệt hại nào phát sinh do bạn không tuân thủ quy định này.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Bạn đồng ý rằng trước khi gửi yêu cầu hỗ trợ về kỹ thuật hoặc chỉnh sửa website, bạn phải sao lưu tất cả dữ liệu tại thời điểm yêu cầu hỗ trợ kỹ thuật. Bạn đồng ý giữ cho Mắt Bão! các công ty liên quan, nhân viên, các đối tác, nhà cung cấp, người bán hàng, các tổ chức cấp giấy phép của Mắt Bão, được vô hại đối với các yêu cầu bồi thường, bao gồm các khoản phí luật sư hợp lý của bất kỳ bên thứ ba nào, phát sinh từ việc bạn không tuân thủ quy định này.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Bạn đồng ý rằng không gian lưu trữ không giới hạn trong tất cả các gói dịch vụ được mô tả ở dịch vụ CHILI, có thể đến một giới hạn không hơn 100,000 tập tin và thư mục cho mỗi một website. Bất kỳ website nào vượt quá giới hạn này sẽ được ban hành một cảnh báo vi phạm và bị đình chỉ nếu không có hành động nào được thực hiện bởi bạn để giảm số lượng của các tập tin và thư mục.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Bạn đồng ý rằng dịch vụ lưu trữ dành cho các trang web và Ứng dụng CHILI web là dịch vụ lưu trữ chia sẻ (share hosting), có thể dẫn đến việc giới hạn tốc độ truy cập hoặc số lượng truy cập trong cùng một thời điểm và có thể dẫn đến việc hoạt động của website bị gián đoạn. Bất kỳ website nào vượt quá giới hạn này sẽ được ban hành một cảnh báo vi phạm và đề nghị chuyển đổi trang web lên hình thức lưu trữ tối ưu hơn, ví dụ: máy chủ ảo (VPS) hoặc máy chủ riêng (server). Bạn đồng ý thanh toán các chi phí liên quan tới việc chuyển đổi này.&quot;&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;10. DỊCH VỤ CAO CẤP&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Mỗi một tài khoản Thành viên được tạo ra một hoặc nhiều Dịch vụ Cao cấp có trả phí từ chúng tôi. Hiện tại, Dịch vụ Cao cấp bao gồm các tùy chọn khác nhau như đăng ký tên miền đã thuộc sở hữu của bạn, đăng ký tên miền mới cho cá nhân, email cho tên miền đó,... Các loại hình và biểu phí Dịch vụ Cao cấp của chúng tôi được mô tả ở đây và có thể thay đổi theo thời gian.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;CHILI có thể tạm thời thay đổi biểu phí cho Dịch vụ Cao cấp áp dụng với một số chương trình khuyến mãi ở bất kỳ thời điểm nào, và những thay đổi như vậy có hiệu quả tức thì ngay khi các chương trình khuyến mãi được đăng tải trên CHILI.vn. Bất kỳ thay đổi biểu phí Dịch vụ Cao cấp nào mà không phải là tạm thời hoặc khuyến mãi sẽ có hiệu lực ở thời điểm ba mươi (30) ngày sau khi chúng tôi thông báo cho bạn bằng cách đăng những thay đổi như vậy trên CHILI.vn. Trừ khi có quy định khác, tất cả các lệ phí tính bằng Việt Nam Đồng.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Với Dịch vụ Cao cấp, bạn có thể nâng cấp lên gói dịch vụ cao hơn để đáp ứng được nhu cầu của mình. Yêu cầu nâng cấp gói dịch vụ sẽ được thực hiện sau khi bạn hoàn tất thủ tục đóng phí chênh lệch. Việc ghi nhận chuyển đổi gói dịch vụ sẽ được thể hiện bằng phiếu thu hoặc ghi nhận giao dịch Ngân hàng.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Với Dịch vụ Cao cấp, website của bạn sẽ được khởi tạo và hoàn tất trong 03 ngày làm việc đối với gói dịch vụ Start Up và 05 ngày làm việc đối với các gói dịch vụ Speed Up; Success và Glory. Thông thường website của bạn sẽ được khởi tạo trong ngày, ngay sau khi bạn hoàn tất việc đóng phí, tuy nhiên dữ liệu mặc định sẽ là dữ liệu mẫu. Trong khoảng thời hạn như đã nêu, CHILI sẽ nhập dữ liệu cho bạn dựa trên số lượng dữ liệu bạn được hỗ trợ theo từng gói dịch vụ, thời gian hoàn tất sẽ còn tuỳ thuộc vào thời điểm mà chúng tôi nhận những dữ liệu từ bạn.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;11. CHẠY THỬ NGHIỆM VÀ NGHIỆM THU TRANG WEB&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Đối với dịch vụ cao cấp của CHILI, trang web của bạn sẽ được chạy thử nghiệm và nghiệm thu bởi bạn trước khi đưa vào sử dụng chính thức. Bạn đồng ý và tuân thủ theo quy trình chạy thử nghiệm và nghiệm thu sau đây:&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Trang web sẽ được đưa lên môi trường internet dưới hình thức chạy thử nghiệm. Trong thời gian chạy thử nghiệm, trang web sẽ được đặt dưới tên miền phụ do bạn lựa chọn ở bước đăng kí dịch vụ, ví dụ: ten_cua_ban.chiliweb.org, đồng thời, CHILI sẽ đặt một banner thông báo thử nghiệm dưới chân của trang web. Banner này sẽ được gỡ bỏ ngay khi thử nghiệm kết thúc;&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Một thư điện tử (email) sẽ được Mắt Bão gởi đến bạn thông qua hệ thống gởi email tự động hoặc do nhân viên gởi để xác nhận việc nghiệm thu. Trong vòng 03 (ba) ngày kể từ lúc nhận được email, bạn đồng ý rằng bạn sẽ phản hồi hoặc đồng ý việc nghiệm thu trang web. Bạn cũng đồng ý rằng sau 03 (ba) ngày, kể từ lúc email được Mắt Bão gởi đi mà không có sự phản hồi từ bạn, trang web được nghiệm thu. CHILI, với quyền hạn và nghĩa vụ của mình, sẽ thông báo cho bạn về việc gởi email nghiệm thu bằng điện thoại hoặc tin nhắn nhưng không có nghĩa là chúng tôi luôn thực hiện như vậy. Bạn xác nhận và đồng ý việc kiểm tra email, kể cả trong hộp thư rác, là quyền và nghĩa vụ của bạn để đảm bảo quyền lợi của bạn;&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Sau khi trang web được nghiệm thu, việc chạy thử nghiệm chính thức được kết thúc, đồng thời bạn được phép chạy trang web của mình trên tên miền chính (nếu bạn có) và sử dụng email (kèm theo trên các gói dịch vụ CHILI).&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;12. ĐIỀU KHOẢN THANH TOÁN&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Bạn có trách nhiệm thanh toán tất cả các lệ phí và thuế áp dụng với Dịch vụ Cao cấp một cách kịp thời bằng phương thức thanh toán hợp lệ. Bạn cho phép CHILI tính phí bạn thông qua thẻ tín dụng của bạn, thẻ cào, thẻ ghi nợ, PayPal, hoặc tài khoản của tổ chức tài chính (sau đây gọi là &quot;Phương thức Thanh toán&quot;) cho tất cả các chi phí vào tài khoản của bạn ở CHILI. Phương thức Thanh toán của bạn sẽ được tính phí cho các loại phí hiện hành mà bạn sử dụng vào các Dịch vụ Cao cấp vào ngày mà bạn bấm vào nút &quot;Đặt Mua&quot; trong quá trình đặt hàng. Các Dịch vụ Cao cấp do CHILI cung cấp phải nộp tiền định kỳ. Bạn đồng ý rằng CHILI có thể tự động tính lệ phí bằng Phương thức Thanh toán của bạn vào đầu mỗi khoảng thời gian định kỳ (hoặc đến 30 ngày trước khi tên miền của bạn hết hạn). Ví dụ, nếu bạn chọn một Dịch vụ Cao cấp với một kế hoạch mỗi ba tháng, bạn sẽ được lập hoá đơn định kỳ ba (03) tháng vào ngày mà bạn nhấp vào nút &quot;Đặt Mua&quot;. Trong trường hợp tên miền, bạn có thể được lập hoá đơn khoản 30 ngày trước khi tên miền của bạn hết hạn - điều này tùy thuộc vào các điều khoản gia hạn của Nhà Đăng ký Tên Miền (những điều khoản này không thuộc thẩm quyền của CHILI).&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Trong tất cả các trường hợp, bạn xác nhận và đồng ý rằng bất kỳ thẻ tín dụng và hóa đơn thanh toán liên quan và thông tin thanh toán mà bạn cung cấp cho CHILI có thể được CHILI chia sẻ cho các công ty hoạt động thay mặt cho CHILI, chẳng hạn như công ty xử lý thanh toán và/hoặc các cơ quan tín dụng, chỉ duy nhất cho Mục đích kiểm tra tín dụng, thực hiện việc thanh toán để CHILI phục vụ bạn. Các điều khoản về việc thanh toán của bạn sẽ được dựa trên Phương thức Thanh toán mà bạn lựa chọn và có thể được xác định bởi thỏa thuận giữa bạn và tổ chức tài chính cung cấp Phương thức Thanh toán đó. Bạn đồng ý trả cho CHILI tất cả các chi phí phát sinh trong tài khoản của bạn cho bất kỳ Dịch vụ Cao cấp nào được sử dụng. Nếu Phương thức Thanh toán của bạn không hoạt động hoặc tài khoản của bạn quá hạn, (a) bạn đồng ý thanh toán tất cả chi phí phải trả cho CHILI theo yêu cầu, (b) CHILI toàn quyền đình chỉ hoặc chấm dứt Dịch vụ Cao cấp hoặc Tài khoản của bạn tại CHILI, bao gồm cả xóa Trang web Thành viên của bạn từ CHILI.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;13. CHÍNH SÁCH HỦY BỎ ĐĂNG KÝ VÀ CHẤM DỨT DỊCH VỤ&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Tư cách thành viên của bạn đối với Dịch vụ Cao cấp của chúng tôi sẽ được tiếp tục cho đến khi bạn hủy bỏ đăng ký. Hủy sẽ xảy ra vào cuối thời gian đăng ký đã thoả thuận. Trừ trường hợp được cung cấp bởi chính sách Đảm bảo Hoàn tiền của chúng tôi, chúng tôi không hoàn lại tiền lại cho khoản thời gian mà bạn không sử dụng hết. Chính sách Hủy bỏ này áp dụng cho tất cả Dịch vụ Cao cấp ngoại trừ Tên miền. Xin vui lòng xem &quot;Quy định Tên miền&quot; để biết thêm thông tin.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Để hủy Dịch vụ Cao cấp của bạn, hãy truy cập vào trang hồ sơ của bạn tại “Tài khoản của tôi”.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;CHILI có thể tạm ngưng hoặc chấm dứt sử dụng Dịch vụ của bạn bất kỳ lúc nào, mà không cần thông báo vì lý do gì. CHILI sẽ cố gắng cung cấp cho bạn thông-báo-ưu-tiên về việc tạm ngưng hoặc chấm dứt các Dịch vụ bằng cách gửi một thư điện tử (email), nhưng không có nghĩa là CHILI có nghĩa vụ thực hiện như vậy. Bạn sẽ vẫn chịu trách nhiệm về tất cả sự sử dụng của bạn thông qua các Dịch vụ trước khi chấm dứt, và việc thực hiện nghĩa vụ của bạn, bao gồm nhưng không giới hạn, thanh toán tất cả số tiền bạn nợ trong quá trình sử dụng Trang web hoặc Dịch vụ và/hoặc Ứng dụng CHILI web trước khi chấm dứt hoặc ngừng sử dụng Dịch vụ. Bạn đồng ý trả mọi chi phí và phụ phí (bao gồm cả phí luật sư) mà CHILI có thể phải trả để (1) thu các số tiền bạn nợ theo Thỏa thuận này hoặc (2) để tiến hành thủ tục pháp lý để giải quyết tranh chấp về sự vi phạm của bạn nếu xảy ra.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;14. THUẾ&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Bạn có trách nhiệm thanh toán bất kỳ khoản thuế nào đối với việc sử dụng của bạn với CHILI, bao gồm, nhưng không giới hạn, bán hàng, sử dụng, thuế giá trị gia tăng. Nếu được yêu cầu, bạn sẽ nhanh chóng cung cấp cho CHILI biên lai và/hoặc giấy chứng nhận liên quan ngay khi có thể một cách hợp lý. Trong phạm vi mà CHILI bắt buộc phải thu thuế như vậy, thuế áp dụng sẽ được thêm vào tài khoản thanh toán của bạn.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;15. CẬP NHẬT TRANG WEB&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Bạn đồng ý tích cực duy trì và cập nhật bất kỳ Trang web Thành viên mà bạn tạo ra một cách thường xuyên. Không đăng nhập vào Dịch vụ hoặc cập nhật Trang web Thành viên hơn (12) mười hai tháng, CHILI có thể loại bỏ hoặc vô hiệu hóa việc truy cập vào Trang web Thành viên đó, và sẽ dẫn đến hết thời hạn của bất kỳ các khoản tín dụng không sử dụng nào.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;16. CHÍNH SÁCH ĐẢM BẢO HOÀN TIỀN&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;CHILI cung cấp dịch vụ có phí cho người dùng. Hầu hết các dịch vụ trả tiền đều bao gồm chính sách Đảm bảo Hoàn tiền trong vòng 30 ngày trở lại, trừ các khoản thanh toán không hoàn lại. Nếu không hài lòng với bất kỳ dịch vụ nào mà bạn đang sử dụng tại CHILI vì bất kỳ lý do gì, bạn sẽ nhận được một khoản hoàn lại nếu bạn hủy bỏ dịch vụ có phí trong vòng 30 ngày kể từ ngày đăng kí. Chính sách Đảm bảo Hoàn tiền trong vòng 30 ngày KHÔNG áp dụng các khoản thanh toán để mua tên miền riêng, chuyển đổi Nhà quản lý tên miền, dịch vụ Email cao cấp kèm theo, sử dụng dịch vụ cộng thêm bao gồm nhưng không giới hạn: dịch vụ cập nhật Nội dung, thiết kế banner slide, phí cài đặt và cho các khoản tín dụng đã được kích hoạt như mã khuyến mãi, phiếu giảm giá, ... Số tiền hoàn lại của bạn sẽ là giá trị của dịch vụ trả tiền bạn đã mua từ CHILI trừ đi các khoản thuế theo quy định của Nhà Nước Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam, các lệ phí đăng ký tên miền và phí dịch vụ cộng thêm, và trừ đi giá trị của bất kỳ các khoản tín dụng nào đã được kích hoạt. Nếu giá trị của các khoản tín dụng mà bạn đã mua lại vượt quá mức giá của dịch vụ trả tiền, bạn sẽ không nhận được khoản hoàn lại.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Thời gian và phương thức hoàn tiền:&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Việc hoàn tiền sẽ được tiến hành ngay khi nhận được yêu cầu hợp lệ từ bạn. Đồng thời, tiến trình xử lý hoàn tiền sẽ không vượt quá 02 (hai) ngày làm việc;&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn phải chuyển phát biên bản thanh lý hợp đồng trước khi nhận lại tiền;&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bạn thanh toán đơn hàng theo phương thức nào thì sẽ được hoàn tiền theo phương thức đó. Có thể thông qua: Smartlink, hoặc Paypal, hoặc chuyển khoản, hoặc tại một trong các văn phòng công ty Cổ Phần Mắt Bão. Với các phương thức hoàn tiền thông qua đối tác thứ ba của CHILI, bạn có thể phải chịu phí chuyển tiền;&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Trong một số trường hợp, bạn có thể nhận tiền mặt trực tiếp ngay tại văn phòng công ty;&lt;br&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;/p&gt;\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;17. ĐIỀU KHOẢN VỀ TÊN MIỀN&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Bạn là chủ sở hữu hợp pháp của tên miền mà bạn đăng ký. Bạn đồng ý thanh toán tất cả các loại thuế, phí liên quan đến việc đăng ký tên miền của bạn. Chúng tôi sẽ cố gắng trong điều kiện cho phép để liên lạc với bạn trước khi thời gian đăng ký hết hạn và cung cấp cho bạn các tùy chọn để gia hạn đăng ký tên miền của bạn. Nếu CHILI không thể liên lạc với bạn bằng cách sử dụng các thông tin bạn cung cấp, CHILI không chịu trách nhiệm về sự mất mát tên miền. CHILI có quyền thay đổi giá tên miền bất kỳ lúc nào. Bạn không thể trả lại hoặc đổi tên miền của bạn.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;18. GIÁM SÁT, QUYỀN RIÊNG TƯ&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;CHILI có quyền, nhưng không bị bắt buộc, giám sát việc sử dụng các máy chủ và nội dung liên quan trong tài khoản người dùng. Bạn thừa nhận rằng bạn không kỳ vọng sự riêng tư đối với bất kỳ thông tin liên lạc, hoặc các nội dung đăng tải, và bạn đồng ý việc giám sát như vậy. Đối với thông tin như là “Làm thế nào chúng tôi thu thập và sử dụng thông tin cá nhân trên Trang web này?”, xin vui lòng xem Chính sách Quyền Riêng Tư của chúng tôi.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Bằng cách sử dụng Ứng dụng CHILI web và/hoặc Trang web CHILI, bạn đồng ý với bất kỳ chuyển giao thông tin cá nhân, được thu thập bởi CHILI, cho mục đích lưu trữ các thông tin mà CHILI và/hoặc đại lý duy trì những tiện ích.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Bạn có trách nhiệm bảo vệ và thực thi các quyền của bạn với bất kỳ sự đệ trình nào của bạn. Sẽ không có bồi thường đối với việc sử dụng những thông tin đệ trình, như được cung cấp ở đây. CHILI không chịu trách nhiệm đưa lên hoặc sử dụng bất kỳ sự Đệ trình nào mà bạn có thể cung cấp và có thể loại bỏ bất kỳ thông tin vào bất kỳ lúc nào tùy theo quyết định của CHILI.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;19. QUYỀN SỞ HỮU TRÍ TUỆ&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Bạn thừa nhận rằng CHILI sở hữu tất cả quyền, danh hiệu, và sự quan tâm đến các Trang web, Ứng dụng CHILI web và/hoặc bất kỳ nội dung nào trên Trang web mà chúng không được đăng bởi Thành viên của CHILI và/hoặc một bên thứ ba được công nhận, bao gồm tất cả các quyền sở hữu trí tuệ ( &quot;SHTT CHILI&quot;). SHTT CHILI được bảo vệ bởi luật pháp nước Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam và các luật sở hữu trí tuệ quốc tế. Theo đó, bạn đồng ý rằng bạn sẽ không sao chép, thay đổi, điều chỉnh, hoặc tạo ra các sản phẩm phái sinh từ các Trang web CHILI hoặc SHTT CHILI. Bạn cũng đồng ý rằng bạn sẽ không sử dụng bất kỳ robot, spider, thiết bị tự động hoặc thao tác thủ công để theo dõi hoặc sao chép bất kỳ nội dung nào từ các Trang web CHILI hoặc SHTT CHILI&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;20. BỒI THƯỜNG&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Bạn đồng ý không làm tổn hại và đòi bồi thường CHILI, công ty con, chi nhánh của nó, cán bộ, đại lý và người lao động và chống lại bất kỳ khiếu nại của bên thứ ba phát sinh liên quan đến việc sử dụng của bạn với Ứng dụng CHILI web, dịch vụ và/hoặc Trang web CHILI, bao gồm bất kỳ trách nhiệm pháp lý hoặc chi phí phát sinh từ tất cả các khiếu nại, tổn thất, thiệt hại (thực tế hoặc hậu quả), chi phí kiện tụng và phí luật sư.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;21. GIỚI HẠN BẢO HÀNH&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;CHILI không bảo đảm rằng Trang web, Dịch vụ, Ứng dụng CHILI web hoặc những Trang web Thành viên sẽ đáp ứng yêu cầu của bạn hoặc các hoạt động của chúng sẽ không bị gián đoạn hoặc không bao giờ lỗi. Toàn bộ rủi ro về chất lượng và hiệu quả của Trang web, Dịch vụ và Ứng dụng CHILI web là do bạn. Với bất kỳ khiếm khuyết đã nêu ra trước đó, bạn chịu chi phí toàn bộ cho các sửa chữa dịch vụ cần thiết hoặc hoàn thiện.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;&lt;span style=&quot;font-weight: bold; color: inherit; font-family: inherit; font-size: 15px; line-height: 1.1;&quot;&gt;22. ĐIỀU KHOẢN MIỄN TRỪ TRÁCH NHIỆM&lt;/span&gt;&lt;br&gt;&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;Thông tin, nội dung, phần mềm, sản phẩm, và dịch vụ trên Trang web và Dịch vụ có thể bao gồm những sự thiếu chính xác hoặc lỗi đánh máy. Những thay đổi sẽ được bổ sung định kỳ các thông tin ở đây. CHILI và/hoặc những nhà cung cấp có thể cải tiến và/hoặc thay đổi trong bất kỳ lúc nào. Lời khuyên nhận được thông qua Trang web hay bất kỳ Trang web Thành viên nào không nên được tin cậy vào đó, ví dụ các vấn đề cá nhân, y tế, luật pháp hoặc tài chính. Bạn nên hỏi ý kiến của những chuyên gia cho những lời khuyên phù hợp với hoàn cảnh của bạn.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Bạn thừa nhận và đồng ý rằng CHILI không (1) xác nhận trang web của bất kỳ bên thứ ba, hoặc (2) chịu trách nhiệm về tính chính xác của vật liệu bất kỳ chứa trong đó, hoặc (3) bất kỳ hành vi xâm phạm quyền sở hữu trí tuệ của bên thứ ba phát sinh từ đây, hoặc (4) bất kỳ gian lận nào hoặc tội phạm khác được tạo điều kiện bằng cách đó.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;CHILI sẽ không chịu trách nhiệm cho bất kỳ hành động hoặc thiếu sót nào của bên thứ ba, bao gồm nhưng không giới hạn, tổ chức tài chính của bạn, bất kỳ hệ thống thanh toán nào, bất kỳ bên cung cấp dịch vụ thứ ba, bất kỳ nhà cung cấp dịch vụ viễn thông, các điểm truy cập Internet hoặc các trung tâm dữ liệu hoặc thiết bị máy tính hoặc phần mềm, bất kỳ dịch vụ thư tín hoặc dịch vụ giao nhận hoặc cho bất kỳ trường hợp ngoài tầm kiểm soát của CHILI (bao gồm nhưng không giới hạn, cháy, lụt, thảm họa thiên nhiên khác, chiến tranh, bạo loạn, đình công, hành vi dân sự hoặc cơ quan quân sự, thiết bị bị lỗi, virus máy tính, xâm nhập hoặc tấn công bởi một bên thứ ba, hoặc bị gián đoạn điện; viễn thông; dịch vụ tiện ích khác).&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;CHILI và/hoặc những nhà cung cấp không đại diện cho sự phù hợp, sự đáng tin cậy, an toàn, có sẵn, hạn định và sự chính xác của những thông tin, phần mềm, sản phẩm, dịch vụ và những hình ảnh có liên quan đăng tải trên Trang web hoặc truy cập thông qua Dịch vụ cho bất kỳ mục đích nào. CHILI và/hoặc những nhà cung cấp của nó do đó từ chối mọi bảo đảm và điều kiện liên quan đến những thông tin, phần mềm, sản phẩm, dịch vụ và những hình ảnh có liên quan, bao gồm tất cả các ngụ ý bảo đảm điều kiện thương mại, phù hợp với một mục đích cụ thể, và không vi phạm.&lt;/p&gt;\r\n\r\n\r\n\r\n&lt;p&gt;Theo những luật lệ hiện hành, trong trường hợp CHILI và/hoặc những nhà cung cấp của nó không chịu trách nhiệm cho bất kỳ trực tiếp, gián tiếp, trừng phạt, ngẫu nhiên, bất kỳ tổn hại nào bao gồm nhưng không giới hạn, tổn hại do không thể sử dụng dữ liệu hay lợi nhuận, Dịch vụ hoặc Ứng dụng CHILI web, với sự chậm trễ hoặc không có khả năng sử dụng Trang web, Dịch vụ hoặc Ứng dụng CHILI web, sự dự phòng hoặc thất bại cung cấp dịch vụ, hoặc vì bất kỳ thông tin, phần mềm, sản phẩm, dịch vụ và những hình ảnh có liên quan lấy được từ Trang web hay Dịch vụ. Nếu bạn không hài lòng với bất kỳ phần nào của Trang web, Dịch vụ hoặc Ứng dụng CHILI web, hoặc với bất kỳ điều khoản sử dụng&lt;/p&gt;', 'Thỏa thuận người dùng', '', '');
INSERT INTO `oc_information_description` (`information_id`, `language_id`, `title`, `description`, `meta_title`, `meta_description`, `meta_keyword`) VALUES
(5, 2, 'Điều khoản sử dụng', '&lt;h4 style=&quot;margin-right: 0px; margin-bottom: 0px; margin-left: 0px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;ĐIỀU KHOẢN MUA BÁN HÀNG HÓA&lt;/span&gt;&lt;/h4&gt;\r\n&lt;h4 style=&quot;margin-right: 0px; margin-bottom: 0px; margin-left: 0px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;/h4&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;Chào mừng quý khách đến với ĐỊACHỈWEBSITE.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;Chúng tôi là TÊNWEBSITE, địa chỉ ĐỊACHỈCỬAHÀNGCỦABẠN, hoạt động kinh doanh thương mại điện tử qua trang web www.ĐỊACHỈWEBSITE&amp;nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;Khi quý khách truy cập vào trang web của chúng tôi có nghĩa là quý khách đồng ý với các điều khoản này. Trang web có quyền thay đổi, chỉnh sửa, thêm hoặc lược bỏ bất kỳ phần nào trong Quy định và Điều kiện sử dụng, vào bất cứ lúc nào. Các thay đổi có hiệu lực ngay khi được đăng trên trang web mà không cần thông báo trước. Và khi quý khách tiếp tục sử dụng trang web, sau khi các thay đổi về Quy định và Điều kiện được đăng tải, có nghĩa là quý khách chấp nhận với những thay đổi đó. Quý khách vui lòng kiểm tra thường xuyên để cập nhật những thay đổi của chúng tôi.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;Xin vui lòng đọc kỹ trước khi quyết định mua hàng:&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;1. HƯỚNG DẪN SỬ DỤNG WEB&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Khi vào web của chúng tôi, người dùng tối thiểu phải 18 tuổi hoặc truy cập dưới sự giám sát của cha mẹ hay người giám hộ hợp pháp.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Chúng tôi cấp giấy phép sử dụng để bạn có thể mua sắm trên web trong khuôn khổ Điều khoản và Điều kiện sử dụng đã đề ra.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Nghiêm cấm sử dụng bất kỳ phần nào của trang web này với mục đích thương mại hoặc nhân danh bất kỳ đối tác thứ ba nào nếu không được chúng tôi cho phép bằng văn bản. Nếu vi phạm bất cứ điều nào trong đây, chúng tôi sẽ hủy giấy phép của bạn mà không cần báo trước.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Trang web này chỉ dùng để cung cấp thông tin sản phẩm chứ chúng tôi không phải nhà sản xuất nên những nhận xét hiển thị trên web là ý kiến cá nhân của khách hàng, không phải của chúng tôi.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Quý khách phải đăng ký tài khoản với thông tin xác thực về bản thân và phải cập nhật nếu có bất kỳ thay đổi nào. Mỗi người truy cập phải có trách nhiệm với mật khẩu, tài khoản và hoạt động của mình trên web. Hơn nữa, quý khách phải thông báo cho chúng tôi biết khi tài khoản bị truy cập trái phép. Chúng tôi không chịu bất kỳ trách nhiệm nào, dù trực tiếp hay gián tiếp, đối với những thiệt hại hoặc mất mát gây ra do quý khách không tuân thủ quy định.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Trong suốt quá trình đăng ký, quý khách đồng ý nhận email quảng cáo từ website. Sau đó, nếu không muốn tiếp tục nhận mail, quý khách có thể từ chối bằng cách nhấp vào đường link ở dưới cùng trong mọi email quảng cáo.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;2. Ý KIẾN KHÁCH HÀNG&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Tất cả nội dung trang web và ý kiến phê bình của quý khách đều là tài sản của chúng tôi. Nếu chúng tôi phát hiện bất kỳ thông tin giả mạo nào, chúng tôi sẽ khóa tài khoản của quý khách ngay lập tức hoặc áp dụng các biện pháp khác theo quy định của pháp luật Việt Nam&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;3 &amp;nbsp;ĐẶT HÀNG VÀ XÁC NHẬN ĐƠN HÀNG&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Khi quý khách đặt hàng tại ĐỊACHỈWEBSITE, chúng tôi sẽ nhận được yêu cầu đặt hàng và gửi đến quý khách mã số đơn hàng. Tuy nhiên, yêu cầu đặt hàng cần thông qua một bước xác nhận đơn hàng, ĐỊACHỈWEBSITE chỉ xác nhận đơn hàng nếu yêu cầu đặt hàng của quý khách thỏa mãn các tiêu chí thực hiện đơn hàng tại ĐỊACHỈWEBSITE.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Để yêu cầu đặt hàng được xác nhận nhanh chóng, quý khách vui lòng cung cấp đúng và đầy đủ các thông tin liên quan đến việc giao nhận, hoặc các điều khoản và điều kiện của chương trình khuyến mãi (nếu có) mà quý khách tham gia.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;4. GIÁ TRỊ ĐƠN HÀNG VÀ HÌNH THỨC THANH TOÁN&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- ĐỊACHỈWEBSITE cung cấp các hình thức thanh toán: tiền mặt khi nhận hàng, thẻ Thanh toán Quốc tế hoặc thẻ Thanh toán Nội địa.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Trừ một số trường hợp có ghi chú riêng, thông thường quý khách có thể lựa chọn một trong 3 hình thức thanh toán trên khi tiến hành đặt hàng. Tuy nhiên, để đảm bảo tính an toàn dành cho quý khách trong quá trình thanh toán, đối những đơn hàng có giá trị cao từ 30 (ba mươi) triệu trở lên, ĐỊACHỈWEBSITE chỉ chấp nhận hình thức thanh toán trước bằng thẻ Thanh toán Quốc tế hoặc thẻ Thanh toán Nội địa.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;5. CHƯƠNG TRÌNH KHUYẾN MÃI&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Với mong muốn mang lại nhiều lợi ích cho khách hàng, ĐỊACHỈWEBSITE cùng các Thương nhân thành viên thường xuyên có các chương trình giảm giá đặc biệt. Tuy nhiên, để đảm bảo tính công bằng cho khách hàng là người tiêu dùng cuối cùng của ĐỊACHỈWEBSITE, chúng tôi có quyền từ chối các đơn hàng không nhằm mục đích sử dụng cho cá nhân, mua hàng số lượng nhiều hoặc với mục đích mua đi bán lại khi quý khách tham gia các chương trình khuyến mãi.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Thông thường, số lượng sản phẩm tối đa dành cho mỗi khách hàng khi tham gia chương trình khuyến mãi đặc biệt tại ĐỊACHỈWEBSITE là hai (02) sản phẩm. Thể lệ của chương trình khuyến mãi sẽ được cập nhật tại trang khuyến mãi theo từng thời điểm chạy chương trình và có thể được thay đổi mà không cần thông báo trước cho khách hàng.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- ĐỊACHỈWEBSITE có quyền từ chối các đơn hàng không thỏa mãn điều khoản và điều kiện tham gia các chương trình khuyến mãi mà không cần thông báo đến khách hàng. Vì vậy, xin quý khách vui lòng tham khảo kĩ Thể lệ của từng chương trình trước khi tham gia.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;6. MÃ GIẢM GIÁ&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Mã giảm giá là hình thức chiết khấu mà ĐỊACHỈWEBSITE dành cho khách hàng có thể có giá trị giảm một phần hoặc toàn phần giá trị của đơn hàng.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Mỗi đơn hàng chỉ có thể áp dụng 1 mã giảm giá, quý khách sẽ nhận được thông tin chi tiết về điều khoản và điều kiện sử dụng mã giảm giá kèm theo. Để đảm bảo tính công bằng cho khách hàng là người tiêu dùng cuối cùng của ĐỊACHỈWEBSITE, chúng tôi có quyền từ chối các đơn hàng không nhằm mục đích sử dụng cho cá nhân, mua hàng số lượng nhiều hoặc với mục đích mua đi bán lại.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- ĐỊACHỈWEBSITE có quyền từ chối các đơn hàng sử dụng mã giảm giá không thỏa mãn điều khoản và điều kiện sử dụng mã giảm gía mà không cần thông báo trước. Mã giảm giá trong trường hợp này sẽ không được cấp lại. Ngoài ra, ĐỊACHỈWEBSITE có quyền từ chối việc gia hạn mã đã hết hạn sử dụng, mã không được sử dụng hết giá trị hoặc các trường hợp đơn phương ngừng thược hiện đơn hàng phát sinh từ phía quý khách.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;7. KHU VỰC GIAO HÀNG&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- ĐỊACHỈWEBSITE giao hàng toàn quốc đối với các sản phẩm do chính ĐỊACHỈWEBSITE phân phối, trừ các mặt hàng điện lạnh như máy lạnh, máy giặt, tủ lạnh, tủ đông v.v… và một số mặt hàng khác nếu quá trình vận chuyển có thể làm ảnh hưởng đến chất lượng sản phẩm hoặc sức khỏe khách hàng.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Đối với sản phẩm do các đơn vị Thương nhân thành viên phân phối, khu vực giao hàng có thể sẽ được giới hạn theo thông cập nhật tại trang sản phẩm. Trong một số trường hợp, mà khu vực giao hàng không được cập nhật kịp thời tại thời điểm quý khách đặt hàng, ĐỊACHỈWEBSITE sẽ liên hệ đến quý khách để thông báo chi tiết.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;8. GIÁ CẢ&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Giá cả sản phẩm được niêm yết tại ĐỊACHỈWEBSITE là giá bán cuối cùng đã bao gồm thuế Giá trị gia tăng (VAT). Giá cả của sản phẩm có thể thay đổi tùy thời điểm và chương trình khuyến mãi kèm theo. Phí vận chuyển hoặc Phí thực hiện đơn hàng sẽ được áp dụng thêm nếu có, và sẽ được hiển thị rõ tại trang Thanh toán khi quý khách tiến hành đặt hàng.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Mặc dù chúng tôi cố gắng tốt nhất để bảo đảm rằng tất cả các thông tin và giá hiển thị là chính xác đối với từng sản phẩm, đôi khi sẽ có một số trường hợp bị lỗi hoặc sai sót. Nếu chúng tôi phát hiện lỗi về giá của bất kỳ sản phẩm nào trong đơn hàng của quý khách, chúng tôi sẽ thông báo cho quý khách trong thời gian sớm nhất có thể và gửi đến quý khách lựa chọn để xác nhận lại đơn hàng với giá chính xác hoặc hủy đơn hàng. Nếu chúng tôi không thể liên lạc với quý khách, đơn hàng sẽ tự động hủy trên hệ thống và lệnh hoàn tiền sẽ được thực hiện (nếu đơn hàng đã được thanh toán trước).&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Khác biệt giá: Các Thương nhân thành viên hoạt động tại sàn giao dịch Thương mại điện tử ĐỊACHỈWEBSITE có thể cùng cung cấp 1 sản phẩm giống nhau với chính sách giá khác nhau, Quý khách có quyền lựa chọn và so sánh giá cả giữa các thương nhân thành viên để có được mức giá hợp lý nhất cho yêu cầu đặt hàng của mình. ĐỊACHỈWEBSITE không can thiệp về chính sách giá của từng Thương nhân thành viên nếu có phát sinh tranh chấp.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;9. THÔNG TIN SẢN PHẨM&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- ĐỊACHỈWEBSITE cung cấp thông tin chi tiết đối với từng sản phẩm mà chúng tôi đăng tải, tuy nhiên chúng tôi không thể cam kết cung cấp thông tin đầy đủ một cách chính xác, toàn vẹn, cập nhật, và không sai sót đối với từng sản phẩm.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Trong trường hợp sản phẩm quý khách nhận được không đúng như những gì ĐỊACHỈWEBSITE đã mô tả trong phần thông tin sản phẩm, quý khách vui lòng thông tin đến bộ phận Hỗ trợ khách hàng trong thời gian sớm nhất kể từ khi nhận hàng đồng thời đảm bảo sản phẩm trong tình trạng chưa qua sử dụng để được hỗ trợ đổi trả. Thông tin chi tiết về chính sách đổi trả vui lòng tham khảo tại: http://www.ĐỊACHỈWEBSITE/chinh-sach-doi-tra-hang/&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;10. CHÍNH SÁCH VỀ HÀNG GIẢ, HÀNG NHÁI, HÀNG KHÔNG ĐÚNG CHẤT LƯỢNG&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- ĐỊACHỈWEBSITE hướng đến việc cung cấp hàng hóa và chất lượng dịch vụ tốt nhất cho khách hàng qua các sản phẩm được đăng bán trên trang web của chúng và từ chối bán các sản phẩm sản xuất trái phép, sao chép, hàng giả, hàng nhái, không rõ nguồn gốc xuất xứ...&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Các Thương nhân thành viên của ĐỊACHỈWEBSITE đều được yêu cầu thực hiện một cách nghiêm túc đối với việc đảm bảo chất lượng và nguồn gốc, xuất xứ của sản phẩm, cũng như tự chịu trách nhiệm trước pháp luật đối với các hành vi vi phạm. Đối với các trường hợp phát hiện sản phẩm sản xuất trái phép, sao chép, hàng giả, hàng nhái, không rõ nguồn gốc xuất xứ..., ĐỊACHỈWEBSITE sẽ ngay lập tức đình chỉ hoặc chấm dứt quyền bán hàng và thực hiện các biện pháp chế tài đối với đơn vị Thương nhân thành viên vi phạm.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Trong trường hợp quý khách có nghi ngờ sản phẩm sản xuất trái phép, sao chép, hàng giả, hàng nhái, không rõ nguồn gốc xuất xứ..., vui lòng thông báo ngay cho chúng tôi bằng cách liên hệ với Bộ phận Hỗ trợ khách hàng tại www.ĐỊACHỈWEBSITE/contact/ để được xác thực thông tin và hỗ trợ.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;11. THƯƠNG HIỆU VÀ BẢN QUYỀN&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Mọi quyền sở hữu trí tuệ (đã đăng ký hoặc chưa đăng ký), nội dung thông tin và tất cả các thiết kế, văn bản, đồ họa, phần mềm, hình ảnh, video, âm nhạc, âm thanh, biên dịch phần mềm, mã nguồn và phần mềm cơ bản đều là tài sản của chúng tôi. Toàn bộ nội dung của trang web được bảo vệ bởi luật bản quyền của Việt Nam và các công ước quốc tế. Bản quyền đã được bảo lưu.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;12. QUYỀN PHÁP LÝ&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Các điều kiện, điều khoản và nội dung của trang web này được điều chỉnh bởi luật pháp Việt Nam và Tòa án có thẩm quyền tại Việt Nam sẽ giải quyết bất kỳ tranh chấp nào phát sinh từ việc sử dụng trái phép trang web này.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;13. QUY ĐỊNH VỀ BẢO MẬT&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Trang web của chúng tôi coi trọng việc bảo mật thông tin và sử dụng các biện pháp tốt nhất bảo vệ thông tin và việc thanh toán của quý khách. Thông tin của quý khách trong quá trình thanh toán sẽ được mã hóa để đảm bảo an toàn. Sau khi quý khách hoàn thành quá trình đặt hàng, quý khách sẽ thoát khỏi chế độ an toàn.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Quý khách không được sử dụng bất kỳ chương trình, công cụ hay hình thức nào khác để can thiệp vào hệ thống hay làm thay đổi cấu trúc dữ liệu. Trang web cũng nghiêm cấm việc phát tán, truyền bá hay cổ vũ cho bất kỳ hoạt động nào nhằm can thiệp, phá hoại hay xâm nhập vào dữ liệu của hệ thống. Cá nhân hay tổ chức vi phạm sẽ bị tước bỏ mọi quyền lợi cũng như sẽ bị truy tố trước pháp luật nếu cần thiết.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;Mọi thông tin giao dịch sẽ được bảo mật nhưng trong trường hợp cơ quan pháp luật yêu cầu, chúng tôi sẽ buộc phải cung cấp những thông tin này cho các cơ quan pháp luật.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;14. THANH TOÁN AN TOÀN VÀ TIỆN LỢI ĐỊACHỈWEBSITE&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;Mọi khách hàng tham giao giao dịch tại ĐỊACHỈWEBSITE qua thẻ tín dụng quốc tế đều được bảo mật thông tin bằng mã hóa (xem chi tiết tại điều khoản “Quy định về bảo mật” được nêu ở trên). Qua đó, khi thực hiện thanh toán qua mạng quý khách lưu ý các chi tiết sau:&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Chỉ sử dụng trang web có chứng chỉ thanh toán an toàn.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Tuyệt đối không cho người khác mượn thẻ tín dụng hoặc tài khoản của mình để thực hiện thanh toán tại ĐỊACHỈWEBSITE; trong trường hợp phát sinh giao dịch ngoài ý muốn, quý khách vui lòng thông báo cho ĐỊACHỈWEBSITE biết để có thể hỗ trợ kịp thời.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Kiểm tra tài khoản ngân hàng của mình thường xuyên để đảm bảo tất cả giao dịch qua thẻ đều nằm trong tầm kiểm soát.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;15. GIAO KẾT GIAO DỊCH TẠI ĐỊACHỈWEBSITE&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Khách hàng khi mua sắm tại ĐỊACHỈWEBSITE phải thực hiện các thao tác đặt hàng và nhận hàng theo trình tự sau:&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;text-decoration: underline;&quot;&gt;Cách 1:&amp;nbsp;Thanh toán trước online qua thẻ tín dụng (Visa, Master card..):&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Bước 1:&amp;nbsp;Khách hàng đặt hàng, cung cấp thông tin đầy đủ, xác thực&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bước 2:&amp;nbsp;Khách hàng thanh toán trước;&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bước 3:&amp;nbsp;ĐỊACHỈWEBSITE kiểm tra, xác nhận đơn hàng và chuyển hàng;&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bước 4:&amp;nbsp;Khách hàng kiểm tra và nhận hàng;&lt;br&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;text-decoration: underline;&quot;&gt;Cách 2:&amp;nbsp;Thanh toán sau:&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Bước 1:&amp;nbsp;Khách hàng đặt hàng; cung cấp thông tin đầy đủ, xác thực&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bước 2:&amp;nbsp;ĐỊACHỈWEBSITE xác thực đơn hàng;&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bước 3:&amp;nbsp;ĐỊACHỈWEBSITE xác nhận thông tin khách hàng (điện thoại, tin nhắn, email);&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bước 4:&amp;nbsp;ĐỊACHỈWEBSITE chuyển hàng;&lt;br&gt;&lt;/li&gt;\r\n&lt;li&gt;Bước 5:&amp;nbsp;Khách hàng nhận hàng và thanh toán;&lt;br&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Trong các trường hợp, khách hàng có thể tra cứu thông tin giao dịch qua email gửi vào hộp thư khách hàng đã đăng ký với ĐỊACHỈWEBSITE hoặc tra cứu tình trạng giao dịch tại website http://www.ĐỊACHỈWEBSITE/kiem-tra-don-hang/. Ngoài ra, khách hàng có thể tra cứu được lịch sử giao dịch khi đăng nhập vào tài khoản của mình tại website ĐỊACHỈWEBSITE&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;Trường hợp khách hàng muốn chỉnh sửa thông tin, khách hàng thông báo cho ĐỊACHỈWEBSITE qua đường dây nóng SỐHOTLINECỦAWEBSITE hoặc ghi lời nhắn tại http://www.ĐỊACHỈWEBSITE/contact/.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;16. THAY ĐỔI, HỦY BỎ GIAO DỊCH TẠI ĐỊACHỈWEBSITE&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Trong mọi trường hợp, khách hàng đều có quyền chấm dứt giao dịch nếu đã thực hiện các biện pháp sau đây:&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;1. Thông báo cho ĐỊACHỈWEBSITE về việc hủy giao dịch qua đường dây nóng SỐHOTLINECỦAWEBSITE hoặc lời ghi nhắn tại http://www.ĐỊACHỈWEBSITE/contact/&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;2. Trả lại hàng hoá đã nhận nhưng chưa sử dụng hoặc hưởng bất kỳ lợi ích nào từ hàng hóa đó (theo quy định của chính sách đổi trả hàng tại http://www.ĐỊACHỈWEBSITE/chinh-sach-doi-tra-hang/)&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;17. GIẢI QUYẾT HẬU QUẢ DO LỖI NHẬP SAI THÔNG TIN THƯƠNG MẠI TẠI ĐỊACHỈWEBSITE&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Khách hàng có trách nhiệm cung cấp thông tin đầy đủ và chính xác khi tham gia giao dịch tại ĐỊACHỈWEBSITE. Trong trường hợp khách hàng nhập sai thông tin gửi vào trang thông tin điện tử bán hàng ĐỊACHỈWEBSITE, ĐỊACHỈWEBSITE có quyền từ chối thực hiện giao dịch. Ngoài ra, trong mọi trường hợp, khách hàng đều có quyền đơn phương chấm dứt giao dịch nếu đã thực hiện các biện pháp sau đây:&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;1. Thông báo cho ĐỊACHỈWEBSITE qua đường dây nóng SỐHOTLINECỦAWEBSITE hoặc lời nhập nhắn tại địa chỉ ĐỊACHỈWEBSITE/contact&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;2. Trả lại hàng hoá đã nhận nhưng chưa sử dụng hoặc hưởng bất kỳ lợi ích nào từ hàng hóa đó.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;18. GIẢI PHÁP TRANH CHẤP&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Bất kỳ tranh cãi, khiếu nại hoặc tranh chấp phát sinh từ hoặc liên quan đến giao dịch tại ĐỊACHỈWEBSITE hoặc các Quy định và Điều kiện này đều sẽ được giải quyết bằng hình thức thương lượng, hòa giải, trọng tài và/hoặc Tòa án theo Luật bảo vệ Người tiêu dùng Chương 4 về Giải quyết tranh chấp giữa người tiêu dùng và tổ chức, cá nhân kinh doanh hàng hóa, dịch vụ.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;19. QUY ĐỊNH CHẤP DỨT THỎA THUẬN&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Trong trường hợp có bất kỳ thiệt hại nào phát sinh do việc vi phạm Quy Định sử dụng trang web, chúng tôi có quyền đình chỉ hoặc khóa tài khoản của quý khách vĩnh viễn. Nếu quý khách không hài lòng với trang web hoặc bất kỳ điều khoản, điều kiện, quy tắc, chính sách, hướng dẫn, hoặc cách thức vận hành của ĐỊACHỈWEBSITE thì biện pháp khắc phục duy nhất là ngưng làm việc với chúng tôi.&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;20. NHỮNG QUY ĐỊNH KHÁC&lt;/span&gt;&lt;/p&gt;\r\n&lt;p style=&quot;margin-bottom: 15px;&quot;&gt;- Tất cả các Điều Khoản và Điều Kiện (và tất cả nghĩa vụ phát sinh ngoài Điều khoản và Điều kiện này hoặc có liên quan) sẽ bị chi phối và được hiểu theo luật pháp Việt Nam. Chúng tôi có quyền sửa đổi các Điều khoản và Điều kiện này vào bất kỳ thời điểm nào và các sửa đổi đó sẽ có hiệu lực ngay tại thời điểm được được đăng tải tại ĐỊACHỈWEBSITE.&lt;/p&gt;', 'Điều khoản và điều kiện', '', ''),
(4, 2, 'Về chúng tôi', '&lt;p&gt;&lt;span style=&quot;font-size:30px; line-height: 20px&quot;&gt;C&lt;/span&gt;húng tôi chuyên cung cấp các sản phẩm từ các thương hiệu nổi tiếng với mức giá cạnh tranh nhất. Đến với Chúng tôi, quý khách có thể thoả sức lựa chọn hàng nghìn sản phẩm khác nhau từ thiết bị y tế, thuốc chữa bệnh, thực phẩm chức năng đến các dòng sản phẩm chăm sóc sắc đẹp và cơ thể. &lt;/p&gt;\r\n&lt;p&gt;Luôn đặt lợi ích của khách hàng lên hàng đầu với khẩu hiệu &quot;Vì sức khỏe người Việt&quot;, Chúng tôi áp dụng chính sách ưu đãi cho tất cả các đơn hàng trên 1,000,000 VND với dịch vụ giao hàng miễn phí trên toàn quốc trong không quá 7 ngày và chính sách đổi trả hàng trong vòng 30 ngày. Với chúng tôi, sự hài lòng và thoải mái của quý khách luôn là ưu tiên hàng đầu trong tiêu chí phục vụ cũng như hoạt động tại nhà thuốc chúng tôi.Không chỉ là kênh bán lẻ trực tuyến hàng đầu mà còn là một môi trường làm việc đa văn hoá và chuyên nghiệp. &lt;/p&gt;\r\n&lt;p&gt;Hiện tại, chúng tôi đã thể hiện sức vươn mạnh mẽ với hơn đội ngũ nhân viên, bác sĩ, dược sĩ, trình dược viên năng động và đầy nhiệt huyết. Cung cấp cho khách hàng không chỉ những sản phẩm tốt nhất mà còn luôn sẵn sàng lắng nghe, hỗ trợ giải đáp và tư vấn cho khách những thắc mắc, băn khoăn trong việc sử dụng sản phẩm cũng như chăm sóc sức khỏe. &lt;/p&gt;\r\n&lt;p&gt;Chúng tôi không ngừng cố gắng và nỗ lực để có thể mang tới những sản phẩm, dịch vụ tốt nhất cho khách hàng.Sứ mệnh của chúng tôi là mang lại cho khách hàng những lợi ích tối đa trong việc chăm sóc sức khỏe thông qua việc cung cấp các sản phẩm và dịch vụ tốt nhất. Luôn cố gắng hết sức để lắng nghe và thấu hiểu tâm tư của người tiêu dùng, trở thành người đồng hành tin cậy trong việc chăm sóc sức khỏe của mọi gia đình.&lt;/p&gt;\r\n&lt;p&gt;Chúng tôi thỏa mãn nhu cầu mua sắm nhanh chóng, hiệu quả, tiết kiệm và an toàn. Đồng thời, cung cấp các sản phẩm tối ưu, chất lượng tốt, giá cạnh tranh và phù hợp với từng khách hàng.&lt;/p&gt;', 'Về chúng tôi', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_information_to_layout`
--

CREATE TABLE `oc_information_to_layout` (
  `information_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_information_to_layout`
--

INSERT INTO `oc_information_to_layout` (`information_id`, `store_id`, `layout_id`) VALUES
(4, 0, 0),
(5, 0, 0),
(3, 0, 0),
(7, 0, 0),
(8, 0, 0),
(9, 0, 0),
(10, 0, 0),
(11, 0, 0),
(12, 0, 0),
(13, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_information_to_store`
--

CREATE TABLE `oc_information_to_store` (
  `information_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_information_to_store`
--

INSERT INTO `oc_information_to_store` (`information_id`, `store_id`) VALUES
(3, 0),
(4, 0),
(5, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(11, 0),
(12, 0),
(13, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_language`
--

CREATE TABLE `oc_language` (
  `language_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `code` varchar(5) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `image` varchar(64) NOT NULL,
  `directory` varchar(32) NOT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_language`
--

INSERT INTO `oc_language` (`language_id`, `name`, `code`, `locale`, `image`, `directory`, `sort_order`, `status`) VALUES
(2, 'Tiếng Việt', 'vi', 'vi_VN.UTF-8,vi_VN,vi-vn,vietnamese', 'vn.png', 'vietnamese', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_layout`
--

CREATE TABLE `oc_layout` (
  `layout_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_layout`
--

INSERT INTO `oc_layout` (`layout_id`, `name`) VALUES
(1, 'Trang chủ'),
(2, 'Sản phẩm'),
(3, 'Danh mục'),
(4, 'Mặc định'),
(5, 'Nhà sản xuất'),
(6, 'Tài khoản'),
(7, 'Thanh toán'),
(8, 'Liên hệ'),
(9, 'Sơ đồ trang'),
(10, 'Tiếp thị'),
(11, 'Thông tin'),
(12, 'So sánh'),
(13, 'Tìm kiếm');

-- --------------------------------------------------------

--
-- Table structure for table `oc_layout_module`
--

CREATE TABLE `oc_layout_module` (
  `layout_module_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL,
  `code` varchar(64) NOT NULL,
  `position` varchar(14) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_layout_module`
--

INSERT INTO `oc_layout_module` (`layout_module_id`, `layout_id`, `code`, `position`, `sort_order`) VALUES
(1159, 8, 'content_info.53', 'content_top', 1),
(1171, 10, 'affiliate', 'column_right', 0),
(1158, 8, 'google_maps.47', 'content_top', 0),
(1317, 2, 'module_col.65', 'column_left', 2),
(1315, 2, 'category', 'column_left', 0),
(1316, 2, 'banner.88', 'column_left', 1),
(1313, 3, 'banner.88', 'column_left', 1),
(1314, 3, 'module_col.90', 'column_left', 3),
(1312, 3, 'category', 'column_left', 0),
(1394, 1, 'module_col.39', 'footer_top', 0),
(1395, 1, 'module_col.40', 'footer_bottom', 15),
(1393, 1, 'module_col.92', 'content_top', 1),
(1392, 1, 'module_col.87', 'content_top', 0),
(1391, 1, 'module_col.65', 'column_left', 1),
(1390, 1, 'module_col.86', 'custom_top', 13),
(1389, 1, 'mb_mini_cart', 'main_menu', 10),
(1388, 1, 'menu.33', 'main_menu', 9),
(1387, 1, 'module_col.45', 'header', 9),
(1386, 1, 'html.85', 'top', 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_layout_route`
--

CREATE TABLE `oc_layout_route` (
  `layout_route_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `route` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_layout_route`
--

INSERT INTO `oc_layout_route` (`layout_route_id`, `layout_id`, `store_id`, `route`) VALUES
(54, 6, 0, 'account/%'),
(66, 10, 0, 'affiliate/%'),
(64, 3, 0, 'product/category'),
(59, 1, 0, 'common/home'),
(56, 2, 0, 'product/product'),
(58, 11, 0, 'information/information'),
(63, 7, 0, 'checkout/%'),
(68, 8, 0, 'information/contact'),
(67, 9, 0, 'information/sitemap'),
(60, 4, 0, ''),
(57, 5, 0, 'product/manufacturer'),
(62, 12, 0, 'product/compare'),
(55, 13, 0, 'product/search');

-- --------------------------------------------------------

--
-- Table structure for table `oc_length_class`
--

CREATE TABLE `oc_length_class` (
  `length_class_id` int(11) NOT NULL,
  `value` decimal(15,8) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_length_class`
--

INSERT INTO `oc_length_class` (`length_class_id`, `value`) VALUES
(1, '1.00000000'),
(2, '10.00000000'),
(3, '0.39370000');

-- --------------------------------------------------------

--
-- Table structure for table `oc_length_class_description`
--

CREATE TABLE `oc_length_class_description` (
  `length_class_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `title` varchar(32) NOT NULL,
  `unit` varchar(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_length_class_description`
--

INSERT INTO `oc_length_class_description` (`length_class_id`, `language_id`, `title`, `unit`) VALUES
(1, 2, 'Centimeter', 'cm'),
(2, 2, 'Millimeter', 'mm'),
(3, 2, 'Inch', 'in');

-- --------------------------------------------------------

--
-- Table structure for table `oc_location`
--

CREATE TABLE `oc_location` (
  `location_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `address` text NOT NULL,
  `telephone` varchar(32) NOT NULL,
  `fax` varchar(32) NOT NULL,
  `geocode` varchar(32) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `open` text NOT NULL,
  `comment` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_location`
--

INSERT INTO `oc_location` (`location_id`, `name`, `address`, `telephone`, `fax`, `geocode`, `image`, `open`, `comment`) VALUES
(1, 'Chili Shop 2', 'Chili shop địa chỉ', '1312414124', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_manufacturer`
--

CREATE TABLE `oc_manufacturer` (
  `manufacturer_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_manufacturer`
--

INSERT INTO `oc_manufacturer` (`manufacturer_id`, `name`, `image`, `sort_order`) VALUES
(5, 'HTC', 'catalog/demo/htc_logo.jpg', 0),
(6, 'Palm', 'catalog/demo/palm_logo.jpg', 0),
(7, 'Hewlett-Packard', 'catalog/demo/hp_logo.jpg', 0),
(8, 'Apple', 'catalog/demo/apple_logo.jpg', 0),
(9, 'Canon', 'catalog/demo/canon_logo.jpg', 0),
(10, 'Sony', 'catalog/demo/sony_logo.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_manufacturer_to_store`
--

CREATE TABLE `oc_manufacturer_to_store` (
  `manufacturer_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_manufacturer_to_store`
--

INSERT INTO `oc_manufacturer_to_store` (`manufacturer_id`, `store_id`) VALUES
(5, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_marketing`
--

CREATE TABLE `oc_marketing` (
  `marketing_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` text NOT NULL,
  `code` varchar(64) NOT NULL,
  `clicks` int(5) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_menu`
--

CREATE TABLE `oc_menu` (
  `menu_id` int(11) NOT NULL,
  `code` varchar(500) NOT NULL,
  `type` varchar(255) NOT NULL,
  `picture` tinyint(1) NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL,
  `name` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_menu`
--

INSERT INTO `oc_menu` (`menu_id`, `code`, `type`, `picture`, `image`, `name`, `status`) VALUES
(3, 'MB01', 'horizontal', 1, '', 'Trình đơn chính', 1),
(5, 'footer1', 'vertical', 1, '', 'Thông tin', 1),
(6, 'tai_khoan', 'vertical', 1, '', 'Tài khoản', 1),
(7, 'dich_vu', 'vertical', 1, '', 'Dịch vụ', 1),
(9, 'DM_1', 'horizontal', 1, '', 'Trình danh mục', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_menu_group`
--

CREATE TABLE `oc_menu_group` (
  `menu_group_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL DEFAULT '0',
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `module_id` int(11) NOT NULL DEFAULT '0',
  `module_type` varchar(250) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `url` varchar(250) NOT NULL,
  `keyword` varchar(600) NOT NULL,
  `window` varchar(250) NOT NULL,
  `style` varchar(250) NOT NULL,
  `font` varchar(250) NOT NULL,
  `image` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_menu_group`
--

INSERT INTO `oc_menu_group` (`menu_group_id`, `menu_id`, `parent_id`, `module_id`, `module_type`, `sort`, `url`, `keyword`, `window`, `style`, `font`, `image`) VALUES
(206, 3, 0, 0, 'link', 19, 'index.php?route=information/contact', '', '0', 'dropdown', '', ''),
(210, 3, 215, 10, 'information', 15, 'information_id=10', '', '0', '', '', ''),
(120, 3, 119, 2, 'category', 2, 'category_id=2', '', '0', 'dropdown', 'fa-arrow-circle-o-left', ''),
(135, 3, 136, 3, 'category', 9, 'category_id=3', '', '0', 'dropdown', 'fa-anchor', ''),
(146, 3, 157, 4, 'information', 20, 'information_id=4', '', '0', 'dropdown', 'fa-apple', ''),
(123, 5, 0, 3, 'information', 0, 'information_id=3', 'privacy', '0', 'dropdown', '', ''),
(124, 5, 0, 4, 'information', 3, 'information_id=4', 'about_us', '0', 'dropdown', '', ''),
(241, 5, 0, 13, 'information', 1, 'information_id=13', '', '0', 'dropdown', '', ''),
(126, 5, 0, 5, 'information', 2, 'information_id=5', '', '0', 'dropdown', '', ''),
(127, 6, 0, 0, 'link', 0, '?route=account/account', '', '0', 'dropdown', '', ''),
(128, 6, 0, 0, 'link', 0, '?route=account/order', '', '0', 'dropdown', '', ''),
(129, 6, 0, 0, 'link', 0, '?route=account/wishlist', '', '0', 'dropdown', '', ''),
(130, 6, 0, 0, 'link', 0, '?route=account/newsletter', '', '0', 'dropdown', '', ''),
(131, 7, 0, 0, 'link', 0, '/index.php?route=information/contact', '', '0', 'dropdown', '', ''),
(132, 7, 0, 0, 'link', 1, '?route=account/return/add', '', '0', 'dropdown', '', ''),
(133, 7, 0, 0, 'link', 2, '?route=information/sitemap', '', '0', 'dropdown', '', ''),
(134, 7, 0, 0, 'link', 3, '?route=affiliate/login', '', '0', 'dropdown', '', ''),
(136, 3, 137, 59, 'category', 8, 'category_id=59', '', '0', 'dropdown', 'fa-arrows-h', ''),
(137, 3, 119, 2, 'category', 7, 'category_id=2', '', '0', 'dropdown', 'fa-beer', ''),
(138, 3, 120, 4, 'category', 3, 'category_id=4', '', '0', 'dropdown', 'fa-angle-double-up', ''),
(140, 3, 120, 7, 'information', 4, 'information_id=7', 'huong-dan-dat-hang', '0', 'dropdown', 'fa-archive', ''),
(141, 3, 140, 10, 'information', 5, 'information_id=10', '', '0', 'dropdown', 'fa-arrow-circle-o-down', ''),
(143, 3, 144, 8, 'information', 14, 'information_id=8', '', '0', 'dropdown', 'fa-arrow-circle-o-up', ''),
(202, 3, 205, 20, 'product', 4, 'product_id=20', '', '0', '', '', ''),
(243, 9, 0, 63, 'category', 1, 'category_id=63', '', '0', 'dropdown', '', 'catalog/icon/Chair.png'),
(148, 9, 147, 3, 'category', 1, 'category_id=3', '', '0', 'dropdown', 'fa-ambulance', ''),
(149, 9, 148, 59, 'category', 2, 'category_id=59', '', '0', 'dropdown', 'fa-apple', ''),
(150, 9, 149, 2, 'category', 3, 'category_id=2', '', '0', 'dropdown', 'fa-android', ''),
(151, 9, 149, 4, 'category', 4, 'category_id=4', '', '0', 'dropdown', 'fa-bank', ''),
(242, 9, 0, 62, 'category', 0, 'category_id=62', '', '0', 'dropdown', '', 'catalog/icon/Table.png'),
(188, 9, 148, 59, 'category', 6, 'category_id=59', '', '0', '', '', ''),
(268, 3, 252, 85, 'category', 10, 'category_id=85', '', '0', '', '', ''),
(207, 3, 0, 0, 'link', 0, '', '', '0', 'dropdown', '', ''),
(153, 3, 144, 10, 'information', 15, 'information_id=10', '', '0', 'dropdown', 'fa-briefcase', ''),
(157, 3, 139, 8, 'information', 19, 'information_id=8', '', '0', 'dropdown', 'fa-arrows', ''),
(189, 9, 148, 2, 'category', 5, 'category_id=2', '', '0', '', '', ''),
(240, 3, 0, 4, 'information', 1, '', '', '0', 'dropdown', '', ''),
(212, 3, 215, 12, 'information', 13, 'information_id=12', '', '0', '', '', ''),
(213, 3, 215, 11, 'information', 18, 'information_id=11', '', '0', '', '', ''),
(214, 3, 215, 8, 'information', 17, 'information_id=8', '', '0', '', '', ''),
(215, 3, 0, 0, 'link', 12, '', '', '0', 'dropdown', '', ''),
(216, 3, 215, 9, 'information', 16, 'information_id=9', '', '0', 'dropdown', '', ''),
(217, 3, 215, 7, 'information', 14, 'information_id=7', '', '0', 'dropdown', '', ''),
(218, 3, 208, 62, 'category', 3, 'category_id=62', '', '0', '', '', ''),
(232, 3, 218, 71, 'category', 6, 'category_id=71', '', '0', '', '', ''),
(233, 3, 218, 70, 'category', 5, 'category_id=70', '', '0', '', '', ''),
(224, 3, 208, 63, 'category', 9, 'category_id=63', '', '0', '', '', ''),
(234, 3, 218, 69, 'category', 4, 'category_id=69', '', '0', '', '', ''),
(230, 3, 218, 73, 'category', 8, 'category_id=73', '', '0', '', '', ''),
(231, 3, 218, 72, 'category', 7, 'category_id=72', '', '0', '', '', ''),
(235, 3, 224, 65, 'category', 11, 'category_id=65', '', '0', '', '', ''),
(236, 3, 224, 66, 'category', 12, 'category_id=66', '', '0', '', '', ''),
(237, 3, 224, 64, 'category', 10, 'category_id=64', '', '0', '', '', ''),
(238, 3, 224, 67, 'category', 13, 'category_id=67', '', '0', '', '', ''),
(239, 3, 224, 68, 'category', 14, 'category_id=68', '', '0', '', '', ''),
(244, 9, 0, 70, 'category', 3, 'category_id=70', '', '0', 'dropdown', '', 'catalog/icon/Sofa.png'),
(245, 9, 0, 71, 'category', 2, 'category_id=71', '', '0', 'dropdown', '', 'catalog/icon/Light.png'),
(246, 9, 0, 69, 'category', 4, 'category_id=69', '', '0', 'dropdown', '', 'catalog/icon/Accessories.png'),
(266, 3, 262, 63, 'category', 4, 'category_id=63', '', '0', '', '', ''),
(252, 3, 0, 0, 'link', 2, '', '', '0', 'dropdown', '', ''),
(250, 9, 248, 0, 'link', 3, '', '', '0', 'dropdown', '', ''),
(251, 9, 250, 0, 'link', 4, '', '', '0', 'dropdown', '', ''),
(271, 3, 269, 87, 'category', 8, 'category_id=87', '', '0', '', '', ''),
(269, 3, 252, 83, 'category', 6, 'category_id=83', '', '0', '', '', ''),
(270, 3, 269, 86, 'category', 7, 'category_id=86', '', '0', '', '', ''),
(258, 3, 254, 0, 'link', 8, '', '', '0', 'dropdown', '', ''),
(259, 3, 254, 0, 'link', 5, '', '', '0', 'dropdown', '', ''),
(260, 3, 259, 0, 'link', 7, '', '', '0', 'dropdown', '', ''),
(261, 3, 259, 0, 'link', 6, '', '', '0', 'dropdown', '', ''),
(267, 3, 266, 71, 'category', 5, 'category_id=71', '', '0', '', '', ''),
(272, 3, 252, 80, 'category', 3, 'category_id=80', '', '0', '', '', ''),
(273, 3, 272, 81, 'category', 4, 'category_id=81', '', '0', '', '', ''),
(274, 3, 272, 82, 'category', 5, 'category_id=82', '', '0', '', '', ''),
(275, 3, 252, 84, 'category', 9, 'category_id=84', '', '0', '', '', ''),
(276, 3, 252, 88, 'category', 11, 'category_id=88', '', '0', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_menu_group_description`
--

CREATE TABLE `oc_menu_group_description` (
  `menu_group_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_menu_group_description`
--

INSERT INTO `oc_menu_group_description` (`menu_group_id`, `language_id`, `name`) VALUES
(202, 2, 'Chuối sấy Hà Nội'),
(146, 2, 'Giới thiệu'),
(120, 2, 'Hoa quả xuất khẩu'),
(135, 2, 'Hoa quả sấy khô'),
(123, 2, 'Chính sách riêng tư'),
(124, 2, 'Về chúng tôi'),
(241, 2, 'Thỏa thuận người dùng'),
(126, 2, 'Điều khoản sử dụng'),
(127, 2, 'Tài khoản'),
(128, 2, 'Đơn hàng'),
(129, 2, 'Yêu thích'),
(130, 2, 'Thông báo'),
(131, 2, 'Liên hệ'),
(132, 2, 'Đổi trả hàng'),
(133, 2, 'Sơ đồ trang'),
(134, 2, 'Bán hàng'),
(136, 2, 'Hoa quả theo mùa'),
(137, 2, 'Hoa quả xuất khẩu'),
(138, 2, 'Mâm quả ngày tết'),
(242, 2, 'Bàn'),
(140, 2, 'Hướng dẫn đặt hàng'),
(141, 2, 'Chuyển khoản ngân hàng'),
(143, 2, 'Hướng dẫn thanh toán qua Ngân Lượng'),
(189, 2, 'Hoa quả xuất khẩu'),
(243, 2, 'Ghế'),
(148, 2, 'Hoa quả sấy khô'),
(149, 2, 'Hoa quả theo mùa'),
(150, 2, 'Hoa quả xuất khẩu'),
(151, 2, 'Mâm quả ngày tết'),
(153, 2, 'Chuyển khoản ngân hàng'),
(188, 2, 'Hoa quả theo mùa'),
(157, 2, 'Hướng dẫn thanh toán qua Ngân Lượng'),
(210, 2, 'Chuyển khoản ngân hàng'),
(206, 2, 'Liên hệ'),
(207, 2, 'Trang chủ'),
(269, 2, 'Dược phẩm &amp; sức khỏe'),
(240, 2, 'Giới thiệu'),
(217, 2, 'Hướng dẫn đặt hàng'),
(212, 2, 'Hướng dẫn thanh toán'),
(213, 2, 'Hướng dẫn thanh toán qua Bảo Kim'),
(214, 2, 'Hướng dẫn thanh toán qua Ngân Lượng'),
(215, 2, 'Hướng dẫn'),
(216, 2, 'Hướng dẫn thanh toán qua Paypal'),
(218, 2, 'Nam'),
(235, 2, 'Áo'),
(230, 2, 'Phụ kiện'),
(234, 2, 'Áo thun'),
(224, 2, 'Nữ'),
(232, 2, 'Áo khoác'),
(231, 2, 'Quần'),
(233, 2, 'Áo sơ mi'),
(236, 2, 'Áo khoác'),
(237, 2, 'Đầm'),
(238, 2, 'Quần'),
(239, 2, 'Phụ kiện'),
(244, 2, 'Sofas'),
(245, 2, 'Đèn'),
(246, 2, 'Đồ dùng gỗ'),
(268, 2, 'Dinh dưỡng thể thao'),
(252, 2, 'Sản phẩm'),
(250, 2, 'aaa'),
(251, 2, 'zzzzzzzzzz'),
(258, 2, 'abc'),
(259, 2, 'aBCASDASDZXC'),
(260, 2, 'Sản phẩm'),
(261, 2, 'Sản phẩm 2'),
(266, 2, 'Nón'),
(267, 2, 'Trang sức'),
(270, 2, 'Làm đẹp'),
(271, 2, 'Vitamin'),
(272, 2, 'Gia đình'),
(273, 2, 'Nam'),
(274, 2, 'Nữ'),
(275, 2, 'Mẹ &amp; bé'),
(276, 2, 'Mỹ phẩm thiên nhiên');

-- --------------------------------------------------------

--
-- Table structure for table `oc_modification`
--

CREATE TABLE `oc_modification` (
  `modification_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `code` varchar(64) NOT NULL,
  `author` varchar(64) NOT NULL,
  `version` varchar(32) NOT NULL,
  `link` varchar(255) NOT NULL,
  `xml` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_modification`
--

INSERT INTO `oc_modification` (`modification_id`, `name`, `code`, `author`, `version`, `link`, `xml`, `status`, `date_added`) VALUES
(1, 'Local copy OCMOD by iSenseLabs', 'isensealabs_quickfix_ocmod', 'iSenseLabs', '1.1.1', 'http://isenselabs.com', '<modification>\r\n    <name>Local copy OCMOD by iSenseLabs</name>\r\n	<version>1.1.1</version>\r\n	<link>http://isenselabs.com</link>\r\n	<author>iSenseLabs</author>\r\n	<code>isensealabs_quickfix_ocmod</code>\r\n\r\n	<file path="admin/controller/extension/installer.php">\r\n		<operation>\r\n			<search ><![CDATA[\'url\'  => str_replace(\'&amp;\', \'&\', $this->url->link(\'extension/installer/ftp\', \'token=\' . $this->session->data[\'token\'], \'SSL\')),]]></search>\r\n			<add position="replace"><![CDATA[\'url\'  => str_replace(\'&amp;\', \'&\', $this->url->link(\'extension/installer/localcopy\', \'token=\' . $this->session->data[\'token\'], \'SSL\')),]]></add>\r\n		</operation>\r\n\r\n		<operation>\r\n			<search><![CDATA[public function unzip() {]]></search>\r\n			<add position="before"><![CDATA[			\r\n	public function localcopy() {\r\n		$this->load->language(\'extension/installer\');\r\n\r\n		$json = array();\r\n\r\n		if (!$this->user->hasPermission(\'modify\', \'extension/installer\')) {\r\n			$json[\'error\'] = $this->language->get(\'error_permission\');\r\n		}\r\n\r\n        if (VERSION == \'2.0.0.0\') {\r\n            $directory = DIR_DOWNLOAD  . str_replace(array(\'../\', \'..\\\\\', \'..\'), \'\', $this->request->post[\'path\']) . \'/upload/\';\r\n        } else {\r\n            $directory = DIR_UPLOAD  . str_replace(array(\'../\', \'..\\\\\', \'..\'), \'\', $this->request->post[\'path\']) . \'/upload/\';\r\n        }\r\n\r\n		if (!is_dir($directory)) {\r\n			$json[\'error\'] = $this->language->get(\'error_directory\');\r\n		}\r\n\r\n		if (!$json) {\r\n			// Get a list of files ready to upload\r\n			$files = array();\r\n\r\n			$path = array($directory . \'*\');\r\n\r\n			while (count($path) != 0) {\r\n				$next = array_shift($path);\r\n\r\n				foreach (glob($next) as $file) {\r\n					if (is_dir($file)) {\r\n						$path[] = $file . \'/*\';\r\n					}\r\n\r\n					$files[] = $file;\r\n				}\r\n			}\r\n\r\n			$root = dirname(DIR_APPLICATION).\'/\';\r\n\r\n			foreach ($files as $file) {\r\n				// Upload everything in the upload directory\r\n				$destination = $root.substr($file, strlen($directory));\r\n\r\n				if (is_dir($file)) {\r\n					$list = glob(rtrim($destination, \'/\').\'/*\');\r\n\r\n					if (!file_exists($destination)) {\r\n						if (!mkdir($destination)) {\r\n							$json[\'error\'] = sprintf($this->language->get(\'error_ftp_directory\'), $destination);\r\n						}\r\n					}\r\n				}\r\n\r\n				if (is_file($file)) {\r\n					if (!copy($file, $destination)) {\r\n						$json[\'error\'] = sprintf($this->language->get(\'error_ftp_file\'), $file);\r\n					}\r\n				}\r\n			}\r\n		}\r\n\r\n		$this->response->addHeader(\'Content-Type: application/json\');\r\n		$this->response->setOutput(json_encode($json));\r\n	}]]></add>\r\n		</operation>\r\n	</file>	\r\n</modification>', 1, '2015-12-17 14:20:08'),
(63, 'Custom login page', 'customloginpage', 'Quocdv@matbao.com', '1.0', 'chili.vn', '<modification>\r\n    <name>Custom login page</name>\r\n	<version>1.0</version>\r\n	<link>chili.vn</link>\r\n	<author>Quocdv@matbao.com</author>\r\n	<code>customloginpage</code>\r\n	\r\n	<file path="admin/controller/common/login.php">\r\n		<operation>\r\n			<search ><![CDATA[$this->response->setOutput($this->load->view(\'common/login.tpl\', $data));]]></search>\r\n			<add position="replace"><![CDATA[$this->response->setOutput($this->load->view(\'common/login_custom.tpl\', $data));]]></add>\r\n		</operation>\r\n	</file>	\r\n</modification>', 1, '2016-10-13 14:52:59'),
(62, 'AJAX QUICK CHECKOUT V5.0 BY DREAMVENTION', 'quocdv_quickcheckout_ocmod', 'Custom OCMOD by QUOCDV', '2.0.0.0', 'dreamvention.com', '<?xml version="1.0" encoding="UTF-8"?>\n<modification>\n<name>AJAX QUICK CHECKOUT V5.0 BY DREAMVENTION</name>\n	<version>2.0.0.0</version>\n	<link>dreamvention.com</link>\n	<author>Custom OCMOD by QUOCDV</author>\n	<code>quocdv_quickcheckout_ocmod</code>\n	<file path="catalog/controller/checkout/checkout.php">\n		<operation>\n			<search><![CDATA[if (file_exists(DIR_TEMPLATE . $this->config->get(\'config_template\') . \'/template/checkout/checkout.tpl\')) {]]></search>\n			<add position="replace" offset="4"><![CDATA[\n			$this->load->model(\'setting/setting\');\n			$quickcheckout = $this->model_setting_setting->getSetting(\'d_quickcheckout\', $this->config->get(\'config_store_id\'));\n			if(isset($quickcheckout[\'d_quickcheckout\'][\'general\'][\'main_checkout\'])){\n				$template = ($quickcheckout[\'d_quickcheckout\'][\'general\'][\'main_checkout\']) ? \'d_quickcheckout\' : \'checkout\';\n			}else{\n				$template = \'checkout\';\n			}\n			if (file_exists(DIR_TEMPLATE . $this->config->get(\'config_template\') . \'/template/checkout/\'.$template.\'.tpl\')) {\n				$this->template = $this->config->get(\'config_template\') . \'/template/checkout/\'.$template.\'.tpl\';\n			} else {\n				$this->template = \'default/template/checkout/\'.$template.\'.tpl\';\n			}\n			$this->response->setOutput($this->load->view($this->template, $data));]]></add>\n		</operation>\n		<operation>\n			<search><![CDATA[$data[\'header\'] = $this->load->controller(\'common/header\');]]></search>\n			<add position="before"><![CDATA[$data[\'d_quickcheckout\'] = $this->load->controller(\'module/d_quickcheckout\');]]></add>\n		</operation>\n	</file>\n	<!-- opencart 1.5.1x issue-->\n	<file path="catalog/model/setting/setting.php">\n		<operation>\n			<search><![CDATA[$data[$result[\'key\']] = unserialize($setting[\'value\']);]]></search>\n			<add position="replace"><![CDATA[$data[$result[\'key\']] = unserialize($result[\'value\']);]]></add>\n		</operation>\n	</file>\n	<file path="admin/model/setting/setting.php">\n		<operation>\n			<search><![CDATA[$data[$result[\'key\']] = unserialize($setting[\'value\']);]]></search>\n			<add position="replace"><![CDATA[$data[$result[\'key\']] = unserialize($result[\'value\']);]]></add>\n		</operation>\n	</file>	\n\n	<!-- payment methods fix -->\n	<file path="catalog/view/theme/default/template/payment/cheque.tpl">\n		<operation>\n			<search><![CDATA[$(\'#button-confirm\').bind(\'click\', function() {]]></search>\n			<add position="replace"><![CDATA[$(\'#button-confirm\').bind(\'click\', function(event) {\n				event.stopImmediatePropagation()]]></add>\n		</operation>\n	</file>\n	<file path="catalog/view/theme/default/template/payment/pp_pro_uk.tpl">\n		<operation>\n			<search><![CDATA[$(\'#button-confirm\').bind(\'click\', function() {]]></search>\n			<add position="replace"><![CDATA[$(\'#button-confirm\').bind(\'click\', function(event) {\n				event.stopImmediatePropagation()]]></add>\n		</operation>\n	</file>\n	<file path="catalog/view/theme/default/template/payment/pp_pro.tpl"> \n		<operation>\n			<search><![CDATA[$(\'#button-confirm\').bind(\'click\', function() {]]></search>\n			<add position="replace"><![CDATA[$(\'#button-confirm\').bind(\'click\', function(event) {\n				event.stopImmediatePropagation()]]></add>\n		</operation>\n	</file>\n</modification>\n', 1, '2016-04-20 09:59:59'),
(12, 'Thư viện ảnh - Edit: 22/12/2015', 'Gallery_Images', 'Mogi Megantara', '1.2', 'chili.vn', '<?xml version="1.0" encoding="UTF-8"?>\r\n<modification>\r\n	<name>Thư viện ảnh - Edit: 22/12/2015</name>\r\n	<version>1.2</version>\r\n	<link>chili.vn</link>\r\n	<author>Mogi Megantara</author>\r\n	<code>Gallery_Images</code>\r\n  <file path="admin/view/template/common/menu.tpl">\r\n		<operation error="skip">\r\n      		<search><![CDATA[\r\n			<li><a href="<?php echo $information; ?>"><?php echo $text_information; ?></a></li>\r\n			]]></search>\r\n      	<add  position="after"><![CDATA[\r\n			<li><a href="<?php echo $gallimage; ?>"><?php echo $text_gallimage; ?></a></li>\r\n		]]></add>\r\n    	</operation>\r\n  </file>\r\n  <file path="admin/controller/common/menu.php">\r\n		<operation error="skip">\r\n      		<search><![CDATA[\r\n			$data[\'text_information\'] = $this->language->get(\'text_information\');\r\n			]]></search>\r\n      	<add  position="after"><![CDATA[\r\n			$data[\'text_gallimage\'] = $this->language->get(\'text_gallimage\');\r\n		]]></add>\r\n    	</operation>\r\n		<operation error="skip">\r\n      		<search><![CDATA[\r\n			$data[\'information\'] = $this->url->link(\'catalog/information\', \'token=\' . $this->session->data[\'token\'], \'SSL\');\r\n			]]></search>\r\n      	<add position="after"><![CDATA[\r\n			$data[\'gallimage\'] = $this->url->link(\'catalog/gallimage\', \'token=\' . $this->session->data[\'token\'], \'SSL\');\r\n		]]></add>\r\n    	</operation>\r\n  </file>\r\n  <file path="admin/language/english/common/menu.php">\r\n		<operation error="skip">\r\n      		<search><![CDATA[\r\n			$_[\'text_information\']                 = \'Information\';\r\n			]]></search>\r\n      	<add  position="after"><![CDATA[\r\n			$_[\'text_gallimage\']                   = \'Gallery Images\';\r\n		]]></add>\r\n    	</operation>\r\n  </file>\r\n  <file path="admin/language/vietnamese/common/menu.php">\r\n		<operation error="skip">\r\n      		<search><![CDATA[\r\n			$_[\'text_information\']\r\n			]]></search>\r\n      	<add  position="after"><![CDATA[\r\n			$_[\'text_gallimage\']                   = \'Quản lý thư viện ảnh\'; \r\n		]]></add>\r\n    	</operation>\r\n  </file>\r\n  <file path="catalog/view/theme/*/template/common/footer.tpl">\r\n		<operation error="skip">\r\n            <search><![CDATA[</body>]]></search>\r\n      	<add position="before"><![CDATA[\r\n			<script type="text/javascript"><!--\r\n$(\'#blueimp-gallery\').data(\'useBootstrapModal\', 0);\r\n$(\'#blueimp-gallery\').toggleClass(\'blueimp-gallery-controls\', 0);\r\n--></script>   \r\n		]]></add>\r\n    	</operation>\r\n  </file>    \r\n</modification>', 0, '2015-12-22 11:11:11'),
(38, 'Add-on Visual Builder', 'Add-on-custom-visualbuilder', 'Quocdv date_modi: 11/6/2015', '2.x', 'http://chili.vn', '<modification>\r\n	<name>Add-on Visual Builder</name>\r\n	<version>2.x</version>\r\n	<link>http://chili.vn</link>\r\n	<author>Quocdv date_modi: 11/6/2015</author>\r\n	<code>Add-on-custom-visualbuilder</code>\r\n	<file path="admin/controller/module/visualbuilder.php">\r\n		<operation>\r\n			<search><![CDATA[$data[\'footer\'] = $this->load->controller(\'common/footer\');]]></search>\r\n			<add position="after"><![CDATA[\r\n				$data[\'show_position\']=false;\r\n				if(file_exists(DIR_CONFIG.\'position.php\')){\r\n					include DIR_CONFIG.\'position.php\'; \r\n					if(!in_array($this->config->get(\'config_template\'),$themes_not_use_position)){\r\n						$data[\'show_position\']=true;\r\n					}\r\n				}\r\n			]]></add>\r\n		</operation>\r\n	</file>\r\n	<file path="admin/view/template/module/visualbuilder_form.tpl">\r\n		<operation>\r\n			<search><![CDATA[include ($adminLayoutDir . "main.tpl");]]></search>\r\n			<add position="replace"><![CDATA[\r\n				if($show_position){ include ($adminLayoutDir . "main_custom.tpl");}else{ include ($adminLayoutDir . "main.tpl"); }\r\n			]]></add>\r\n		</operation>\r\n	</file>\r\n</modification>', 1, '2016-01-05 13:06:17'),
(53, 'Advance MB Position', 'mb_postion_custom', 'Quocdv', '2.x', 'http://chili.vn', '<modification>\r\n	<name>Advance MB Position</name>\r\n	<version>2.x</version>\r\n	<link>http://chili.vn</link>\r\n	<author>Quocdv</author>\r\n	<code>mb_postion_custom</code>\r\n	<file path="catalog/controller/common/header.php">\r\n		<operation>\r\n			<search><![CDATA[public function index() {]]></search>\r\n			<add position="after">\r\n			<![CDATA[\r\n			if(file_exists(DIR_CONFIG.\'position.php\')){\r\n						include DIR_CONFIG.\'position.php\'; \r\n						if(!in_array($this->config->get(\'config_template\'),$themes_not_use_position)){\r\n							foreach ($position as $k=>$item_position){\r\n								foreach($item_position[\'position\'] as $key=>$item){ \r\n									if($item_position[\'boss\']==\'theme_header\'){ \r\n										$content=$this->load->controller(\'common/position\',$item);\r\n										if(!empty($content)){\r\n										   $data[$item[\'position_id\']] =$content;\r\n										   $data[\'config\'][$item[\'position_id\']] =$item;\r\n										}\r\n									}\r\n								}\r\n							}\r\n						}\r\n					}\r\n			]]>\r\n			</add>\r\n		</operation>\r\n	</file>\r\n	<file path="catalog/controller/common/footer.php">\r\n		<operation>\r\n			<search><![CDATA[public function index() {]]></search>\r\n			<add position="after">\r\n			<![CDATA[\r\n			if(file_exists(DIR_CONFIG.\'position.php\')){\r\n						include DIR_CONFIG.\'position.php\'; \r\n						if(!in_array($this->config->get(\'config_template\'),$themes_not_use_position)){\r\n							foreach ($position as $k=>$item_position){\r\n								foreach($item_position[\'position\'] as $key=>$item){ \r\n									if($item_position[\'boss\']==\'theme_footer\'){ \r\n										$content=$this->load->controller(\'common/position\',$item);\r\n										if(!empty($content)){\r\n										   $data[$item[\'position_id\']] =$content;\r\n										   $data[\'config\'][$item[\'position_id\']] =$item;\r\n										}\r\n									}\r\n								}\r\n							}\r\n						}\r\n					}\r\n			]]>\r\n			</add> \r\n		</operation>\r\n	</file>\r\n</modification>', 1, '2016-01-18 18:36:13'),
(70, 'Quản Lý Ảnh Pro', 'image_manager_plus', 'OpencartPlus.com', '2.x', 'http://www.opencartplus.com', '<modification>\r\n   	<name><span class="image_manager_plus">Quản Lý Ảnh Pro</span></name>\r\n	<code>image_manager_plus</code>\r\n    <version>2.x</version>\r\n    <author>OpencartPlus.com</author>\r\n    <link>http://www.opencartplus.com</link>\r\n<file path="admin/view/template/common/filemanager.tpl">\r\n		<operation>\r\n			<search position="replace"><![CDATA[$(\'a.directory\').on(\'click\', function(e) {]]></search>\r\n			<add><![CDATA[\r\n			<?php if(isset($ignore_dvquoc)){ ?>\r\n				$(document).on(\'shown.bs.modal\', function(event) {\r\n					if(localStorage.getItem("filemanager_path") !="undefined"&&localStorage.getItem("filemanager_path") !=""){\r\n						var filemanager_path = localStorage.getItem("filemanager_path").replace("&token","&oldtoken");\r\n							filemanager_path = filemanager_path.replace("&target","&oldtarget")<?php if (isset($target)) { ?>+\'&target=\'+ \'<?php echo $target; ?>\'<?php } ?>;\r\n							filemanager_path = filemanager_path.replace("&thumb","&oldthumb")<?php if (isset($thumb)) { ?>+\'&thumb=\'+ \'<?php echo $thumb; ?>\'<?php } ?>;\r\n							$(\'#modal-image\').load(filemanager_path+\'&token=\' + getURLVar(\'token\'));\r\n					}\r\n				}); \r\n			<?php } ?>\r\n			$(\'a.directory\').on(\'click\', function(e) {\r\n			<?php if(isset($ignore_dvquoc)){ ?>\r\n			localStorage.setItem("filemanager_path",$(this).attr(\'href\'));\r\n			<?php } ?>\r\n			]]></add>\r\n		</operation>\r\n</file>\r\n<file path="admin/controller/common/header.php">\r\n		<operation>\r\n			<search position="replace"><![CDATA[$data[\'styles\'] = $this->document->getStyles();]]></search>\r\n			<add><![CDATA[\r\n		$get_route = \'common/dashboard\';\r\n		if (isset($this->request->get[\'route\'])) {\r\n				$get_route = $this->request->get[\'route\'];\r\n		}\r\n		$part = explode(\'/\', $get_route);\r\n		$route = $part[0].\'/\'.$part[1];\r\n		\r\n		$ignore_routes = array(\r\n			\'extension/installer\',\r\n			\'module/revslideropencart\',\r\n			\'module/journal\',\r\n		);\r\nif (!in_array($route, $ignore_routes)) {\r\n	   $this->document->addStyle(\'view/template/image_manager/elfinder/jquery-ui/jquery-ui.css\');\r\n	   $this->document->addStyle(\'view/template/image_manager/elfinder/css/elfinder.min.css\');   \r\n	   $this->document->addScript(\'view/template/image_manager/elfinder/jquery/jquery-migrate-1.2.1.min.js\');\r\n	  	$this->document->addScript(\'view/template/image_manager/elfinder/jquery-ui/jquery-ui.js\');  \r\n	   $this->document->addScript(\'view/template/image_manager/elfinder/jquery/rcookie.js\');\r\n	   $this->document->addScript(\'view/template/image_manager/elfinder/js/elFinder.js\');	\r\n	   $this->document->addScript(\'view/template/image_manager/elfinder/js/ui/elfinder-ui.js\');	\r\n	   $this->document->addScript(\'view/template/image_manager/elfinder/js/commands/commands.js\');\r\n	   $this->document->addScript(\'view/template/image_manager/elfinder/js/i18n/elfinder.\'.$this->language->get(\'code\').\'.js\');	\r\n	   $this->document->addScript(\'view/template/image_manager/elfinder/js/proxy/elFinderSupportVer1.js\'); \r\n}\r\n	   $data[\'styles\'] = $this->document->getStyles();]]></add>\r\n		</operation>\r\n</file>	\r\n<file path="admin/controller/common/menu.php">\r\n		<operation>\r\n			<search position="replace"><![CDATA[$this->load->language(\'common/menu\');]]></search>\r\n			<add><![CDATA[$this->load->language(\'common/menu\');\r\n		$data[\'token\'] = $this->session->data[\'token\'];]]></add>\r\n		</operation>\r\n</file>\r\n<file path="admin/controller/common/filemanager.php">\r\n		<operation>\r\n			<search position="replace"><![CDATA[\r\n			$this->response->setOutput($this->load->view(\'common/filemanager.tpl\', $data));]]></search>\r\n			<add><![CDATA[\r\n			$this->response->setOutput($this->load->view(\'common/filemanager.tpl\', $data));\r\n		$ignore = false;\r\n		$referer = (isset($this->request->server[\'HTTP_REFERER\']))?$this->request->server[\'HTTP_REFERER\']:\'\';\r\n		if (strpos($referer,\'module/journal\') !== false || strpos($referer,\'module/revslideropencart\') !== false || strpos($referer,\'module%2Frevslideropencart\')!= false) {\r\n			$ignore = true;\r\n		}\r\n		if($this->config->get(\'image_manager_plus_status\')==1&&$ignore==false){ \r\n			 if(isset($this->request->server[\'HTTPS\'])&&(($this->request->server[\'HTTPS\']==\'on\')||($this->request->server[\'HTTPS\']==\'1\'))){\r\n				$data[\'http_image\'] = HTTPS_CATALOG.\'image/\';\r\n			 }else{\r\n				$data[\'http_image\'] = HTTP_CATALOG.\'image/\';\r\n			 }\r\n			$data[\'image_manager_plus_command\'] = $this->config->get(\'image_manager_plus_command\'); 	\r\n			$data[\'image_manager_plus_status\'] = $this->config->get(\'image_manager_plus_status\'); \r\n					\r\n			$this->load->model(\'user/user\');		\r\n		   $user_info = $this->model_user_user->getUser($this->user->getId());\r\n		   $data[\'user_group_id\'] = FALSE;\r\n		   if(!empty($user_info)){\r\n				$data[\'user_group_id\'] = $user_info[\'user_group_id\'];\r\n		   }\r\n			$this->response->setOutput($this->load->view(\'image_manager/popup.tpl\', $data));\r\n		}else{\r\n			$data[\'ignore_dvquoc\']=true;\r\n		}]]></add>\r\n		</operation>\r\n</file>\r\n<file path="admin/controller/catalog/category.php">\r\n		<operation>\r\n			<search position="replace"><![CDATA[$data[\'categories\'] = array();]]></search>\r\n			<add><![CDATA[$data[\'categories\'] = array();\r\n		$this->load->model(\'tool/image\');]]></add>\r\n		</operation>\r\n		<operation>\r\n			<search position="replace"><![CDATA[$data[\'categories\'][] = array(]]></search>\r\n			<add><![CDATA[\r\n			$img_query = $this->db->query("SELECT image FROM ".DB_PREFIX."category WHERE category_id = \'".(int)$result[\'category_id\']."\'");\r\n			$image = \'no_image.png\';\r\n			if ($img_query->row[\'image\']) {\r\n					$image = $img_query->row[\'image\'];\r\n			}\r\n			if (file_exists(DIR_IMAGE . $image)) {\r\n				$thumb = $this->model_tool_image->resize($image, 80, 80);\r\n			} else{\r\n				$thumb = $this->model_tool_image->resize(\'no_image.png\', 80, 80);\r\n			}\r\n			$data[\'categories\'][] = array(]]></add>\r\n		</operation>\r\n		<operation>\r\n			<search position="replace"><![CDATA[\'sort_order\'  => $result[\'sort_order\'],]]></search>\r\n			<add><![CDATA[\'sort_order\'  => $result[\'sort_order\'],\r\n		\'image\'  => $thumb,]]></add>\r\n		</operation>\r\n</file>\r\n<file path="admin/view/template/catalog/category_list.tpl">\r\n		<operation>\r\n			<search position="replace"><![CDATA[<td style="width: 1px;" class="text-center"><input type="checkbox" onclick="$(\'input[name*=\\\'selected\\\']\').prop(\'checked\', this.checked);" /></td>]]></search>\r\n			<add><![CDATA[<td style="width: 1px;" class="text-center"><input type="checkbox" onclick="$(\'input[name*=\\\'selected\\\']\').prop(\'checked\', this.checked);" /></td><td style="width:80px;" class="text-center">Hình ảnh</td>]]></add>\r\n		</operation>\r\n		<operation>\r\n			<search position="replace"><![CDATA[<td class="text-left"><?php echo $category[\'name\']; ?></td>]]></search>\r\n			<add><![CDATA[<td class="text-center"><?php if (isset($category[\'image\'])) { ?><img src="<?php echo $category[\'image\']; ?>" alt="<?php echo $category[\'name\']; ?>" style="width: 80px;" class="img-thumbnail" /><?php } else { ?><span class="img-thumbnail list"><i class="fa fa-camera fa-2x"></i></span><?php } ?></td>\r\n			<td class="text-left"><?php echo $category[\'name\']; ?></td>]]></add>\r\n		</operation>\r\n		<operation>\r\n			<search position="replace"><![CDATA[<td class="text-center" colspan="4"><?php echo $text_no_results; ?></td>]]></search>\r\n			<add><![CDATA[<td class="text-center" colspan="5"><?php echo $text_no_results; ?></td>]]></add>\r\n		</operation>\r\n</file>\r\n<file path="admin/controller/catalog/product.php">\r\n		<operation>\r\n			<search position="replace"><![CDATA[$this->load->model(\'design/layout\');]]></search>\r\n			<add><![CDATA[\r\n			$data[\'image_manager_plus_status\']  = $this->config->get(\'image_manager_plus_status\'); \r\n			if (isset($this->request->get[\'product_id\'])) {\r\n				$data[\'product_id\'] = $this->request->get[\'product_id\'];\r\n			} else {\r\n				$data[\'product_id\'] = 0;\r\n			}\r\n			$this->load->model(\'design/layout\');]]></add>\r\n		</operation>\r\n</file>\r\n<file path="admin/view/template/catalog/product_form.tpl">\r\n		<operation>\r\n			<search position="replace"><![CDATA[<div class="tab-pane" id="tab-image">]]></search>\r\n			<add><![CDATA[<div class="tab-pane" id="tab-image">\r\n			<?php global $config;			\r\n			$image_manager_plus_status  = $config->get(\'image_manager_plus_status\'); ?>\r\n			<?php if($image_manager_plus_status==1){?>\r\n			<div class="clearfix"><p class="pull-right"><button type="button" onclick="filemanager();" class="btn btn-danger"><i class="fa fa-plus-circle"></i> Chèn nhiều hình</button></p></div>\r\n			<?php } ?>\r\n			]]></add>\r\n		</operation>\r\n		<operation>\r\n			<search position="replace"><![CDATA[<td class="text-left"><?php echo $entry_image; ?></td>]]></search>\r\n			<add><![CDATA[<td class="text-left"><?php echo $entry_image; ?></td><td class="text-left">Chọn hình ảnh đại diện</td>]]></add>\r\n		</operation>\r\n		<operation>\r\n			<search position="replace"><![CDATA[<tr id="image-row<?php echo $image_row; ?>">]]></search>\r\n			<add><![CDATA[<tr class="image-row" id="image-row<?php echo $image_row; ?>">]]></add>\r\n		</operation>\r\n		<operation>\r\n			<search position="replace"><![CDATA[<td class="text-right"><input type="text" name="product_image[<?php echo $image_row; ?>][sort_order]" value="<?php echo $product_image[\'sort_order\']; ?>" placeholder="<?php echo $entry_sort_order; ?>" class="form-control" /></td>]]></search>\r\n			<add><![CDATA[<td class="text-left"><input type="radio" name="primary_image" onclick="changePrimaryImage(<?php echo $image_row; ?>)"></td><td class="text-right"><input type="text" name="product_image[<?php echo $image_row; ?>][sort_order]" value="<?php echo $product_image[\'sort_order\']; ?>" placeholder="<?php echo $entry_sort_order; ?>" class="form-control sort_order" /></td>]]></add>\r\n		</operation>\r\n		<operation>\r\n			<search position="replace"><![CDATA[<td class="text-left"><button type="button" onclick="addImage();" data-toggle="tooltip" title="<?php echo $button_image_add; ?>" class="btn btn-primary"><i class="fa fa-plus-circle"></i></button></td>]]></search>\r\n			<add><![CDATA[<td></td><td class="text-right"><button type="button" onclick="addImage();" data-toggle="tooltip" title="<?php echo $button_image_add; ?>" class="btn btn-primary"><i class="fa fa-plus-circle"></i></button></td>]]></add>\r\n		</operation>		\r\n		<operation>\r\n		<search position="replace"><![CDATA[var image_row = <?php echo $image_row; ?>;]]></search>		\r\n		<add><![CDATA[<?php if($image_manager_plus_status==1){?>\r\n		$.rcookie(\'product<?php echo $product_id; ?>_image_row\',null);\r\n		<?php }else{?>\r\n		var image_row = <?php echo $image_row; ?>;\r\n		<?php } ?>]]></add>\r\n	</operation>\r\n	<operation>\r\n		<search position="replace"><![CDATA[function addImage() {]]></search>		\r\n		<add><![CDATA[function addImage() {		\r\n		<?php if($image_manager_plus_status==1){?>\r\n		if ($.rcookie(\'product<?php echo $product_id; ?>_image_row\')==null||$.rcookie(\'product<?php echo $product_id; ?>_image_row\')==\'\') {\r\n			var cookie_image_row = <?php echo $image_row; ?>;	\r\n		}else{	\r\n			var cookie_image_row = $.rcookie(\'product<?php echo $product_id; ?>_image_row\');	\r\n		}	\r\n		var image_row = cookie_image_row;\r\n		$.rcookie(\'product<?php echo $product_id; ?>_image_row\',null);\r\n		<?php } ?>\r\n		]]></add>\r\n	</operation>\r\n	<operation>\r\n		<search position="replace"><![CDATA[html  = \'<tr id="image-row\' + image_row + \'">\';]]></search>\r\n		<add><![CDATA[html  = \'<tr class="image-row" id="image-row\' + image_row + \'">\';]]></add>\r\n	</operation>\r\n	<operation>\r\n		<search position="replace"><![CDATA[html += \'  <td class="text-right"><input type="text" name="product_image[\' + image_row + \'][sort_order]" value="" placeholder="<?php echo $entry_sort_order; ?>" class="form-control" /></td>\';]]></search>\r\n		<add><![CDATA[html += \'<td class="text-left"><input type="radio" name="primary_image" onclick="changePrimaryImage(\' + image_row + \')"/></td><td class="text-right"><input type="text" name="product_image[\' + image_row + \'][sort_order]" value="\' + image_row + \'" placeholder="<?php echo $entry_sort_order; ?>" class="form-control sort_order" /></td>\';]]></add>\r\n	</operation>\r\n		<operation>\r\n			<search position="replace"><![CDATA[$(\'#images tbody\').append(html);]]></search>\r\n			<add><![CDATA[$(\'#images tbody\').append(html);\r\n			<?php if($image_manager_plus_status==1){?>\r\n			$(\'#images\').sortable(\'refresh\');\r\n			var numrow= parseInt(image_row)+1;\r\n			$.rcookie(\'product<?php echo $product_id; ?>_image_row\',numrow);\r\n			<?php } ?>\r\n			]]></add>\r\n		</operation>	\r\n			<operation>\r\n			<search position="replace"><![CDATA[<?php echo $footer; ?>]]></search>\r\n			<add><![CDATA[<script type="text/javascript"><!--\r\n<?php if($image_manager_plus_status==1){?>\r\n	function insertImage(fileName) {  \r\n			if ($.rcookie(\'product<?php echo $product_id; ?>_image_row\')==null||$.rcookie(\'product<?php echo $product_id; ?>_image_row\')==\'\') {\r\n				var cookie_add_row = <?php echo $image_row; ?>;	\r\n			}else{	\r\n				var cookie_add_row = $.rcookie(\'product<?php echo $product_id; ?>_image_row\');\r\n			}					\r\n			var add_row = cookie_add_row;\r\n					\r\n			$.rcookie(\'product<?php echo $product_id; ?>_image_row\',null);\r\n				\r\n			html  = \'<tr class="image-row" id="image-row\' + add_row + \'">\';\r\n			html += \'  <td class="text-left"><a href="" id="thumb-image\' + add_row + \'"data-toggle="image" class="img-thumbnail"><img style="width:100px;" src="../image/\' + fileName + \'" alt="" title="" data-placeholder="<?php echo $placeholder; ?>" /><input type="hidden" name="product_image[\' + add_row + \'][image]" value="\' + fileName + \'" id="input-image\' + add_row + \'" /></td>\';\r\n			html += \'<td class="text-left"><input type="radio" name="primary_image" onclick="changePrimaryImage(\' + add_row + \')"/></td>\';\r\n			html += \'<td class="text-right"><input type="text" name="product_image[\' + add_row + \'][sort_order]" value="\' + add_row + \'" placeholder="<?php echo $entry_sort_order; ?>" class="form-control sort_order" /></td>\';\r\n			html += \'  <td class="text-left"><button type="button" onclick="$(\\\'#image-row\' + add_row  + \'\\\').remove();" data-toggle="tooltip" title="<?php echo $button_remove; ?>" class="btn btn-danger"><i class="fa fa-minus-circle"></i></button></td>\';\r\n			html += \'</tr>\';\r\n			$(\'#images tbody\').append(html);		\r\n			$(\'#images\').sortable(\'refresh\');\r\n			var numrow= parseInt(add_row)+1;\r\n			$.rcookie(\'product<?php echo $product_id; ?>_image_row\',numrow);	\r\n			add_row++;    \r\n	};\r\n<?php } ?>\r\n$(\'#images\').bind(\'sortupdate\', function(event, ui) {\r\n	var sort_order = 0;\r\n	 $(\'#images>tbody>tr\').each(function() {    \r\n		sort_order += 1;       \r\n		var so = $(this).find(\'.sort_order\');\r\n		so.attr(\'value\',sort_order);\r\n	});\r\n});		\r\n//--></script>\r\n<?php echo $footer; ?>]]></add>\r\n		</operation>\r\n</file>\r\n\r\n<file path="admin/controller/design/banner.php">\r\n		<operation>\r\n			<search position="replace"><![CDATA[$data[\'placeholder\'] = $this->model_tool_image->resize(\'no_image.png\', 100, 100);]]></search>\r\n			<add><![CDATA[$data[\'placeholder\'] = $this->model_tool_image->resize(\'no_image.png\', 100, 100);\r\n			if (isset($this->request->get[\'banner_id\'])) {\r\n				$data[\'banner_id\'] = $this->request->get[\'banner_id\'];\r\n			} else {\r\n				$data[\'banner_id\'] = 0;\r\n			}]]></add>\r\n		</operation>\r\n</file>\r\n<file path="admin/view/template/design/banner_form.tpl">\r\n		<operation>\r\n			<search position="replace"><![CDATA[<table id="images" class="table table-striped table-bordered table-hover">]]></search>\r\n			<add><![CDATA[<?php global $config;			\r\n			$image_manager_plus_status  = $config->get(\'image_manager_plus_status\'); ?>\r\n			<?php if($image_manager_plus_status==1){?>\r\n			<div class="clearfix"><p class="pull-right"><button type="button" onclick="filemanager();" class="btn btn-danger"><i class="fa fa-plus-circle"></i> Chèn nhiều hình</button></p></div>\r\n			<?php } ?>\r\n			<table id="images" class="table table-striped table-bordered table-hover">]]></add>\r\n		</operation>	\r\n		<operation>\r\n			<search position="replace"><![CDATA[<td class="text-left"><?php echo $entry_title; ?></td>]]></search>\r\n			<add><![CDATA[<td class="text-left" style="width:30%"><?php echo $entry_title; ?></td>]]></add>\r\n		</operation>\r\n		<operation>\r\n			<search position="replace"><![CDATA[<tr id="image-row<?php echo $image_row; ?>">]]></search>\r\n			<add><![CDATA[<tr class="image-row" id="image-row<?php echo $image_row; ?>">]]></add>\r\n		</operation>\r\n		<operation>\r\n		<search position="replace"><![CDATA[var image_row = <?php echo $image_row; ?>;]]></search>		\r\n		<add><![CDATA[<?php if($image_manager_plus_status==1){?>\r\n		$.rcookie(\'banner<?php echo $banner_id; ?>_image_row\',null);\r\n		<?php }else{ ?>\r\n		var image_row = <?php echo $image_row; ?>;\r\n		<?php } ?>]]></add>\r\n	</operation>	\r\n	<operation>\r\n		<search position="replace"><![CDATA[function addImage() {]]></search>		\r\n		<add><![CDATA[function addImage() {\r\n		<?php if($image_manager_plus_status==1){?>\r\n		if ($.rcookie(\'banner<?php echo $banner_id; ?>_image_row\')==null||$.rcookie(\'banner<?php echo $banner_id; ?>_image_row\')==\'\') {\r\n			var cookie_image_row = <?php echo $image_row; ?>;	\r\n		}else{	\r\n			var cookie_image_row = $.rcookie(\'banner<?php echo $banner_id; ?>_image_row\');	\r\n		}	\r\n		var image_row = cookie_image_row;\r\n		$.rcookie(\'banner<?php echo $banner_id; ?>_image_row\',null);\r\n		<?php } ?>]]></add>\r\n	</operation>	\r\n	<operation>\r\n			<search position="replace"><![CDATA[<td class="text-right"><input type="text" name="banner_image[<?php echo $image_row; ?>][sort_order]" value="<?php echo $banner_image[\'sort_order\']; ?>" placeholder="<?php echo $entry_sort_order; ?>" class="form-control" /></td>]]></search>\r\n			<add><![CDATA[<td class="text-right"><input type="text" name="banner_image[<?php echo $image_row; ?>][sort_order]" value="<?php echo $banner_image[\'sort_order\']; ?>" placeholder="<?php echo $entry_sort_order; ?>" class="form-control sort_order" /></td>]]></add>\r\n		</operation>	\r\n	<operation>\r\n			<search position="replace"><![CDATA[html += \'  <td class="text-right"><input type="text" name="banner_image[\' + image_row + \'][sort_order]" value="" placeholder="<?php echo $entry_sort_order; ?>" class="form-control" /></td>\';]]></search>\r\n			<add><![CDATA[html += \'  <td class="text-right"><input type="text" name="banner_image[\' + image_row + \'][sort_order]" value="\' + image_row + \'" placeholder="<?php echo $entry_sort_order; ?>" class="form-control sort_order" /></td>\';]]></add>\r\n	</operation>\r\n		<operation>\r\n			<search position="replace"><![CDATA[$(\'#images tbody\').append(html);]]></search>\r\n			<add><![CDATA[$(\'#images tbody\').append(html);\r\n			<?php if($image_manager_plus_status==1){?>\r\n			$(\'#images\').sortable(\'refresh\');\r\n			var numrow= parseInt(image_row)+1;\r\n			$.rcookie(\'banner<?php echo $banner_id; ?>_image_row\',numrow);\r\n			<?php } ?>\r\n			]]></add>\r\n		</operation>		\r\n		<operation>\r\n			<search position="before"><![CDATA[<?php echo $footer; ?>]]></search>\r\n			<add><![CDATA[<?php if($image_manager_plus_status==1){?>\r\n			<script type="text/javascript"><!--\r\nfunction insertImage(fileName) {							 \r\n	if ($.rcookie(\'banner<?php echo $banner_id; ?>_image_row\')==null||$.rcookie(\'banner<?php echo $banner_id; ?>_image_row\')==\'\') {\r\n		var cookie_add_row = <?php echo $image_row; ?>;	\r\n	}else{	\r\n		var cookie_add_row = $.rcookie(\'banner<?php echo $banner_id; ?>_image_row\');		\r\n	}					\r\n	var add_row = cookie_add_row;\r\n	html  = \'<tr class="image-row" id="image-row\' + add_row + \'">\';\r\n    html += \'  <td class="text-left">\';\r\n	<?php foreach ($languages as $language) { ?>\r\n	html += \'    <div class="input-group">\';\r\n	html += \'      <span class="input-group-addon"><img src="view/image/flags/<?php echo $language[\'image\']; ?>" title="<?php echo $language[\'name\']; ?>" /></span><input type="text" name="banner_image[\' + add_row + \'][banner_image_description][<?php echo $language[\'language_id\']; ?>][title]" value="" placeholder="<?php echo $entry_title; ?>" class="form-control" />\';\r\n    html += \'    </div>\';\r\n	<?php } ?>\r\n	html += \'  </td>\';	\r\n	html += \'  <td class="text-left"><input type="text" name="banner_image[\' + add_row + \'][link]" value="" placeholder="<?php echo $entry_link; ?>" class="form-control" /></td>\';	\r\n	html += \'  <td class="text-left"><a href="" id="thumb-image\' + add_row + \'" data-toggle="image" class="img-thumbnail"><img style="width:100px;" src="../image/\' + fileName + \'" alt="" title="" data-placeholder="<?php echo $placeholder; ?>" /></a><input type="hidden" name="banner_image[\' + add_row + \'][image]" value="\' + fileName + \'" id="input-image\' + add_row + \'" /></td>\';\r\n	html += \'  <td class="text-right"><input type="text" name="banner_image[\' + add_row + \'][sort_order]" value="\' + add_row + \'" placeholder="<?php echo $entry_sort_order; ?>" class="form-control sort_order" /></td>\';\r\n	html += \'  <td class="text-left"><button type="button" onclick="$(\\\'#image-row\' + add_row  + \'\\\').remove();" data-toggle="tooltip" title="<?php echo $button_remove; ?>" class="btn btn-danger"><i class="fa fa-minus-circle"></i></button></td>\';\r\n	html += \'</tr>\';\r\n	$(\'#images tbody\').append(html);\r\n	$(\'#images\').sortable(\'refresh\');	\r\n	var numrow= parseInt(add_row)+1;\r\n	$.rcookie(\'banner<?php echo $banner_id; ?>_image_row\',numrow);\r\n	add_row++;\r\n};\r\n$(\'#images\').bind(\'sortupdate\', function(event, ui) {\r\n	var sort_order = 0;\r\n	 $(\'#images>tbody>tr\').each(function() {    \r\n		sort_order += 1;       \r\n		var so = $(this).find(\'.sort_order\');\r\n		so.attr(\'value\',sort_order);\r\n	});\r\n});	\r\n//--></script><?php } ?>]]></add>\r\n		</operation>	\r\n</file>\r\n</modification>', 0, '2016-11-30 10:15:38'),
(73, 'Trình Đơn Nhanh', 'menu_group_short', 'Quocdv@matbao.com', '1.0', 'http://chili.vn', '<modification>\r\n    <name>Trình Đơn Nhanh</name>\r\n	<version>1.0</version>\r\n	<link>http://chili.vn</link>\r\n	<author>Quocdv@matbao.com</author>\r\n	<code>menu_group_short</code>\r\n	<file path="admin/controller/common/header.php">\r\n		<operation>\r\n			<search trim="true"><![CDATA[return $this->load->view(\'common/header.tpl\', $data);]]></search>\r\n			<add position="before" offset="1">\r\n				<![CDATA[\r\n					if($this->user->isLogged()){\r\n						$this->load->model(\'setting/setting\');\r\n						$all_group=$groups=$this->model_setting_setting->getSetting(\'group_menu\');\r\n						$data[\'link_edit\']=$this->url->link(\'module/groupmenu\',\'token=\'.$this->session->data[\'token\'],\'SSL\');\r\n						$lag=$this->language->get(\'code\');\r\n						if($lag==\'vi\'){\r\n							$data[\'text_menugroup\']="Ứng dụng đã cài";\r\n						}else{\r\n							$data[\'text_menugroup\']="Installed applications";\r\n						}\r\n						if(!empty($all_group[\'group_menu_value\'])){\r\n							foreach($all_group[\'group_menu_value\'] as $key_group=>$item_group){\r\n									$all_menus=$this->model_setting_setting->getSetting(\'menu\');\r\n									$menu=!empty($all_menus[\'menu_\'.$key_group])?$all_menus[\'menu_\'.$key_group]:NULL;\r\n									if(!empty($menu)){\r\n										foreach($menu as $key_menu=>$item_menu){// do link ok\r\n											$part=explode(\'/\',$item_menu[\'link_menu\']);\r\n											if ($this->user->hasPermission(\'access\',$part[0].\'/\'.$part[1])) {\r\n												$array_link=explode("/mb_qdv/", $item_menu[\'link_menu\']);\r\n												if(count($array_link)>1)\r\n													$array_link=$this->url->link($array_link[0],\'token=\'.$this->session->data[\'token\'].\'&\'.$array_link[1],\'SSL\');\r\n												else\r\n													$array_link=$this->url->link($item_menu[\'link_menu\'],\'token=\'.$this->session->data[\'token\'],\'SSL\');\r\n												$menu[$key_menu]=array(\r\n													\'id_menu\'=>$item_menu[\'id_menu\'],\r\n													\'title_menu\'=>$item_menu[\'title_menu\'][$this->config->get(\'config_language_id\')],\r\n													\'link_menu\'=>$array_link,\r\n													\'order_menu\'=>$item_menu[\'order_menu\'],\r\n												   );\r\n											}else{\r\n												unset($menu[$key_menu]);\r\n											}\r\n										}\r\n										//var_dump($menu);\r\n										if(!empty($menu)){\r\n											$data[\'menu_short\'][]=array(\r\n												\'group_info\'=>array($item_group[\'title_group\'][$this->config->get(\'config_language_id\')],$item_group[\'description_group\'][$this->config->get(\'config_language_id\')]),\r\n												\'menu_info\'=>$menu,\r\n											);\r\n										}\r\n\r\n									}\r\n							}\r\n						}\r\n					}\r\n				]]>\r\n			</add>\r\n		</operation>	\r\n	</file>\r\n	<file path="admin/view/template/common/header.tpl">\r\n			<operation>\r\n				<search trim="true"><![CDATA[<ul class="nav pull-right">]]></search>\r\n				<add position="before">\r\n					<![CDATA[ \r\n						<a class="dropdown-toggle dropdown-menushort" data-toggle="dropdown">\r\n						<i class="fa fa-plug"></i> <?php echo $text_menugroup; ?></a>\r\n						<div class="dropdown-menu" style="padding:5px 20px; margin: 0 auto; float: none; width: 100%; border-radius: 0px;background-color: #2DA7E8;">\r\n							<style type="text/css">\r\n								a.dropdown-menushort{\r\n									display: inline-block;\r\n									padding: 13px;\r\n									color: #000;\r\n									font-weight: bold;\r\n									text-transform: uppercase;\r\n									cursor: pointer;\r\n									position: relative;\r\n									padding-left: 35px;\r\n								}\r\n								a.dropdown-menushort>.fa{\r\n								    padding: 5px;\r\n									display: inline-block;\r\n									background: #5BC0DE;\r\n									color: #fff;\r\n									border-radius: 100%; 									\r\n									position: absolute;\r\n									left: 7px;\r\n									top: 10px;\r\n								}\r\n								a.dropdown-menushort:hover{\r\n									color:#1E91CF;\r\n								}\r\n								#menu_short a{ color:#fff; text-decoration: none; padding:3px 5px; width: 100%;}\r\n								#menu_short .item-group{list-style:none; display:inline-block; position:relative;}\r\n								.out-item-menu{ background:#0A94DC;}\r\n								#menu_short .group-title{\r\n									padding:10px;\r\n									display:inline-block;\r\n									color:#fff; font-size:13px;  border:0; border-radius:0;\r\n									text-transform: uppercase;\r\n									font-weight: bold;\r\n									border-bottom: 1px solid #1279B1;\r\n									background-color: #0C445F;\r\n								}\r\n								#menu_short .menu-group .item-menu{display:block;}\r\n								#menu_short .menu-group .item-menu a{display:block; padding:10px; font-size:13px; border-bottom:1px solid #0A8DD4;}\r\n								#menu_short .menu-group .item-menu a:hover{background: #1279B1;}\r\n							</style>\r\n							<?php if(!empty($menu_short)):  ?>\r\n							<div id="menu_short" class="row">\r\n								<?php foreach($menu_short as $key_group=>$item_group):?>\r\n								<div class="item-group col-md-2" style="padding: 10px;">\r\n									<div class="out-item-menu">\r\n									<a class="group-title"><i class="fa fa-dashboard fa-fw"></i> <?php echo $item_group[\'group_info\'][0]; ?> &nbsp;&nbsp; <span class="fa fa-question-circle" data-toggle="tooltip" data-placement="right" data-original-title="<?php echo $item_group[\'group_info\'][1]; ?>"></span></a>\r\n									<div class="menu-group">\r\n										<?php foreach($item_group[\'menu_info\'] as $key_menu=>$item_menu): ?>\r\n										<div class="item-menu">\r\n											<a href="<?php echo $item_menu[\'link_menu\']; ?>">\r\n												<i class="fa  fa-angle-double-right"></i>\r\n												<?php echo $item_menu[\'title_menu\']; ?>\r\n											</a>\r\n										</div>\r\n										<?php endforeach; ?>\r\n									</div>\r\n									</div>\r\n								</div>\r\n								<?php endforeach; ?>\r\n							</div>\r\n							<?php  else: ?>\r\n								<div class="text-center" style="color: #fff;">Không có trình đơn nhanh nào. Hãy vào cài đặt và sử dụng !</div>\r\n							<?php endif;  ?>\r\n					</div>\r\n					]]>\r\n				</add>\r\n			</operation>	\r\n		</file>	\r\n</modification>', 0, '2016-11-30 14:57:36');

-- --------------------------------------------------------

--
-- Table structure for table `oc_module`
--

CREATE TABLE `oc_module` (
  `module_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `code` varchar(32) NOT NULL,
  `setting` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_module`
--

INSERT INTO `oc_module` (`module_id`, `name`, `code`, `setting`) VALUES
(60, 'Khuyến mãi', 'special', 'a:5:{s:4:"name";s:13:"Khuyến mãi";s:5:"limit";s:1:"5";s:5:"width";s:3:"360";s:6:"height";s:3:"360";s:6:"status";s:1:"1";}'),
(69, 'Banner 1 trang chủ', 'banner', 'a:5:{s:4:"name";s:20:"Banner 1 trang chủ";s:9:"banner_id";s:2:"10";s:5:"width";s:3:"360";s:6:"height";s:3:"270";s:6:"status";s:1:"1";}'),
(29, 'Nhà sản xuất', 'carousel', 'a:5:{s:4:"name";s:17:"Nhà sản xuất";s:9:"banner_id";s:1:"8";s:5:"width";s:3:"210";s:6:"height";s:3:"111";s:6:"status";s:1:"1";}'),
(31, 'Thông tin bản quyền', 'html', 'a:3:{s:4:"name";s:24:"Thông tin bản quyền";s:18:"module_description";a:1:{i:2;a:2:{s:5:"title";s:0:"";s:11:"description";s:264:"© 2016 Copyright by CosyCare – Số ĐKKD 1111 – Tại sở Kế Hoạch và Đầu Tư TP.HCM – (&lt;a href=&quot;/chinh-sach-rieng-tu.html&quot; class=&quot;provision&quot; style=&quot;margin: 0px; padding: 0px;&quot;&gt;Chính sách riêng tư&lt;/a&gt;)";}}s:6:"status";s:1:"1";}'),
(46, 'Slider - Trang chủ', 'revslideroutput', 'a:3:{s:4:"name";s:20:"Slider - Trang chủ";s:9:"slider_id";s:1:"1";s:6:"status";s:1:"1";}'),
(33, 'Trình đơn chính', 'menu', 'a:7:{s:4:"name";s:19:"Trình đơn chính";s:9:"name_lang";a:1:{i:2;a:1:{s:5:"title";s:19:"Trình đơn chính";}}s:7:"menu_id";s:1:"3";s:5:"width";s:3:"100";s:6:"height";s:3:"100";s:4:"size";s:2:"14";s:6:"status";s:1:"1";}'),
(47, 'Bản đồ trang liên hệ', 'google_maps', 'a:7:{s:4:"name";s:28:"Bản đồ trang liên hệ";s:3:"ids";a:1:{i:0;s:3:"111";}s:5:"width";s:4:"100%";s:6:"height";s:5:"400px";s:4:"zoom";s:2:"17";s:7:"maptype";s:7:"ROADMAP";s:6:"status";s:1:"1";}'),
(54, 'Hotline', 'content_info', 'a:11:{s:4:"name";s:7:"Hotline";s:5:"title";a:1:{i:2;s:7:"Hotline";}s:5:"class";s:7:"hotline";s:10:"show_title";s:1:"0";s:4:"type";s:4:"list";s:5:"width";s:0:"";s:6:"height";s:0:"";s:6:"column";s:1:"1";s:12:"setting_link";s:5:"title";s:6:"status";s:1:"1";s:4:"info";a:5:{s:4:"name";a:1:{i:2;a:3:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";}}s:5:"title";a:1:{i:2;a:3:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";}}s:11:"description";a:1:{i:2;a:3:{i:0;s:15:"+84 123 456 789";i:1;s:15:"+84 123 456 789";i:2;s:55:"Thứ 2 - 6: 7h - 21h, Thứ 7 - chủ nhật: 8h - 22h";}}s:5:"image";a:2:{i:0;a:3:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";}i:1;a:3:{i:0;s:8:"fa-phone";i:1;s:8:"fa-phone";i:2;s:0:"";}}s:4:"link";a:3:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";}}}'),
(35, 'Thông tin', 'menu', 'a:7:{s:4:"name";s:10:"Thông tin";s:9:"name_lang";a:1:{i:2;a:1:{s:5:"title";s:10:"Thông tin";}}s:7:"menu_id";s:1:"5";s:5:"width";s:3:"100";s:6:"height";s:3:"100";s:4:"size";s:2:"14";s:6:"status";s:1:"1";}'),
(36, 'Tài khoản', 'menu', 'a:7:{s:4:"name";s:12:"Tài khoản";s:9:"name_lang";a:1:{i:2;a:1:{s:5:"title";s:12:"Tài khoản";}}s:7:"menu_id";s:1:"6";s:5:"width";s:3:"100";s:6:"height";s:3:"100";s:4:"size";s:2:"14";s:6:"status";s:1:"1";}'),
(37, 'Dịch vụ', 'menu', 'a:7:{s:4:"name";s:11:"Dịch vụ";s:9:"name_lang";a:1:{i:2;a:1:{s:5:"title";s:11:"Dịch vụ";}}s:7:"menu_id";s:1:"7";s:5:"width";s:3:"100";s:6:"height";s:3:"100";s:4:"size";s:2:"14";s:6:"status";s:1:"1";}'),
(38, 'Giới thiệu cuối trang', 'html', 'a:3:{s:4:"name";s:27:"Giới thiệu cuối trang";s:18:"module_description";a:1:{i:2;a:2:{s:5:"title";s:8:"CosyCare";s:11:"description";s:406:"&lt;p&gt;Nhà Thuốc CosyCare là nhà thuốc uy tín, đội ngũ dược sĩ có chuyên môn cao và tận tâm vì sức khoẻ của bạn và gia đình.&lt;/p&gt;&lt;p&gt;Email: &lt;span style=&quot;color: rgb(0, 0, 0);&quot;&gt;taikhoan@tenmien.com&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Hotline: &lt;span style=&quot;font-weight: bold; color: rgb(0, 0, 0);&quot;&gt;(0123) 456 789&lt;/span&gt;&lt;/p&gt;";}}s:6:"status";s:1:"1";}'),
(76, 'Thông tin liên hệ cuối trang', 'content_info', 'a:11:{s:4:"name";s:34:"Thông tin liên hệ cuối trang";s:5:"title";a:1:{i:2;s:10:"Liên hệ";}s:5:"class";s:12:"info_contact";s:10:"show_title";s:1:"1";s:4:"type";s:4:"list";s:5:"width";s:0:"";s:6:"height";s:0:"";s:6:"column";s:1:"1";s:12:"setting_link";s:5:"title";s:6:"status";s:1:"1";s:4:"info";a:5:{s:4:"name";a:1:{i:2;a:3:{i:0;s:0:"";i:1;s:24:"Hotline: (0123) 456 789 ";i:2;s:27:"Email: taikhoan@tenmien.com";}}s:5:"title";a:1:{i:2;a:3:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";}}s:11:"description";a:1:{i:2;a:3:{i:0;s:64:"Số 123, Đường ABC, Quận ABC, Thành Phố Hồ Chí Minh";i:1;s:21:"Fax: (84) 2345 - 6789";i:2;s:27:" Website: tenmiencuaban.com";}}s:5:"image";a:2:{i:0;a:3:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";}i:1;a:3:{i:0;s:13:"fa-map-marker";i:1;s:8:"fa-phone";i:2;s:10:"fa-clock-o";}}s:4:"link";a:3:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";}}}'),
(39, 'Cuối trang', 'module_col', 'a:9:{s:4:"name";s:12:"Cuối trang";s:5:"title";a:1:{i:2;s:12:"Cuối trang";}s:5:"class";s:16:" vertical_footer";s:5:"id_dv";s:0:"";s:10:"width_full";s:1:"1";s:6:"col_ms";s:1:"0";s:10:"show_title";s:1:"0";s:6:"status";s:1:"1";s:6:"module";a:4:{i:0;s:55:"3quocdvowowGiới thiệu cuối trangquocdvowowhtml.38";i:1;s:38:"3quocdvowowThông tinquocdvowowmenu.35";i:2;s:39:"3quocdvowowDịch vụquocdvowowmenu.37";i:3;s:40:"3quocdvowowTài khoảnquocdvowowmenu.36";}}'),
(72, 'Chính sách', 'content_info', 'a:11:{s:4:"name";s:12:"Chính sách";s:5:"title";a:1:{i:2;s:12:"Chính sách";}s:10:"show_title";s:1:"0";s:4:"type";s:6:"column";s:5:"class";s:6:"policy";s:5:"width";s:2:"50";s:6:"height";s:2:"47";s:6:"column";s:1:"3";s:12:"setting_link";s:3:"all";s:6:"status";s:1:"1";s:4:"info";a:5:{s:4:"name";a:1:{i:2;a:3:{i:0;s:26:"Miễn phí vận chuyển";i:1;s:19:"Ưu đãi mua hàng";i:2;s:25:"Chính sách hoàn tiền";}}s:5:"title";a:1:{i:2;a:3:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";}}s:11:"description";a:1:{i:2;a:3:{i:0;s:87:"Miễn phí vận chuyển trên toàn quốc cho mọi đơn hàng từ 1.000.000 VNĐ";i:1;s:56:"Giảm 10% cho đơn hàng tiếp theo của quý khách";i:2;s:68:"Hoàn 100% tiền khi sản phẩm lỗi hoặc không như mô tả";}}s:5:"image";a:2:{i:0;a:3:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";}i:1;a:3:{i:0;s:14:"fa-thumbs-o-up";i:1;s:7:"fa-gift";i:2;s:14:"fa-certificate";}}s:4:"link";a:3:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";}}}'),
(40, 'Thông tin', 'module_col', 'a:9:{s:4:"name";s:10:"Thông tin";s:5:"title";a:1:{i:2;s:10:"Thông tin";}s:5:"class";s:0:"";s:5:"id_dv";s:0:"";s:10:"width_full";s:1:"1";s:6:"col_ms";s:1:"0";s:10:"show_title";s:1:"0";s:6:"status";s:1:"1";s:6:"module";a:1:{i:0;s:53:"12quocdvowowThông tin bản quyềnquocdvowowhtml.31";}}'),
(48, 'Mới nhất', 'latest', 'a:5:{s:4:"name";s:12:"Mới nhất";s:5:"limit";s:1:"5";s:5:"width";s:3:"100";s:6:"height";s:3:"100";s:6:"status";s:1:"1";}'),
(45, 'Đầu trang', 'module_col', 'a:9:{s:4:"name";s:12:"Đầu trang";s:5:"title";a:1:{i:2;s:12:"Đầu trang";}s:5:"class";s:6:"header";s:5:"id_dv";s:6:"header";s:10:"width_full";s:1:"1";s:6:"col_ms";s:1:"0";s:10:"show_title";s:1:"0";s:6:"status";s:1:"1";s:6:"module";a:2:{i:0;s:48:"6quocdvowowLogo đầu trangquocdvowowmb_logo.49";i:1;s:101:"6quocdvowow Tìm kiếmquocdvkaka Thay đổi ngôn ngữquocdvowowmb_searchquocdvkakalanguage_switch";}}'),
(49, 'Logo đầu trang', 'mb_logo', 'a:7:{s:4:"name";s:17:"Logo đầu trang";s:5:"image";s:16:"catalog/logo.png";s:4:"size";s:1:"1";s:5:"width";s:3:"163";s:6:"height";s:2:"34";s:9:"logo_text";s:1:"0";s:6:"status";s:1:"1";}'),
(50, 'Trình danh mục chính', 'menu', 'a:7:{s:4:"name";s:24:"Trình danh mục chính";s:9:"name_lang";a:1:{i:2;a:1:{s:5:"title";s:23:"Danh mục sản phẩm";}}s:7:"menu_id";s:1:"9";s:5:"width";s:2:"60";s:6:"height";s:2:"50";s:4:"size";s:2:"14";s:6:"status";s:1:"1";}'),
(51, 'footer', 'module_col', 'a:8:{s:4:"name";s:6:"footer";s:5:"class";s:0:"";s:5:"id_dv";s:0:"";s:10:"width_full";s:1:"1";s:6:"col_ms";s:1:"0";s:10:"show_title";s:1:"0";s:6:"status";s:1:"1";s:6:"module";a:6:{i:0;s:36:"6quocdvowowCopyrigtquocdvowowhtml.31";i:1;s:42:"6quocdvowow   Danh mụcquocdvowowcategory";i:2;s:48:"12quocdvowowTrình đơn chínhquocdvowowmenu.33";i:3;s:57:"12quocdvowow   Đăng ký nhận tinquocdvowownewsletters";i:4;s:38:"6quocdvowowThông tinquocdvowowmenu.35";i:5;s:44:"6quocdvowow   Tìm kiếmquocdvowowmb_search";}}'),
(52, 'Mạng xã hội', 'content_info', 'a:12:{s:4:"name";s:16:"Mạng xã hội";s:5:"title";a:1:{i:2;s:0:"";}s:5:"class";s:13:"footer-social";s:10:"show_title";s:1:"0";s:4:"type";s:4:"list";s:18:"hidden_description";s:1:"1";s:5:"width";s:0:"";s:6:"height";s:0:"";s:6:"column";s:1:"1";s:12:"setting_link";s:3:"all";s:6:"status";s:1:"1";s:4:"info";a:3:{s:4:"name";a:1:{i:2;a:5:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";i:4;s:0:"";}}s:5:"image";a:2:{i:0;a:5:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";i:4;s:0:"";}i:1;a:5:{i:0;s:11:"fa-facebook";i:1;s:10:"fa-twitter";i:2;s:14:"fa-google-plus";i:3;s:12:"fa-instagram";i:4;s:17:"fa-youtube-square";}}s:4:"link";a:5:{i:0;s:24:"https://www.facebook.com";i:1;s:19:"https://twitter.com";i:2;s:23:"https://plus.google.com";i:3;s:25:"https://www.instagram.com";i:4;s:23:"https://www.youtube.com";}}}'),
(53, 'Thông tin liên hệ', 'content_info', 'a:11:{s:4:"name";s:21:"Thông tin liên hệ";s:5:"title";a:1:{i:2;s:0:"";}s:5:"class";s:11:"add_contact";s:10:"show_title";s:1:"0";s:4:"type";s:6:"column";s:5:"width";s:3:"163";s:6:"height";s:2:"34";s:6:"column";s:1:"4";s:12:"setting_link";s:5:"title";s:6:"status";s:1:"1";s:4:"info";a:5:{s:4:"name";a:1:{i:2;a:4:{i:0;s:0:"";i:1;s:0:"";i:2;s:27:"Email: taikhoan@tenmien.com";i:3;s:21:"Thứ 2 - 6: 7h - 21h";}}s:5:"title";a:1:{i:2;a:4:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";}}s:11:"description";a:1:{i:2;a:4:{i:0;s:0:"";i:1;s:79:"Địa chỉ:  Số 123, Đường ABC, Quận ABC, Thành Phố Hồ Chí Minh";i:2;s:24:"Hotline: +84 123 456 789";i:3;s:32:"Thứ 7 - chủ nhật: 8h - 22h";}}s:5:"image";a:2:{i:0;a:4:{i:0;s:16:"catalog/logo.png";i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";}i:1;a:4:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";}}s:4:"link";a:4:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";}}}'),
(71, 'Đăng ký nhận tin', 'module_col', 'a:9:{s:4:"name";s:21:"Đăng ký nhận tin";s:5:"title";a:1:{i:2;s:0:"";}s:5:"class";s:15:"newsletter_home";s:5:"id_dv";s:15:"newsletter_home";s:10:"width_full";s:1:"1";s:6:"col_ms";s:1:"1";s:10:"show_title";s:1:"0";s:6:"status";s:1:"1";s:6:"module";a:1:{i:0;s:57:"12quocdvowow   Đăng ký nhận tinquocdvowownewsletters";}}'),
(64, 'Nổi bật', 'featured', 'a:6:{s:4:"name";s:11:"Nổi bật";s:7:"product";a:8:{i:0;s:3:"120";i:1;s:3:"126";i:2;s:3:"129";i:3;s:3:"131";i:4;s:3:"133";i:5;s:3:"134";i:6;s:3:"119";i:7;s:3:"121";}s:5:"limit";s:1:"6";s:5:"width";s:3:"360";s:6:"height";s:3:"360";s:6:"status";s:1:"1";}'),
(65, 'Sản phẩm cột trái - phải', 'module_col', 'a:9:{s:4:"name";s:33:"Sản phẩm cột trái - phải";s:5:"title";a:1:{i:2;s:0:"";}s:5:"class";s:12:"list_product";s:5:"id_dv";s:0:"";s:10:"width_full";s:1:"1";s:6:"col_ms";s:1:"1";s:10:"show_title";s:1:"0";s:6:"status";s:1:"1";s:6:"module";a:1:{i:0;s:43:"12quocdvowowMới nhấtquocdvowowlatest.48";}}'),
(66, 'Sản phẩm mới', 'showintabs', 'a:8:{s:4:"name";s:18:"Sản phẩm mới";s:4:"tabs";a:3:{i:0;s:1:"5";i:1;s:1:"6";i:2;s:1:"7";}s:8:"carousel";s:1:"1";s:9:"show_link";s:1:"0";s:5:"limit";s:2:"10";s:5:"width";s:3:"270";s:6:"height";s:3:"270";s:6:"status";s:1:"1";}'),
(73, 'Chính sách', 'module_col', 'a:9:{s:4:"name";s:12:"Chính sách";s:5:"title";a:1:{i:2;s:0:"";}s:5:"class";s:0:"";s:5:"id_dv";s:6:"policy";s:10:"width_full";s:1:"0";s:6:"col_ms";s:1:"1";s:10:"show_title";s:1:"0";s:6:"status";s:1:"1";s:6:"module";a:1:{i:0;s:49:"12quocdvowowChính sáchquocdvowowcontent_info.72";}}'),
(87, 'Nổi bật trang chủ', 'module_col', 'a:9:{s:4:"name";s:23:"Nổi bật trang chủ";s:5:"title";a:1:{i:2;s:13:"Khuyến mãi";}s:5:"class";s:9:"sale-home";s:5:"id_dv";s:9:"sale_home";s:10:"width_full";s:1:"1";s:6:"col_ms";s:1:"1";s:10:"show_title";s:1:"1";s:6:"status";s:1:"1";s:6:"module";a:1:{i:0;s:45:"12quocdvowowKhuyến mãiquocdvowowspecial.60";}}'),
(86, 'Slide &amp; banner', 'module_col', 'a:9:{s:4:"name";s:18:"Slide &amp; banner";s:5:"title";a:1:{i:2;s:0:"";}s:5:"class";s:9:"slide-box";s:5:"id_dv";s:9:"slide-box";s:10:"width_full";s:1:"1";s:6:"col_ms";s:1:"1";s:10:"show_title";s:1:"0";s:6:"status";s:1:"1";s:6:"module";a:2:{i:0;s:59:"8quocdvowowSlider - Trang chủquocdvowowrevslideroutput.46";i:1;s:105:"4quocdvowowBanner 1 trang chủquocdvkaka   Đăng ký nhận tinquocdvowowbanner.69quocdvkakanewsletters";}}'),
(79, 'Sản phẩm theo mục', 'showintabs', 'a:8:{s:4:"name";s:23:"Sản phẩm theo mục";s:4:"tabs";a:3:{i:0;s:1:"0";i:1;s:1:"1";i:2;s:1:"2";}s:8:"carousel";s:1:"0";s:9:"show_link";s:1:"0";s:5:"limit";s:2:"10";s:5:"width";s:3:"270";s:6:"height";s:3:"270";s:6:"status";s:1:"1";}'),
(92, 'Sản phẩm trang chủ', 'module_col', 'a:9:{s:4:"name";s:24:"Sản phẩm trang chủ";s:5:"title";a:1:{i:2;s:0:"";}s:5:"class";s:12:"product-home";s:5:"id_dv";s:12:"product-home";s:10:"width_full";s:1:"1";s:6:"col_ms";s:1:"1";s:10:"show_title";s:1:"0";s:6:"status";s:1:"1";s:6:"module";a:1:{i:0;s:44:"12quocdvowowNổi bậtquocdvowowfeatured.64";}}'),
(88, 'Banner cột trái', 'banner', 'a:5:{s:4:"name";s:18:"Banner cột trái";s:9:"banner_id";s:2:"11";s:5:"width";s:3:"263";s:6:"height";s:3:"288";s:6:"status";s:1:"1";}'),
(89, 'Bán chạy', 'bestseller', 'a:5:{s:4:"name";s:11:"Bán chạy";s:5:"limit";s:1:"3";s:5:"width";s:3:"200";s:6:"height";s:3:"200";s:6:"status";s:1:"1";}'),
(90, 'Bán chạy cột trái', 'module_col', 'a:9:{s:4:"name";s:23:"Bán chạy cột trái";s:5:"title";a:1:{i:2;s:11:"bán chạy";}s:5:"class";s:12:"list_product";s:5:"id_dv";s:0:"";s:10:"width_full";s:1:"1";s:6:"col_ms";s:1:"1";s:10:"show_title";s:1:"0";s:6:"status";s:1:"1";s:6:"module";a:1:{i:0;s:46:"12quocdvowowBán chạyquocdvowowbestseller.89";}}'),
(91, 'Tư vấn', 'content_info', 'a:12:{s:4:"name";s:9:"Tư vấn";s:5:"title";a:1:{i:2;s:0:"";}s:5:"class";s:13:"free-shipping";s:10:"show_title";s:1:"0";s:4:"type";s:4:"list";s:12:"hidden_image";s:1:"1";s:5:"width";s:0:"";s:6:"height";s:0:"";s:6:"column";s:1:"1";s:12:"setting_link";s:3:"all";s:6:"status";s:1:"1";s:4:"info";a:4:{s:4:"name";a:1:{i:2;a:1:{i:0;s:24:"TƯ VẤN - HỎI ĐÁP ";}}s:5:"title";a:1:{i:2;a:1:{i:0;s:87:"Hãy liên hệ chúng tôi để được tư vấn và giải đáp các thắc mắc";}}s:11:"description";a:1:{i:2;a:1:{i:0;s:0:"";}}s:4:"link";a:1:{i:0;s:35:"index.php?route=information/contact";}}}'),
(85, 'giới thiệu đầu trang', 'html', 'a:3:{s:4:"name";s:27:"giới thiệu đầu trang";s:18:"module_description";a:1:{i:2;a:2:{s:5:"title";s:0:"";s:11:"description";s:306:"&lt;p&gt;&lt;span style=&quot;color: rgb(9, 176, 96); font-family: Arial, sans-serif;&quot;&gt;Miễn phí vận chuyển&lt;/span&gt;&lt;span style=&quot;color: rgb(140, 140, 140); font-family: Arial, sans-serif;&quot;&gt;&amp;nbsp;cho đơn hàng lớn hơn 1.000.000VNĐ&lt;/span&gt;&lt;br&gt;&lt;/p&gt;";}}s:6:"status";s:1:"1";}');

-- --------------------------------------------------------

--
-- Table structure for table `oc_newsletter`
--

CREATE TABLE `oc_newsletter` (
  `news_id` int(11) NOT NULL,
  `news_email` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_openbay_faq`
--

CREATE TABLE `oc_openbay_faq` (
  `id` int(11) NOT NULL,
  `route` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_option`
--

CREATE TABLE `oc_option` (
  `option_id` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_option`
--

INSERT INTO `oc_option` (`option_id`, `type`, `sort_order`) VALUES
(1, 'select', 1),
(2, 'checkbox', 2),
(4, 'text', 3),
(5, 'image', 4),
(6, 'textarea', 5),
(7, 'file', 6),
(8, 'date', 7),
(9, 'time', 8),
(10, 'datetime', 9),
(12, 'date', 11),
(13, 'select', 2),
(14, 'select', 3);

-- --------------------------------------------------------

--
-- Table structure for table `oc_option_description`
--

CREATE TABLE `oc_option_description` (
  `option_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_option_description`
--

INSERT INTO `oc_option_description` (`option_id`, `language_id`, `name`) VALUES
(1, 2, 'Kích thước'),
(2, 2, 'Tùy chọn nhiều'),
(4, 2, 'Văn bản'),
(6, 2, 'Vùng nhập văn bản'),
(8, 2, 'Ngày'),
(7, 2, 'Tập tin'),
(5, 2, 'Màu sắc'),
(9, 2, 'Thời gian'),
(10, 2, 'Ngày và giờ'),
(12, 2, 'Ngày giao hàng'),
(13, 2, 'Trọng lượng'),
(14, 2, 'Miếng');

-- --------------------------------------------------------

--
-- Table structure for table `oc_option_value`
--

CREATE TABLE `oc_option_value` (
  `option_value_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_option_value`
--

INSERT INTO `oc_option_value` (`option_value_id`, `option_id`, `image`, `sort_order`) VALUES
(43, 1, '', 3),
(31, 1, '', 2),
(40, 5, 'catalog/mausac_tuychon/xanhduong.jpg', 2),
(32, 1, '', 1),
(24, 2, '', 2),
(23, 2, '', 1),
(39, 5, 'catalog/mausac_tuychon/do.jpg', 1),
(54, 5, 'catalog/mausac_tuychon/vang.jpg', 0),
(53, 5, 'catalog/mausac_tuychon/trang.jpg', 0),
(52, 5, 'catalog/mausac_tuychon/tim.jpg', 0),
(51, 5, 'catalog/mausac_tuychon/hong.jpg', 0),
(50, 5, 'catalog/mausac_tuychon/den.jpg', 0),
(49, 5, 'catalog/mausac_tuychon/cam.jpg', 0),
(42, 5, 'catalog/mausac_tuychon/xanhla.jpg', 4),
(55, 5, 'catalog/mausac_tuychon/xam.jpg', 0),
(56, 5, 'catalog/mausac_tuychon/nau.jpg', 0),
(57, 13, '', 1),
(58, 13, '', 2),
(59, 13, '', 3),
(60, 14, '', 0),
(61, 14, '', 0),
(62, 14, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_option_value_description`
--

CREATE TABLE `oc_option_value_description` (
  `option_value_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_option_value_description`
--

INSERT INTO `oc_option_value_description` (`option_value_id`, `language_id`, `option_id`, `name`) VALUES
(31, 2, 1, 'Vừa'),
(24, 2, 2, 'Tùy chọn nhiều 2'),
(32, 2, 1, 'Nhỏ'),
(40, 2, 5, 'Xanh dương'),
(39, 2, 5, 'Đỏ'),
(23, 2, 2, 'Tùy chọn nhiều 1'),
(54, 2, 5, 'Vàng'),
(53, 2, 5, 'Trắng'),
(52, 2, 5, 'Tím'),
(51, 2, 5, 'Hồng'),
(50, 2, 5, 'Đen'),
(49, 2, 5, 'Cam'),
(42, 2, 5, 'Xanh lá'),
(55, 2, 5, 'Xám'),
(56, 2, 5, 'Nâu'),
(43, 2, 1, 'Lớn'),
(57, 2, 13, '100g'),
(58, 2, 13, '250g'),
(59, 2, 13, '500g'),
(60, 2, 14, '12 Miếng'),
(61, 2, 14, '24 Miếng'),
(62, 2, 14, '50 Miếng');

-- --------------------------------------------------------

--
-- Table structure for table `oc_order`
--

CREATE TABLE `oc_order` (
  `order_id` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL DEFAULT '0',
  `invoice_prefix` varchar(26) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `store_name` varchar(64) NOT NULL,
  `store_url` varchar(255) NOT NULL,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `customer_group_id` int(11) NOT NULL DEFAULT '0',
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(96) NOT NULL,
  `telephone` varchar(32) NOT NULL,
  `fax` varchar(32) NOT NULL,
  `custom_field` text NOT NULL,
  `payment_firstname` varchar(32) NOT NULL,
  `payment_lastname` varchar(32) NOT NULL,
  `payment_company` varchar(40) NOT NULL,
  `payment_address_1` varchar(128) NOT NULL,
  `payment_address_2` varchar(128) NOT NULL,
  `payment_city` varchar(128) NOT NULL,
  `payment_postcode` varchar(10) NOT NULL,
  `payment_country` varchar(128) NOT NULL,
  `payment_country_id` int(11) NOT NULL,
  `payment_zone` varchar(128) NOT NULL,
  `payment_zone_id` int(11) NOT NULL,
  `payment_address_format` text NOT NULL,
  `payment_custom_field` text NOT NULL,
  `payment_method` varchar(128) NOT NULL,
  `payment_code` varchar(128) NOT NULL,
  `shipping_firstname` varchar(32) NOT NULL,
  `shipping_lastname` varchar(32) NOT NULL,
  `shipping_company` varchar(40) NOT NULL,
  `shipping_address_1` varchar(128) NOT NULL,
  `shipping_address_2` varchar(128) NOT NULL,
  `shipping_city` varchar(128) NOT NULL,
  `shipping_postcode` varchar(10) NOT NULL,
  `shipping_country` varchar(128) NOT NULL,
  `shipping_country_id` int(11) NOT NULL,
  `shipping_zone` varchar(128) NOT NULL,
  `shipping_zone_id` int(11) NOT NULL,
  `shipping_address_format` text NOT NULL,
  `shipping_custom_field` text NOT NULL,
  `shipping_method` varchar(128) NOT NULL,
  `shipping_code` varchar(128) NOT NULL,
  `comment` text NOT NULL,
  `total` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `order_status_id` int(11) NOT NULL DEFAULT '0',
  `affiliate_id` int(11) NOT NULL,
  `commission` decimal(15,4) NOT NULL,
  `marketing_id` int(11) NOT NULL,
  `tracking` varchar(64) NOT NULL,
  `language_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `currency_code` varchar(3) NOT NULL,
  `currency_value` decimal(15,8) NOT NULL DEFAULT '1.00000000',
  `ip` varchar(40) NOT NULL,
  `forwarded_ip` varchar(40) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `accept_language` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `tracking_code` varchar(255) NOT NULL,
  `data_cancel_order_boxme` varchar(255) NOT NULL,
  `statusboxme` varchar(255) NOT NULL,
  `info_statusboxme` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_order`
--

INSERT INTO `oc_order` (`order_id`, `invoice_no`, `invoice_prefix`, `store_id`, `store_name`, `store_url`, `customer_id`, `customer_group_id`, `firstname`, `lastname`, `email`, `telephone`, `fax`, `custom_field`, `payment_firstname`, `payment_lastname`, `payment_company`, `payment_address_1`, `payment_address_2`, `payment_city`, `payment_postcode`, `payment_country`, `payment_country_id`, `payment_zone`, `payment_zone_id`, `payment_address_format`, `payment_custom_field`, `payment_method`, `payment_code`, `shipping_firstname`, `shipping_lastname`, `shipping_company`, `shipping_address_1`, `shipping_address_2`, `shipping_city`, `shipping_postcode`, `shipping_country`, `shipping_country_id`, `shipping_zone`, `shipping_zone_id`, `shipping_address_format`, `shipping_custom_field`, `shipping_method`, `shipping_code`, `comment`, `total`, `order_status_id`, `affiliate_id`, `commission`, `marketing_id`, `tracking`, `language_id`, `currency_id`, `currency_code`, `currency_value`, `ip`, `forwarded_ip`, `user_agent`, `accept_language`, `date_added`, `date_modified`, `tracking_code`, `data_cancel_order_boxme`, `statusboxme`, `info_statusboxme`) VALUES
(50, 0, 'INV-2015-00', 0, 'CosyCare', 'http://boxmes.webthongminh.info/', 1, 0, 'Tuấn', 'Anh', 'votuananh8127@gmail.com', '0983492410', '0983492410', 'b:0;', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Thu tiền khi giao hàng', 'cod', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Phí vận chuyển cố định', 'flat.flat', '', '1120000.0000', 2, 0, '0.0000', 0, '', 2, 2, 'VND', '1.00000000', '112.78.13.106', '', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36', 'en-US,en;q=0.8', '2017-04-14 13:41:11', '2017-04-14 15:05:02', 'SC51199666894', 'SUCCESS', '{"TrackingCode":"SC51199666894","StatusId":22,"StatusName":"Hủy đơn hàng","TimeStamp":1492157082}', '{"tracking_code":{"data":{"trackingcode":"SC51199666894","cod":"16800","pbh":"0","pvc":"28000"}}}'),
(53, 0, 'INV-2015-00', 0, 'CosyCare', 'http://boxmes.webthongminh.info/', 1, 0, 'Tuấn', 'Anh', 'votuananh8127@gmail.com', '0983492410', '0983492410', 'b:0;', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Thu tiền khi giao hàng', 'cod', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Phí vận chuyển cố định', 'flat.flat', '', '1120000.0000', 2, 0, '0.0000', 0, '', 2, 2, 'VND', '1.00000000', '112.78.13.106', '', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36', 'en-US,en;q=0.8', '2017-04-14 14:38:13', '2017-04-14 15:30:33', 'SC5241323515', '', '{"TrackingCode":"SC5241323515","StatusId":22,"StatusName":"Hủy đơn hàng","TimeStamp":1492158613}', '{"tracking_code":{"data":{"trackingcode":"SC5241323515","cod":"16800","pbh":"0","pvc":"28000"}}}'),
(54, 0, 'INV-2015-00', 0, 'CosyCare', 'http://boxmes.webthongminh.info/', 1, 0, 'Tuấn', 'Anh', 'votuananh8127@gmail.com', '0983492410', '0983492410', 'b:0;', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Thu tiền khi giao hàng', 'cod', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Phí vận chuyển cố định', 'flat.flat', '', '1120000.0000', 2, 0, '0.0000', 0, '', 2, 2, 'VND', '1.00000000', '112.78.13.106', '', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36', 'en-US,en;q=0.8', '2017-04-14 14:43:03', '2017-04-14 15:44:26', 'SC51884683279', '', '{"TrackingCode":"SC51884683279","StatusId":22,"StatusName":"Hủy đơn hàng","TimeStamp":1492159446}', '{"tracking_code":{"data":{"trackingcode":"SC51884683279","cod":"0","pbh":"0","pvc":"20000"}}}'),
(55, 0, 'INV-2015-00', 0, 'CosyCare', 'http://boxmes.webthongminh.info/', 1, 0, 'Tuấn', 'Anh', 'votuananh8127@gmail.com', '0983492410', '0983492410', 'b:0;', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Thu tiền khi giao hàng', 'cod', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Phí vận chuyển cố định', 'flat.flat', '', '1120000.0000', 2, 0, '0.0000', 0, '', 2, 2, 'VND', '1.00000000', '112.78.13.106', '', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36', 'en-US,en;q=0.8', '2017-04-14 15:00:14', '2017-04-14 16:59:07', 'SC51303153498', 'SUCCESS', '{"TrackingCode":"SC51303153498","StatusId":22,"StatusName":"Hủy đơn hàng","TimeStamp":1492163927}', '{"tracking_code":{"data":{"trackingcode":"SC51303153498","cod":"0","pbh":"0","pvc":"15000"}}}'),
(51, 0, 'INV-2015-00', 0, 'CosyCare', 'http://boxmes.webthongminh.info/', 1, 0, 'Tuấn', 'Anh', 'votuananh8127@gmail.com', '0983492410', '0983492410', 'b:0;', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Thu tiền khi giao hàng', 'cod', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Phí vận chuyển cố định', 'flat.flat', '', '1120000.0000', 2, 0, '0.0000', 0, '', 2, 2, 'VND', '1.00000000', '112.78.13.106', '', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36', 'en-US,en;q=0.8', '2017-04-14 14:17:13', '2017-04-14 15:13:52', 'SC51989467486', 'SUCCESS', '{"TrackingCode":"SC51989467486","StatusId":22,"StatusName":"Hủy đơn hàng","TimeStamp":1492157612}', '{"tracking_code":{"data":{"trackingcode":"SC51989467486","cod":"11200","pbh":"0","pvc":"20000"}}}'),
(49, 0, 'INV-2015-00', 0, 'CosyCare', 'http://boxmes.webthongminh.info/', 1, 0, 'Tuấn', 'Anh', 'votuananh8127@gmail.com', '0983492410', '0983492410', 'b:0;', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Thu tiền khi giao hàng', 'cod', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Phí vận chuyển cố định', 'flat.flat', '', '1120000.0000', 2, 0, '0.0000', 0, '', 2, 2, 'VND', '1.00000000', '112.78.13.106', '', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36', 'en-US,en;q=0.8', '2017-04-14 13:40:57', '2017-04-14 15:14:56', 'SC51782364641', 'SUCCESS', '{"TrackingCode":"SC51782364641","StatusId":22,"StatusName":"Hủy đơn hàng","TimeStamp":1492157675}', '{"tracking_code":{"data":{"trackingcode":"SC5547328109","cod":"0","pbh":"0","pvc":"15000"}}}'),
(52, 0, 'INV-2015-00', 0, 'CosyCare', 'http://boxmes.webthongminh.info/', 1, 0, 'Tuấn', 'Anh', 'votuananh8127@gmail.com', '0983492410', '0983492410', 'b:0;', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Thu tiền khi giao hàng', 'cod', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Phí vận chuyển cố định', 'flat.flat', '', '1120000.0000', 2, 0, '0.0000', 0, '', 2, 2, 'VND', '1.00000000', '112.78.13.106', '', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36', 'en-US,en;q=0.8', '2017-04-14 14:24:05', '2017-04-14 15:22:37', 'SC5552696251', 'SUCCESS', '{"TrackingCode":"SC5552696251","StatusId":22,"StatusName":"Hủy đơn hàng","TimeStamp":1492158136}', '{"tracking_code":{"data":{"trackingcode":"SC5552696251","cod":"16800","pbh":"0","pvc":"28000"}}}'),
(56, 0, 'INV-2015-00', 0, 'CosyCare', 'http://localhost/app/boxme/', 0, 0, 'Võ Tuấn Anh', 'Tuấn', 'votuananh8127@gmail.com', '0983492410', '', 'a:0:{}', 'Võ Tuấn Anh', 'Tuấn', '', 'Hoàng Diệu 2 - Thủ Đức', '', 'Hồ Chí Minh', '', 'Việt Nam', 230, 'Hồ Chí Minh', 3780, '', 'a:0:{}', 'Thu tiền khi giao hàng', 'cod', 'Võ Tuấn Anh', 'Tuấn', '', 'Hoàng Diệu 2 - Thủ Đức', '', 'Hồ Chí Minh', '', 'Việt Nam', 230, 'Hồ Chí Minh', 3780, '', 'a:0:{}', 'Phí vận chuyển cố định', 'flat.flat', '', '1120000.0000', 2, 0, '0.0000', 0, '', 2, 2, 'VND', '1.00000000', '::1', '', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36', 'en-US,en;q=0.8', '2017-04-20 09:50:04', '2017-04-20 09:50:04', 'SC5226038868', 'SUCCESS', '', '{"tracking_code":{"data":{"trackingcode":"SC5226038868","cod":"0","pbh":"0","pvc":"20000"}}}'),
(57, 0, 'INV-2015-00', 0, 'CosyCare', 'http://localhost/app/boxme/', 1, 0, 'Tuấn', 'Anh', 'votuananh8127@gmail.com', '0983492410', '0983492410', 'b:0;', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Thu tiền khi giao hàng', 'cod', 'Tuấn', 'Anh', 'Mắt Bão', 'TD7 - Tân Lập - Ninh Sim - Ninh Hòa - Khánh Hòa', '', 'Ninh Hòa', '70000', 'Việt Nam', 230, 'Khánh Hòa', 4231, '', 'a:0:{}', 'Phí vận chuyển cố định', 'flat.flat', '', '1120000.0000', 2, 0, '0.0000', 0, '', 2, 2, 'VND', '1.00000000', '::1', '', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36', 'en-US,en;q=0.8', '2017-04-20 11:09:22', '2017-04-20 11:09:23', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_custom_field`
--

CREATE TABLE `oc_order_custom_field` (
  `order_custom_field_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `custom_field_value_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `type` varchar(32) NOT NULL,
  `location` varchar(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_history`
--

CREATE TABLE `oc_order_history` (
  `order_history_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_status_id` int(11) NOT NULL,
  `notify` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_order_history`
--

INSERT INTO `oc_order_history` (`order_history_id`, `order_id`, `order_status_id`, `notify`, `comment`, `date_added`) VALUES
(1, 3, 2, 0, '', '2017-03-13 13:54:07'),
(2, 3, 2, 0, '', '2017-03-13 14:22:01'),
(94, 55, 2, 0, '', '2017-04-14 15:00:15'),
(75, 44, 2, 0, '', '2017-04-14 10:12:11'),
(93, 54, 2, 0, '', '2017-04-14 14:43:04'),
(92, 53, 2, 0, '', '2017-04-14 14:38:13'),
(91, 52, 2, 0, '', '2017-04-14 14:24:05'),
(80, 49, 2, 0, '', '2017-04-14 13:40:57'),
(81, 50, 2, 0, '', '2017-04-14 13:41:11'),
(90, 51, 2, 0, '', '2017-04-14 14:17:13'),
(95, 56, 2, 0, '', '2017-04-20 09:50:04'),
(96, 57, 2, 0, '', '2017-04-20 11:09:23');

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_option`
--

CREATE TABLE `oc_order_option` (
  `order_option_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_product_id` int(11) NOT NULL,
  `product_option_id` int(11) NOT NULL,
  `product_option_value_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `type` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_order_option`
--

INSERT INTO `oc_order_option` (`order_option_id`, `order_id`, `order_product_id`, `product_option_id`, `product_option_value_id`, `name`, `value`, `type`) VALUES
(1, 1, 1, 333, 332, 'Trọng lượng', '250g', 'select');

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_product`
--

CREATE TABLE `oc_order_product` (
  `order_product_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `model` varchar(64) NOT NULL,
  `quantity` int(4) NOT NULL,
  `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `total` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `tax` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `reward` int(8) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_order_product`
--

INSERT INTO `oc_order_product` (`order_product_id`, `order_id`, `product_id`, `name`, `model`, `quantity`, `price`, `total`, `tax`, `reward`) VALUES
(1, 1, 120, 'Bổ khớp S50', 'Bổ khớp S50', 1, '750000.0000', '750000.0000', '0.0000', 0),
(2, 2, 256, 'CHILI', '345435', 1, '34543543.0000', '34543543.0000', '0.0000', 0),
(22, 3, 279, 'Sản phẩm test 4', 'GBN', 1, '12000.0000', '12000.0000', '0.0000', 0),
(167, 7, 279, 'Sản phẩm test 4', 'GBN', 1, '12000.0000', '12000.0000', '0.0000', 0),
(677, 36, 367, 'Máy cung cấp thực phẩm', 'MCCTP01', 10, '110000.0000', '1100000.0000', '0.0000', 0),
(740, 44, 367, 'Máy cung cấp thực phẩm', 'MCCTP01', 10, '110000.0000', '1100000.0000', '0.0000', 0),
(812, 55, 367, 'Máy cung cấp thực phẩm', 'MCCTP01', 10, '110000.0000', '1100000.0000', '0.0000', 0),
(806, 54, 367, 'Máy cung cấp thực phẩm', 'MCCTP01', 10, '110000.0000', '1100000.0000', '0.0000', 0),
(800, 53, 367, 'Máy cung cấp thực phẩm', 'MCCTP01', 10, '110000.0000', '1100000.0000', '0.0000', 0),
(794, 52, 367, 'Máy cung cấp thực phẩm', 'MCCTP01', 10, '110000.0000', '1100000.0000', '0.0000', 0),
(788, 51, 367, 'Máy cung cấp thực phẩm', 'MCCTP01', 10, '110000.0000', '1100000.0000', '0.0000', 0),
(776, 49, 367, 'Máy cung cấp thực phẩm', 'MCCTP01', 10, '110000.0000', '1100000.0000', '0.0000', 0),
(782, 50, 367, 'Máy cung cấp thực phẩm', 'MCCTP01', 10, '110000.0000', '1100000.0000', '0.0000', 0),
(834, 56, 367, 'Máy cung cấp thực phẩm', 'MCCTP01', 10, '110000.0000', '1100000.0000', '0.0000', 0),
(842, 57, 367, 'Máy cung cấp thực phẩm', 'MCCTP01', 10, '110000.0000', '1100000.0000', '0.0000', 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_recurring`
--

CREATE TABLE `oc_order_recurring` (
  `order_recurring_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `recurring_id` int(11) NOT NULL,
  `recurring_name` varchar(255) NOT NULL,
  `recurring_description` varchar(255) NOT NULL,
  `recurring_frequency` varchar(25) NOT NULL,
  `recurring_cycle` smallint(6) NOT NULL,
  `recurring_duration` smallint(6) NOT NULL,
  `recurring_price` decimal(10,4) NOT NULL,
  `trial` tinyint(1) NOT NULL,
  `trial_frequency` varchar(25) NOT NULL,
  `trial_cycle` smallint(6) NOT NULL,
  `trial_duration` smallint(6) NOT NULL,
  `trial_price` decimal(10,4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_recurring_transaction`
--

CREATE TABLE `oc_order_recurring_transaction` (
  `order_recurring_transaction_id` int(11) NOT NULL,
  `order_recurring_id` int(11) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `amount` decimal(10,4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_status`
--

CREATE TABLE `oc_order_status` (
  `order_status_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `statusboxme` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_order_status`
--

INSERT INTO `oc_order_status` (`order_status_id`, `language_id`, `name`, `statusboxme`) VALUES
(3, 2, 'Đang vận chuyển', '9'),
(5, 2, 'Chờ duyệt', '12'),
(7, 2, 'Đang lấy hàng', '14'),
(6, 2, 'Đã duyệt', '13'),
(19, 2, 'Đã lấy hàng', '16'),
(11, 2, 'Phát hàng không thành công', '18'),
(13, 2, 'Chờ XN chuyển hoàn', '20'),
(12, 2, 'Đã phát hàng thành công', '19'),
(14, 2, 'Chuyển hoàn', '21'),
(15, 2, 'Đã hủy', '22'),
(10, 2, 'Đang phát hàng', '17'),
(8, 2, 'Lấy không thành công', '15'),
(4, 2, 'Hoàn thành', '10'),
(2, 2, 'Đang xử lý', '8'),
(1, 2, 'Mới tiếp nhận', '7');

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_total`
--

CREATE TABLE `oc_order_total` (
  `order_total_id` int(10) NOT NULL,
  `order_id` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `title` varchar(255) NOT NULL,
  `value` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_order_total`
--

INSERT INTO `oc_order_total` (`order_total_id`, `order_id`, `code`, `title`, `value`, `sort_order`) VALUES
(1, 1, 'sub_total', 'Thành tiền', '750000.0000', 1),
(2, 1, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(3, 1, 'total', 'Tổng cộng ', '770000.0000', 9),
(4, 2, 'sub_total', 'Thành tiền', '34543543.0000', 1),
(5, 2, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(6, 2, 'total', 'Tổng cộng ', '34563543.0000', 9),
(84, 3, 'total', 'Tổng cộng ', '32000.0000', 9),
(83, 3, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(82, 3, 'reward', 'Điểm thưởng():', '0.0000', 2),
(81, 3, 'sub_total', 'Thành tiền', '12000.0000', 1),
(322, 7, 'sub_total', 'Thành tiền', '12000.0000', 1),
(323, 7, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(324, 7, 'total', 'Tổng cộng ', '32000.0000', 9),
(1769, 36, 'total', 'Tổng cộng ', '1120000.0000', 9),
(1768, 36, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(1767, 36, 'sub_total', 'Thành tiền', '1100000.0000', 1),
(2240, 55, 'total', 'Tổng cộng ', '1120000.0000', 9),
(2239, 55, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(2238, 55, 'reward', 'Điểm thưởng():', '0.0000', 2),
(2237, 55, 'sub_total', 'Thành tiền', '1100000.0000', 1),
(1998, 44, 'total', 'Tổng cộng ', '1120000.0000', 9),
(1997, 44, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(1996, 44, 'reward', 'Điểm thưởng():', '0.0000', 2),
(1995, 44, 'sub_total', 'Thành tiền', '1100000.0000', 1),
(2217, 54, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(2218, 54, 'total', 'Tổng cộng ', '1120000.0000', 9),
(2216, 54, 'reward', 'Điểm thưởng():', '0.0000', 2),
(2215, 54, 'sub_total', 'Thành tiền', '1100000.0000', 1),
(2196, 53, 'total', 'Tổng cộng ', '1120000.0000', 9),
(2195, 53, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(2194, 53, 'reward', 'Điểm thưởng():', '0.0000', 2),
(2193, 53, 'sub_total', 'Thành tiền', '1100000.0000', 1),
(2174, 52, 'total', 'Tổng cộng ', '1120000.0000', 9),
(2173, 52, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(2172, 52, 'reward', 'Điểm thưởng():', '0.0000', 2),
(2171, 52, 'sub_total', 'Thành tiền', '1100000.0000', 1),
(2152, 51, 'total', 'Tổng cộng ', '1120000.0000', 9),
(2151, 51, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(2150, 51, 'reward', 'Điểm thưởng():', '0.0000', 2),
(2149, 51, 'sub_total', 'Thành tiền', '1100000.0000', 1),
(2107, 49, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(2105, 49, 'sub_total', 'Thành tiền', '1100000.0000', 1),
(2106, 49, 'reward', 'Điểm thưởng():', '0.0000', 2),
(2108, 49, 'total', 'Tổng cộng ', '1120000.0000', 9),
(2129, 50, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(2127, 50, 'sub_total', 'Thành tiền', '1100000.0000', 1),
(2128, 50, 'reward', 'Điểm thưởng():', '0.0000', 2),
(2130, 50, 'total', 'Tổng cộng ', '1120000.0000', 9),
(2326, 56, 'total', 'Tổng cộng ', '1120000.0000', 9),
(2325, 56, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(2324, 56, 'reward', 'Điểm thưởng():', '0.0000', 2),
(2323, 56, 'sub_total', 'Thành tiền', '1100000.0000', 1),
(2350, 57, 'sub_total', 'Thành tiền', '1100000.0000', 1),
(2351, 57, 'reward', 'Điểm thưởng():', '0.0000', 2),
(2352, 57, 'shipping', 'Phí vận chuyển cố định', '20000.0000', 3),
(2353, 57, 'total', 'Tổng cộng ', '1120000.0000', 9);

-- --------------------------------------------------------

--
-- Table structure for table `oc_order_voucher`
--

CREATE TABLE `oc_order_voucher` (
  `order_voucher_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `voucher_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `code` varchar(10) NOT NULL,
  `from_name` varchar(64) NOT NULL,
  `from_email` varchar(96) NOT NULL,
  `to_name` varchar(64) NOT NULL,
  `to_email` varchar(96) NOT NULL,
  `voucher_theme_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `amount` decimal(15,4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product`
--

CREATE TABLE `oc_product` (
  `product_id` int(11) NOT NULL,
  `model` varchar(64) NOT NULL,
  `sku` varchar(64) NOT NULL,
  `upc` varchar(12) NOT NULL,
  `ean` varchar(14) NOT NULL,
  `jan` varchar(13) NOT NULL,
  `isbn` varchar(17) NOT NULL,
  `mpn` varchar(64) NOT NULL,
  `location` varchar(128) NOT NULL,
  `quantity` int(4) NOT NULL DEFAULT '0',
  `stock_status_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `manufacturer_id` int(11) NOT NULL,
  `shipping` tinyint(1) NOT NULL DEFAULT '1',
  `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `points` int(8) NOT NULL DEFAULT '0',
  `tax_class_id` int(11) NOT NULL,
  `date_available` date NOT NULL DEFAULT '0000-00-00',
  `weight` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `weight_class_id` int(11) NOT NULL DEFAULT '0',
  `length` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `width` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `height` decimal(15,8) NOT NULL DEFAULT '0.00000000',
  `length_class_id` int(11) NOT NULL DEFAULT '0',
  `subtract` tinyint(1) NOT NULL DEFAULT '1',
  `minimum` int(11) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `viewed` int(5) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `productid_boxme` int(11) NOT NULL,
  `status_boxme` int(11) NOT NULL,
  `shipment_codeboxme` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product`
--

INSERT INTO `oc_product` (`product_id`, `model`, `sku`, `upc`, `ean`, `jan`, `isbn`, `mpn`, `location`, `quantity`, `stock_status_id`, `image`, `manufacturer_id`, `shipping`, `price`, `points`, `tax_class_id`, `date_available`, `weight`, `weight_class_id`, `length`, `width`, `height`, `length_class_id`, `subtract`, `minimum`, `sort_order`, `status`, `viewed`, `date_added`, `date_modified`, `productid_boxme`, `status_boxme`, `shipment_codeboxme`) VALUES
(369, 'ST01', 'ST01', '', '', '', '', '', '151576', 10, 6, 'catalog/san_pham/sp1.jpg', 8, 1, '150.0000', 0, 0, '2017-04-08', '10.00000000', 1, '16.00000000', '15.00000000', '15.00000000', 1, 1, 1, 1, 1, 2, '2017-04-08 09:53:01', '2017-04-10 11:21:09', 89639, 1, 'BX126222DD59'),
(368, 'TPCCDD01', 'TPCCDD01', '', '', '', '', '', '151576', 10, 6, 'catalog/san_pham/sp10.jpg', 8, 1, '120000.0000', 0, 0, '2017-04-08', '10.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 1, 1, 1, 1, 1, '2017-04-08 09:50:06', '2017-04-10 11:39:08', 89638, 1, 'BX293184DD59'),
(367, 'MCCTP01', 'MCCTP01', '', '', '', '', '', '151576', -108, 6, 'catalog/san_pham/sp14.jpg', 0, 1, '130.0000', 0, 0, '2017-04-08', '12.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 1, 10, 1, 1, 1, '2017-04-08 09:20:14', '2017-04-10 11:20:21', 89647, 1, 'BX268478DD59'),
(365, 'GGGGGGHHH', 'GGGGGGHHH', '', '', '', '', '', '151576', 11, 6, 'catalog/san_pham/sp10.jpg', 0, 1, '460.0000', 0, 0, '2017-04-05', '12.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 1, 1, 1, 1, 4, '2017-04-05 16:38:46', '2017-04-10 11:20:04', 89646, 1, 'BX213368DD59'),
(358, 'TBT012', 'TBT012', '', '', '', '', '', '151576', 12, 6, 'catalog/san_pham/sp4.jpg', 8, 1, '180.0000', 0, 0, '2017-04-05', '2.00000000', 1, '12.00000000', '13.00000000', '14.00000000', 1, 1, 1, 1, 1, 2, '2017-04-05 10:58:56', '2017-04-10 11:20:34', 89650, 0, 'BX168582DD59'),
(364, 'TTDB01', 'TTDB01', '', '', '', '', '', '151576', 10, 6, 'catalog/chili_user.jpg', 0, 1, '180.0000', 0, 0, '2017-04-05', '10.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 1, 1, 1, 1, 0, '2017-04-05 16:08:26', '2017-04-20 17:14:24', 89649, 1, 'BX150929DD59'),
(366, 'TPCNCL01', 'TPCNCL01', 'TPCNCL01', '', '', '', '', '151576', 13, 6, 'catalog/san_pham/sp11.jpg', 8, 1, '160.0000', 0, 0, '2017-04-08', '12.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 1, 1, 1, 1, 2, '2017-04-08 09:02:32', '2017-04-10 11:20:28', 89648, 1, 'BX147117DD59'),
(363, 'ABCDS', 'ABCDS', '', '', '', '', '', '152714', 10, 6, 'catalog/san_pham/sp10.jpg', 0, 1, '500.0000', 0, 0, '2017-04-05', '23423.00000000', 1, '10.00000000', '25.00000000', '17.00000000', 1, 1, 1, 1, 1, 0, '2017-04-05 15:51:56', '2017-04-20 17:20:11', 89629, 1, 'BX250327DD59'),
(370, 'SPKHBM01', 'SPKHBM01', '', '', '', '', '', '152714', 10, 6, 'catalog/san_pham/sp10.jpg', 0, 1, '230.0000', 0, 0, '2017-04-05', '10.00000000', 1, '12.00000000', '13.00000000', '14.00000000', 1, 1, 1, 1, 1, 1, '2017-04-10 02:08:10', '2017-04-10 11:33:06', 89651, 1, 'BX108561DD59'),
(371, 'PM11', 'PM11', '', '', '', '', '', '151576', 10, 6, 'catalog/san_pham/sp10.jpg', 0, 1, '460.0000', 0, 0, '2017-04-05', '12.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 1, 1, 1, 1, 0, '2017-04-10 13:41:16', '2017-04-10 13:49:19', 0, 1, 'BX332875DD59'),
(372, 'ABCDS', '', '', '', '', '', '', '152714', 10, 6, 'catalog/san_pham/sp10.jpg', 0, 1, '500.0000', 0, 0, '2017-04-05', '23423.00000000', 1, '10.00000000', '25.00000000', '17.00000000', 1, 1, 1, 1, 0, 0, '2017-04-20 08:54:46', '2017-04-20 17:19:49', 0, 1, ''),
(373, 'Demo', 'Demo', '', '', '', '', '', '151576', 1, 6, 'catalog/chili_user.jpg', 8, 1, '567777.0000', 0, 0, '2017-04-20', '0.00000000', 1, '0.00000000', '0.00000000', '0.00000000', 1, 1, 1, 1, 1, 0, '2017-04-20 17:27:38', '0000-00-00 00:00:00', 89724, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_attribute`
--

CREATE TABLE `oc_product_attribute` (
  `product_id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_description`
--

CREATE TABLE `oc_product_description` (
  `product_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `tag` text NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_description`
--

INSERT INTO `oc_product_description` (`product_id`, `language_id`, `name`, `description`, `tag`, `meta_title`, `meta_description`, `meta_keyword`) VALUES
(369, 2, 'Nước rửa tay trẻ em SH', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Sữa tươi', 'Sữa tươi', 'Sữa tươi', 'Sữa tươi'),
(358, 2, 'Máy kiểm tra hơi thở', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Túi bảo vệ vết thương', 'Túi bảo vệ vết thương', 'Túi bảo vệ vết thương', 'Túi bảo vệ vết thương'),
(366, 2, 'Thực phẩm chức năng chất lượng 01', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Thực phẩm chức năng chất lượng', 'Thực phẩm chức năng chất lượng', 'Thực phẩm chức năng chất lượng', 'Thực phẩm chức năng chất lượng'),
(0, 2, 'Soài Miền Tây 6', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', '', 'Soài Miền Tây 6', '', ''),
(367, 2, 'Máy cung cấp thực phẩm', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Máy cung cấp thực phẩm', 'Máy cung cấp thực phẩm', 'Máy cung cấp thực phẩm', 'Máy cung cấp thực phẩm'),
(368, 2, 'Thực phẩm cung cấp dinh dưỡng', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Thực phẩm cung cấp dinh dưỡng', 'Thực phẩm cung cấp dinh dưỡng', 'Thực phẩm cung cấp dinh dưỡng', 'Thực phẩm cung cấp dinh dưỡng'),
(370, 2, 'Sản phẩm kho hàng Boxme', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Sản phẩm kho hàng Boxme', 'Sản phẩm kho hàng Boxme', 'Sản phẩm kho hàng Boxme', 'Sản phẩm kho hàng Boxme'),
(365, 2, 'Kính áp tròng PM11', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'GGGGGGHHH', 'GGGGGGHHH', 'GGGGGGHHH', 'GGGGGGHHH'),
(371, 2, 'Kính áp tròng PM11', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'GGGGGGHHH', 'GGGGGGHHH', 'GGGGGGHHH', 'GGGGGGHHH'),
(363, 2, 'Bổ khớp S50 dfsdf', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'ABCDS', 'ABCDS', 'ABCDS', 'ABCDS'),
(373, 2, 'Demo', '&lt;p&gt;Demo&lt;/p&gt;', 'Demo', 'Demo', 'Demo', 'Demo'),
(372, 2, 'Bổ khớp S50 01', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'ABCDS', 'ABCDS', 'ABCDS', 'ABCDS'),
(364, 2, 'Túi bảo vệ vết thương', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 'Trái tim đóng băng', 'Trái tim đóng băng', 'Trái tim đóng băng', 'Trái tim đóng băng');

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_discount`
--

CREATE TABLE `oc_product_discount` (
  `product_discount_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  `quantity` int(4) NOT NULL DEFAULT '0',
  `priority` int(5) NOT NULL DEFAULT '1',
  `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `date_start` date NOT NULL DEFAULT '0000-00-00',
  `date_end` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_filter`
--

CREATE TABLE `oc_product_filter` (
  `product_id` int(11) NOT NULL,
  `filter_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_image`
--

CREATE TABLE `oc_product_image` (
  `product_image_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_option`
--

CREATE TABLE `oc_product_option` (
  `product_option_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `required` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_option_value`
--

CREATE TABLE `oc_product_option_value` (
  `product_option_value_id` int(11) NOT NULL,
  `product_option_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `option_value_id` int(11) NOT NULL,
  `quantity` int(3) NOT NULL,
  `subtract` tinyint(1) NOT NULL,
  `price` decimal(15,4) NOT NULL,
  `price_prefix` varchar(1) NOT NULL,
  `points` int(8) NOT NULL,
  `points_prefix` varchar(1) NOT NULL,
  `weight` decimal(15,8) NOT NULL,
  `weight_prefix` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_parent`
--

CREATE TABLE `oc_product_parent` (
  `relative_ID` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `oc_product_parent`
--

INSERT INTO `oc_product_parent` (`relative_ID`, `price`, `status`) VALUES
(1, 0, 1),
(2, 0, 1),
(3, 0, 1),
(4, 0, 1),
(5, 0, 1),
(6, 0, 1),
(7, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_recurring`
--

CREATE TABLE `oc_product_recurring` (
  `product_id` int(11) NOT NULL,
  `recurring_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_related`
--

CREATE TABLE `oc_product_related` (
  `product_id` int(11) NOT NULL,
  `related_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_relative`
--

CREATE TABLE `oc_product_relative` (
  `product_parent_ID` int(11) NOT NULL,
  `parent_ID` int(11) NOT NULL,
  `product_ID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `oc_product_relative`
--

INSERT INTO `oc_product_relative` (`product_parent_ID`, `parent_ID`, `product_ID`) VALUES
(1, 1, 142),
(2, 1, 143),
(3, 2, 144),
(4, 2, 145),
(5, 3, 259),
(6, 4, 260),
(7, 4, 261),
(8, 4, 262),
(9, 4, 263),
(10, 4, 264),
(11, 4, 265),
(12, 5, 266),
(13, 5, 267),
(14, 5, 268),
(15, 5, 269),
(16, 5, 270),
(17, 5, 271),
(18, 6, 272),
(19, 6, 273),
(20, 6, 274),
(21, 6, 275),
(22, 6, 276),
(23, 6, 277),
(24, 7, 278);

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_reward`
--

CREATE TABLE `oc_product_reward` (
  `product_reward_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL DEFAULT '0',
  `customer_group_id` int(11) NOT NULL DEFAULT '0',
  `points` int(8) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_special`
--

CREATE TABLE `oc_product_special` (
  `product_special_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  `priority` int(5) NOT NULL DEFAULT '1',
  `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `date_start` date NOT NULL DEFAULT '0000-00-00',
  `date_end` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_special`
--

INSERT INTO `oc_product_special` (`product_special_id`, `product_id`, `customer_group_id`, `priority`, `price`, `date_start`, `date_end`) VALUES
(516, 367, 0, 0, '110000.0000', '0000-00-00', '0000-00-00'),
(517, 368, 0, 0, '110000.0000', '0000-00-00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_to_category`
--

CREATE TABLE `oc_product_to_category` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_to_category`
--

INSERT INTO `oc_product_to_category` (`product_id`, `category_id`) VALUES
(358, 83),
(366, 83),
(367, 85),
(368, 85),
(369, 83),
(373, 83);

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_to_download`
--

CREATE TABLE `oc_product_to_download` (
  `product_id` int(11) NOT NULL,
  `download_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_to_layout`
--

CREATE TABLE `oc_product_to_layout` (
  `product_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_to_layout`
--

INSERT INTO `oc_product_to_layout` (`product_id`, `store_id`, `layout_id`) VALUES
(365, 0, 0),
(368, 0, 0),
(369, 0, 0),
(367, 0, 0),
(0, 0, 0),
(366, 0, 0),
(363, 0, 0),
(358, 0, 0),
(364, 0, 0),
(370, 0, 0),
(371, 0, 0),
(372, 0, 0),
(373, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_product_to_store`
--

CREATE TABLE `oc_product_to_store` (
  `product_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_product_to_store`
--

INSERT INTO `oc_product_to_store` (`product_id`, `store_id`) VALUES
(0, 0),
(358, 0),
(363, 0),
(364, 0),
(365, 0),
(366, 0),
(367, 0),
(368, 0),
(369, 0),
(370, 0),
(371, 0),
(372, 0),
(373, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_realex_order`
--

CREATE TABLE `oc_realex_order` (
  `realex_order_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_ref` char(50) NOT NULL,
  `order_ref_previous` char(50) NOT NULL,
  `pasref` varchar(50) NOT NULL,
  `pasref_previous` varchar(50) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `capture_status` int(1) DEFAULT NULL,
  `void_status` int(1) DEFAULT NULL,
  `settle_type` int(1) DEFAULT NULL,
  `rebate_status` int(1) DEFAULT NULL,
  `currency_code` char(3) NOT NULL,
  `authcode` varchar(30) NOT NULL,
  `account` varchar(30) NOT NULL,
  `total` decimal(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_realex_order_transaction`
--

CREATE TABLE `oc_realex_order_transaction` (
  `realex_order_transaction_id` int(11) NOT NULL,
  `realex_order_id` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `type` enum('auth','payment','rebate','void') DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_recurring`
--

CREATE TABLE `oc_recurring` (
  `recurring_id` int(11) NOT NULL,
  `price` decimal(10,4) NOT NULL,
  `frequency` enum('day','week','semi_month','month','year') NOT NULL,
  `duration` int(10) UNSIGNED NOT NULL,
  `cycle` int(10) UNSIGNED NOT NULL,
  `trial_status` tinyint(4) NOT NULL,
  `trial_price` decimal(10,4) NOT NULL,
  `trial_frequency` enum('day','week','semi_month','month','year') NOT NULL,
  `trial_duration` int(10) UNSIGNED NOT NULL,
  `trial_cycle` int(10) UNSIGNED NOT NULL,
  `status` tinyint(4) NOT NULL,
  `sort_order` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_recurring`
--

INSERT INTO `oc_recurring` (`recurring_id`, `price`, `frequency`, `duration`, `cycle`, `trial_status`, `trial_price`, `trial_frequency`, `trial_duration`, `trial_cycle`, `status`, `sort_order`) VALUES
(1, '300000.0000', 'week', 0, 1, 1, '300000.0000', 'week', 0, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_recurring_description`
--

CREATE TABLE `oc_recurring_description` (
  `recurring_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_recurring_description`
--

INSERT INTO `oc_recurring_description` (`recurring_id`, `language_id`, `name`) VALUES
(1, 2, 'Thanh toán định kỳ');

-- --------------------------------------------------------

--
-- Table structure for table `oc_return`
--

CREATE TABLE `oc_return` (
  `return_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(96) NOT NULL,
  `telephone` varchar(32) NOT NULL,
  `product` varchar(255) NOT NULL,
  `model` varchar(64) NOT NULL,
  `quantity` int(4) NOT NULL,
  `opened` tinyint(1) NOT NULL,
  `return_reason_id` int(11) NOT NULL,
  `return_action_id` int(11) NOT NULL,
  `return_status_id` int(11) NOT NULL,
  `comment` text,
  `date_ordered` date NOT NULL DEFAULT '0000-00-00',
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_return_action`
--

CREATE TABLE `oc_return_action` (
  `return_action_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_return_history`
--

CREATE TABLE `oc_return_history` (
  `return_history_id` int(11) NOT NULL,
  `return_id` int(11) NOT NULL,
  `return_status_id` int(11) NOT NULL,
  `notify` tinyint(1) NOT NULL,
  `comment` text NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_return_reason`
--

CREATE TABLE `oc_return_reason` (
  `return_reason_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_return_status`
--

CREATE TABLE `oc_return_status` (
  `return_status_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_review`
--

CREATE TABLE `oc_review` (
  `review_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `author` varchar(64) NOT NULL,
  `text` text NOT NULL,
  `rating` int(1) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_revslider_attachment_images`
--

CREATE TABLE `oc_revslider_attachment_images` (
  `ID` int(10) NOT NULL,
  `file_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_revslider_attachment_images`
--

INSERT INTO `oc_revslider_attachment_images` (`ID`, `file_name`) VALUES
(1, '6599843_slide1.PNG'),
(2, '6170605_slide_2.PNG'),
(3, '8537924_slide_3.PNG');

-- --------------------------------------------------------

--
-- Table structure for table `oc_revslider_css`
--

CREATE TABLE `oc_revslider_css` (
  `id` int(9) NOT NULL,
  `handle` text NOT NULL,
  `settings` text,
  `hover` text,
  `params` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_revslider_css`
--

INSERT INTO `oc_revslider_css` (`id`, `handle`, `settings`, `hover`, `params`) VALUES
(1, '.tp-caption.lightgrey_divider', NULL, NULL, '{"text-decoration":"none","background-color":"rgba(235, 235, 235, 1)","width":"370px","height":"3px","background-position":"initial initial","background-repeat":"initial initial","border-width":"0px","border-color":"rgb(34, 34, 34)","border-style":"none"}'),
(2, '.tp-caption.large_bold_grey', NULL, NULL, '{"font-size":"60px","line-height":"60px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(102, 102, 102)","text-decoration":"none","background-color":"transparent","text-shadow":"none","margin":"0px","padding":"1px 4px 0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(3, '.tp-caption.medium_thin_grey', NULL, NULL, '{"font-size":"34px","line-height":"30px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(102, 102, 102)","text-decoration":"none","background-color":"transparent","padding":"1px 4px 0px","text-shadow":"none","margin":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(4, '.tp-caption.small_thin_grey', NULL, NULL, '{"font-size":"18px","line-height":"26px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(117, 117, 117)","text-decoration":"none","background-color":"transparent","padding":"1px 4px 0px","text-shadow":"none","margin":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(5, '.tp-caption.large_bold_darkblue', NULL, NULL, '{"font-size":"58px","line-height":"60px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(52, 73, 94)","text-decoration":"none","background-color":"transparent","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(6, '.tp-caption.medium_bg_darkblue', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(52, 73, 94)","padding":"10px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(7, '.tp-caption.medium_bold_red', NULL, NULL, '{"font-size":"24px","line-height":"30px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(227, 58, 12)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(8, '.tp-caption.medium_light_red', NULL, NULL, '{"font-size":"21px","line-height":"26px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(227, 58, 12)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(9, '.tp-caption.medium_bg_red', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(227, 58, 12)","padding":"10px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(10, '.tp-caption.medium_bold_orange', NULL, NULL, '{"font-size":"24px","line-height":"30px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(243, 156, 18)","text-decoration":"none","background-color":"transparent","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(11, '.tp-caption.medium_bg_orange', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(243, 156, 18)","padding":"10px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(12, '.tp-caption.medium_bg_asbestos', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(127, 140, 141)","padding":"10px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(13, '.tp-caption.large_bold_white', NULL, NULL, '{"font-size":"58px","line-height":"60px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(14, '.tp-caption.medium_light_white', NULL, NULL, '{"font-size":"30px","line-height":"36px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(15, '.tp-caption.grassfloor', NULL, NULL, '{"text-decoration":"none","background-color":"rgba(160, 179, 151, 1)","width":"4000px","height":"150px","border-width":"0px","border-color":"rgb(34, 34, 34)","border-style":"none"}'),
(16, '.tp-caption.mediumlarge_light_white', NULL, NULL, '{"font-size":"34px","line-height":"40px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(17, '.tp-caption.mediumlarge_light_white_center', NULL, NULL, '{"font-size":"34px","line-height":"40px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"#ffffff","text-decoration":"none","background-color":"transparent","padding":"0px 0px 0px 0px","text-align":"center","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(18, '.tp-caption.black_heavy_60', NULL, NULL, '{"font-size":"60px","line-height":"60px","font-weight":"900","font-family":"Raleway","color":"rgb(0, 0, 0)","text-decoration":"none","background-color":"transparent","text-shadow":"none","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(19, '.tp-caption.black_bold_bg_20', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"900","font-family":"Raleway","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(0, 0, 0)","padding":"5px 8px","text-shadow":"none","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(20, '.tp-caption.green_bold_bg_20', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"900","font-family":"Raleway","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(134, 181, 103)","padding":"5px 8px","text-shadow":"none","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(21, '.tp-caption.greenishbg_heavy_70', NULL, NULL, '{"font-size":"70px","line-height":"70px","font-weight":"900","font-family":"Raleway","color":"rgb(255, 255, 255)","text-decoration":"none","padding":"50px","text-shadow":"none","background-color":"rgba(40, 67, 62, 0.8)","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(22, '.tp-caption.borderbox_725x130', NULL, NULL, '{"min-width":"725px","min-height":"130px","background-color":"transparent","text-decoration":"none","border-width":"2px","border-color":"rgb(255, 255, 255)","border-style":"solid"}'),
(23, '.tp-caption.black_heavy_70', NULL, NULL, '{"font-size":"70px","line-height":"70px","font-weight":"900","font-family":"Raleway","color":"rgb(0, 0, 0)","text-decoration":"none","background-color":"transparent","text-shadow":"none","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(24, '.tp-caption.light_heavy_70', NULL, NULL, '{"font-size":"70px","line-height":"70px","font-weight":"900","font-family":"Raleway","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","text-shadow":"none","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(25, '.tp-caption.black_bold_40', NULL, NULL, '{"font-size":"40px","line-height":"40px","font-weight":"800","font-family":"Raleway","color":"rgb(0, 0, 0)","text-decoration":"none","background-color":"transparent","text-shadow":"none","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(26, '.tp-caption.white_bold_bg_20', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"900","font-family":"Raleway","color":"rgb(0, 0, 0)","text-decoration":"none","background-color":"rgb(255, 255, 255)","padding":"5px 8px","text-shadow":"none","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(27, '.tp-caption.red_bold_bg_20', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"900","font-family":"Raleway","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(224, 51, 0)","padding":"5px 8px","text-shadow":"none","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(28, '.tp-caption.blue_bold_bg_20', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"900","font-family":"Raleway","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(53, 152, 220)","padding":"5px 8px","text-shadow":"none","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(29, '.tp-caption.light_heavy_40', NULL, NULL, '{"font-size":"40px","line-height":"40px","font-weight":"900","font-family":"Raleway","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","text-shadow":"none","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(30, '.tp-caption.white_thin_34', NULL, NULL, '{"font-size":"35px","line-height":"35px","font-weight":"200","font-family":"Raleway","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","text-shadow":"none","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(31, '.tp-caption.light_heavy_70_shadowed', NULL, NULL, '{"font-size":"70px","line-height":"70px","font-weight":"900","font-family":"Raleway","color":"#ffffff","text-decoration":"none","background-color":"transparent","text-shadow":"0px 0px 7px rgba(0, 0, 0, 0.25)","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(32, '.tp-caption.light_medium_30_shadowed', NULL, NULL, '{"font-size":"30px","line-height":"40px","font-weight":"700","font-family":"Raleway","color":"#ffffff","text-decoration":"none","background-color":"transparent","text-shadow":"0px 0px 7px rgba(0, 0, 0, 0.25)","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}'),
(33, '.tp-caption.bignumbers_white', NULL, NULL, '{"color":"#ffffff","background-color":"rgba(0, 0, 0, 0)","font-size":"84px","line-height":"84px","font-weight":"800","font-family":"Raleway","text-decoration":"none","padding":"0px 0px 0px 0px","text-shadow":"rgba(0, 0, 0, 0.247059) 0px 0px 7px","border-width":"0px","border-color":"rgb(255, 255, 255)","border-style":"none solid none none"}'),
(34, '.tp-caption.bignumbers_whitefdf', NULL, NULL, '{"font-size":"92px","line-height":"61px","font-weight":"500","font-family":"Raleway","color":"rgb(43, 38, 38)","text-decoration":"none","padding":"0px","text-shadow":"rgba(0, 0, 0, 0.247059) 0px 0px 7px","background-color":"rgba(0, 0, 0, 0.00784314)","border-width":"0px","border-color":"rgb(255, 255, 255)","border-style":"none"}'),
(35, '.tp-caption.simplegreat_text', NULL, NULL, '{"font-size":"30px","line-height":"40px","font-weight":"normal","font-family":"\\"Open Sans\\"","color":"#ffffff","text-decoration":"none","background-color":"transparent","padding":"0px 0px 0px 0px","text-align":"center","text-transform":"uppercase","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}'),
(36, '.tp-caption.black', NULL, NULL, '{"color":"#000","text-shadow":"none"}');

-- --------------------------------------------------------

--
-- Table structure for table `oc_revslider_layer_animations`
--

CREATE TABLE `oc_revslider_layer_animations` (
  `id` int(9) NOT NULL,
  `handle` text NOT NULL,
  `params` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_revslider_settings`
--

CREATE TABLE `oc_revslider_settings` (
  `id` int(9) NOT NULL,
  `general` text NOT NULL,
  `params` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_revslider_sliders`
--

CREATE TABLE `oc_revslider_sliders` (
  `id` int(9) NOT NULL,
  `title` tinytext NOT NULL,
  `alias` tinytext,
  `params` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_revslider_sliders`
--

INSERT INTO `oc_revslider_sliders` (`id`, `title`, `alias`, `params`) VALUES
(1, 'slider homepage', 'slider homepage', '{"title":"slider homepage","alias":"slider homepage","source_type":"gallery","post_types":"product","post_category":"","post_sortby":"ID","prd_img_width":"880","prd_img_height":"345","posts_sort_direction":"DESC","max_slider_posts":"30","excerpt_limit":"55","slider_template_id":"","posts_list":"","slider_type":"fullwidth","fullscreen_offset_container":"","fullscreen_offset_size":"","fullscreen_min_height":"","full_screen_align_force":"off","auto_height":"off","force_full_width":"off","min_height":"","width":"750","height":"500","responsitive_w1":"940","responsitive_sw1":"770","responsitive_w2":"780","responsitive_sw2":"500","responsitive_w3":"510","responsitive_sw3":"310","responsitive_w4":"0","responsitive_sw4":"0","responsitive_w5":"0","responsitive_sw5":"0","responsitive_w6":"0","responsitive_sw6":"0","delay":"9000","shuffle":"off","lazy_load":"off","use_wpml":"off","enable_static_layers":"off","next_slide_on_window_focus":"off","simplify_ie8_ios4":"off","stop_slider":"off","stop_after_loops":0,"stop_at_slide":2,"show_timerbar":"top","loop_slide":"loop","position":"center","margin_top":0,"margin_bottom":0,"margin_left":0,"margin_right":0,"shadow_type":"0","padding":0,"background_color":"#E9E9E9","background_dotted_overlay":"none","show_background_image":"false","background_image":"http:\\/\\/\\/","bg_fit":"cover","bg_repeat":"no-repeat","bg_position":"center top","stop_on_hover":"on","keyboard_navigation":"off","navigation_style":"round","navigaion_type":"bullet","navigation_arrows":"solo","navigaion_always_on":"false","hide_thumbs":200,"navigaion_align_hor":"center","navigaion_align_vert":"bottom","navigaion_offset_hor":"0","navigaion_offset_vert":20,"leftarrow_align_hor":"left","leftarrow_align_vert":"center","leftarrow_offset_hor":20,"leftarrow_offset_vert":0,"rightarrow_align_hor":"right","rightarrow_align_vert":"center","rightarrow_offset_hor":20,"rightarrow_offset_vert":0,"thumb_width":100,"thumb_height":50,"thumb_amount":5,"use_spinner":"0","spinner_color":"#FFFFFF","use_parallax":"off","disable_parallax_mobile":"off","parallax_type":"mouse","parallax_bg_freeze":"off","parallax_level_1":"5","parallax_level_2":"10","parallax_level_3":"15","parallax_level_4":"20","parallax_level_5":"25","parallax_level_6":"30","parallax_level_7":"35","parallax_level_8":"40","parallax_level_9":"45","parallax_level_10":"50","touchenabled":"on","swipe_velocity":75,"swipe_min_touches":1,"drag_block_vertical":"false","disable_on_mobile":"off","disable_kenburns_on_mobile":"off","hide_slider_under":0,"hide_defined_layers_under":0,"hide_all_layers_under":0,"hide_arrows_on_mobile":"off","hide_bullets_on_mobile":"off","hide_thumbs_on_mobile":"off","hide_thumbs_under_resolution":0,"hide_thumbs_delay_mobile":1500,"start_with_slide":"1","first_transition_active":"false","first_transition_type":"fade","first_transition_duration":300,"first_transition_slot_amount":7,"reset_transitions":"","reset_transition_duration":0,"0":"Execute settings on all slides","jquery_noconflict":"off","js_to_body":"false","output_type":"none","custom_css":"","custom_javascript":"","template":"false"}');

-- --------------------------------------------------------

--
-- Table structure for table `oc_revslider_slides`
--

CREATE TABLE `oc_revslider_slides` (
  `id` int(9) NOT NULL,
  `slider_id` int(9) NOT NULL,
  `slide_order` int(11) NOT NULL,
  `params` text NOT NULL,
  `layers` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_revslider_slides`
--

INSERT INTO `oc_revslider_slides` (`id`, `slider_id`, `slide_order`, `params`, `layers`) VALUES
(11, 1, 2, '{"background_type":"image","image":"http:\\/\\/4028.chilishop.net\\/image\\/catalog\\/revslider_media_folder\\/Slider2.jpg","title":"Slide","state":"published","date_from":"","date_to":"","slide_transition":"random","0":"Remove","slot_amount":7,"transition_rotation":0,"transition_duration":300,"delay":"","save_performance":"off","enable_link":"true","link_type":"regular","link":"index.php?route=information\\/contact","link_open_in":"same","slide_link":"nothing","link_pos":"front","slide_thumb":"","class_attr":"","id_attr":"","attr_attr":"","data_attr":"","slide_bg_color":"#E7E7E7","slide_bg_external":"","bg_fit":"cover","bg_fit_x":"100","bg_fit_y":"100","bg_repeat":"no-repeat","bg_position":"center top","bg_position_x":"0","bg_position_y":"0","bg_end_position_x":"0","bg_end_position_y":"0","bg_end_position":"center top","kenburn_effect":"off","kb_start_fit":"100","kb_end_fit":"100","kb_duration":"9000","kb_easing":"Linear.easeNone","0":"Remove"}', '[]'),
(12, 1, 1, '{"background_type":"image","image":"http:\\/\\/4028.chilishop.net\\/image\\/catalog\\/revslider_media_folder\\/Slider1.jpg","title":"Slide","state":"published","date_from":"","date_to":"","slide_transition":"random","0":"Remove","slot_amount":7,"transition_rotation":0,"transition_duration":300,"delay":"","save_performance":"off","enable_link":"true","link_type":"regular","link":"dinh-duong-bar-z10","link_open_in":"same","slide_link":"nothing","link_pos":"front","slide_thumb":"","class_attr":"","id_attr":"","attr_attr":"","data_attr":"","slide_bg_color":"#E7E7E7","slide_bg_external":"","bg_fit":"cover","bg_fit_x":"100","bg_fit_y":"100","bg_repeat":"no-repeat","bg_position":"center top","bg_position_x":"0","bg_position_y":"0","bg_end_position_x":"0","bg_end_position_y":"0","bg_end_position":"center top","kenburn_effect":"off","kb_start_fit":"100","kb_end_fit":"100","kb_duration":"9000","kb_easing":"Linear.easeNone","0":"Remove"}', '[]'),
(13, 1, 3, '{"background_type":"image","image":"http:\\/\\/4028.chilishop.net\\/image\\/catalog\\/revslider_media_folder\\/Slider3.jpg","title":"Slide","state":"published","date_from":"","date_to":"","slide_transition":"random","0":"Remove","slot_amount":7,"transition_rotation":0,"transition_duration":300,"delay":"","save_performance":"off","enable_link":"true","link_type":"regular","link":"tui-bao-ve-vet-thuong","link_open_in":"same","slide_link":"nothing","link_pos":"front","slide_thumb":"","class_attr":"","id_attr":"","attr_attr":"","data_attr":"","slide_bg_color":"#E7E7E7","slide_bg_external":"","bg_fit":"cover","bg_fit_x":"100","bg_fit_y":"100","bg_repeat":"no-repeat","bg_position":"center top","bg_position_x":"0","bg_position_y":"0","bg_end_position_x":"0","bg_end_position_y":"0","bg_end_position":"center top","kenburn_effect":"off","kb_start_fit":"100","kb_end_fit":"100","kb_duration":"9000","kb_easing":"Linear.easeNone"}', '[]');

-- --------------------------------------------------------

--
-- Table structure for table `oc_revslider_static_slides`
--

CREATE TABLE `oc_revslider_static_slides` (
  `id` int(9) NOT NULL,
  `slider_id` int(9) NOT NULL,
  `params` text NOT NULL,
  `layers` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_setting`
--

CREATE TABLE `oc_setting` (
  `setting_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `code` varchar(32) NOT NULL,
  `key` varchar(64) NOT NULL,
  `value` text NOT NULL,
  `serialized` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_setting`
--

INSERT INTO `oc_setting` (`setting_id`, `store_id`, `code`, `key`, `value`, `serialized`) VALUES
(1, 0, 'shipping', 'shipping_sort_order', '3', 0),
(2, 0, 'sub_total', 'sub_total_sort_order', '1', 0),
(3, 0, 'sub_total', 'sub_total_status', '1', 0),
(4, 0, 'tax', 'tax_status', '1', 0),
(5, 0, 'total', 'total_sort_order', '9', 0),
(6, 0, 'total', 'total_status', '1', 0),
(7, 0, 'tax', 'tax_sort_order', '5', 0),
(14, 0, 'shipping', 'shipping_status', '1', 0),
(15, 0, 'shipping', 'shipping_estimator', '1', 0),
(27, 0, 'coupon', 'coupon_sort_order', '4', 0),
(28, 0, 'coupon', 'coupon_status', '1', 0),
(4849, 0, 'flat', 'flat_sort_order', '1', 0),
(4848, 0, 'flat', 'flat_status', '1', 0),
(4847, 0, 'flat', 'flat_geo_zone_id', '0', 0),
(4846, 0, 'flat', 'flat_tax_class_id', '0', 0),
(4845, 0, 'flat', 'flat_cost', '20000', 0),
(42, 0, 'credit', 'credit_sort_order', '7', 0),
(43, 0, 'credit', 'credit_status', '1', 0),
(1452, 0, 'reward', 'reward_sort_order', '2', 0),
(1451, 0, 'reward', 'reward_status', '1', 0),
(146, 0, 'category', 'category_status', '1', 0),
(158, 0, 'account', 'account_status', '1', 0),
(3061, 0, 'affiliate', 'affiliate_status', '1', 0),
(1454, 0, 'information', 'information_status', '1', 0),
(3887, 0, 'image_manager_plus_installed', 'image_manager_plus_installed', '1', 0),
(94, 0, 'voucher', 'voucher_sort_order', '8', 0),
(95, 0, 'voucher', 'voucher_status', '1', 0),
(1939, 0, 'openbaypro', 'openbaypro_status', '0', 0),
(1938, 0, 'openbaypro', 'openbaypro_menu', '0', 0),
(4857, 0, 'bank_transfer', 'bank_transfer_sort_order', '1', 0),
(4856, 0, 'bank_transfer', 'bank_transfer_status', '1', 0),
(7792, 0, 'image_manager_plus', 'image_manager_plus_status', '1', 0),
(7791, 0, 'image_manager_plus', 'image_manager_plus_command', 'a:1:{i:1;a:20:{s:5:"mkdir";s:1:"1";s:6:"mkfile";s:1:"1";s:6:"upload";s:1:"1";s:6:"reload";s:1:"1";s:7:"getfile";s:1:"1";s:2:"up";s:1:"1";s:8:"download";s:1:"1";s:2:"rm";s:1:"1";s:9:"duplicate";s:1:"1";s:6:"rename";s:1:"1";s:4:"copy";s:1:"1";s:3:"cut";s:1:"1";s:5:"paste";s:1:"1";s:4:"edit";s:1:"1";s:7:"extract";s:1:"1";s:7:"archive";s:1:"1";s:4:"view";s:1:"1";s:6:"resize";s:1:"1";s:4:"sort";s:1:"1";s:6:"search";s:1:"1";}}', 1),
(2419, 0, 'language_switch', 'language_switch_status', '1', 0),
(6269, 0, 'mb_search', 'mb_search_status', '1', 0),
(2421, 0, 'mb_mini_cart', 'mb_mini_cart_status', '1', 0),
(4866, 0, 'cod', 'cod_status', '1', 0),
(4865, 0, 'cod', 'cod_geo_zone_id', '0', 0),
(4864, 0, 'cod', 'cod_order_status_id', '2', 0),
(3769, 0, 'newsletters', 'newsletters_status', '1', 0),
(3060, 0, 'visualbuilder', 'visualbuilder_excluded', 'a:5:{i:0;s:13:"amazon_button";i:1;s:15:"google_hangouts";i:2;s:8:"pp_login";i:3;s:17:"revslideropencart";i:4;s:12:"showinconfig";}', 1),
(6969, 0, 'google_maps', 'google_maps_module_map', 'a:1:{i:1;a:8:{s:2:"id";s:3:"111";s:5:"alias";s:6:"ban_do";s:7:"address";s:0:"";s:8:"latitude";s:18:"10.782615706880339";s:9:"longitude";s:18:"106.69589012861252";s:13:"balloon_width";s:3:"400";s:7:"maptext";a:1:{i:2;s:48:"Số 123, Đường ABC, Quận ABC, Thành ABC.";}s:11:"onelinetext";a:1:{i:2;s:0:"";}}}', 1),
(8502, 0, 'chili_setting', 'chili_setting_domain', 'http://localhost/app/boxme/', 0),
(4007, 0, 'google_sitemap', 'google_sitemap_status', '1', 0),
(6968, 0, 'd_quickcheckout', 'd_quickcheckout', 'a:4:{s:7:"general";a:10:{s:6:"enable";s:1:"1";s:14:"default_option";s:5:"guest";s:13:"main_checkout";s:1:"1";s:13:"clear_session";s:1:"1";s:13:"login_refresh";s:1:"1";s:13:"default_email";s:20:"noreply@chiliweb.org";s:5:"debug";s:1:"0";s:9:"min_order";a:2:{s:5:"value";s:1:"0";s:4:"text";a:1:{i:2;s:32:"Trình tự tối thiểu là %s";}}s:12:"min_quantity";a:2:{s:5:"value";s:1:"0";s:4:"text";a:1:{i:2;s:34:"Số lượng tối thiểu là %s";}}s:7:"trigger";s:113:"#confirm_payment .button, #confirm_payment .btn, #confirm_payment .button_oc, #confirm_payment input[type=submit]";}s:6:"option";a:3:{s:5:"guest";a:4:{s:15:"payment_address";a:2:{s:7:"display";s:1:"1";s:6:"fields";a:17:{s:9:"firstname";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:8:"lastname";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:5:"email";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:13:"email_confirm";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:9:"telephone";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";}s:3:"fax";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:7:"heading";a:1:{s:7:"display";s:1:"0";}s:7:"company";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:17:"customer_group_id";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:9:"address_1";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:9:"address_2";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:4:"city";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:8:"postcode";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:10:"country_id";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:7:"zone_id";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:8:"shipping";a:1:{s:7:"display";s:1:"1";}s:5:"agree";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}}}s:16:"shipping_address";a:3:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";s:6:"fields";a:9:{s:9:"firstname";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:8:"lastname";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:7:"company";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";}s:9:"address_1";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:9:"address_2";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:4:"city";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";}s:8:"postcode";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:10:"country_id";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:7:"zone_id";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}}}s:4:"cart";a:3:{s:7:"display";s:1:"1";s:7:"columns";a:6:{s:5:"image";s:1:"1";s:4:"name";s:1:"1";s:5:"model";s:1:"0";s:8:"quantity";s:1:"1";s:5:"price";s:1:"1";s:5:"total";s:1:"1";}s:6:"option";a:3:{s:6:"coupon";a:1:{s:7:"display";s:1:"1";}s:7:"voucher";a:1:{s:7:"display";s:1:"1";}s:6:"reward";a:1:{s:7:"display";s:1:"1";}}}s:7:"confirm";a:1:{s:6:"fields";a:2:{s:5:"agree";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:7:"comment";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";}}}}s:8:"register";a:4:{s:15:"payment_address";a:2:{s:7:"display";s:1:"1";s:6:"fields";a:20:{s:9:"firstname";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:8:"lastname";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:5:"email";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:13:"email_confirm";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:9:"telephone";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:3:"fax";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:8:"password";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:7:"confirm";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:7:"heading";a:1:{s:7:"display";s:1:"0";}s:7:"company";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:17:"customer_group_id";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:9:"address_1";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:9:"address_2";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:4:"city";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:8:"postcode";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:10:"country_id";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:7:"zone_id";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:10:"newsletter";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";}s:8:"shipping";a:1:{s:7:"display";s:1:"1";}s:5:"agree";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}}}s:16:"shipping_address";a:3:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";s:6:"fields";a:9:{s:9:"firstname";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:8:"lastname";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:7:"company";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";}s:9:"address_1";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:9:"address_2";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:4:"city";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";}s:8:"postcode";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:10:"country_id";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:7:"zone_id";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}}}s:4:"cart";a:3:{s:7:"display";s:1:"1";s:7:"columns";a:6:{s:5:"image";s:1:"1";s:4:"name";s:1:"1";s:5:"model";s:1:"0";s:8:"quantity";s:1:"1";s:5:"price";s:1:"1";s:5:"total";s:1:"1";}s:6:"option";a:3:{s:6:"coupon";a:1:{s:7:"display";s:1:"1";}s:7:"voucher";a:1:{s:7:"display";s:1:"1";}s:6:"reward";a:1:{s:7:"display";s:1:"1";}}}s:7:"confirm";a:1:{s:6:"fields";a:2:{s:5:"agree";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:7:"comment";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";}}}}s:6:"logged";a:4:{s:15:"payment_address";a:2:{s:7:"display";s:1:"1";s:6:"fields";a:10:{s:9:"firstname";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:8:"lastname";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:7:"company";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:9:"address_1";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:9:"address_2";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:4:"city";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";}s:8:"postcode";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:10:"country_id";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"1";}s:7:"zone_id";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:8:"shipping";a:1:{s:7:"display";s:1:"1";}}}s:16:"shipping_address";a:3:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";s:6:"fields";a:9:{s:9:"firstname";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:8:"lastname";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:7:"company";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";}s:9:"address_1";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:9:"address_2";a:2:{s:7:"display";s:1:"0";s:7:"require";s:1:"0";}s:4:"city";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:8:"postcode";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:10:"country_id";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}s:7:"zone_id";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"1";}}}s:4:"cart";a:3:{s:7:"display";s:1:"1";s:7:"columns";a:6:{s:5:"image";s:1:"1";s:4:"name";s:1:"1";s:5:"model";s:1:"0";s:8:"quantity";s:1:"1";s:5:"price";s:1:"1";s:5:"total";s:1:"1";}s:6:"option";a:3:{s:6:"coupon";a:1:{s:7:"display";s:1:"1";}s:7:"voucher";a:1:{s:7:"display";s:1:"1";}s:6:"reward";a:1:{s:7:"display";s:1:"1";}}}s:7:"confirm";a:1:{s:6:"fields";a:2:{s:5:"agree";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"4";}s:7:"comment";a:2:{s:7:"display";s:1:"1";s:7:"require";s:1:"0";}}}}}s:4:"step";a:8:{s:15:"payment_address";a:3:{s:6:"fields";a:20:{s:9:"firstname";a:1:{s:10:"sort_order";s:1:"1";}s:8:"lastname";a:1:{s:10:"sort_order";s:1:"2";}s:5:"email";a:1:{s:10:"sort_order";s:1:"3";}s:13:"email_confirm";a:1:{s:10:"sort_order";s:1:"3";}s:9:"telephone";a:1:{s:10:"sort_order";s:1:"4";}s:3:"fax";a:1:{s:10:"sort_order";s:1:"5";}s:8:"password";a:1:{s:10:"sort_order";s:1:"6";}s:7:"confirm";a:1:{s:10:"sort_order";s:1:"7";}s:7:"heading";a:1:{s:10:"sort_order";s:1:"8";}s:7:"company";a:1:{s:10:"sort_order";s:1:"9";}s:17:"customer_group_id";a:1:{s:10:"sort_order";s:2:"12";}s:9:"address_1";a:1:{s:10:"sort_order";s:2:"13";}s:9:"address_2";a:1:{s:10:"sort_order";s:2:"14";}s:4:"city";a:1:{s:10:"sort_order";s:2:"15";}s:8:"postcode";a:1:{s:10:"sort_order";s:2:"16";}s:10:"country_id";a:1:{s:10:"sort_order";s:2:"17";}s:7:"zone_id";a:1:{s:10:"sort_order";s:2:"18";}s:10:"newsletter";a:1:{s:10:"sort_order";s:2:"19";}s:8:"shipping";a:1:{s:10:"sort_order";s:2:"20";}s:5:"agree";a:1:{s:10:"sort_order";s:2:"21";}}s:6:"column";s:1:"1";s:3:"row";s:1:"1";}s:16:"shipping_address";a:3:{s:6:"fields";a:9:{s:9:"firstname";a:1:{s:10:"sort_order";s:1:"1";}s:8:"lastname";a:1:{s:10:"sort_order";s:1:"2";}s:7:"company";a:1:{s:10:"sort_order";s:1:"3";}s:9:"address_1";a:1:{s:10:"sort_order";s:1:"4";}s:9:"address_2";a:1:{s:10:"sort_order";s:1:"5";}s:4:"city";a:1:{s:10:"sort_order";s:1:"6";}s:8:"postcode";a:1:{s:10:"sort_order";s:1:"7";}s:10:"country_id";a:1:{s:10:"sort_order";s:1:"8";}s:7:"zone_id";a:1:{s:10:"sort_order";s:1:"9";}}s:6:"column";s:1:"1";s:3:"row";s:1:"2";}s:15:"shipping_method";a:7:{s:7:"display";s:1:"1";s:15:"display_options";s:1:"1";s:13:"display_title";s:1:"1";s:11:"input_style";s:5:"radio";s:14:"default_option";s:7:"auspost";s:6:"column";s:1:"2";s:3:"row";s:1:"1";}s:14:"payment_method";a:7:{s:7:"display";s:1:"1";s:15:"display_options";s:1:"1";s:11:"input_style";s:5:"radio";s:14:"display_images";s:1:"1";s:14:"default_option";s:15:"amazon_checkout";s:6:"column";s:1:"3";s:3:"row";s:1:"1";}s:7:"confirm";a:3:{s:6:"fields";a:2:{s:5:"agree";a:1:{s:10:"sort_order";s:0:"";}s:7:"comment";a:1:{s:10:"sort_order";s:0:"";}}s:6:"column";s:1:"4";s:3:"row";s:1:"2";}s:5:"login";a:1:{s:6:"option";a:3:{s:5:"login";a:1:{s:7:"display";s:1:"1";}s:8:"register";a:1:{s:7:"display";s:1:"1";}s:5:"guest";a:1:{s:7:"display";s:1:"1";}}}s:7:"payment";a:2:{s:6:"column";s:1:"4";s:3:"row";s:1:"2";}s:4:"cart";a:2:{s:6:"column";s:1:"4";s:3:"row";s:1:"2";}}s:6:"design";a:10:{s:5:"theme";s:7:"default";s:11:"block_style";s:3:"row";s:11:"login_style";s:5:"popup";s:13:"address_style";s:5:"radio";s:15:"cart_image_size";a:2:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";}s:9:"max_width";s:0:"";s:7:"uniform";s:1:"0";s:18:"only_quickcheckout";s:1:"0";s:12:"column_width";a:4:{i:1;s:2:"40";i:2;s:2:"30";i:3;s:2:"30";i:4;s:2:"60";}s:12:"custom_style";s:0:"";}}', 1),
(4855, 0, 'bank_transfer', 'bank_transfer_geo_zone_id', '0', 0),
(4854, 0, 'bank_transfer', 'bank_transfer_order_status_id', '2', 0),
(4853, 0, 'bank_transfer', 'bank_transfer_total', '', 0),
(4852, 0, 'bank_transfer', 'bank_transfer_bank2', 'ABC Á Châu\r\nTên chủ tài khoản: Nguyễn Văn A\r\nSố tài khoản:5734953453495345', 0),
(4863, 0, 'cod', 'cod_total', '', 0),
(4867, 0, 'cod', 'cod_sort_order', '', 0),
(10353, 0, 'config', 'config_google_captcha_secret', '', 0),
(10354, 0, 'config', 'config_google_captcha_status', '0', 0),
(10352, 0, 'config', 'config_google_captcha_public', '', 0),
(6971, 0, 'showinconfig', 'showinconfig_tab', 'a:6:{i:0;a:6:{s:5:"title";a:1:{i:2;s:21:"Balo &amp; Túi xách";}s:13:"product_group";s:2:"BS";s:11:"data_source";s:2:"CQ";s:15:"filter_category";s:2:"62";s:19:"filter_manufacturer";s:3:"ALL";s:4:"sort";s:7:"pd.name";}i:1;a:6:{s:5:"title";a:1:{i:2;s:5:"Khăn";}s:13:"product_group";s:2:"BS";s:11:"data_source";s:2:"CQ";s:15:"filter_category";s:2:"69";s:19:"filter_manufacturer";s:3:"ALL";s:4:"sort";s:7:"pd.name";}i:2;a:6:{s:5:"title";a:1:{i:2;s:11:"Trang sức";}s:13:"product_group";s:2:"BS";s:11:"data_source";s:2:"CQ";s:15:"filter_category";s:2:"71";s:19:"filter_manufacturer";s:3:"ALL";s:4:"sort";s:7:"pd.name";}i:5;a:6:{s:5:"title";a:1:{i:2;s:12:"Mới nhất";}s:11:"data_source";s:2:"PG";s:13:"product_group";s:2:"LA";s:15:"filter_category";s:3:"ALL";s:19:"filter_manufacturer";s:3:"ALL";s:4:"sort";s:7:"pd.name";}i:6;a:6:{s:5:"title";a:1:{i:2;s:13:"Khuyến mãi";}s:11:"data_source";s:2:"PG";s:13:"product_group";s:2:"SP";s:15:"filter_category";s:3:"ALL";s:19:"filter_manufacturer";s:3:"ALL";s:4:"sort";s:7:"pd.name";}i:7;a:7:{s:5:"title";a:1:{i:2;s:11:"Nổi bật";}s:11:"data_source";s:2:"SP";s:8:"products";a:5:{i:110;a:1:{s:10:"product_id";s:3:"110";}i:113;a:1:{s:10:"product_id";s:3:"113";}i:101;a:1:{s:10:"product_id";s:3:"101";}i:108;a:1:{s:10:"product_id";s:3:"108";}i:104;a:1:{s:10:"product_id";s:3:"104";}}s:13:"product_group";s:2:"BS";s:15:"filter_category";s:3:"ALL";s:19:"filter_manufacturer";s:3:"ALL";s:4:"sort";s:7:"pd.name";}}', 1),
(10351, 0, 'config', 'config_google_analytics_status', '0', 0),
(10350, 0, 'config', 'config_google_analytics', '', 0),
(10349, 0, 'config', 'config_error_filename', 'error.log', 0),
(10348, 0, 'config', 'config_error_log', '1', 0),
(10347, 0, 'config', 'config_error_display', '0', 0),
(10346, 0, 'config', 'config_compression', '', 0),
(10343, 0, 'config', 'config_maintenance', '1', 0),
(10344, 0, 'config', 'config_password', '1', 0),
(10345, 0, 'config', 'config_encryption', '1701c3221012c23dec03ce067f473180', 0),
(10339, 0, 'config', 'config_seo_url', '0', 0),
(10340, 0, 'config', 'config_file_max_size', '300000', 0),
(10341, 0, 'config', 'config_file_ext_allowed', 'zip\r\ntxt\r\npng\r\njpe\r\njpeg\r\njpg\r\ngif\r\nbmp\r\nico\r\ntiff\r\ntif\r\nsvg\r\nsvgz\r\nzip\r\nrar\r\nmsi\r\ncab\r\nmp3\r\nqt\r\nmov\r\npdf\r\npsd\r\nai\r\neps\r\nps\r\ndoc', 0),
(10342, 0, 'config', 'config_file_mime_allowed', 'text/plain\r\nimage/png\r\nimage/jpeg\r\nimage/gif\r\nimage/bmp\r\nimage/tiff\r\nimage/svg+xml\r\napplication/zip\r\n&quot;application/zip&quot;\r\napplication/x-zip\r\n&quot;application/x-zip&quot;\r\napplication/x-zip-compressed\r\n&quot;application/x-zip-compressed&quot;\r\napplication/rar\r\n&quot;application/rar&quot;\r\napplication/x-rar\r\n&quot;application/x-rar&quot;\r\napplication/x-rar-compressed\r\n&quot;application/x-rar-compressed&quot;\r\napplication/octet-stream\r\n&quot;application/octet-stream&quot;\r\naudio/mpeg\r\nvideo/quicktime\r\napplication/pdf', 0),
(7911, 0, 'group_menu', 'group_menu_value', 'a:1:{s:13:"id_1480478918";a:3:{s:11:"title_group";a:2:{i:4;s:13:"Setting Boxme";i:2;s:17:"Cấu hình Boxme";}s:17:"description_group";a:2:{i:4;s:10:"Boxme - En";i:2;s:5:"Boxme";}s:12:"status_group";s:1:"1";}}', 1),
(7907, 0, 'menu', 'menu_id_1480478918', 'a:2:{s:13:"id_1480480267";a:5:{s:7:"id_menu";s:13:"id_1480480267";s:8:"id_group";s:13:"id_1480478918";s:10:"title_menu";a:2:{i:2;s:12:"Quảng cáo";i:4;s:13:"Advertisement";}s:9:"link_menu";s:13:"module/banner";s:10:"order_menu";i:0;}s:13:"id_1480479176";a:5:{s:7:"id_menu";s:13:"id_1480479176";s:8:"id_group";s:13:"id_1480478918";s:10:"title_menu";a:2:{i:4;s:61:"Danh sách thông tin &gt; Thông tin liên hệ cuối trang";i:2;s:61:"Danh sách thông tin &gt; Thông tin liên hệ cuối trang";}s:9:"link_menu";s:39:"module/content_info/mb_qdv/module_id=76";s:10:"order_menu";i:0;}}', 1),
(10338, 0, 'config', 'config_robots', 'abot\r\ndbot\r\nebot\r\nhbot\r\nkbot\r\nlbot\r\nmbot\r\nnbot\r\nobot\r\npbot\r\nrbot\r\nsbot\r\ntbot\r\nvbot\r\nybot\r\nzbot\r\nbot.\r\nbot/\r\n_bot\r\n.bot\r\n/bot\r\n-bot\r\n:bot\r\n(bot\r\ncrawl\r\nslurp\r\nspider\r\nseek\r\naccoona\r\nacoon\r\nadressendeutschland\r\nah-ha.com\r\nahoy\r\naltavista\r\nananzi\r\nanthill\r\nappie\r\narachnophilia\r\narale\r\naraneo\r\naranha\r\narchitext\r\naretha\r\narks\r\nasterias\r\natlocal\r\natn\r\natomz\r\naugurfind\r\nbackrub\r\nbannana_bot\r\nbaypup\r\nbdfetch\r\nbig brother\r\nbiglotron\r\nbjaaland\r\nblackwidow\r\nblaiz\r\nblog\r\nblo.\r\nbloodhound\r\nboitho\r\nbooch\r\nbradley\r\nbutterfly\r\ncalif\r\ncassandra\r\nccubee\r\ncfetch\r\ncharlotte\r\nchurl\r\ncienciaficcion\r\ncmc\r\ncollective\r\ncomagent\r\ncombine\r\ncomputingsite\r\ncsci\r\ncurl\r\ncusco\r\ndaumoa\r\ndeepindex\r\ndelorie\r\ndepspid\r\ndeweb\r\ndie blinde kuh\r\ndigger\r\nditto\r\ndmoz\r\ndocomo\r\ndownload express\r\ndtaagent\r\ndwcp\r\nebiness\r\nebingbong\r\ne-collector\r\nejupiter\r\nemacs-w3 search engine\r\nesther\r\nevliya celebi\r\nezresult\r\nfalcon\r\nfelix ide\r\nferret\r\nfetchrover\r\nfido\r\nfindlinks\r\nfireball\r\nfish search\r\nfouineur\r\nfunnelweb\r\ngazz\r\ngcreep\r\ngenieknows\r\ngetterroboplus\r\ngeturl\r\nglx\r\ngoforit\r\ngolem\r\ngrabber\r\ngrapnel\r\ngralon\r\ngriffon\r\ngromit\r\ngrub\r\ngulliver\r\nhamahakki\r\nharvest\r\nhavindex\r\nhelix\r\nheritrix\r\nhku www octopus\r\nhomerweb\r\nhtdig\r\nhtml index\r\nhtml_analyzer\r\nhtmlgobble\r\nhubater\r\nhyper-decontextualizer\r\nia_archiver\r\nibm_planetwide\r\nichiro\r\niconsurf\r\niltrovatore\r\nimage.kapsi.net\r\nimagelock\r\nincywincy\r\nindexer\r\ninfobee\r\ninformant\r\ningrid\r\ninktomisearch.com\r\ninspector web\r\nintelliagent\r\ninternet shinchakubin\r\nip3000\r\niron33\r\nisraeli-search\r\nivia\r\njack\r\njakarta\r\njavabee\r\njetbot\r\njumpstation\r\nkatipo\r\nkdd-explorer\r\nkilroy\r\nknowledge\r\nkototoi\r\nkretrieve\r\nlabelgrabber\r\nlachesis\r\nlarbin\r\nlegs\r\nlibwww\r\nlinkalarm\r\nlink validator\r\nlinkscan\r\nlockon\r\nlwp\r\nlycos\r\nmagpie\r\nmantraagent\r\nmapoftheinternet\r\nmarvin/\r\nmattie\r\nmediafox\r\nmediapartners\r\nmercator\r\nmerzscope\r\nmicrosoft url control\r\nminirank\r\nmiva\r\nmj12\r\nmnogosearch\r\nmoget\r\nmonster\r\nmoose\r\nmotor\r\nmultitext\r\nmuncher\r\nmuscatferret\r\nmwd.search\r\nmyweb\r\nnajdi\r\nnameprotect\r\nnationaldirectory\r\nnazilla\r\nncsa beta\r\nnec-meshexplorer\r\nnederland.zoek\r\nnetcarta webmap engine\r\nnetmechanic\r\nnetresearchserver\r\nnetscoop\r\nnewscan-online\r\nnhse\r\nnokia6682/\r\nnomad\r\nnoyona\r\nnutch\r\nnzexplorer\r\nobjectssearch\r\noccam\r\nomni\r\nopen text\r\nopenfind\r\nopenintelligencedata\r\norb search\r\nosis-project\r\npack rat\r\npageboy\r\npagebull\r\npage_verifier\r\npanscient\r\nparasite\r\npartnersite\r\npatric\r\npear.\r\npegasus\r\nperegrinator\r\npgp key agent\r\nphantom\r\nphpdig\r\npicosearch\r\npiltdownman\r\npimptrain\r\npinpoint\r\npioneer\r\npiranha\r\nplumtreewebaccessor\r\npogodak\r\npoirot\r\npompos\r\npoppelsdorf\r\npoppi\r\npopular iconoclast\r\npsycheclone\r\npublisher\r\npython\r\nrambler\r\nraven search\r\nroach\r\nroad runner\r\nroadhouse\r\nrobbie\r\nrobofox\r\nrobozilla\r\nrules\r\nsalty\r\nsbider\r\nscooter\r\nscoutjet\r\nscrubby\r\nsearch.\r\nsearchprocess\r\nsemanticdiscovery\r\nsenrigan\r\nsg-scout\r\nshai\'hulud\r\nshark\r\nshopwiki\r\nsidewinder\r\nsift\r\nsilk\r\nsimmany\r\nsite searcher\r\nsite valet\r\nsitetech-rover\r\nskymob.com\r\nsleek\r\nsmartwit\r\nsna-\r\nsnappy\r\nsnooper\r\nsohu\r\nspeedfind\r\nsphere\r\nsphider\r\nspinner\r\nspyder\r\nsteeler/\r\nsuke\r\nsuntek\r\nsupersnooper\r\nsurfnomore\r\nsven\r\nsygol\r\nszukacz\r\ntach black widow\r\ntarantula\r\ntempleton\r\n/teoma\r\nt-h-u-n-d-e-r-s-t-o-n-e\r\ntheophrastus\r\ntitan\r\ntitin\r\ntkwww\r\ntoutatis\r\nt-rex\r\ntutorgig\r\ntwiceler\r\ntwisted\r\nucsd\r\nudmsearch\r\nurl check\r\nupdated\r\nvagabondo\r\nvalkyrie\r\nverticrawl\r\nvictoria\r\nvision-search\r\nvolcano\r\nvoyager/\r\nvoyager-hc\r\nw3c_validator\r\nw3m2\r\nw3mir\r\nwalker\r\nwallpaper\r\nwanderer\r\nwauuu\r\nwavefire\r\nweb core\r\nweb hopper\r\nweb wombat\r\nwebbandit\r\nwebcatcher\r\nwebcopy\r\nwebfoot\r\nweblayers\r\nweblinker\r\nweblog monitor\r\nwebmirror\r\nwebmonkey\r\nwebquest\r\nwebreaper\r\nwebsitepulse\r\nwebsnarf\r\nwebstolperer\r\nwebvac\r\nwebwalk\r\nwebwatch\r\nwebwombat\r\nwebzinger\r\nwhizbang\r\nwhowhere\r\nwild ferret\r\nworldlight\r\nwwwc\r\nwwwster\r\nxenu\r\nxget\r\nxift\r\nxirq\r\nyandex\r\nyanga\r\nyeti\r\nyodao\r\nzao\r\nzippp\r\nzyborg', 0),
(10337, 0, 'config', 'config_shared', '0', 0),
(10336, 0, 'config', 'config_secure', '0', 0),
(10335, 0, 'config', 'config_mail_alert', '', 0),
(10333, 0, 'config', 'config_mail_smtp_port', '25', 0),
(10334, 0, 'config', 'config_mail_smtp_timeout', '5', 0),
(10332, 0, 'config', 'config_mail_smtp_password', 'H4Hh@G2', 0),
(10331, 0, 'config', 'config_mail_smtp_username', 'noreply@chiliweb.org', 0),
(10330, 0, 'config', 'config_mail_smtp_hostname', 'localhost', 0),
(10328, 0, 'config', 'config_mail_protocol', 'mail', 0),
(10329, 0, 'config', 'config_mail_parameter', 'noreply@chiliweb.org', 0),
(10326, 0, 'config', 'config_ftp_root', '', 0),
(10327, 0, 'config', 'config_ftp_status', '0', 0),
(10325, 0, 'config', 'config_ftp_password', '', 0),
(10324, 0, 'config', 'config_ftp_username', '', 0),
(10323, 0, 'config', 'config_ftp_port', '21', 0),
(10322, 0, 'config', 'config_ftp_hostname', 'coreshop.chilibusiness.net', 0),
(10321, 0, 'config', 'config_image_location_height', '200', 0),
(10320, 0, 'config', 'config_image_location_width', '300', 0),
(10319, 0, 'config', 'config_image_cart_height', '70', 0),
(10318, 0, 'config', 'config_image_cart_width', '70', 0),
(10317, 0, 'config', 'config_image_wishlist_height', '47', 0),
(10240, 0, 'boxme', 'boxme_warehouse_chili', '151576', 0),
(10316, 0, 'config', 'config_image_wishlist_width', '47', 0),
(10313, 0, 'config', 'config_image_related_height', '270', 0),
(10314, 0, 'config', 'config_image_compare_width', '90', 0),
(10315, 0, 'config', 'config_image_compare_height', '90', 0),
(10312, 0, 'config', 'config_image_related_width', '270', 0),
(10311, 0, 'config', 'config_image_additional_height', '150', 0),
(10310, 0, 'config', 'config_image_additional_width', '150', 0),
(10308, 0, 'config', 'config_image_product_width', '270', 0),
(10309, 0, 'config', 'config_image_product_height', '270', 0),
(10307, 0, 'config', 'config_image_popup_height', '650', 0),
(10306, 0, 'config', 'config_image_popup_width', '650', 0),
(10239, 0, 'boxme', 'boxme_key', 'c333e43500c3a0a4df7c4b47b6cc35df', 0),
(10305, 0, 'config', 'config_image_thumb_height', '450', 0),
(10304, 0, 'config', 'config_image_thumb_width', '450', 0),
(10303, 0, 'config', 'config_image_category_height', '80', 0),
(10301, 0, 'config', 'config_icon', 'catalog/favicon.png', 0),
(10302, 0, 'config', 'config_image_category_width', '80', 0),
(10300, 0, 'config', 'config_logo', 'catalog/logo.png', 0),
(10299, 0, 'config', 'config_return_id', '5', 0),
(10298, 0, 'config', 'config_affiliate_mail', '1', 0),
(10297, 0, 'config', 'config_affiliate_id', '5', 0),
(10296, 0, 'config', 'config_affiliate_commission', '5', 0),
(10295, 0, 'config', 'config_affiliate_auto', '1', 0),
(10293, 0, 'config', 'config_stock_checkout', '1', 0),
(10294, 0, 'config', 'config_affiliate_approval', '0', 0),
(10291, 0, 'config', 'config_stock_display', '1', 0),
(10292, 0, 'config', 'config_stock_warning', '1', 0),
(10290, 0, 'config', 'config_order_mail', '1', 0),
(10289, 0, 'config', 'config_complete_status', 'a:1:{i:0;s:1:"4";}', 1),
(10288, 0, 'config', 'config_processing_status', 'a:2:{i:0;s:1:"3";i:1;s:1:"2";}', 1),
(10287, 0, 'config', 'config_order_status_id', '1', 0),
(10286, 0, 'config', 'config_checkout_id', '5', 0),
(10285, 0, 'config', 'config_checkout_guest', '1', 0),
(10284, 0, 'config', 'config_cart_weight', '1', 0),
(10283, 0, 'config', 'config_api_id', '2', 0),
(10282, 0, 'config', 'config_invoice_prefix', 'INV-2015-00', 0),
(10281, 0, 'config', 'config_account_mail', '1', 0),
(10273, 0, 'config', 'config_voucher_max', '99000000 ', 0),
(10274, 0, 'config', 'config_tax', '0', 0),
(10275, 0, 'config', 'config_tax_default', 'shipping', 0),
(10276, 0, 'config', 'config_tax_customer', 'shipping', 0),
(10277, 0, 'config', 'config_customer_online', '1', 0),
(10278, 0, 'config', 'config_customer_price', '0', 0),
(10280, 0, 'config', 'config_account_id', '3', 0),
(10279, 0, 'config', 'config_login_attempts', '5', 0),
(10272, 0, 'config', 'config_voucher_min', '100000', 0),
(10270, 0, 'config', 'config_review_guest', '1', 0),
(10271, 0, 'config', 'config_review_mail', '1', 0),
(10269, 0, 'config', 'config_review_status', '1', 0),
(10268, 0, 'config', 'config_limit_admin', '20', 0),
(10267, 0, 'config', 'config_product_description_length', '160', 0),
(10266, 0, 'config', 'config_product_limit', '12', 0),
(10265, 0, 'config', 'config_product_count', '0', 0),
(10264, 0, 'config', 'config_weight_class_id', '1', 0),
(10263, 0, 'config', 'config_length_class_id', '1', 0),
(10262, 0, 'config', 'config_currency_auto', '1', 0),
(10261, 0, 'config', 'config_currency', 'VND', 0),
(10260, 0, 'config', 'config_admin_language', 'vi', 0),
(10259, 0, 'config', 'config_language', 'vi', 0),
(10258, 0, 'config', 'config_zone_id', '3780', 0),
(10257, 0, 'config', 'config_country_id', '230', 0),
(10256, 0, 'config', 'config_layout_id', '4', 0),
(10253, 0, 'config', 'config_meta_description', 'CosyCare', 0),
(10254, 0, 'config', 'config_meta_keyword', '', 0),
(10255, 0, 'config', 'config_template', 'Mb_Themes', 0),
(10251, 0, 'config', 'config_comment', '', 0),
(10252, 0, 'config', 'config_meta_title', 'CosyCare', 0),
(10250, 0, 'config', 'config_open', '7h - 21h từ thứ 2 - 6\r\n8h - 22h từ thứ 7 - chủ nhật', 0),
(10249, 0, 'config', 'config_image', 'catalog/Logo.png', 0),
(10248, 0, 'config', 'config_fax', '+84 123 456 789', 0),
(10246, 0, 'config', 'config_email', 'noreply@chiliweb.org', 0),
(10247, 0, 'config', 'config_telephone', '+84 123 456 789', 0),
(10245, 0, 'config', 'config_geocode', '70000', 0),
(10244, 0, 'config', 'config_address', 'Số 123, Đường ABC, Quận ABC, Thành Phố Hồ Chí Minh', 0),
(10243, 0, 'config', 'config_owner', 'CosyCare', 0),
(10242, 0, 'config', 'config_name', 'CosyCare', 0),
(10241, 0, 'boxme', 'boxme_status', '1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_stock_status`
--

CREATE TABLE `oc_stock_status` (
  `stock_status_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_stock_status`
--

INSERT INTO `oc_stock_status` (`stock_status_id`, `language_id`, `name`) VALUES
(7, 2, 'Còn hàng'),
(8, 2, 'Đặt hàng trước'),
(5, 2, 'Hết hàng'),
(6, 2, '2-3 ngày'),
(9, 2, 'Chờ duyệt');

-- --------------------------------------------------------

--
-- Table structure for table `oc_store`
--

CREATE TABLE `oc_store` (
  `store_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `url` varchar(255) NOT NULL,
  `ssl` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_tax_class`
--

CREATE TABLE `oc_tax_class` (
  `tax_class_id` int(11) NOT NULL,
  `title` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_tax_class`
--

INSERT INTO `oc_tax_class` (`tax_class_id`, `title`, `description`, `date_added`, `date_modified`) VALUES
(9, 'Hàng hóa chịu thuế', 'Hàng hóa chịu thuế', '2009-01-06 23:21:53', '2015-12-25 15:35:13'),
(10, 'Thuế giá trị gia tăng', 'TGTGT', '2011-09-21 22:19:39', '2015-12-17 15:43:46');

-- --------------------------------------------------------

--
-- Table structure for table `oc_tax_rate`
--

CREATE TABLE `oc_tax_rate` (
  `tax_rate_id` int(11) NOT NULL,
  `geo_zone_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(32) NOT NULL,
  `rate` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `type` char(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_tax_rate`
--

INSERT INTO `oc_tax_rate` (`tax_rate_id`, `geo_zone_id`, `name`, `rate`, `type`, `date_added`, `date_modified`) VALUES
(86, 5, 'VAT (20%)', '20.0000', 'P', '2011-03-09 21:17:10', '2015-12-17 15:43:03'),
(87, 5, 'Sản phẩm tính thuế', '2000.0000', 'F', '2011-09-21 21:49:23', '2015-12-17 15:42:56');

-- --------------------------------------------------------

--
-- Table structure for table `oc_tax_rate_to_customer_group`
--

CREATE TABLE `oc_tax_rate_to_customer_group` (
  `tax_rate_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_tax_rate_to_customer_group`
--

INSERT INTO `oc_tax_rate_to_customer_group` (`tax_rate_id`, `customer_group_id`) VALUES
(86, 1),
(87, 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_tax_rule`
--

CREATE TABLE `oc_tax_rule` (
  `tax_rule_id` int(11) NOT NULL,
  `tax_class_id` int(11) NOT NULL,
  `tax_rate_id` int(11) NOT NULL,
  `based` varchar(10) NOT NULL,
  `priority` int(5) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_tax_rule`
--

INSERT INTO `oc_tax_rule` (`tax_rule_id`, `tax_class_id`, `tax_rate_id`, `based`, `priority`) VALUES
(129, 10, 86, 'payment', 1),
(131, 9, 87, 'shipping', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_upload`
--

CREATE TABLE `oc_upload` (
  `upload_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_url_alias`
--

CREATE TABLE `oc_url_alias` (
  `url_alias_id` int(11) NOT NULL,
  `query` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_url_alias`
--

INSERT INTO `oc_url_alias` (`url_alias_id`, `query`, `keyword`) VALUES
(730, 'manufacturer_id=8', 'apple'),
(890, '?route=information/contact', 'lien-he.html'),
(980, 'information_id=13', 'thoa-thuan-nguoi-dung'),
(979, 'information_id=7', 'huong-dan-dat-hang'),
(1153, 'category_id=80', 'gia-dinh'),
(828, 'manufacturer_id=9', 'canon'),
(829, 'manufacturer_id=5', 'htc'),
(830, 'manufacturer_id=7', 'hewlett-packard'),
(831, 'manufacturer_id=6', 'palm'),
(832, 'manufacturer_id=10', 'sony'),
(1156, 'category_id=83', 'duoc-pham-suc-khoe'),
(1154, 'category_id=81', 'nam'),
(973, 'information_id=3', 'chinh-sach-rieng-tu.html'),
(974, 'information_id=10', 'chuyen-khoan-ngan-hang'),
(975, 'information_id=12', 'huong-dan-thanh-toan'),
(976, 'information_id=11', 'huong-dan-thanh-toan-bao-kim'),
(977, 'information_id=8', 'huong-dan-thanh-toan-ngan-luong'),
(978, 'information_id=9', 'huong-dan-thanh-toan-paypal'),
(1203, 'information_id=4', 'gioi-thieu'),
(1157, 'category_id=84', 'me-be'),
(1155, 'category_id=82', 'nu'),
(1158, 'category_id=85', 'dinh-duong-the-thao'),
(1159, 'category_id=86', 'lam-dep'),
(1160, 'category_id=87', 'vitamin'),
(1161, 'category_id=88', 'my-pham-thien-nhien'),
(1415, 'product_id=313', 't'),
(1408, 'product_id=312', 't'),
(1429, 'product_id=0', ''),
(1430, 'product_id=0', ''),
(1476, 'product_id=373', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_user`
--

CREATE TABLE `oc_user` (
  `user_id` int(11) NOT NULL,
  `user_group_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(9) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `email` varchar(96) NOT NULL,
  `image` varchar(255) NOT NULL,
  `code` varchar(40) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_user`
--

INSERT INTO `oc_user` (`user_id`, `user_group_id`, `username`, `password`, `salt`, `firstname`, `lastname`, `email`, `image`, `code`, `ip`, `status`, `date_added`) VALUES
(1, 1, 'system', '25d55ad283aa400af464c76d713c07ad', '', 'CHILI', 'Super', 'taikhoanadmin@tenmiencuaban.com', 'catalog/chili_user.jpg', '', '::1', 1, '2016-03-22 08:29:03'),
(3, 1, 'admin', '55997a05077ca273f92a436f0f8b680d0b6e5783', '6c4e8d3cf', 'Admin', 'Admin', 'adsa@gmail.com', '', '', '::1', 1, '2017-01-05 16:17:27');

-- --------------------------------------------------------

--
-- Table structure for table `oc_user_group`
--

CREATE TABLE `oc_user_group` (
  `user_group_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `permission` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_user_group`
--

INSERT INTO `oc_user_group` (`user_group_id`, `name`, `permission`) VALUES
(1, 'Administrator', 'a:2:{s:6:"access";a:211:{i:0;s:11:"boxme/order";i:1;s:13:"boxme/product";i:2;s:13:"boxme/setting";i:3;s:15:"boxme/warehouse";i:4;s:17:"catalog/attribute";i:5;s:23:"catalog/attribute_group";i:6;s:26:"catalog/attribute_relative";i:7;s:16:"catalog/category";i:8;s:16:"catalog/download";i:9;s:14:"catalog/filter";i:10;s:17:"catalog/gallimage";i:11;s:19:"catalog/information";i:12;s:20:"catalog/manufacturer";i:13;s:14:"catalog/option";i:14;s:15:"catalog/product";i:15;s:17:"catalog/recurring";i:16;s:14:"catalog/review";i:17;s:20:"common/chili_setting";i:18;s:18:"common/column_left";i:19;s:18:"common/filemanager";i:20;s:11:"common/menu";i:21;s:17:"common/newsletter";i:22;s:14:"common/profile";i:23;s:14:"common/setting";i:24;s:12:"common/stats";i:25;s:25:"content_html/content_html";i:26;s:25:"dashboard/chili_dashboard";i:27;s:13:"design/banner";i:28;s:13:"design/layout";i:29;s:11:"design/menu";i:30;s:14:"extension/feed";i:31;s:15:"extension/fraud";i:32;s:19:"extension/installer";i:33;s:22:"extension/modification";i:34;s:16:"extension/module";i:35;s:17:"extension/openbay";i:36;s:17:"extension/payment";i:37;s:18:"extension/shipping";i:38;s:15:"extension/total";i:39;s:16:"feed/google_base";i:40;s:19:"feed/google_sitemap";i:41;s:23:"feed/image_manager_plus";i:42;s:15:"feed/openbaypro";i:43;s:18:"fraud/fraudlabspro";i:44;s:13:"fraud/maxmind";i:45;s:27:"getting_start/getting_start";i:46;s:20:"google_maps/location";i:47;s:21:"google_maps/mapmodule";i:48;s:20:"localisation/country";i:49;s:21:"localisation/currency";i:50;s:21:"localisation/geo_zone";i:51;s:21:"localisation/language";i:52;s:25:"localisation/length_class";i:53;s:21:"localisation/location";i:54;s:25:"localisation/order_status";i:55;s:26:"localisation/return_action";i:56;s:26:"localisation/return_reason";i:57;s:26:"localisation/return_status";i:58;s:25:"localisation/stock_status";i:59;s:22:"localisation/tax_class";i:60;s:21:"localisation/tax_rate";i:61;s:25:"localisation/weight_class";i:62;s:17:"localisation/zone";i:63;s:15:"loginauto/login";i:64;s:19:"marketing/affiliate";i:65;s:17:"marketing/contact";i:66;s:16:"marketing/coupon";i:67;s:19:"marketing/marketing";i:68;s:14:"module/account";i:69;s:16:"module/affiliate";i:70;s:20:"module/amazon_button";i:71;s:19:"module/amazon_login";i:72;s:17:"module/amazon_pay";i:73;s:13:"module/banner";i:74;s:17:"module/bestseller";i:75;s:15:"module/carousel";i:76;s:15:"module/category";i:77;s:19:"module/content_info";i:78;s:22:"module/currency_switch";i:79;s:22:"module/d_quickcheckout";i:80;s:19:"module/ebay_listing";i:81;s:15:"module/featured";i:82;s:13:"module/filter";i:83;s:16:"module/gallimage";i:84;s:22:"module/google_hangouts";i:85;s:18:"module/google_maps";i:86;s:11:"module/html";i:87;s:18:"module/information";i:88;s:22:"module/language_switch";i:89;s:13:"module/latest";i:90;s:14:"module/mb_logo";i:91;s:19:"module/mb_mini_cart";i:92;s:16:"module/mb_search";i:93;s:11:"module/menu";i:94;s:17:"module/module_col";i:95;s:18:"module/newsletters";i:96;s:16:"module/pp_button";i:97;s:15:"module/pp_login";i:98;s:24:"module/revslideropencart";i:99;s:22:"module/revslideroutput";i:100;s:19:"module/showinconfig";i:101;s:17:"module/showintabs";i:102;s:16:"module/slideshow";i:103;s:14:"module/special";i:104;s:12:"module/store";i:105;s:20:"module/visualbuilder";i:106;s:22:"openbay/amazon_product";i:107;s:16:"openbay/amazonus";i:108;s:24:"openbay/amazonus_product";i:109;s:21:"openbay/ebay_template";i:110;s:12:"openbay/etsy";i:111;s:21:"openbay/etsy_shipping";i:112;s:23:"payment/amazon_checkout";i:113;s:24:"payment/amazon_login_pay";i:114;s:24:"payment/authorizenet_aim";i:115;s:24:"payment/authorizenet_sim";i:116;s:21:"payment/bank_transfer";i:117;s:22:"payment/bluepay_hosted";i:118;s:24:"payment/bluepay_redirect";i:119;s:14:"payment/cheque";i:120;s:11:"payment/cod";i:121;s:17:"payment/firstdata";i:122;s:24:"payment/firstdata_remote";i:123;s:21:"payment/free_checkout";i:124;s:14:"payment/g2apay";i:125;s:17:"payment/globalpay";i:126;s:24:"payment/globalpay_remote";i:127;s:22:"payment/klarna_account";i:128;s:22:"payment/klarna_invoice";i:129;s:14:"payment/liqpay";i:130;s:14:"payment/nochex";i:131;s:15:"payment/paymate";i:132;s:16:"payment/paypoint";i:133;s:13:"payment/payza";i:134;s:26:"payment/perpetual_payments";i:135;s:18:"payment/pp_express";i:136;s:18:"payment/pp_payflow";i:137;s:25:"payment/pp_payflow_iframe";i:138;s:14:"payment/pp_pro";i:139;s:21:"payment/pp_pro_iframe";i:140;s:19:"payment/pp_standard";i:141;s:14:"payment/realex";i:142;s:21:"payment/realex_remote";i:143;s:22:"payment/sagepay_direct";i:144;s:22:"payment/sagepay_server";i:145;s:18:"payment/sagepay_us";i:146;s:24:"payment/securetrading_pp";i:147;s:24:"payment/securetrading_ws";i:148;s:14:"payment/skrill";i:149;s:19:"payment/twocheckout";i:150;s:28:"payment/web_payment_software";i:151;s:16:"payment/webmoney";i:152;s:16:"payment/worldpay";i:153;s:16:"report/affiliate";i:154;s:25:"report/affiliate_activity";i:155;s:22:"report/affiliate_login";i:156;s:24:"report/customer_activity";i:157;s:22:"report/customer_credit";i:158;s:21:"report/customer_login";i:159;s:22:"report/customer_online";i:160;s:21:"report/customer_order";i:161;s:22:"report/customer_reward";i:162;s:16:"report/marketing";i:163;s:24:"report/product_purchased";i:164;s:21:"report/product_viewed";i:165;s:18:"report/sale_coupon";i:166;s:17:"report/sale_order";i:167;s:18:"report/sale_return";i:168;s:20:"report/sale_shipping";i:169;s:15:"report/sale_tax";i:170;s:17:"sale/custom_field";i:171;s:13:"sale/customer";i:172;s:20:"sale/customer_ban_ip";i:173;s:19:"sale/customer_group";i:174;s:10:"sale/order";i:175;s:14:"sale/recurring";i:176;s:11:"sale/return";i:177;s:12:"sale/voucher";i:178;s:18:"sale/voucher_theme";i:179;s:15:"setting/setting";i:180;s:13:"setting/store";i:181;s:16:"shipping/auspost";i:182;s:17:"shipping/citylink";i:183;s:14:"shipping/fedex";i:184;s:13:"shipping/flat";i:185;s:13:"shipping/free";i:186;s:13:"shipping/item";i:187;s:23:"shipping/parcelforce_48";i:188;s:15:"shipping/pickup";i:189;s:19:"shipping/royal_mail";i:190;s:12:"shipping/ups";i:191;s:13:"shipping/usps";i:192;s:15:"shipping/weight";i:193;s:11:"tool/backup";i:194;s:14:"tool/error_log";i:195;s:11:"tool/upload";i:196;s:12:"total/coupon";i:197;s:12:"total/credit";i:198;s:14:"total/handling";i:199;s:16:"total/klarna_fee";i:200;s:19:"total/low_order_fee";i:201;s:12:"total/reward";i:202;s:14:"total/shipping";i:203;s:15:"total/sub_total";i:204;s:9:"total/tax";i:205;s:11:"total/total";i:206;s:13:"total/voucher";i:207;s:8:"user/api";i:208;s:9:"user/user";i:209;s:20:"user/user_permission";i:210;s:27:"user/user_permission_custom";}s:6:"modify";a:211:{i:0;s:11:"boxme/order";i:1;s:13:"boxme/product";i:2;s:13:"boxme/setting";i:3;s:15:"boxme/warehouse";i:4;s:17:"catalog/attribute";i:5;s:23:"catalog/attribute_group";i:6;s:26:"catalog/attribute_relative";i:7;s:16:"catalog/category";i:8;s:16:"catalog/download";i:9;s:14:"catalog/filter";i:10;s:17:"catalog/gallimage";i:11;s:19:"catalog/information";i:12;s:20:"catalog/manufacturer";i:13;s:14:"catalog/option";i:14;s:15:"catalog/product";i:15;s:17:"catalog/recurring";i:16;s:14:"catalog/review";i:17;s:20:"common/chili_setting";i:18;s:18:"common/column_left";i:19;s:18:"common/filemanager";i:20;s:11:"common/menu";i:21;s:17:"common/newsletter";i:22;s:14:"common/profile";i:23;s:14:"common/setting";i:24;s:12:"common/stats";i:25;s:25:"content_html/content_html";i:26;s:25:"dashboard/chili_dashboard";i:27;s:13:"design/banner";i:28;s:13:"design/layout";i:29;s:11:"design/menu";i:30;s:14:"extension/feed";i:31;s:15:"extension/fraud";i:32;s:19:"extension/installer";i:33;s:22:"extension/modification";i:34;s:16:"extension/module";i:35;s:17:"extension/openbay";i:36;s:17:"extension/payment";i:37;s:18:"extension/shipping";i:38;s:15:"extension/total";i:39;s:16:"feed/google_base";i:40;s:19:"feed/google_sitemap";i:41;s:23:"feed/image_manager_plus";i:42;s:15:"feed/openbaypro";i:43;s:18:"fraud/fraudlabspro";i:44;s:13:"fraud/maxmind";i:45;s:27:"getting_start/getting_start";i:46;s:20:"google_maps/location";i:47;s:21:"google_maps/mapmodule";i:48;s:20:"localisation/country";i:49;s:21:"localisation/currency";i:50;s:21:"localisation/geo_zone";i:51;s:21:"localisation/language";i:52;s:25:"localisation/length_class";i:53;s:21:"localisation/location";i:54;s:25:"localisation/order_status";i:55;s:26:"localisation/return_action";i:56;s:26:"localisation/return_reason";i:57;s:26:"localisation/return_status";i:58;s:25:"localisation/stock_status";i:59;s:22:"localisation/tax_class";i:60;s:21:"localisation/tax_rate";i:61;s:25:"localisation/weight_class";i:62;s:17:"localisation/zone";i:63;s:15:"loginauto/login";i:64;s:19:"marketing/affiliate";i:65;s:17:"marketing/contact";i:66;s:16:"marketing/coupon";i:67;s:19:"marketing/marketing";i:68;s:14:"module/account";i:69;s:16:"module/affiliate";i:70;s:20:"module/amazon_button";i:71;s:19:"module/amazon_login";i:72;s:17:"module/amazon_pay";i:73;s:13:"module/banner";i:74;s:17:"module/bestseller";i:75;s:15:"module/carousel";i:76;s:15:"module/category";i:77;s:19:"module/content_info";i:78;s:22:"module/currency_switch";i:79;s:22:"module/d_quickcheckout";i:80;s:19:"module/ebay_listing";i:81;s:15:"module/featured";i:82;s:13:"module/filter";i:83;s:16:"module/gallimage";i:84;s:22:"module/google_hangouts";i:85;s:18:"module/google_maps";i:86;s:11:"module/html";i:87;s:18:"module/information";i:88;s:22:"module/language_switch";i:89;s:13:"module/latest";i:90;s:14:"module/mb_logo";i:91;s:19:"module/mb_mini_cart";i:92;s:16:"module/mb_search";i:93;s:11:"module/menu";i:94;s:17:"module/module_col";i:95;s:18:"module/newsletters";i:96;s:16:"module/pp_button";i:97;s:15:"module/pp_login";i:98;s:24:"module/revslideropencart";i:99;s:22:"module/revslideroutput";i:100;s:19:"module/showinconfig";i:101;s:17:"module/showintabs";i:102;s:16:"module/slideshow";i:103;s:14:"module/special";i:104;s:12:"module/store";i:105;s:20:"module/visualbuilder";i:106;s:22:"openbay/amazon_product";i:107;s:16:"openbay/amazonus";i:108;s:24:"openbay/amazonus_product";i:109;s:21:"openbay/ebay_template";i:110;s:12:"openbay/etsy";i:111;s:21:"openbay/etsy_shipping";i:112;s:23:"payment/amazon_checkout";i:113;s:24:"payment/amazon_login_pay";i:114;s:24:"payment/authorizenet_aim";i:115;s:24:"payment/authorizenet_sim";i:116;s:21:"payment/bank_transfer";i:117;s:22:"payment/bluepay_hosted";i:118;s:24:"payment/bluepay_redirect";i:119;s:14:"payment/cheque";i:120;s:11:"payment/cod";i:121;s:17:"payment/firstdata";i:122;s:24:"payment/firstdata_remote";i:123;s:21:"payment/free_checkout";i:124;s:14:"payment/g2apay";i:125;s:17:"payment/globalpay";i:126;s:24:"payment/globalpay_remote";i:127;s:22:"payment/klarna_account";i:128;s:22:"payment/klarna_invoice";i:129;s:14:"payment/liqpay";i:130;s:14:"payment/nochex";i:131;s:15:"payment/paymate";i:132;s:16:"payment/paypoint";i:133;s:13:"payment/payza";i:134;s:26:"payment/perpetual_payments";i:135;s:18:"payment/pp_express";i:136;s:18:"payment/pp_payflow";i:137;s:25:"payment/pp_payflow_iframe";i:138;s:14:"payment/pp_pro";i:139;s:21:"payment/pp_pro_iframe";i:140;s:19:"payment/pp_standard";i:141;s:14:"payment/realex";i:142;s:21:"payment/realex_remote";i:143;s:22:"payment/sagepay_direct";i:144;s:22:"payment/sagepay_server";i:145;s:18:"payment/sagepay_us";i:146;s:24:"payment/securetrading_pp";i:147;s:24:"payment/securetrading_ws";i:148;s:14:"payment/skrill";i:149;s:19:"payment/twocheckout";i:150;s:28:"payment/web_payment_software";i:151;s:16:"payment/webmoney";i:152;s:16:"payment/worldpay";i:153;s:16:"report/affiliate";i:154;s:25:"report/affiliate_activity";i:155;s:22:"report/affiliate_login";i:156;s:24:"report/customer_activity";i:157;s:22:"report/customer_credit";i:158;s:21:"report/customer_login";i:159;s:22:"report/customer_online";i:160;s:21:"report/customer_order";i:161;s:22:"report/customer_reward";i:162;s:16:"report/marketing";i:163;s:24:"report/product_purchased";i:164;s:21:"report/product_viewed";i:165;s:18:"report/sale_coupon";i:166;s:17:"report/sale_order";i:167;s:18:"report/sale_return";i:168;s:20:"report/sale_shipping";i:169;s:15:"report/sale_tax";i:170;s:17:"sale/custom_field";i:171;s:13:"sale/customer";i:172;s:20:"sale/customer_ban_ip";i:173;s:19:"sale/customer_group";i:174;s:10:"sale/order";i:175;s:14:"sale/recurring";i:176;s:11:"sale/return";i:177;s:12:"sale/voucher";i:178;s:18:"sale/voucher_theme";i:179;s:15:"setting/setting";i:180;s:13:"setting/store";i:181;s:16:"shipping/auspost";i:182;s:17:"shipping/citylink";i:183;s:14:"shipping/fedex";i:184;s:13:"shipping/flat";i:185;s:13:"shipping/free";i:186;s:13:"shipping/item";i:187;s:23:"shipping/parcelforce_48";i:188;s:15:"shipping/pickup";i:189;s:19:"shipping/royal_mail";i:190;s:12:"shipping/ups";i:191;s:13:"shipping/usps";i:192;s:15:"shipping/weight";i:193;s:11:"tool/backup";i:194;s:14:"tool/error_log";i:195;s:11:"tool/upload";i:196;s:12:"total/coupon";i:197;s:12:"total/credit";i:198;s:14:"total/handling";i:199;s:16:"total/klarna_fee";i:200;s:19:"total/low_order_fee";i:201;s:12:"total/reward";i:202;s:14:"total/shipping";i:203;s:15:"total/sub_total";i:204;s:9:"total/tax";i:205;s:11:"total/total";i:206;s:13:"total/voucher";i:207;s:8:"user/api";i:208;s:9:"user/user";i:209;s:20:"user/user_permission";i:210;s:27:"user/user_permission_custom";}}'),
(10, 'Demonstration', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_voucher`
--

CREATE TABLE `oc_voucher` (
  `voucher_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `code` varchar(10) NOT NULL,
  `from_name` varchar(64) NOT NULL,
  `from_email` varchar(96) NOT NULL,
  `to_name` varchar(64) NOT NULL,
  `to_email` varchar(96) NOT NULL,
  `voucher_theme_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_voucher_history`
--

CREATE TABLE `oc_voucher_history` (
  `voucher_history_id` int(11) NOT NULL,
  `voucher_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_voucher_theme`
--

CREATE TABLE `oc_voucher_theme` (
  `voucher_theme_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_voucher_theme`
--

INSERT INTO `oc_voucher_theme` (`voucher_theme_id`, `image`) VALUES
(8, 'catalog/demo/canon_eos_5d_2.jpg'),
(7, 'catalog/demo/gift-voucher-birthday.jpg'),
(6, 'catalog/demo/apple_logo.jpg'),
(9, 'catalog/demo/gift-voucher-birthday.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `oc_voucher_theme_description`
--

CREATE TABLE `oc_voucher_theme_description` (
  `voucher_theme_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_voucher_theme_description`
--

INSERT INTO `oc_voucher_theme_description` (`voucher_theme_id`, `language_id`, `name`) VALUES
(9, 2, 'Giảm giá thường niên'),
(6, 2, 'Ngày 20/10'),
(7, 2, 'Sinh nhật'),
(8, 2, 'Thông thường');

-- --------------------------------------------------------

--
-- Table structure for table `oc_weight_class`
--

CREATE TABLE `oc_weight_class` (
  `weight_class_id` int(11) NOT NULL,
  `value` decimal(15,8) NOT NULL DEFAULT '0.00000000'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_weight_class`
--

INSERT INTO `oc_weight_class` (`weight_class_id`, `value`) VALUES
(1, '1.00000000'),
(2, '1000.00000000');

-- --------------------------------------------------------

--
-- Table structure for table `oc_weight_class_description`
--

CREATE TABLE `oc_weight_class_description` (
  `weight_class_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `title` varchar(32) NOT NULL,
  `unit` varchar(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_weight_class_description`
--

INSERT INTO `oc_weight_class_description` (`weight_class_id`, `language_id`, `title`, `unit`) VALUES
(1, 2, 'Kilogram', 'kg'),
(2, 2, 'Gram', 'g');

-- --------------------------------------------------------

--
-- Table structure for table `oc_zone`
--

CREATE TABLE `oc_zone` (
  `zone_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `code` varchar(32) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_zone`
--

INSERT INTO `oc_zone` (`zone_id`, `country_id`, `name`, `code`, `status`) VALUES
(1, 1, 'Badakhshan', 'BDS', 1),
(2, 1, 'Badghis', 'BDG', 1),
(3, 1, 'Baghlan', 'BGL', 1),
(4, 1, 'Balkh', 'BAL', 1),
(5, 1, 'Bamian', 'BAM', 1),
(6, 1, 'Farah', 'FRA', 1),
(7, 1, 'Faryab', 'FYB', 1),
(8, 1, 'Ghazni', 'GHA', 1),
(9, 1, 'Ghowr', 'GHO', 1),
(10, 1, 'Helmand', 'HEL', 1),
(11, 1, 'Herat', 'HER', 1),
(12, 1, 'Jowzjan', 'JOW', 1),
(13, 1, 'Kabul', 'KAB', 1),
(14, 1, 'Kandahar', 'KAN', 1),
(15, 1, 'Kapisa', 'KAP', 1),
(16, 1, 'Khost', 'KHO', 1),
(17, 1, 'Konar', 'KNR', 1),
(18, 1, 'Kondoz', 'KDZ', 1),
(19, 1, 'Laghman', 'LAG', 1),
(20, 1, 'Lowgar', 'LOW', 1),
(21, 1, 'Nangrahar', 'NAN', 1),
(22, 1, 'Nimruz', 'NIM', 1),
(23, 1, 'Nurestan', 'NUR', 1),
(24, 1, 'Oruzgan', 'ORU', 1),
(25, 1, 'Paktia', 'PIA', 1),
(26, 1, 'Paktika', 'PKA', 1),
(27, 1, 'Parwan', 'PAR', 1),
(28, 1, 'Samangan', 'SAM', 1),
(29, 1, 'Sar-e Pol', 'SAR', 1),
(30, 1, 'Takhar', 'TAK', 1),
(31, 1, 'Wardak', 'WAR', 1),
(32, 1, 'Zabol', 'ZAB', 1),
(33, 2, 'Berat', 'BR', 1),
(34, 2, 'Bulqize', 'BU', 1),
(35, 2, 'Delvine', 'DL', 1),
(36, 2, 'Devoll', 'DV', 1),
(37, 2, 'Diber', 'DI', 1),
(38, 2, 'Durres', 'DR', 1),
(39, 2, 'Elbasan', 'EL', 1),
(40, 2, 'Kolonje', 'ER', 1),
(41, 2, 'Fier', 'FR', 1),
(42, 2, 'Gjirokaster', 'GJ', 1),
(43, 2, 'Gramsh', 'GR', 1),
(44, 2, 'Has', 'HA', 1),
(45, 2, 'Kavaje', 'KA', 1),
(46, 2, 'Kurbin', 'KB', 1),
(47, 2, 'Kucove', 'KC', 1),
(48, 2, 'Korce', 'KO', 1),
(49, 2, 'Kruje', 'KR', 1),
(50, 2, 'Kukes', 'KU', 1),
(51, 2, 'Librazhd', 'LB', 1),
(52, 2, 'Lezhe', 'LE', 1),
(53, 2, 'Lushnje', 'LU', 1),
(54, 2, 'Malesi e Madhe', 'MM', 1),
(55, 2, 'Mallakaster', 'MK', 1),
(56, 2, 'Mat', 'MT', 1),
(57, 2, 'Mirdite', 'MR', 1),
(58, 2, 'Peqin', 'PQ', 1),
(59, 2, 'Permet', 'PR', 1),
(60, 2, 'Pogradec', 'PG', 1),
(61, 2, 'Puke', 'PU', 1),
(62, 2, 'Shkoder', 'SH', 1),
(63, 2, 'Skrapar', 'SK', 1),
(64, 2, 'Sarande', 'SR', 1),
(65, 2, 'Tepelene', 'TE', 1),
(66, 2, 'Tropoje', 'TP', 1),
(67, 2, 'Tirane', 'TR', 1),
(68, 2, 'Vlore', 'VL', 1),
(69, 3, 'Adrar', 'ADR', 1),
(70, 3, 'Ain Defla', 'ADE', 1),
(71, 3, 'Ain Temouchent', 'ATE', 1),
(72, 3, 'Alger', 'ALG', 1),
(73, 3, 'Annaba', 'ANN', 1),
(74, 3, 'Batna', 'BAT', 1),
(75, 3, 'Bechar', 'BEC', 1),
(76, 3, 'Bejaia', 'BEJ', 1),
(77, 3, 'Biskra', 'BIS', 1),
(78, 3, 'Blida', 'BLI', 1),
(79, 3, 'Bordj Bou Arreridj', 'BBA', 1),
(80, 3, 'Bouira', 'BOA', 1),
(81, 3, 'Boumerdes', 'BMD', 1),
(82, 3, 'Chlef', 'CHL', 1),
(83, 3, 'Constantine', 'CON', 1),
(84, 3, 'Djelfa', 'DJE', 1),
(85, 3, 'El Bayadh', 'EBA', 1),
(86, 3, 'El Oued', 'EOU', 1),
(87, 3, 'El Tarf', 'ETA', 1),
(88, 3, 'Ghardaia', 'GHA', 1),
(89, 3, 'Guelma', 'GUE', 1),
(90, 3, 'Illizi', 'ILL', 1),
(91, 3, 'Jijel', 'JIJ', 1),
(92, 3, 'Khenchela', 'KHE', 1),
(93, 3, 'Laghouat', 'LAG', 1),
(94, 3, 'Muaskar', 'MUA', 1),
(95, 3, 'Medea', 'MED', 1),
(96, 3, 'Mila', 'MIL', 1),
(97, 3, 'Mostaganem', 'MOS', 1),
(98, 3, 'M\'Sila', 'MSI', 1),
(99, 3, 'Naama', 'NAA', 1),
(100, 3, 'Oran', 'ORA', 1),
(101, 3, 'Ouargla', 'OUA', 1),
(102, 3, 'Oum el-Bouaghi', 'OEB', 1),
(103, 3, 'Relizane', 'REL', 1),
(104, 3, 'Saida', 'SAI', 1),
(105, 3, 'Setif', 'SET', 1),
(106, 3, 'Sidi Bel Abbes', 'SBA', 1),
(107, 3, 'Skikda', 'SKI', 1),
(108, 3, 'Souk Ahras', 'SAH', 1),
(109, 3, 'Tamanghasset', 'TAM', 1),
(110, 3, 'Tebessa', 'TEB', 1),
(111, 3, 'Tiaret', 'TIA', 1),
(112, 3, 'Tindouf', 'TIN', 1),
(113, 3, 'Tipaza', 'TIP', 1),
(114, 3, 'Tissemsilt', 'TIS', 1),
(115, 3, 'Tizi Ouzou', 'TOU', 1),
(116, 3, 'Tlemcen', 'TLE', 1),
(117, 4, 'Eastern', 'E', 1),
(118, 4, 'Manu\'a', 'M', 1),
(119, 4, 'Rose Island', 'R', 1),
(120, 4, 'Swains Island', 'S', 1),
(121, 4, 'Western', 'W', 1),
(122, 5, 'Andorra la Vella', 'ALV', 1),
(123, 5, 'Canillo', 'CAN', 1),
(124, 5, 'Encamp', 'ENC', 1),
(125, 5, 'Escaldes-Engordany', 'ESE', 1),
(126, 5, 'La Massana', 'LMA', 1),
(127, 5, 'Ordino', 'ORD', 1),
(128, 5, 'Sant Julia de Loria', 'SJL', 1),
(129, 6, 'Bengo', 'BGO', 1),
(130, 6, 'Benguela', 'BGU', 1),
(131, 6, 'Bie', 'BIE', 1),
(132, 6, 'Cabinda', 'CAB', 1),
(133, 6, 'Cuando-Cubango', 'CCU', 1),
(134, 6, 'Cuanza Norte', 'CNO', 1),
(135, 6, 'Cuanza Sul', 'CUS', 1),
(136, 6, 'Cunene', 'CNN', 1),
(137, 6, 'Huambo', 'HUA', 1),
(138, 6, 'Huila', 'HUI', 1),
(139, 6, 'Luanda', 'LUA', 1),
(140, 6, 'Lunda Norte', 'LNO', 1),
(141, 6, 'Lunda Sul', 'LSU', 1),
(142, 6, 'Malange', 'MAL', 1),
(143, 6, 'Moxico', 'MOX', 1),
(144, 6, 'Namibe', 'NAM', 1),
(145, 6, 'Uige', 'UIG', 1),
(146, 6, 'Zaire', 'ZAI', 1),
(147, 9, 'Saint George', 'ASG', 1),
(148, 9, 'Saint John', 'ASJ', 1),
(149, 9, 'Saint Mary', 'ASM', 1),
(150, 9, 'Saint Paul', 'ASL', 1),
(151, 9, 'Saint Peter', 'ASR', 1),
(152, 9, 'Saint Philip', 'ASH', 1),
(153, 9, 'Barbuda', 'BAR', 1),
(154, 9, 'Redonda', 'RED', 1),
(155, 10, 'Antartida e Islas del Atlantico', 'AN', 1),
(156, 10, 'Buenos Aires', 'BA', 1),
(157, 10, 'Catamarca', 'CA', 1),
(158, 10, 'Chaco', 'CH', 1),
(159, 10, 'Chubut', 'CU', 1),
(160, 10, 'Cordoba', 'CO', 1),
(161, 10, 'Corrientes', 'CR', 1),
(162, 10, 'Distrito Federal', 'DF', 1),
(163, 10, 'Entre Rios', 'ER', 1),
(164, 10, 'Formosa', 'FO', 1),
(165, 10, 'Jujuy', 'JU', 1),
(166, 10, 'La Pampa', 'LP', 1),
(167, 10, 'La Rioja', 'LR', 1),
(168, 10, 'Mendoza', 'ME', 1),
(169, 10, 'Misiones', 'MI', 1),
(170, 10, 'Neuquen', 'NE', 1),
(171, 10, 'Rio Negro', 'RN', 1),
(172, 10, 'Salta', 'SA', 1),
(173, 10, 'San Juan', 'SJ', 1),
(174, 10, 'San Luis', 'SL', 1),
(175, 10, 'Santa Cruz', 'SC', 1),
(176, 10, 'Santa Fe', 'SF', 1),
(177, 10, 'Santiago del Estero', 'SD', 1),
(178, 10, 'Tierra del Fuego', 'TF', 1),
(179, 10, 'Tucuman', 'TU', 1),
(180, 11, 'Aragatsotn', 'AGT', 1),
(181, 11, 'Ararat', 'ARR', 1),
(182, 11, 'Armavir', 'ARM', 1),
(183, 11, 'Geghark\'unik\'', 'GEG', 1),
(184, 11, 'Kotayk\'', 'KOT', 1),
(185, 11, 'Lorri', 'LOR', 1),
(186, 11, 'Shirak', 'SHI', 1),
(187, 11, 'Syunik\'', 'SYU', 1),
(188, 11, 'Tavush', 'TAV', 1),
(189, 11, 'Vayots\' Dzor', 'VAY', 1),
(190, 11, 'Yerevan', 'YER', 1),
(191, 13, 'Australian Capital Territory', 'ACT', 1),
(192, 13, 'New South Wales', 'NSW', 1),
(193, 13, 'Northern Territory', 'NT', 1),
(194, 13, 'Queensland', 'QLD', 1),
(195, 13, 'South Australia', 'SA', 1),
(196, 13, 'Tasmania', 'TAS', 1),
(197, 13, 'Victoria', 'VIC', 1),
(198, 13, 'Western Australia', 'WA', 1),
(199, 14, 'Burgenland', 'BUR', 1),
(200, 14, 'Kärnten', 'KAR', 1),
(201, 14, 'Nieder&ouml;sterreich', 'NOS', 1),
(202, 14, 'Ober&ouml;sterreich', 'OOS', 1),
(203, 14, 'Salzburg', 'SAL', 1),
(204, 14, 'Steiermark', 'STE', 1),
(205, 14, 'Tirol', 'TIR', 1),
(206, 14, 'Vorarlberg', 'VOR', 1),
(207, 14, 'Wien', 'WIE', 1),
(208, 15, 'Ali Bayramli', 'AB', 1),
(209, 15, 'Abseron', 'ABS', 1),
(210, 15, 'AgcabAdi', 'AGC', 1),
(211, 15, 'Agdam', 'AGM', 1),
(212, 15, 'Agdas', 'AGS', 1),
(213, 15, 'Agstafa', 'AGA', 1),
(214, 15, 'Agsu', 'AGU', 1),
(215, 15, 'Astara', 'AST', 1),
(216, 15, 'Baki', 'BA', 1),
(217, 15, 'BabAk', 'BAB', 1),
(218, 15, 'BalakAn', 'BAL', 1),
(219, 15, 'BArdA', 'BAR', 1),
(220, 15, 'Beylaqan', 'BEY', 1),
(221, 15, 'Bilasuvar', 'BIL', 1),
(222, 15, 'Cabrayil', 'CAB', 1),
(223, 15, 'Calilabab', 'CAL', 1),
(224, 15, 'Culfa', 'CUL', 1),
(225, 15, 'Daskasan', 'DAS', 1),
(226, 15, 'Davaci', 'DAV', 1),
(227, 15, 'Fuzuli', 'FUZ', 1),
(228, 15, 'Ganca', 'GA', 1),
(229, 15, 'Gadabay', 'GAD', 1),
(230, 15, 'Goranboy', 'GOR', 1),
(231, 15, 'Goycay', 'GOY', 1),
(232, 15, 'Haciqabul', 'HAC', 1),
(233, 15, 'Imisli', 'IMI', 1),
(234, 15, 'Ismayilli', 'ISM', 1),
(235, 15, 'Kalbacar', 'KAL', 1),
(236, 15, 'Kurdamir', 'KUR', 1),
(237, 15, 'Lankaran', 'LA', 1),
(238, 15, 'Lacin', 'LAC', 1),
(239, 15, 'Lankaran', 'LAN', 1),
(240, 15, 'Lerik', 'LER', 1),
(241, 15, 'Masalli', 'MAS', 1),
(242, 15, 'Mingacevir', 'MI', 1),
(243, 15, 'Naftalan', 'NA', 1),
(244, 15, 'Neftcala', 'NEF', 1),
(245, 15, 'Oguz', 'OGU', 1),
(246, 15, 'Ordubad', 'ORD', 1),
(247, 15, 'Qabala', 'QAB', 1),
(248, 15, 'Qax', 'QAX', 1),
(249, 15, 'Qazax', 'QAZ', 1),
(250, 15, 'Qobustan', 'QOB', 1),
(251, 15, 'Quba', 'QBA', 1),
(252, 15, 'Qubadli', 'QBI', 1),
(253, 15, 'Qusar', 'QUS', 1),
(254, 15, 'Saki', 'SA', 1),
(255, 15, 'Saatli', 'SAT', 1),
(256, 15, 'Sabirabad', 'SAB', 1),
(257, 15, 'Sadarak', 'SAD', 1),
(258, 15, 'Sahbuz', 'SAH', 1),
(259, 15, 'Saki', 'SAK', 1),
(260, 15, 'Salyan', 'SAL', 1),
(261, 15, 'Sumqayit', 'SM', 1),
(262, 15, 'Samaxi', 'SMI', 1),
(263, 15, 'Samkir', 'SKR', 1),
(264, 15, 'Samux', 'SMX', 1),
(265, 15, 'Sarur', 'SAR', 1),
(266, 15, 'Siyazan', 'SIY', 1),
(267, 15, 'Susa', 'SS', 1),
(268, 15, 'Susa', 'SUS', 1),
(269, 15, 'Tartar', 'TAR', 1),
(270, 15, 'Tovuz', 'TOV', 1),
(271, 15, 'Ucar', 'UCA', 1),
(272, 15, 'Xankandi', 'XA', 1),
(273, 15, 'Xacmaz', 'XAC', 1),
(274, 15, 'Xanlar', 'XAN', 1),
(275, 15, 'Xizi', 'XIZ', 1),
(276, 15, 'Xocali', 'XCI', 1),
(277, 15, 'Xocavand', 'XVD', 1),
(278, 15, 'Yardimli', 'YAR', 1),
(279, 15, 'Yevlax', 'YEV', 1),
(280, 15, 'Zangilan', 'ZAN', 1),
(281, 15, 'Zaqatala', 'ZAQ', 1),
(282, 15, 'Zardab', 'ZAR', 1),
(283, 15, 'Naxcivan', 'NX', 1),
(284, 16, 'Acklins', 'ACK', 1),
(285, 16, 'Berry Islands', 'BER', 1),
(286, 16, 'Bimini', 'BIM', 1),
(287, 16, 'Black Point', 'BLK', 1),
(288, 16, 'Cat Island', 'CAT', 1),
(289, 16, 'Central Abaco', 'CAB', 1),
(290, 16, 'Central Andros', 'CAN', 1),
(291, 16, 'Central Eleuthera', 'CEL', 1),
(292, 16, 'City of Freeport', 'FRE', 1),
(293, 16, 'Crooked Island', 'CRO', 1),
(294, 16, 'East Grand Bahama', 'EGB', 1),
(295, 16, 'Exuma', 'EXU', 1),
(296, 16, 'Grand Cay', 'GRD', 1),
(297, 16, 'Harbour Island', 'HAR', 1),
(298, 16, 'Hope Town', 'HOP', 1),
(299, 16, 'Inagua', 'INA', 1),
(300, 16, 'Long Island', 'LNG', 1),
(301, 16, 'Mangrove Cay', 'MAN', 1),
(302, 16, 'Mayaguana', 'MAY', 1),
(303, 16, 'Moore\'s Island', 'MOO', 1),
(304, 16, 'North Abaco', 'NAB', 1),
(305, 16, 'North Andros', 'NAN', 1),
(306, 16, 'North Eleuthera', 'NEL', 1),
(307, 16, 'Ragged Island', 'RAG', 1),
(308, 16, 'Rum Cay', 'RUM', 1),
(309, 16, 'San Salvador', 'SAL', 1),
(310, 16, 'South Abaco', 'SAB', 1),
(311, 16, 'South Andros', 'SAN', 1),
(312, 16, 'South Eleuthera', 'SEL', 1),
(313, 16, 'Spanish Wells', 'SWE', 1),
(314, 16, 'West Grand Bahama', 'WGB', 1),
(315, 17, 'Capital', 'CAP', 1),
(316, 17, 'Central', 'CEN', 1),
(317, 17, 'Muharraq', 'MUH', 1),
(318, 17, 'Northern', 'NOR', 1),
(319, 17, 'Southern', 'SOU', 1),
(320, 18, 'Barisal', 'BAR', 1),
(321, 18, 'Chittagong', 'CHI', 1),
(322, 18, 'Dhaka', 'DHA', 1),
(323, 18, 'Khulna', 'KHU', 1),
(324, 18, 'Rajshahi', 'RAJ', 1),
(325, 18, 'Sylhet', 'SYL', 1),
(326, 19, 'Christ Church', 'CC', 1),
(327, 19, 'Saint Andrew', 'AND', 1),
(328, 19, 'Saint George', 'GEO', 1),
(329, 19, 'Saint James', 'JAM', 1),
(330, 19, 'Saint John', 'JOH', 1),
(331, 19, 'Saint Joseph', 'JOS', 1),
(332, 19, 'Saint Lucy', 'LUC', 1),
(333, 19, 'Saint Michael', 'MIC', 1),
(334, 19, 'Saint Peter', 'PET', 1),
(335, 19, 'Saint Philip', 'PHI', 1),
(336, 19, 'Saint Thomas', 'THO', 1),
(337, 20, 'Brestskaya (Brest)', 'BR', 1),
(338, 20, 'Homyel\'skaya (Homyel\')', 'HO', 1),
(339, 20, 'Horad Minsk', 'HM', 1),
(340, 20, 'Hrodzyenskaya (Hrodna)', 'HR', 1),
(341, 20, 'Mahilyowskaya (Mahilyow)', 'MA', 1),
(342, 20, 'Minskaya', 'MI', 1),
(343, 20, 'Vitsyebskaya (Vitsyebsk)', 'VI', 1),
(344, 21, 'Antwerpen', 'VAN', 1),
(345, 21, 'Brabant Wallon', 'WBR', 1),
(346, 21, 'Hainaut', 'WHT', 1),
(347, 21, 'Liège', 'WLG', 1),
(348, 21, 'Limburg', 'VLI', 1),
(349, 21, 'Luxembourg', 'WLX', 1),
(350, 21, 'Namur', 'WNA', 1),
(351, 21, 'Oost-Vlaanderen', 'VOV', 1),
(352, 21, 'Vlaams Brabant', 'VBR', 1),
(353, 21, 'West-Vlaanderen', 'VWV', 1),
(354, 22, 'Belize', 'BZ', 1),
(355, 22, 'Cayo', 'CY', 1),
(356, 22, 'Corozal', 'CR', 1),
(357, 22, 'Orange Walk', 'OW', 1),
(358, 22, 'Stann Creek', 'SC', 1),
(359, 22, 'Toledo', 'TO', 1),
(360, 23, 'Alibori', 'AL', 1),
(361, 23, 'Atakora', 'AK', 1),
(362, 23, 'Atlantique', 'AQ', 1),
(363, 23, 'Borgou', 'BO', 1),
(364, 23, 'Collines', 'CO', 1),
(365, 23, 'Donga', 'DO', 1),
(366, 23, 'Kouffo', 'KO', 1),
(367, 23, 'Littoral', 'LI', 1),
(368, 23, 'Mono', 'MO', 1),
(369, 23, 'Oueme', 'OU', 1),
(370, 23, 'Plateau', 'PL', 1),
(371, 23, 'Zou', 'ZO', 1),
(372, 24, 'Devonshire', 'DS', 1),
(373, 24, 'Hamilton City', 'HC', 1),
(374, 24, 'Hamilton', 'HA', 1),
(375, 24, 'Paget', 'PG', 1),
(376, 24, 'Pembroke', 'PB', 1),
(377, 24, 'Saint George City', 'GC', 1),
(378, 24, 'Saint George\'s', 'SG', 1),
(379, 24, 'Sandys', 'SA', 1),
(380, 24, 'Smith\'s', 'SM', 1),
(381, 24, 'Southampton', 'SH', 1),
(382, 24, 'Warwick', 'WA', 1),
(383, 25, 'Bumthang', 'BUM', 1),
(384, 25, 'Chukha', 'CHU', 1),
(385, 25, 'Dagana', 'DAG', 1),
(386, 25, 'Gasa', 'GAS', 1),
(387, 25, 'Haa', 'HAA', 1),
(388, 25, 'Lhuntse', 'LHU', 1),
(389, 25, 'Mongar', 'MON', 1),
(390, 25, 'Paro', 'PAR', 1),
(391, 25, 'Pemagatshel', 'PEM', 1),
(392, 25, 'Punakha', 'PUN', 1),
(393, 25, 'Samdrup Jongkhar', 'SJO', 1),
(394, 25, 'Samtse', 'SAT', 1),
(395, 25, 'Sarpang', 'SAR', 1),
(396, 25, 'Thimphu', 'THI', 1),
(397, 25, 'Trashigang', 'TRG', 1),
(398, 25, 'Trashiyangste', 'TRY', 1),
(399, 25, 'Trongsa', 'TRO', 1),
(400, 25, 'Tsirang', 'TSI', 1),
(401, 25, 'Wangdue Phodrang', 'WPH', 1),
(402, 25, 'Zhemgang', 'ZHE', 1),
(403, 26, 'Beni', 'BEN', 1),
(404, 26, 'Chuquisaca', 'CHU', 1),
(405, 26, 'Cochabamba', 'COC', 1),
(406, 26, 'La Paz', 'LPZ', 1),
(407, 26, 'Oruro', 'ORU', 1),
(408, 26, 'Pando', 'PAN', 1),
(409, 26, 'Potosi', 'POT', 1),
(410, 26, 'Santa Cruz', 'SCZ', 1),
(411, 26, 'Tarija', 'TAR', 1),
(412, 27, 'Brcko district', 'BRO', 1),
(413, 27, 'Unsko-Sanski Kanton', 'FUS', 1),
(414, 27, 'Posavski Kanton', 'FPO', 1),
(415, 27, 'Tuzlanski Kanton', 'FTU', 1),
(416, 27, 'Zenicko-Dobojski Kanton', 'FZE', 1),
(417, 27, 'Bosanskopodrinjski Kanton', 'FBP', 1),
(418, 27, 'Srednjebosanski Kanton', 'FSB', 1),
(419, 27, 'Hercegovacko-neretvanski Kanton', 'FHN', 1),
(420, 27, 'Zapadnohercegovacka Zupanija', 'FZH', 1),
(421, 27, 'Kanton Sarajevo', 'FSA', 1),
(422, 27, 'Zapadnobosanska', 'FZA', 1),
(423, 27, 'Banja Luka', 'SBL', 1),
(424, 27, 'Doboj', 'SDO', 1),
(425, 27, 'Bijeljina', 'SBI', 1),
(426, 27, 'Vlasenica', 'SVL', 1),
(427, 27, 'Sarajevo-Romanija or Sokolac', 'SSR', 1),
(428, 27, 'Foca', 'SFO', 1),
(429, 27, 'Trebinje', 'STR', 1),
(430, 28, 'Central', 'CE', 1),
(431, 28, 'Ghanzi', 'GH', 1),
(432, 28, 'Kgalagadi', 'KD', 1),
(433, 28, 'Kgatleng', 'KT', 1),
(434, 28, 'Kweneng', 'KW', 1),
(435, 28, 'Ngamiland', 'NG', 1),
(436, 28, 'North East', 'NE', 1),
(437, 28, 'North West', 'NW', 1),
(438, 28, 'South East', 'SE', 1),
(439, 28, 'Southern', 'SO', 1),
(440, 30, 'Acre', 'AC', 1),
(441, 30, 'Alagoas', 'AL', 1),
(442, 30, 'Amapá', 'AP', 1),
(443, 30, 'Amazonas', 'AM', 1),
(444, 30, 'Bahia', 'BA', 1),
(445, 30, 'Ceará', 'CE', 1),
(446, 30, 'Distrito Federal', 'DF', 1),
(447, 30, 'Espírito Santo', 'ES', 1),
(448, 30, 'Goiás', 'GO', 1),
(449, 30, 'Maranhão', 'MA', 1),
(450, 30, 'Mato Grosso', 'MT', 1),
(451, 30, 'Mato Grosso do Sul', 'MS', 1),
(452, 30, 'Minas Gerais', 'MG', 1),
(453, 30, 'Pará', 'PA', 1),
(454, 30, 'Paraíba', 'PB', 1),
(455, 30, 'Paraná', 'PR', 1),
(456, 30, 'Pernambuco', 'PE', 1),
(457, 30, 'Piauí', 'PI', 1),
(458, 30, 'Rio de Janeiro', 'RJ', 1),
(459, 30, 'Rio Grande do Norte', 'RN', 1),
(460, 30, 'Rio Grande do Sul', 'RS', 1),
(461, 30, 'Rondônia', 'RO', 1),
(462, 30, 'Roraima', 'RR', 1),
(463, 30, 'Santa Catarina', 'SC', 1),
(464, 30, 'São Paulo', 'SP', 1),
(465, 30, 'Sergipe', 'SE', 1),
(466, 30, 'Tocantins', 'TO', 1),
(467, 31, 'Peros Banhos', 'PB', 1),
(468, 31, 'Salomon Islands', 'SI', 1),
(469, 31, 'Nelsons Island', 'NI', 1),
(470, 31, 'Three Brothers', 'TB', 1),
(471, 31, 'Eagle Islands', 'EA', 1),
(472, 31, 'Danger Island', 'DI', 1),
(473, 31, 'Egmont Islands', 'EG', 1),
(474, 31, 'Diego Garcia', 'DG', 1),
(475, 32, 'Belait', 'BEL', 1),
(476, 32, 'Brunei and Muara', 'BRM', 1),
(477, 32, 'Temburong', 'TEM', 1),
(478, 32, 'Tutong', 'TUT', 1),
(479, 33, 'Blagoevgrad', '', 1),
(480, 33, 'Burgas', '', 1),
(481, 33, 'Dobrich', '', 1),
(482, 33, 'Gabrovo', '', 1),
(483, 33, 'Haskovo', '', 1),
(484, 33, 'Kardjali', '', 1),
(485, 33, 'Kyustendil', '', 1),
(486, 33, 'Lovech', '', 1),
(487, 33, 'Montana', '', 1),
(488, 33, 'Pazardjik', '', 1),
(489, 33, 'Pernik', '', 1),
(490, 33, 'Pleven', '', 1),
(491, 33, 'Plovdiv', '', 1),
(492, 33, 'Razgrad', '', 1),
(493, 33, 'Shumen', '', 1),
(494, 33, 'Silistra', '', 1),
(495, 33, 'Sliven', '', 1),
(496, 33, 'Smolyan', '', 1),
(497, 33, 'Sofia', '', 1),
(498, 33, 'Sofia - town', '', 1),
(499, 33, 'Stara Zagora', '', 1),
(500, 33, 'Targovishte', '', 1),
(501, 33, 'Varna', '', 1),
(502, 33, 'Veliko Tarnovo', '', 1),
(503, 33, 'Vidin', '', 1),
(504, 33, 'Vratza', '', 1),
(505, 33, 'Yambol', '', 1),
(506, 34, 'Bale', 'BAL', 1),
(507, 34, 'Bam', 'BAM', 1),
(508, 34, 'Banwa', 'BAN', 1),
(509, 34, 'Bazega', 'BAZ', 1),
(510, 34, 'Bougouriba', 'BOR', 1),
(511, 34, 'Boulgou', 'BLG', 1),
(512, 34, 'Boulkiemde', 'BOK', 1),
(513, 34, 'Comoe', 'COM', 1),
(514, 34, 'Ganzourgou', 'GAN', 1),
(515, 34, 'Gnagna', 'GNA', 1),
(516, 34, 'Gourma', 'GOU', 1),
(517, 34, 'Houet', 'HOU', 1),
(518, 34, 'Ioba', 'IOA', 1),
(519, 34, 'Kadiogo', 'KAD', 1),
(520, 34, 'Kenedougou', 'KEN', 1),
(521, 34, 'Komondjari', 'KOD', 1),
(522, 34, 'Kompienga', 'KOP', 1),
(523, 34, 'Kossi', 'KOS', 1),
(524, 34, 'Koulpelogo', 'KOL', 1),
(525, 34, 'Kouritenga', 'KOT', 1),
(526, 34, 'Kourweogo', 'KOW', 1),
(527, 34, 'Leraba', 'LER', 1),
(528, 34, 'Loroum', 'LOR', 1),
(529, 34, 'Mouhoun', 'MOU', 1),
(530, 34, 'Nahouri', 'NAH', 1),
(531, 34, 'Namentenga', 'NAM', 1),
(532, 34, 'Nayala', 'NAY', 1),
(533, 34, 'Noumbiel', 'NOU', 1),
(534, 34, 'Oubritenga', 'OUB', 1),
(535, 34, 'Oudalan', 'OUD', 1),
(536, 34, 'Passore', 'PAS', 1),
(537, 34, 'Poni', 'PON', 1),
(538, 34, 'Sanguie', 'SAG', 1),
(539, 34, 'Sanmatenga', 'SAM', 1),
(540, 34, 'Seno', 'SEN', 1),
(541, 34, 'Sissili', 'SIS', 1),
(542, 34, 'Soum', 'SOM', 1),
(543, 34, 'Sourou', 'SOR', 1),
(544, 34, 'Tapoa', 'TAP', 1),
(545, 34, 'Tuy', 'TUY', 1),
(546, 34, 'Yagha', 'YAG', 1),
(547, 34, 'Yatenga', 'YAT', 1),
(548, 34, 'Ziro', 'ZIR', 1),
(549, 34, 'Zondoma', 'ZOD', 1),
(550, 34, 'Zoundweogo', 'ZOW', 1),
(551, 35, 'Bubanza', 'BB', 1),
(552, 35, 'Bujumbura', 'BJ', 1),
(553, 35, 'Bururi', 'BR', 1),
(554, 35, 'Cankuzo', 'CA', 1),
(555, 35, 'Cibitoke', 'CI', 1),
(556, 35, 'Gitega', 'GI', 1),
(557, 35, 'Karuzi', 'KR', 1),
(558, 35, 'Kayanza', 'KY', 1),
(559, 35, 'Kirundo', 'KI', 1),
(560, 35, 'Makamba', 'MA', 1),
(561, 35, 'Muramvya', 'MU', 1),
(562, 35, 'Muyinga', 'MY', 1),
(563, 35, 'Mwaro', 'MW', 1),
(564, 35, 'Ngozi', 'NG', 1),
(565, 35, 'Rutana', 'RT', 1),
(566, 35, 'Ruyigi', 'RY', 1),
(567, 36, 'Phnom Penh', 'PP', 1),
(568, 36, 'Preah Seihanu (Kompong Som or Sihanoukville)', 'PS', 1),
(569, 36, 'Pailin', 'PA', 1),
(570, 36, 'Keb', 'KB', 1),
(571, 36, 'Banteay Meanchey', 'BM', 1),
(572, 36, 'Battambang', 'BA', 1),
(573, 36, 'Kampong Cham', 'KM', 1),
(574, 36, 'Kampong Chhnang', 'KN', 1),
(575, 36, 'Kampong Speu', 'KU', 1),
(576, 36, 'Kampong Som', 'KO', 1),
(577, 36, 'Kampong Thom', 'KT', 1),
(578, 36, 'Kampot', 'KP', 1),
(579, 36, 'Kandal', 'KL', 1),
(580, 36, 'Kaoh Kong', 'KK', 1),
(581, 36, 'Kratie', 'KR', 1),
(582, 36, 'Mondul Kiri', 'MK', 1),
(583, 36, 'Oddar Meancheay', 'OM', 1),
(584, 36, 'Pursat', 'PU', 1),
(585, 36, 'Preah Vihear', 'PR', 1),
(586, 36, 'Prey Veng', 'PG', 1),
(587, 36, 'Ratanak Kiri', 'RK', 1),
(588, 36, 'Siemreap', 'SI', 1),
(589, 36, 'Stung Treng', 'ST', 1),
(590, 36, 'Svay Rieng', 'SR', 1),
(591, 36, 'Takeo', 'TK', 1),
(592, 37, 'Adamawa (Adamaoua)', 'ADA', 1),
(593, 37, 'Centre', 'CEN', 1),
(594, 37, 'East (Est)', 'EST', 1),
(595, 37, 'Extreme North (Extreme-Nord)', 'EXN', 1),
(596, 37, 'Littoral', 'LIT', 1),
(597, 37, 'North (Nord)', 'NOR', 1),
(598, 37, 'Northwest (Nord-Ouest)', 'NOT', 1),
(599, 37, 'West (Ouest)', 'OUE', 1),
(600, 37, 'South (Sud)', 'SUD', 1),
(601, 37, 'Southwest (Sud-Ouest).', 'SOU', 1),
(602, 38, 'Alberta', 'AB', 1),
(603, 38, 'British Columbia', 'BC', 1),
(604, 38, 'Manitoba', 'MB', 1),
(605, 38, 'New Brunswick', 'NB', 1),
(606, 38, 'Newfoundland and Labrador', 'NL', 1),
(607, 38, 'Northwest Territories', 'NT', 1),
(608, 38, 'Nova Scotia', 'NS', 1),
(609, 38, 'Nunavut', 'NU', 1),
(610, 38, 'Ontario', 'ON', 1),
(611, 38, 'Prince Edward Island', 'PE', 1),
(612, 38, 'Qu&eacute;bec', 'QC', 1),
(613, 38, 'Saskatchewan', 'SK', 1),
(614, 38, 'Yukon Territory', 'YT', 1),
(615, 39, 'Boa Vista', 'BV', 1),
(616, 39, 'Brava', 'BR', 1),
(617, 39, 'Calheta de Sao Miguel', 'CS', 1),
(618, 39, 'Maio', 'MA', 1),
(619, 39, 'Mosteiros', 'MO', 1),
(620, 39, 'Paul', 'PA', 1),
(621, 39, 'Porto Novo', 'PN', 1),
(622, 39, 'Praia', 'PR', 1),
(623, 39, 'Ribeira Grande', 'RG', 1),
(624, 39, 'Sal', 'SL', 1),
(625, 39, 'Santa Catarina', 'CA', 1),
(626, 39, 'Santa Cruz', 'CR', 1),
(627, 39, 'Sao Domingos', 'SD', 1),
(628, 39, 'Sao Filipe', 'SF', 1),
(629, 39, 'Sao Nicolau', 'SN', 1),
(630, 39, 'Sao Vicente', 'SV', 1),
(631, 39, 'Tarrafal', 'TA', 1),
(632, 40, 'Creek', 'CR', 1),
(633, 40, 'Eastern', 'EA', 1),
(634, 40, 'Midland', 'ML', 1),
(635, 40, 'South Town', 'ST', 1),
(636, 40, 'Spot Bay', 'SP', 1),
(637, 40, 'Stake Bay', 'SK', 1),
(638, 40, 'West End', 'WD', 1),
(639, 40, 'Western', 'WN', 1),
(640, 41, 'Bamingui-Bangoran', 'BBA', 1),
(641, 41, 'Basse-Kotto', 'BKO', 1),
(642, 41, 'Haute-Kotto', 'HKO', 1),
(643, 41, 'Haut-Mbomou', 'HMB', 1),
(644, 41, 'Kemo', 'KEM', 1),
(645, 41, 'Lobaye', 'LOB', 1),
(646, 41, 'Mambere-KadeÔ', 'MKD', 1),
(647, 41, 'Mbomou', 'MBO', 1),
(648, 41, 'Nana-Mambere', 'NMM', 1),
(649, 41, 'Ombella-M\'Poko', 'OMP', 1),
(650, 41, 'Ouaka', 'OUK', 1),
(651, 41, 'Ouham', 'OUH', 1),
(652, 41, 'Ouham-Pende', 'OPE', 1),
(653, 41, 'Vakaga', 'VAK', 1),
(654, 41, 'Nana-Grebizi', 'NGR', 1),
(655, 41, 'Sangha-Mbaere', 'SMB', 1),
(656, 41, 'Bangui', 'BAN', 1),
(657, 42, 'Batha', 'BA', 1),
(658, 42, 'Biltine', 'BI', 1),
(659, 42, 'Borkou-Ennedi-Tibesti', 'BE', 1),
(660, 42, 'Chari-Baguirmi', 'CB', 1),
(661, 42, 'Guera', 'GU', 1),
(662, 42, 'Kanem', 'KA', 1),
(663, 42, 'Lac', 'LA', 1),
(664, 42, 'Logone Occidental', 'LC', 1),
(665, 42, 'Logone Oriental', 'LR', 1),
(666, 42, 'Mayo-Kebbi', 'MK', 1),
(667, 42, 'Moyen-Chari', 'MC', 1),
(668, 42, 'Ouaddai', 'OU', 1),
(669, 42, 'Salamat', 'SA', 1),
(670, 42, 'Tandjile', 'TA', 1),
(671, 43, 'Aisen del General Carlos Ibanez', 'AI', 1),
(672, 43, 'Antofagasta', 'AN', 1),
(673, 43, 'Araucania', 'AR', 1),
(674, 43, 'Atacama', 'AT', 1),
(675, 43, 'Bio-Bio', 'BI', 1),
(676, 43, 'Coquimbo', 'CO', 1),
(677, 43, 'Libertador General Bernardo O\'Higgins', 'LI', 1),
(678, 43, 'Los Lagos', 'LL', 1),
(679, 43, 'Magallanes y de la Antartica Chilena', 'MA', 1),
(680, 43, 'Maule', 'ML', 1),
(681, 43, 'Region Metropolitana', 'RM', 1),
(682, 43, 'Tarapaca', 'TA', 1),
(683, 43, 'Valparaiso', 'VS', 1),
(684, 44, 'Anhui', 'AN', 1),
(685, 44, 'Beijing', 'BE', 1),
(686, 44, 'Chongqing', 'CH', 1),
(687, 44, 'Fujian', 'FU', 1),
(688, 44, 'Gansu', 'GA', 1),
(689, 44, 'Guangdong', 'GU', 1),
(690, 44, 'Guangxi', 'GX', 1),
(691, 44, 'Guizhou', 'GZ', 1),
(692, 44, 'Hainan', 'HA', 1),
(693, 44, 'Hebei', 'HB', 1),
(694, 44, 'Heilongjiang', 'HL', 1),
(695, 44, 'Henan', 'HE', 1),
(696, 44, 'Hong Kong', 'HK', 1),
(697, 44, 'Hubei', 'HU', 1),
(698, 44, 'Hunan', 'HN', 1),
(699, 44, 'Inner Mongolia', 'IM', 1),
(700, 44, 'Jiangsu', 'JI', 1),
(701, 44, 'Jiangxi', 'JX', 1),
(702, 44, 'Jilin', 'JL', 1),
(703, 44, 'Liaoning', 'LI', 1),
(704, 44, 'Macau', 'MA', 1),
(705, 44, 'Ningxia', 'NI', 1),
(706, 44, 'Shaanxi', 'SH', 1),
(707, 44, 'Shandong', 'SA', 1),
(708, 44, 'Shanghai', 'SG', 1),
(709, 44, 'Shanxi', 'SX', 1),
(710, 44, 'Sichuan', 'SI', 1),
(711, 44, 'Tianjin', 'TI', 1),
(712, 44, 'Xinjiang', 'XI', 1),
(713, 44, 'Yunnan', 'YU', 1),
(714, 44, 'Zhejiang', 'ZH', 1),
(715, 46, 'Direction Island', 'D', 1),
(716, 46, 'Home Island', 'H', 1),
(717, 46, 'Horsburgh Island', 'O', 1),
(718, 46, 'South Island', 'S', 1),
(719, 46, 'West Island', 'W', 1),
(720, 47, 'Amazonas', 'AMZ', 1),
(721, 47, 'Antioquia', 'ANT', 1),
(722, 47, 'Arauca', 'ARA', 1),
(723, 47, 'Atlantico', 'ATL', 1),
(724, 47, 'Bogota D.C.', 'BDC', 1),
(725, 47, 'Bolivar', 'BOL', 1),
(726, 47, 'Boyaca', 'BOY', 1),
(727, 47, 'Caldas', 'CAL', 1),
(728, 47, 'Caqueta', 'CAQ', 1),
(729, 47, 'Casanare', 'CAS', 1),
(730, 47, 'Cauca', 'CAU', 1),
(731, 47, 'Cesar', 'CES', 1),
(732, 47, 'Choco', 'CHO', 1),
(733, 47, 'Cordoba', 'COR', 1),
(734, 47, 'Cundinamarca', 'CAM', 1),
(735, 47, 'Guainia', 'GNA', 1),
(736, 47, 'Guajira', 'GJR', 1),
(737, 47, 'Guaviare', 'GVR', 1),
(738, 47, 'Huila', 'HUI', 1),
(739, 47, 'Magdalena', 'MAG', 1),
(740, 47, 'Meta', 'MET', 1),
(741, 47, 'Narino', 'NAR', 1),
(742, 47, 'Norte de Santander', 'NDS', 1),
(743, 47, 'Putumayo', 'PUT', 1),
(744, 47, 'Quindio', 'QUI', 1),
(745, 47, 'Risaralda', 'RIS', 1),
(746, 47, 'San Andres y Providencia', 'SAP', 1),
(747, 47, 'Santander', 'SAN', 1),
(748, 47, 'Sucre', 'SUC', 1),
(749, 47, 'Tolima', 'TOL', 1),
(750, 47, 'Valle del Cauca', 'VDC', 1),
(751, 47, 'Vaupes', 'VAU', 1),
(752, 47, 'Vichada', 'VIC', 1),
(753, 48, 'Grande Comore', 'G', 1),
(754, 48, 'Anjouan', 'A', 1),
(755, 48, 'Moheli', 'M', 1),
(756, 49, 'Bouenza', 'BO', 1),
(757, 49, 'Brazzaville', 'BR', 1),
(758, 49, 'Cuvette', 'CU', 1),
(759, 49, 'Cuvette-Ouest', 'CO', 1),
(760, 49, 'Kouilou', 'KO', 1),
(761, 49, 'Lekoumou', 'LE', 1),
(762, 49, 'Likouala', 'LI', 1),
(763, 49, 'Niari', 'NI', 1),
(764, 49, 'Plateaux', 'PL', 1),
(765, 49, 'Pool', 'PO', 1),
(766, 49, 'Sangha', 'SA', 1),
(767, 50, 'Pukapuka', 'PU', 1),
(768, 50, 'Rakahanga', 'RK', 1),
(769, 50, 'Manihiki', 'MK', 1),
(770, 50, 'Penrhyn', 'PE', 1),
(771, 50, 'Nassau Island', 'NI', 1),
(772, 50, 'Surwarrow', 'SU', 1),
(773, 50, 'Palmerston', 'PA', 1),
(774, 50, 'Aitutaki', 'AI', 1),
(775, 50, 'Manuae', 'MA', 1),
(776, 50, 'Takutea', 'TA', 1),
(777, 50, 'Mitiaro', 'MT', 1),
(778, 50, 'Atiu', 'AT', 1),
(779, 50, 'Mauke', 'MU', 1),
(780, 50, 'Rarotonga', 'RR', 1),
(781, 50, 'Mangaia', 'MG', 1),
(782, 51, 'Alajuela', 'AL', 1),
(783, 51, 'Cartago', 'CA', 1),
(784, 51, 'Guanacaste', 'GU', 1),
(785, 51, 'Heredia', 'HE', 1),
(786, 51, 'Limon', 'LI', 1),
(787, 51, 'Puntarenas', 'PU', 1),
(788, 51, 'San Jose', 'SJ', 1),
(789, 52, 'Abengourou', 'ABE', 1),
(790, 52, 'Abidjan', 'ABI', 1),
(791, 52, 'Aboisso', 'ABO', 1),
(792, 52, 'Adiake', 'ADI', 1),
(793, 52, 'Adzope', 'ADZ', 1),
(794, 52, 'Agboville', 'AGB', 1),
(795, 52, 'Agnibilekrou', 'AGN', 1),
(796, 52, 'Alepe', 'ALE', 1),
(797, 52, 'Bocanda', 'BOC', 1),
(798, 52, 'Bangolo', 'BAN', 1),
(799, 52, 'Beoumi', 'BEO', 1),
(800, 52, 'Biankouma', 'BIA', 1),
(801, 52, 'Bondoukou', 'BDK', 1),
(802, 52, 'Bongouanou', 'BGN', 1),
(803, 52, 'Bouafle', 'BFL', 1),
(804, 52, 'Bouake', 'BKE', 1),
(805, 52, 'Bouna', 'BNA', 1),
(806, 52, 'Boundiali', 'BDL', 1),
(807, 52, 'Dabakala', 'DKL', 1),
(808, 52, 'Dabou', 'DBU', 1),
(809, 52, 'Daloa', 'DAL', 1),
(810, 52, 'Danane', 'DAN', 1),
(811, 52, 'Daoukro', 'DAO', 1),
(812, 52, 'Dimbokro', 'DIM', 1),
(813, 52, 'Divo', 'DIV', 1),
(814, 52, 'Duekoue', 'DUE', 1),
(815, 52, 'Ferkessedougou', 'FER', 1),
(816, 52, 'Gagnoa', 'GAG', 1),
(817, 52, 'Grand-Bassam', 'GBA', 1),
(818, 52, 'Grand-Lahou', 'GLA', 1),
(819, 52, 'Guiglo', 'GUI', 1),
(820, 52, 'Issia', 'ISS', 1),
(821, 52, 'Jacqueville', 'JAC', 1),
(822, 52, 'Katiola', 'KAT', 1),
(823, 52, 'Korhogo', 'KOR', 1),
(824, 52, 'Lakota', 'LAK', 1),
(825, 52, 'Man', 'MAN', 1),
(826, 52, 'Mankono', 'MKN', 1),
(827, 52, 'Mbahiakro', 'MBA', 1),
(828, 52, 'Odienne', 'ODI', 1),
(829, 52, 'Oume', 'OUM', 1),
(830, 52, 'Sakassou', 'SAK', 1),
(831, 52, 'San-Pedro', 'SPE', 1),
(832, 52, 'Sassandra', 'SAS', 1),
(833, 52, 'Seguela', 'SEG', 1),
(834, 52, 'Sinfra', 'SIN', 1),
(835, 52, 'Soubre', 'SOU', 1),
(836, 52, 'Tabou', 'TAB', 1),
(837, 52, 'Tanda', 'TAN', 1),
(838, 52, 'Tiebissou', 'TIE', 1),
(839, 52, 'Tingrela', 'TIN', 1),
(840, 52, 'Tiassale', 'TIA', 1),
(841, 52, 'Touba', 'TBA', 1),
(842, 52, 'Toulepleu', 'TLP', 1),
(843, 52, 'Toumodi', 'TMD', 1),
(844, 52, 'Vavoua', 'VAV', 1),
(845, 52, 'Yamoussoukro', 'YAM', 1),
(846, 52, 'Zuenoula', 'ZUE', 1),
(847, 53, 'Bjelovarsko-bilogorska', 'BB', 1),
(848, 53, 'Grad Zagreb', 'GZ', 1),
(849, 53, 'Dubrovačko-neretvanska', 'DN', 1),
(850, 53, 'Istarska', 'IS', 1),
(851, 53, 'Karlovačka', 'KA', 1),
(852, 53, 'Koprivničko-križevačka', 'KK', 1),
(853, 53, 'Krapinsko-zagorska', 'KZ', 1),
(854, 53, 'Ličko-senjska', 'LS', 1),
(855, 53, 'Međimurska', 'ME', 1),
(856, 53, 'Osječko-baranjska', 'OB', 1),
(857, 53, 'Požeško-slavonska', 'PS', 1),
(858, 53, 'Primorsko-goranska', 'PG', 1),
(859, 53, 'Šibensko-kninska', 'SK', 1),
(860, 53, 'Sisačko-moslavačka', 'SM', 1),
(861, 53, 'Brodsko-posavska', 'BP', 1),
(862, 53, 'Splitsko-dalmatinska', 'SD', 1),
(863, 53, 'Varaždinska', 'VA', 1),
(864, 53, 'Virovitičko-podravska', 'VP', 1),
(865, 53, 'Vukovarsko-srijemska', 'VS', 1),
(866, 53, 'Zadarska', 'ZA', 1),
(867, 53, 'Zagrebačka', 'ZG', 1),
(868, 54, 'Camaguey', 'CA', 1),
(869, 54, 'Ciego de Avila', 'CD', 1),
(870, 54, 'Cienfuegos', 'CI', 1),
(871, 54, 'Ciudad de La Habana', 'CH', 1),
(872, 54, 'Granma', 'GR', 1),
(873, 54, 'Guantanamo', 'GU', 1),
(874, 54, 'Holguin', 'HO', 1),
(875, 54, 'Isla de la Juventud', 'IJ', 1),
(876, 54, 'La Habana', 'LH', 1),
(877, 54, 'Las Tunas', 'LT', 1),
(878, 54, 'Matanzas', 'MA', 1),
(879, 54, 'Pinar del Rio', 'PR', 1),
(880, 54, 'Sancti Spiritus', 'SS', 1),
(881, 54, 'Santiago de Cuba', 'SC', 1),
(882, 54, 'Villa Clara', 'VC', 1),
(883, 55, 'Famagusta', 'F', 1),
(884, 55, 'Kyrenia', 'K', 1),
(885, 55, 'Larnaca', 'A', 1),
(886, 55, 'Limassol', 'I', 1),
(887, 55, 'Nicosia', 'N', 1),
(888, 55, 'Paphos', 'P', 1),
(889, 56, 'Ústecký', 'U', 1),
(890, 56, 'Jihočeský', 'C', 1),
(891, 56, 'Jihomoravský', 'B', 1),
(892, 56, 'Karlovarský', 'K', 1),
(893, 56, 'Královehradecký', 'H', 1),
(894, 56, 'Liberecký', 'L', 1),
(895, 56, 'Moravskoslezský', 'T', 1),
(896, 56, 'Olomoucký', 'M', 1),
(897, 56, 'Pardubický', 'E', 1),
(898, 56, 'Plzeňský', 'P', 1),
(899, 56, 'Praha', 'A', 1),
(900, 56, 'Středočeský', 'S', 1),
(901, 56, 'Vysočina', 'J', 1),
(902, 56, 'Zlínský', 'Z', 1),
(903, 57, 'Arhus', 'AR', 1),
(904, 57, 'Bornholm', 'BH', 1),
(905, 57, 'Copenhagen', 'CO', 1),
(906, 57, 'Faroe Islands', 'FO', 1),
(907, 57, 'Frederiksborg', 'FR', 1),
(908, 57, 'Fyn', 'FY', 1),
(909, 57, 'Kobenhavn', 'KO', 1),
(910, 57, 'Nordjylland', 'NO', 1),
(911, 57, 'Ribe', 'RI', 1),
(912, 57, 'Ringkobing', 'RK', 1),
(913, 57, 'Roskilde', 'RO', 1),
(914, 57, 'Sonderjylland', 'SO', 1),
(915, 57, 'Storstrom', 'ST', 1),
(916, 57, 'Vejle', 'VK', 1),
(917, 57, 'Vestj&aelig;lland', 'VJ', 1),
(918, 57, 'Viborg', 'VB', 1),
(919, 58, '\'Ali Sabih', 'S', 1),
(920, 58, 'Dikhil', 'K', 1),
(921, 58, 'Djibouti', 'J', 1),
(922, 58, 'Obock', 'O', 1),
(923, 58, 'Tadjoura', 'T', 1),
(924, 59, 'Saint Andrew Parish', 'AND', 1),
(925, 59, 'Saint David Parish', 'DAV', 1),
(926, 59, 'Saint George Parish', 'GEO', 1),
(927, 59, 'Saint John Parish', 'JOH', 1),
(928, 59, 'Saint Joseph Parish', 'JOS', 1),
(929, 59, 'Saint Luke Parish', 'LUK', 1),
(930, 59, 'Saint Mark Parish', 'MAR', 1),
(931, 59, 'Saint Patrick Parish', 'PAT', 1),
(932, 59, 'Saint Paul Parish', 'PAU', 1),
(933, 59, 'Saint Peter Parish', 'PET', 1),
(934, 60, 'Distrito Nacional', 'DN', 1),
(935, 60, 'Azua', 'AZ', 1),
(936, 60, 'Baoruco', 'BC', 1),
(937, 60, 'Barahona', 'BH', 1),
(938, 60, 'Dajabon', 'DJ', 1),
(939, 60, 'Duarte', 'DU', 1),
(940, 60, 'Elias Pina', 'EL', 1),
(941, 60, 'El Seybo', 'SY', 1),
(942, 60, 'Espaillat', 'ET', 1),
(943, 60, 'Hato Mayor', 'HM', 1),
(944, 60, 'Independencia', 'IN', 1),
(945, 60, 'La Altagracia', 'AL', 1),
(946, 60, 'La Romana', 'RO', 1),
(947, 60, 'La Vega', 'VE', 1),
(948, 60, 'Maria Trinidad Sanchez', 'MT', 1),
(949, 60, 'Monsenor Nouel', 'MN', 1),
(950, 60, 'Monte Cristi', 'MC', 1),
(951, 60, 'Monte Plata', 'MP', 1),
(952, 60, 'Pedernales', 'PD', 1),
(953, 60, 'Peravia (Bani)', 'PR', 1),
(954, 60, 'Puerto Plata', 'PP', 1),
(955, 60, 'Salcedo', 'SL', 1),
(956, 60, 'Samana', 'SM', 1),
(957, 60, 'Sanchez Ramirez', 'SH', 1),
(958, 60, 'San Cristobal', 'SC', 1),
(959, 60, 'San Jose de Ocoa', 'JO', 1),
(960, 60, 'San Juan', 'SJ', 1),
(961, 60, 'San Pedro de Macoris', 'PM', 1),
(962, 60, 'Santiago', 'SA', 1),
(963, 60, 'Santiago Rodriguez', 'ST', 1),
(964, 60, 'Santo Domingo', 'SD', 1),
(965, 60, 'Valverde', 'VA', 1),
(966, 61, 'Aileu', 'AL', 1),
(967, 61, 'Ainaro', 'AN', 1),
(968, 61, 'Baucau', 'BA', 1),
(969, 61, 'Bobonaro', 'BO', 1),
(970, 61, 'Cova Lima', 'CO', 1),
(971, 61, 'Dili', 'DI', 1),
(972, 61, 'Ermera', 'ER', 1),
(973, 61, 'Lautem', 'LA', 1),
(974, 61, 'Liquica', 'LI', 1),
(975, 61, 'Manatuto', 'MT', 1),
(976, 61, 'Manufahi', 'MF', 1),
(977, 61, 'Oecussi', 'OE', 1),
(978, 61, 'Viqueque', 'VI', 1),
(979, 62, 'Azuay', 'AZU', 1),
(980, 62, 'Bolivar', 'BOL', 1),
(981, 62, 'Ca&ntilde;ar', 'CAN', 1),
(982, 62, 'Carchi', 'CAR', 1),
(983, 62, 'Chimborazo', 'CHI', 1),
(984, 62, 'Cotopaxi', 'COT', 1),
(985, 62, 'El Oro', 'EOR', 1),
(986, 62, 'Esmeraldas', 'ESM', 1),
(987, 62, 'Gal&aacute;pagos', 'GPS', 1),
(988, 62, 'Guayas', 'GUA', 1),
(989, 62, 'Imbabura', 'IMB', 1),
(990, 62, 'Loja', 'LOJ', 1),
(991, 62, 'Los Rios', 'LRO', 1),
(992, 62, 'Manab&iacute;', 'MAN', 1),
(993, 62, 'Morona Santiago', 'MSA', 1),
(994, 62, 'Napo', 'NAP', 1),
(995, 62, 'Orellana', 'ORE', 1),
(996, 62, 'Pastaza', 'PAS', 1),
(997, 62, 'Pichincha', 'PIC', 1),
(998, 62, 'Sucumb&iacute;os', 'SUC', 1),
(999, 62, 'Tungurahua', 'TUN', 1),
(1000, 62, 'Zamora Chinchipe', 'ZCH', 1),
(1001, 63, 'Ad Daqahliyah', 'DHY', 1),
(1002, 63, 'Al Bahr al Ahmar', 'BAM', 1),
(1003, 63, 'Al Buhayrah', 'BHY', 1),
(1004, 63, 'Al Fayyum', 'FYM', 1),
(1005, 63, 'Al Gharbiyah', 'GBY', 1),
(1006, 63, 'Al Iskandariyah', 'IDR', 1),
(1007, 63, 'Al Isma\'iliyah', 'IML', 1),
(1008, 63, 'Al Jizah', 'JZH', 1),
(1009, 63, 'Al Minufiyah', 'MFY', 1),
(1010, 63, 'Al Minya', 'MNY', 1),
(1011, 63, 'Al Qahirah', 'QHR', 1),
(1012, 63, 'Al Qalyubiyah', 'QLY', 1),
(1013, 63, 'Al Wadi al Jadid', 'WJD', 1),
(1014, 63, 'Ash Sharqiyah', 'SHQ', 1),
(1015, 63, 'As Suways', 'SWY', 1),
(1016, 63, 'Aswan', 'ASW', 1),
(1017, 63, 'Asyut', 'ASY', 1),
(1018, 63, 'Bani Suwayf', 'BSW', 1),
(1019, 63, 'Bur Sa\'id', 'BSD', 1),
(1020, 63, 'Dumyat', 'DMY', 1),
(1021, 63, 'Janub Sina\'', 'JNS', 1),
(1022, 63, 'Kafr ash Shaykh', 'KSH', 1),
(1023, 63, 'Matruh', 'MAT', 1),
(1024, 63, 'Qina', 'QIN', 1),
(1025, 63, 'Shamal Sina\'', 'SHS', 1),
(1026, 63, 'Suhaj', 'SUH', 1),
(1027, 64, 'Ahuachapan', 'AH', 1),
(1028, 64, 'Cabanas', 'CA', 1),
(1029, 64, 'Chalatenango', 'CH', 1),
(1030, 64, 'Cuscatlan', 'CU', 1),
(1031, 64, 'La Libertad', 'LB', 1),
(1032, 64, 'La Paz', 'PZ', 1),
(1033, 64, 'La Union', 'UN', 1),
(1034, 64, 'Morazan', 'MO', 1),
(1035, 64, 'San Miguel', 'SM', 1),
(1036, 64, 'San Salvador', 'SS', 1),
(1037, 64, 'San Vicente', 'SV', 1),
(1038, 64, 'Santa Ana', 'SA', 1),
(1039, 64, 'Sonsonate', 'SO', 1),
(1040, 64, 'Usulutan', 'US', 1),
(1041, 65, 'Provincia Annobon', 'AN', 1),
(1042, 65, 'Provincia Bioko Norte', 'BN', 1),
(1043, 65, 'Provincia Bioko Sur', 'BS', 1),
(1044, 65, 'Provincia Centro Sur', 'CS', 1),
(1045, 65, 'Provincia Kie-Ntem', 'KN', 1),
(1046, 65, 'Provincia Litoral', 'LI', 1),
(1047, 65, 'Provincia Wele-Nzas', 'WN', 1),
(1048, 66, 'Central (Maekel)', 'MA', 1),
(1049, 66, 'Anseba (Keren)', 'KE', 1),
(1050, 66, 'Southern Red Sea (Debub-Keih-Bahri)', 'DK', 1),
(1051, 66, 'Northern Red Sea (Semien-Keih-Bahri)', 'SK', 1),
(1052, 66, 'Southern (Debub)', 'DE', 1),
(1053, 66, 'Gash-Barka (Barentu)', 'BR', 1),
(1054, 67, 'Harjumaa (Tallinn)', 'HA', 1),
(1055, 67, 'Hiiumaa (Kardla)', 'HI', 1),
(1056, 67, 'Ida-Virumaa (Johvi)', 'IV', 1),
(1057, 67, 'Jarvamaa (Paide)', 'JA', 1),
(1058, 67, 'Jogevamaa (Jogeva)', 'JO', 1),
(1059, 67, 'Laane-Virumaa (Rakvere)', 'LV', 1),
(1060, 67, 'Laanemaa (Haapsalu)', 'LA', 1),
(1061, 67, 'Parnumaa (Parnu)', 'PA', 1),
(1062, 67, 'Polvamaa (Polva)', 'PO', 1),
(1063, 67, 'Raplamaa (Rapla)', 'RA', 1),
(1064, 67, 'Saaremaa (Kuessaare)', 'SA', 1),
(1065, 67, 'Tartumaa (Tartu)', 'TA', 1),
(1066, 67, 'Valgamaa (Valga)', 'VA', 1),
(1067, 67, 'Viljandimaa (Viljandi)', 'VI', 1),
(1068, 67, 'Vorumaa (Voru)', 'VO', 1),
(1069, 68, 'Afar', 'AF', 1),
(1070, 68, 'Amhara', 'AH', 1),
(1071, 68, 'Benishangul-Gumaz', 'BG', 1),
(1072, 68, 'Gambela', 'GB', 1),
(1073, 68, 'Hariai', 'HR', 1),
(1074, 68, 'Oromia', 'OR', 1),
(1075, 68, 'Somali', 'SM', 1),
(1076, 68, 'Southern Nations - Nationalities and Peoples Region', 'SN', 1),
(1077, 68, 'Tigray', 'TG', 1),
(1078, 68, 'Addis Ababa', 'AA', 1),
(1079, 68, 'Dire Dawa', 'DD', 1),
(1080, 71, 'Central Division', 'C', 1),
(1081, 71, 'Northern Division', 'N', 1),
(1082, 71, 'Eastern Division', 'E', 1),
(1083, 71, 'Western Division', 'W', 1),
(1084, 71, 'Rotuma', 'R', 1),
(1085, 72, 'Ahvenanmaan lääni', 'AL', 1),
(1086, 72, 'Etelä-Suomen lääni', 'ES', 1),
(1087, 72, 'Itä-Suomen lääni', 'IS', 1),
(1088, 72, 'Länsi-Suomen lääni', 'LS', 1),
(1089, 72, 'Lapin lääni', 'LA', 1),
(1090, 72, 'Oulun lääni', 'OU', 1),
(1114, 74, 'Ain', '01', 1),
(1115, 74, 'Aisne', '02', 1),
(1116, 74, 'Allier', '03', 1),
(1117, 74, 'Alpes de Haute Provence', '04', 1),
(1118, 74, 'Hautes-Alpes', '05', 1),
(1119, 74, 'Alpes Maritimes', '06', 1),
(1120, 74, 'Ard&egrave;che', '07', 1),
(1121, 74, 'Ardennes', '08', 1),
(1122, 74, 'Ari&egrave;ge', '09', 1),
(1123, 74, 'Aube', '10', 1),
(1124, 74, 'Aude', '11', 1),
(1125, 74, 'Aveyron', '12', 1),
(1126, 74, 'Bouches du Rh&ocirc;ne', '13', 1),
(1127, 74, 'Calvados', '14', 1),
(1128, 74, 'Cantal', '15', 1),
(1129, 74, 'Charente', '16', 1),
(1130, 74, 'Charente Maritime', '17', 1),
(1131, 74, 'Cher', '18', 1),
(1132, 74, 'Corr&egrave;ze', '19', 1),
(1133, 74, 'Corse du Sud', '2A', 1),
(1134, 74, 'Haute Corse', '2B', 1),
(1135, 74, 'C&ocirc;te d&#039;or', '21', 1),
(1136, 74, 'C&ocirc;tes d&#039;Armor', '22', 1),
(1137, 74, 'Creuse', '23', 1),
(1138, 74, 'Dordogne', '24', 1),
(1139, 74, 'Doubs', '25', 1),
(1140, 74, 'Dr&ocirc;me', '26', 1),
(1141, 74, 'Eure', '27', 1),
(1142, 74, 'Eure et Loir', '28', 1),
(1143, 74, 'Finist&egrave;re', '29', 1),
(1144, 74, 'Gard', '30', 1),
(1145, 74, 'Haute Garonne', '31', 1),
(1146, 74, 'Gers', '32', 1),
(1147, 74, 'Gironde', '33', 1),
(1148, 74, 'H&eacute;rault', '34', 1),
(1149, 74, 'Ille et Vilaine', '35', 1),
(1150, 74, 'Indre', '36', 1),
(1151, 74, 'Indre et Loire', '37', 1),
(1152, 74, 'Is&eacute;re', '38', 1),
(1153, 74, 'Jura', '39', 1),
(1154, 74, 'Landes', '40', 1),
(1155, 74, 'Loir et Cher', '41', 1),
(1156, 74, 'Loire', '42', 1),
(1157, 74, 'Haute Loire', '43', 1),
(1158, 74, 'Loire Atlantique', '44', 1),
(1159, 74, 'Loiret', '45', 1),
(1160, 74, 'Lot', '46', 1),
(1161, 74, 'Lot et Garonne', '47', 1),
(1162, 74, 'Loz&egrave;re', '48', 1),
(1163, 74, 'Maine et Loire', '49', 1),
(1164, 74, 'Manche', '50', 1),
(1165, 74, 'Marne', '51', 1),
(1166, 74, 'Haute Marne', '52', 1),
(1167, 74, 'Mayenne', '53', 1),
(1168, 74, 'Meurthe et Moselle', '54', 1),
(1169, 74, 'Meuse', '55', 1),
(1170, 74, 'Morbihan', '56', 1),
(1171, 74, 'Moselle', '57', 1),
(1172, 74, 'Ni&egrave;vre', '58', 1),
(1173, 74, 'Nord', '59', 1),
(1174, 74, 'Oise', '60', 1),
(1175, 74, 'Orne', '61', 1),
(1176, 74, 'Pas de Calais', '62', 1),
(1177, 74, 'Puy de D&ocirc;me', '63', 1),
(1178, 74, 'Pyr&eacute;n&eacute;es Atlantiques', '64', 1),
(1179, 74, 'Hautes Pyr&eacute;n&eacute;es', '65', 1),
(1180, 74, 'Pyr&eacute;n&eacute;es Orientales', '66', 1),
(1181, 74, 'Bas Rhin', '67', 1),
(1182, 74, 'Haut Rhin', '68', 1),
(1183, 74, 'Rh&ocirc;ne', '69', 1),
(1184, 74, 'Haute Sa&ocirc;ne', '70', 1),
(1185, 74, 'Sa&ocirc;ne et Loire', '71', 1),
(1186, 74, 'Sarthe', '72', 1),
(1187, 74, 'Savoie', '73', 1),
(1188, 74, 'Haute Savoie', '74', 1),
(1189, 74, 'Paris', '75', 1),
(1190, 74, 'Seine Maritime', '76', 1),
(1191, 74, 'Seine et Marne', '77', 1),
(1192, 74, 'Yvelines', '78', 1),
(1193, 74, 'Deux S&egrave;vres', '79', 1),
(1194, 74, 'Somme', '80', 1),
(1195, 74, 'Tarn', '81', 1),
(1196, 74, 'Tarn et Garonne', '82', 1),
(1197, 74, 'Var', '83', 1),
(1198, 74, 'Vaucluse', '84', 1),
(1199, 74, 'Vend&eacute;e', '85', 1),
(1200, 74, 'Vienne', '86', 1),
(1201, 74, 'Haute Vienne', '87', 1),
(1202, 74, 'Vosges', '88', 1),
(1203, 74, 'Yonne', '89', 1),
(1204, 74, 'Territoire de Belfort', '90', 1),
(1205, 74, 'Essonne', '91', 1),
(1206, 74, 'Hauts de Seine', '92', 1),
(1207, 74, 'Seine St-Denis', '93', 1),
(1208, 74, 'Val de Marne', '94', 1),
(1209, 74, 'Val d\'Oise', '95', 1),
(1210, 76, 'Archipel des Marquises', 'M', 1),
(1211, 76, 'Archipel des Tuamotu', 'T', 1),
(1212, 76, 'Archipel des Tubuai', 'I', 1),
(1213, 76, 'Iles du Vent', 'V', 1),
(1214, 76, 'Iles Sous-le-Vent', 'S', 1),
(1215, 77, 'Iles Crozet', 'C', 1),
(1216, 77, 'Iles Kerguelen', 'K', 1),
(1217, 77, 'Ile Amsterdam', 'A', 1),
(1218, 77, 'Ile Saint-Paul', 'P', 1),
(1219, 77, 'Adelie Land', 'D', 1),
(1220, 78, 'Estuaire', 'ES', 1),
(1221, 78, 'Haut-Ogooue', 'HO', 1),
(1222, 78, 'Moyen-Ogooue', 'MO', 1),
(1223, 78, 'Ngounie', 'NG', 1),
(1224, 78, 'Nyanga', 'NY', 1),
(1225, 78, 'Ogooue-Ivindo', 'OI', 1),
(1226, 78, 'Ogooue-Lolo', 'OL', 1),
(1227, 78, 'Ogooue-Maritime', 'OM', 1),
(1228, 78, 'Woleu-Ntem', 'WN', 1),
(1229, 79, 'Banjul', 'BJ', 1),
(1230, 79, 'Basse', 'BS', 1),
(1231, 79, 'Brikama', 'BR', 1),
(1232, 79, 'Janjangbure', 'JA', 1),
(1233, 79, 'Kanifeng', 'KA', 1),
(1234, 79, 'Kerewan', 'KE', 1),
(1235, 79, 'Kuntaur', 'KU', 1),
(1236, 79, 'Mansakonko', 'MA', 1),
(1237, 79, 'Lower River', 'LR', 1),
(1238, 79, 'Central River', 'CR', 1),
(1239, 79, 'North Bank', 'NB', 1),
(1240, 79, 'Upper River', 'UR', 1),
(1241, 79, 'Western', 'WE', 1),
(1242, 80, 'Abkhazia', 'AB', 1),
(1243, 80, 'Ajaria', 'AJ', 1),
(1244, 80, 'Tbilisi', 'TB', 1),
(1245, 80, 'Guria', 'GU', 1),
(1246, 80, 'Imereti', 'IM', 1),
(1247, 80, 'Kakheti', 'KA', 1),
(1248, 80, 'Kvemo Kartli', 'KK', 1),
(1249, 80, 'Mtskheta-Mtianeti', 'MM', 1),
(1250, 80, 'Racha Lechkhumi and Kvemo Svanet', 'RL', 1),
(1251, 80, 'Samegrelo-Zemo Svaneti', 'SZ', 1),
(1252, 80, 'Samtskhe-Javakheti', 'SJ', 1),
(1253, 80, 'Shida Kartli', 'SK', 1),
(1254, 81, 'Baden-W&uuml;rttemberg', 'BAW', 1),
(1255, 81, 'Bayern', 'BAY', 1),
(1256, 81, 'Berlin', 'BER', 1),
(1257, 81, 'Brandenburg', 'BRG', 1),
(1258, 81, 'Bremen', 'BRE', 1),
(1259, 81, 'Hamburg', 'HAM', 1),
(1260, 81, 'Hessen', 'HES', 1),
(1261, 81, 'Mecklenburg-Vorpommern', 'MEC', 1),
(1262, 81, 'Niedersachsen', 'NDS', 1),
(1263, 81, 'Nordrhein-Westfalen', 'NRW', 1),
(1264, 81, 'Rheinland-Pfalz', 'RHE', 1),
(1265, 81, 'Saarland', 'SAR', 1),
(1266, 81, 'Sachsen', 'SAS', 1),
(1267, 81, 'Sachsen-Anhalt', 'SAC', 1),
(1268, 81, 'Schleswig-Holstein', 'SCN', 1),
(1269, 81, 'Th&uuml;ringen', 'THE', 1),
(1270, 82, 'Ashanti Region', 'AS', 1),
(1271, 82, 'Brong-Ahafo Region', 'BA', 1),
(1272, 82, 'Central Region', 'CE', 1),
(1273, 82, 'Eastern Region', 'EA', 1),
(1274, 82, 'Greater Accra Region', 'GA', 1),
(1275, 82, 'Northern Region', 'NO', 1),
(1276, 82, 'Upper East Region', 'UE', 1),
(1277, 82, 'Upper West Region', 'UW', 1),
(1278, 82, 'Volta Region', 'VO', 1),
(1279, 82, 'Western Region', 'WE', 1),
(1280, 84, 'Attica', 'AT', 1),
(1281, 84, 'Central Greece', 'CN', 1),
(1282, 84, 'Central Macedonia', 'CM', 1),
(1283, 84, 'Crete', 'CR', 1),
(1284, 84, 'East Macedonia and Thrace', 'EM', 1),
(1285, 84, 'Epirus', 'EP', 1),
(1286, 84, 'Ionian Islands', 'II', 1),
(1287, 84, 'North Aegean', 'NA', 1),
(1288, 84, 'Peloponnesos', 'PP', 1),
(1289, 84, 'South Aegean', 'SA', 1),
(1290, 84, 'Thessaly', 'TH', 1),
(1291, 84, 'West Greece', 'WG', 1),
(1292, 84, 'West Macedonia', 'WM', 1),
(1293, 85, 'Avannaa', 'A', 1),
(1294, 85, 'Tunu', 'T', 1),
(1295, 85, 'Kitaa', 'K', 1),
(1296, 86, 'Saint Andrew', 'A', 1),
(1297, 86, 'Saint David', 'D', 1),
(1298, 86, 'Saint George', 'G', 1),
(1299, 86, 'Saint John', 'J', 1),
(1300, 86, 'Saint Mark', 'M', 1),
(1301, 86, 'Saint Patrick', 'P', 1),
(1302, 86, 'Carriacou', 'C', 1),
(1303, 86, 'Petit Martinique', 'Q', 1),
(1304, 89, 'Alta Verapaz', 'AV', 1),
(1305, 89, 'Baja Verapaz', 'BV', 1),
(1306, 89, 'Chimaltenango', 'CM', 1),
(1307, 89, 'Chiquimula', 'CQ', 1),
(1308, 89, 'El Peten', 'PE', 1),
(1309, 89, 'El Progreso', 'PR', 1),
(1310, 89, 'El Quiche', 'QC', 1),
(1311, 89, 'Escuintla', 'ES', 1),
(1312, 89, 'Guatemala', 'GU', 1),
(1313, 89, 'Huehuetenango', 'HU', 1),
(1314, 89, 'Izabal', 'IZ', 1),
(1315, 89, 'Jalapa', 'JA', 1),
(1316, 89, 'Jutiapa', 'JU', 1),
(1317, 89, 'Quetzaltenango', 'QZ', 1),
(1318, 89, 'Retalhuleu', 'RE', 1),
(1319, 89, 'Sacatepequez', 'ST', 1),
(1320, 89, 'San Marcos', 'SM', 1),
(1321, 89, 'Santa Rosa', 'SR', 1),
(1322, 89, 'Solola', 'SO', 1),
(1323, 89, 'Suchitepequez', 'SU', 1),
(1324, 89, 'Totonicapan', 'TO', 1),
(1325, 89, 'Zacapa', 'ZA', 1),
(1326, 90, 'Conakry', 'CNK', 1),
(1327, 90, 'Beyla', 'BYL', 1),
(1328, 90, 'Boffa', 'BFA', 1),
(1329, 90, 'Boke', 'BOK', 1),
(1330, 90, 'Coyah', 'COY', 1),
(1331, 90, 'Dabola', 'DBL', 1),
(1332, 90, 'Dalaba', 'DLB', 1),
(1333, 90, 'Dinguiraye', 'DGR', 1),
(1334, 90, 'Dubreka', 'DBR', 1),
(1335, 90, 'Faranah', 'FRN', 1),
(1336, 90, 'Forecariah', 'FRC', 1),
(1337, 90, 'Fria', 'FRI', 1),
(1338, 90, 'Gaoual', 'GAO', 1),
(1339, 90, 'Gueckedou', 'GCD', 1),
(1340, 90, 'Kankan', 'KNK', 1),
(1341, 90, 'Kerouane', 'KRN', 1),
(1342, 90, 'Kindia', 'KND', 1),
(1343, 90, 'Kissidougou', 'KSD', 1),
(1344, 90, 'Koubia', 'KBA', 1),
(1345, 90, 'Koundara', 'KDA', 1),
(1346, 90, 'Kouroussa', 'KRA', 1),
(1347, 90, 'Labe', 'LAB', 1),
(1348, 90, 'Lelouma', 'LLM', 1),
(1349, 90, 'Lola', 'LOL', 1),
(1350, 90, 'Macenta', 'MCT', 1),
(1351, 90, 'Mali', 'MAL', 1),
(1352, 90, 'Mamou', 'MAM', 1),
(1353, 90, 'Mandiana', 'MAN', 1),
(1354, 90, 'Nzerekore', 'NZR', 1),
(1355, 90, 'Pita', 'PIT', 1),
(1356, 90, 'Siguiri', 'SIG', 1),
(1357, 90, 'Telimele', 'TLM', 1),
(1358, 90, 'Tougue', 'TOG', 1),
(1359, 90, 'Yomou', 'YOM', 1),
(1360, 91, 'Bafata Region', 'BF', 1),
(1361, 91, 'Biombo Region', 'BB', 1),
(1362, 91, 'Bissau Region', 'BS', 1),
(1363, 91, 'Bolama Region', 'BL', 1),
(1364, 91, 'Cacheu Region', 'CA', 1),
(1365, 91, 'Gabu Region', 'GA', 1),
(1366, 91, 'Oio Region', 'OI', 1),
(1367, 91, 'Quinara Region', 'QU', 1),
(1368, 91, 'Tombali Region', 'TO', 1),
(1369, 92, 'Barima-Waini', 'BW', 1),
(1370, 92, 'Cuyuni-Mazaruni', 'CM', 1),
(1371, 92, 'Demerara-Mahaica', 'DM', 1),
(1372, 92, 'East Berbice-Corentyne', 'EC', 1),
(1373, 92, 'Essequibo Islands-West Demerara', 'EW', 1),
(1374, 92, 'Mahaica-Berbice', 'MB', 1),
(1375, 92, 'Pomeroon-Supenaam', 'PM', 1),
(1376, 92, 'Potaro-Siparuni', 'PI', 1),
(1377, 92, 'Upper Demerara-Berbice', 'UD', 1),
(1378, 92, 'Upper Takutu-Upper Essequibo', 'UT', 1),
(1379, 93, 'Artibonite', 'AR', 1),
(1380, 93, 'Centre', 'CE', 1),
(1381, 93, 'Grand\'Anse', 'GA', 1),
(1382, 93, 'Nord', 'ND', 1),
(1383, 93, 'Nord-Est', 'NE', 1),
(1384, 93, 'Nord-Ouest', 'NO', 1),
(1385, 93, 'Ouest', 'OU', 1),
(1386, 93, 'Sud', 'SD', 1),
(1387, 93, 'Sud-Est', 'SE', 1),
(1388, 94, 'Flat Island', 'F', 1),
(1389, 94, 'McDonald Island', 'M', 1),
(1390, 94, 'Shag Island', 'S', 1),
(1391, 94, 'Heard Island', 'H', 1),
(1392, 95, 'Atlantida', 'AT', 1),
(1393, 95, 'Choluteca', 'CH', 1),
(1394, 95, 'Colon', 'CL', 1),
(1395, 95, 'Comayagua', 'CM', 1),
(1396, 95, 'Copan', 'CP', 1),
(1397, 95, 'Cortes', 'CR', 1),
(1398, 95, 'El Paraiso', 'PA', 1),
(1399, 95, 'Francisco Morazan', 'FM', 1),
(1400, 95, 'Gracias a Dios', 'GD', 1),
(1401, 95, 'Intibuca', 'IN', 1),
(1402, 95, 'Islas de la Bahia (Bay Islands)', 'IB', 1),
(1403, 95, 'La Paz', 'PZ', 1),
(1404, 95, 'Lempira', 'LE', 1),
(1405, 95, 'Ocotepeque', 'OC', 1),
(1406, 95, 'Olancho', 'OL', 1),
(1407, 95, 'Santa Barbara', 'SB', 1),
(1408, 95, 'Valle', 'VA', 1),
(1409, 95, 'Yoro', 'YO', 1),
(1410, 96, 'Central and Western Hong Kong Island', 'HCW', 1),
(1411, 96, 'Eastern Hong Kong Island', 'HEA', 1),
(1412, 96, 'Southern Hong Kong Island', 'HSO', 1),
(1413, 96, 'Wan Chai Hong Kong Island', 'HWC', 1),
(1414, 96, 'Kowloon City Kowloon', 'KKC', 1),
(1415, 96, 'Kwun Tong Kowloon', 'KKT', 1),
(1416, 96, 'Sham Shui Po Kowloon', 'KSS', 1),
(1417, 96, 'Wong Tai Sin Kowloon', 'KWT', 1),
(1418, 96, 'Yau Tsim Mong Kowloon', 'KYT', 1),
(1419, 96, 'Islands New Territories', 'NIS', 1),
(1420, 96, 'Kwai Tsing New Territories', 'NKT', 1),
(1421, 96, 'North New Territories', 'NNO', 1),
(1422, 96, 'Sai Kung New Territories', 'NSK', 1),
(1423, 96, 'Sha Tin New Territories', 'NST', 1),
(1424, 96, 'Tai Po New Territories', 'NTP', 1),
(1425, 96, 'Tsuen Wan New Territories', 'NTW', 1),
(1426, 96, 'Tuen Mun New Territories', 'NTM', 1),
(1427, 96, 'Yuen Long New Territories', 'NYL', 1),
(1467, 98, 'Austurland', 'AL', 1),
(1468, 98, 'Hofuoborgarsvaeoi', 'HF', 1),
(1469, 98, 'Norourland eystra', 'NE', 1),
(1470, 98, 'Norourland vestra', 'NV', 1),
(1471, 98, 'Suourland', 'SL', 1),
(1472, 98, 'Suournes', 'SN', 1),
(1473, 98, 'Vestfiroir', 'VF', 1),
(1474, 98, 'Vesturland', 'VL', 1),
(1475, 99, 'Andaman and Nicobar Islands', 'AN', 1),
(1476, 99, 'Andhra Pradesh', 'AP', 1),
(1477, 99, 'Arunachal Pradesh', 'AR', 1),
(1478, 99, 'Assam', 'AS', 1),
(1479, 99, 'Bihar', 'BI', 1),
(1480, 99, 'Chandigarh', 'CH', 1),
(1481, 99, 'Dadra and Nagar Haveli', 'DA', 1),
(1482, 99, 'Daman and Diu', 'DM', 1),
(1483, 99, 'Delhi', 'DE', 1),
(1484, 99, 'Goa', 'GO', 1),
(1485, 99, 'Gujarat', 'GU', 1),
(1486, 99, 'Haryana', 'HA', 1),
(1487, 99, 'Himachal Pradesh', 'HP', 1),
(1488, 99, 'Jammu and Kashmir', 'JA', 1),
(1489, 99, 'Karnataka', 'KA', 1),
(1490, 99, 'Kerala', 'KE', 1),
(1491, 99, 'Lakshadweep Islands', 'LI', 1),
(1492, 99, 'Madhya Pradesh', 'MP', 1),
(1493, 99, 'Maharashtra', 'MA', 1),
(1494, 99, 'Manipur', 'MN', 1),
(1495, 99, 'Meghalaya', 'ME', 1),
(1496, 99, 'Mizoram', 'MI', 1),
(1497, 99, 'Nagaland', 'NA', 1),
(1498, 99, 'Orissa', 'OR', 1),
(1499, 99, 'Pondicherry', 'PO', 1),
(1500, 99, 'Punjab', 'PU', 1),
(1501, 99, 'Rajasthan', 'RA', 1),
(1502, 99, 'Sikkim', 'SI', 1),
(1503, 99, 'Tamil Nadu', 'TN', 1),
(1504, 99, 'Tripura', 'TR', 1),
(1505, 99, 'Uttar Pradesh', 'UP', 1),
(1506, 99, 'West Bengal', 'WB', 1),
(1507, 100, 'Aceh', 'AC', 1),
(1508, 100, 'Bali', 'BA', 1),
(1509, 100, 'Banten', 'BT', 1),
(1510, 100, 'Bengkulu', 'BE', 1),
(1511, 100, 'BoDeTaBek', 'BD', 1),
(1512, 100, 'Gorontalo', 'GO', 1),
(1513, 100, 'Jakarta Raya', 'JK', 1),
(1514, 100, 'Jambi', 'JA', 1),
(1515, 100, 'Jawa Barat', 'JB', 1),
(1516, 100, 'Jawa Tengah', 'JT', 1),
(1517, 100, 'Jawa Timur', 'JI', 1),
(1518, 100, 'Kalimantan Barat', 'KB', 1),
(1519, 100, 'Kalimantan Selatan', 'KS', 1),
(1520, 100, 'Kalimantan Tengah', 'KT', 1),
(1521, 100, 'Kalimantan Timur', 'KI', 1),
(1522, 100, 'Kepulauan Bangka Belitung', 'BB', 1),
(1523, 100, 'Lampung', 'LA', 1),
(1524, 100, 'Maluku', 'MA', 1),
(1525, 100, 'Maluku Utara', 'MU', 1),
(1526, 100, 'Nusa Tenggara Barat', 'NB', 1),
(1527, 100, 'Nusa Tenggara Timur', 'NT', 1),
(1528, 100, 'Papua', 'PA', 1),
(1529, 100, 'Riau', 'RI', 1),
(1530, 100, 'Sulawesi Selatan', 'SN', 1),
(1531, 100, 'Sulawesi Tengah', 'ST', 1),
(1532, 100, 'Sulawesi Tenggara', 'SG', 1),
(1533, 100, 'Sulawesi Utara', 'SA', 1),
(1534, 100, 'Sumatera Barat', 'SB', 1),
(1535, 100, 'Sumatera Selatan', 'SS', 1),
(1536, 100, 'Sumatera Utara', 'SU', 1),
(1537, 100, 'Yogyakarta', 'YO', 1),
(1538, 101, 'Tehran', 'TEH', 1),
(1539, 101, 'Qom', 'QOM', 1),
(1540, 101, 'Markazi', 'MKZ', 1),
(1541, 101, 'Qazvin', 'QAZ', 1),
(1542, 101, 'Gilan', 'GIL', 1),
(1543, 101, 'Ardabil', 'ARD', 1),
(1544, 101, 'Zanjan', 'ZAN', 1),
(1545, 101, 'East Azarbaijan', 'EAZ', 1),
(1546, 101, 'West Azarbaijan', 'WEZ', 1),
(1547, 101, 'Kurdistan', 'KRD', 1),
(1548, 101, 'Hamadan', 'HMD', 1),
(1549, 101, 'Kermanshah', 'KRM', 1),
(1550, 101, 'Ilam', 'ILM', 1),
(1551, 101, 'Lorestan', 'LRS', 1),
(1552, 101, 'Khuzestan', 'KZT', 1),
(1553, 101, 'Chahar Mahaal and Bakhtiari', 'CMB', 1),
(1554, 101, 'Kohkiluyeh and Buyer Ahmad', 'KBA', 1),
(1555, 101, 'Bushehr', 'BSH', 1),
(1556, 101, 'Fars', 'FAR', 1),
(1557, 101, 'Hormozgan', 'HRM', 1),
(1558, 101, 'Sistan and Baluchistan', 'SBL', 1),
(1559, 101, 'Kerman', 'KRB', 1),
(1560, 101, 'Yazd', 'YZD', 1),
(1561, 101, 'Esfahan', 'EFH', 1),
(1562, 101, 'Semnan', 'SMN', 1),
(1563, 101, 'Mazandaran', 'MZD', 1),
(1564, 101, 'Golestan', 'GLS', 1),
(1565, 101, 'North Khorasan', 'NKH', 1),
(1566, 101, 'Razavi Khorasan', 'RKH', 1),
(1567, 101, 'South Khorasan', 'SKH', 1),
(1568, 102, 'Baghdad', 'BD', 1),
(1569, 102, 'Salah ad Din', 'SD', 1),
(1570, 102, 'Diyala', 'DY', 1),
(1571, 102, 'Wasit', 'WS', 1),
(1572, 102, 'Maysan', 'MY', 1),
(1573, 102, 'Al Basrah', 'BA', 1),
(1574, 102, 'Dhi Qar', 'DQ', 1),
(1575, 102, 'Al Muthanna', 'MU', 1),
(1576, 102, 'Al Qadisyah', 'QA', 1),
(1577, 102, 'Babil', 'BB', 1),
(1578, 102, 'Al Karbala', 'KB', 1),
(1579, 102, 'An Najaf', 'NJ', 1),
(1580, 102, 'Al Anbar', 'AB', 1),
(1581, 102, 'Ninawa', 'NN', 1),
(1582, 102, 'Dahuk', 'DH', 1),
(1583, 102, 'Arbil', 'AL', 1),
(1584, 102, 'At Ta\'mim', 'TM', 1),
(1585, 102, 'As Sulaymaniyah', 'SL', 1),
(1586, 103, 'Carlow', 'CA', 1),
(1587, 103, 'Cavan', 'CV', 1),
(1588, 103, 'Clare', 'CL', 1),
(1589, 103, 'Cork', 'CO', 1),
(1590, 103, 'Donegal', 'DO', 1),
(1591, 103, 'Dublin', 'DU', 1),
(1592, 103, 'Galway', 'GA', 1),
(1593, 103, 'Kerry', 'KE', 1),
(1594, 103, 'Kildare', 'KI', 1),
(1595, 103, 'Kilkenny', 'KL', 1),
(1596, 103, 'Laois', 'LA', 1);
INSERT INTO `oc_zone` (`zone_id`, `country_id`, `name`, `code`, `status`) VALUES
(1597, 103, 'Leitrim', 'LE', 1),
(1598, 103, 'Limerick', 'LI', 1),
(1599, 103, 'Longford', 'LO', 1),
(1600, 103, 'Louth', 'LU', 1),
(1601, 103, 'Mayo', 'MA', 1),
(1602, 103, 'Meath', 'ME', 1),
(1603, 103, 'Monaghan', 'MO', 1),
(1604, 103, 'Offaly', 'OF', 1),
(1605, 103, 'Roscommon', 'RO', 1),
(1606, 103, 'Sligo', 'SL', 1),
(1607, 103, 'Tipperary', 'TI', 1),
(1608, 103, 'Waterford', 'WA', 1),
(1609, 103, 'Westmeath', 'WE', 1),
(1610, 103, 'Wexford', 'WX', 1),
(1611, 103, 'Wicklow', 'WI', 1),
(1612, 104, 'Be\'er Sheva', 'BS', 1),
(1613, 104, 'Bika\'at Hayarden', 'BH', 1),
(1614, 104, 'Eilat and Arava', 'EA', 1),
(1615, 104, 'Galil', 'GA', 1),
(1616, 104, 'Haifa', 'HA', 1),
(1617, 104, 'Jehuda Mountains', 'JM', 1),
(1618, 104, 'Jerusalem', 'JE', 1),
(1619, 104, 'Negev', 'NE', 1),
(1620, 104, 'Semaria', 'SE', 1),
(1621, 104, 'Sharon', 'SH', 1),
(1622, 104, 'Tel Aviv (Gosh Dan)', 'TA', 1),
(3860, 105, 'Caltanissetta', 'CL', 1),
(3842, 105, 'Agrigento', 'AG', 1),
(3843, 105, 'Alessandria', 'AL', 1),
(3844, 105, 'Ancona', 'AN', 1),
(3845, 105, 'Aosta', 'AO', 1),
(3846, 105, 'Arezzo', 'AR', 1),
(3847, 105, 'Ascoli Piceno', 'AP', 1),
(3848, 105, 'Asti', 'AT', 1),
(3849, 105, 'Avellino', 'AV', 1),
(3850, 105, 'Bari', 'BA', 1),
(3851, 105, 'Belluno', 'BL', 1),
(3852, 105, 'Benevento', 'BN', 1),
(3853, 105, 'Bergamo', 'BG', 1),
(3854, 105, 'Biella', 'BI', 1),
(3855, 105, 'Bologna', 'BO', 1),
(3856, 105, 'Bolzano', 'BZ', 1),
(3857, 105, 'Brescia', 'BS', 1),
(3858, 105, 'Brindisi', 'BR', 1),
(3859, 105, 'Cagliari', 'CA', 1),
(1643, 106, 'Clarendon Parish', 'CLA', 1),
(1644, 106, 'Hanover Parish', 'HAN', 1),
(1645, 106, 'Kingston Parish', 'KIN', 1),
(1646, 106, 'Manchester Parish', 'MAN', 1),
(1647, 106, 'Portland Parish', 'POR', 1),
(1648, 106, 'Saint Andrew Parish', 'AND', 1),
(1649, 106, 'Saint Ann Parish', 'ANN', 1),
(1650, 106, 'Saint Catherine Parish', 'CAT', 1),
(1651, 106, 'Saint Elizabeth Parish', 'ELI', 1),
(1652, 106, 'Saint James Parish', 'JAM', 1),
(1653, 106, 'Saint Mary Parish', 'MAR', 1),
(1654, 106, 'Saint Thomas Parish', 'THO', 1),
(1655, 106, 'Trelawny Parish', 'TRL', 1),
(1656, 106, 'Westmoreland Parish', 'WML', 1),
(1657, 107, 'Aichi', 'AI', 1),
(1658, 107, 'Akita', 'AK', 1),
(1659, 107, 'Aomori', 'AO', 1),
(1660, 107, 'Chiba', 'CH', 1),
(1661, 107, 'Ehime', 'EH', 1),
(1662, 107, 'Fukui', 'FK', 1),
(1663, 107, 'Fukuoka', 'FU', 1),
(1664, 107, 'Fukushima', 'FS', 1),
(1665, 107, 'Gifu', 'GI', 1),
(1666, 107, 'Gumma', 'GU', 1),
(1667, 107, 'Hiroshima', 'HI', 1),
(1668, 107, 'Hokkaido', 'HO', 1),
(1669, 107, 'Hyogo', 'HY', 1),
(1670, 107, 'Ibaraki', 'IB', 1),
(1671, 107, 'Ishikawa', 'IS', 1),
(1672, 107, 'Iwate', 'IW', 1),
(1673, 107, 'Kagawa', 'KA', 1),
(1674, 107, 'Kagoshima', 'KG', 1),
(1675, 107, 'Kanagawa', 'KN', 1),
(1676, 107, 'Kochi', 'KO', 1),
(1677, 107, 'Kumamoto', 'KU', 1),
(1678, 107, 'Kyoto', 'KY', 1),
(1679, 107, 'Mie', 'MI', 1),
(1680, 107, 'Miyagi', 'MY', 1),
(1681, 107, 'Miyazaki', 'MZ', 1),
(1682, 107, 'Nagano', 'NA', 1),
(1683, 107, 'Nagasaki', 'NG', 1),
(1684, 107, 'Nara', 'NR', 1),
(1685, 107, 'Niigata', 'NI', 1),
(1686, 107, 'Oita', 'OI', 1),
(1687, 107, 'Okayama', 'OK', 1),
(1688, 107, 'Okinawa', 'ON', 1),
(1689, 107, 'Osaka', 'OS', 1),
(1690, 107, 'Saga', 'SA', 1),
(1691, 107, 'Saitama', 'SI', 1),
(1692, 107, 'Shiga', 'SH', 1),
(1693, 107, 'Shimane', 'SM', 1),
(1694, 107, 'Shizuoka', 'SZ', 1),
(1695, 107, 'Tochigi', 'TO', 1),
(1696, 107, 'Tokushima', 'TS', 1),
(1697, 107, 'Tokyo', 'TK', 1),
(1698, 107, 'Tottori', 'TT', 1),
(1699, 107, 'Toyama', 'TY', 1),
(1700, 107, 'Wakayama', 'WA', 1),
(1701, 107, 'Yamagata', 'YA', 1),
(1702, 107, 'Yamaguchi', 'YM', 1),
(1703, 107, 'Yamanashi', 'YN', 1),
(1704, 108, '\'Amman', 'AM', 1),
(1705, 108, 'Ajlun', 'AJ', 1),
(1706, 108, 'Al \'Aqabah', 'AA', 1),
(1707, 108, 'Al Balqa\'', 'AB', 1),
(1708, 108, 'Al Karak', 'AK', 1),
(1709, 108, 'Al Mafraq', 'AL', 1),
(1710, 108, 'At Tafilah', 'AT', 1),
(1711, 108, 'Az Zarqa\'', 'AZ', 1),
(1712, 108, 'Irbid', 'IR', 1),
(1713, 108, 'Jarash', 'JA', 1),
(1714, 108, 'Ma\'an', 'MA', 1),
(1715, 108, 'Madaba', 'MD', 1),
(1716, 109, 'Almaty', 'AL', 1),
(1717, 109, 'Almaty City', 'AC', 1),
(1718, 109, 'Aqmola', 'AM', 1),
(1719, 109, 'Aqtobe', 'AQ', 1),
(1720, 109, 'Astana City', 'AS', 1),
(1721, 109, 'Atyrau', 'AT', 1),
(1722, 109, 'Batys Qazaqstan', 'BA', 1),
(1723, 109, 'Bayqongyr City', 'BY', 1),
(1724, 109, 'Mangghystau', 'MA', 1),
(1725, 109, 'Ongtustik Qazaqstan', 'ON', 1),
(1726, 109, 'Pavlodar', 'PA', 1),
(1727, 109, 'Qaraghandy', 'QA', 1),
(1728, 109, 'Qostanay', 'QO', 1),
(1729, 109, 'Qyzylorda', 'QY', 1),
(1730, 109, 'Shyghys Qazaqstan', 'SH', 1),
(1731, 109, 'Soltustik Qazaqstan', 'SO', 1),
(1732, 109, 'Zhambyl', 'ZH', 1),
(1733, 110, 'Central', 'CE', 1),
(1734, 110, 'Coast', 'CO', 1),
(1735, 110, 'Eastern', 'EA', 1),
(1736, 110, 'Nairobi Area', 'NA', 1),
(1737, 110, 'North Eastern', 'NE', 1),
(1738, 110, 'Nyanza', 'NY', 1),
(1739, 110, 'Rift Valley', 'RV', 1),
(1740, 110, 'Western', 'WE', 1),
(1741, 111, 'Abaiang', 'AG', 1),
(1742, 111, 'Abemama', 'AM', 1),
(1743, 111, 'Aranuka', 'AK', 1),
(1744, 111, 'Arorae', 'AO', 1),
(1745, 111, 'Banaba', 'BA', 1),
(1746, 111, 'Beru', 'BE', 1),
(1747, 111, 'Butaritari', 'bT', 1),
(1748, 111, 'Kanton', 'KA', 1),
(1749, 111, 'Kiritimati', 'KR', 1),
(1750, 111, 'Kuria', 'KU', 1),
(1751, 111, 'Maiana', 'MI', 1),
(1752, 111, 'Makin', 'MN', 1),
(1753, 111, 'Marakei', 'ME', 1),
(1754, 111, 'Nikunau', 'NI', 1),
(1755, 111, 'Nonouti', 'NO', 1),
(1756, 111, 'Onotoa', 'ON', 1),
(1757, 111, 'Tabiteuea', 'TT', 1),
(1758, 111, 'Tabuaeran', 'TR', 1),
(1759, 111, 'Tamana', 'TM', 1),
(1760, 111, 'Tarawa', 'TW', 1),
(1761, 111, 'Teraina', 'TE', 1),
(1762, 112, 'Chagang-do', 'CHA', 1),
(1763, 112, 'Hamgyong-bukto', 'HAB', 1),
(1764, 112, 'Hamgyong-namdo', 'HAN', 1),
(1765, 112, 'Hwanghae-bukto', 'HWB', 1),
(1766, 112, 'Hwanghae-namdo', 'HWN', 1),
(1767, 112, 'Kangwon-do', 'KAN', 1),
(1768, 112, 'P\'yongan-bukto', 'PYB', 1),
(1769, 112, 'P\'yongan-namdo', 'PYN', 1),
(1770, 112, 'Ryanggang-do (Yanggang-do)', 'YAN', 1),
(1771, 112, 'Rason Directly Governed City', 'NAJ', 1),
(1772, 112, 'P\'yongyang Special City', 'PYO', 1),
(1773, 113, 'Ch\'ungch\'ong-bukto', 'CO', 1),
(1774, 113, 'Ch\'ungch\'ong-namdo', 'CH', 1),
(1775, 113, 'Cheju-do', 'CD', 1),
(1776, 113, 'Cholla-bukto', 'CB', 1),
(1777, 113, 'Cholla-namdo', 'CN', 1),
(1778, 113, 'Inch\'on-gwangyoksi', 'IG', 1),
(1779, 113, 'Kangwon-do', 'KA', 1),
(1780, 113, 'Kwangju-gwangyoksi', 'KG', 1),
(1781, 113, 'Kyonggi-do', 'KD', 1),
(1782, 113, 'Kyongsang-bukto', 'KB', 1),
(1783, 113, 'Kyongsang-namdo', 'KN', 1),
(1784, 113, 'Pusan-gwangyoksi', 'PG', 1),
(1785, 113, 'Soul-t\'ukpyolsi', 'SO', 1),
(1786, 113, 'Taegu-gwangyoksi', 'TA', 1),
(1787, 113, 'Taejon-gwangyoksi', 'TG', 1),
(1788, 114, 'Al \'Asimah', 'AL', 1),
(1789, 114, 'Al Ahmadi', 'AA', 1),
(1790, 114, 'Al Farwaniyah', 'AF', 1),
(1791, 114, 'Al Jahra\'', 'AJ', 1),
(1792, 114, 'Hawalli', 'HA', 1),
(1793, 115, 'Bishkek', 'GB', 1),
(1794, 115, 'Batken', 'B', 1),
(1795, 115, 'Chu', 'C', 1),
(1796, 115, 'Jalal-Abad', 'J', 1),
(1797, 115, 'Naryn', 'N', 1),
(1798, 115, 'Osh', 'O', 1),
(1799, 115, 'Talas', 'T', 1),
(1800, 115, 'Ysyk-Kol', 'Y', 1),
(1801, 116, 'Vientiane', 'VT', 1),
(1802, 116, 'Attapu', 'AT', 1),
(1803, 116, 'Bokeo', 'BK', 1),
(1804, 116, 'Bolikhamxai', 'BL', 1),
(1805, 116, 'Champasak', 'CH', 1),
(1806, 116, 'Houaphan', 'HO', 1),
(1807, 116, 'Khammouan', 'KH', 1),
(1808, 116, 'Louang Namtha', 'LM', 1),
(1809, 116, 'Louangphabang', 'LP', 1),
(1810, 116, 'Oudomxai', 'OU', 1),
(1811, 116, 'Phongsali', 'PH', 1),
(1812, 116, 'Salavan', 'SL', 1),
(1813, 116, 'Savannakhet', 'SV', 1),
(1814, 116, 'Vientiane', 'VI', 1),
(1815, 116, 'Xaignabouli', 'XA', 1),
(1816, 116, 'Xekong', 'XE', 1),
(1817, 116, 'Xiangkhoang', 'XI', 1),
(1818, 116, 'Xaisomboun', 'XN', 1),
(1852, 119, 'Berea', 'BE', 1),
(1853, 119, 'Butha-Buthe', 'BB', 1),
(1854, 119, 'Leribe', 'LE', 1),
(1855, 119, 'Mafeteng', 'MF', 1),
(1856, 119, 'Maseru', 'MS', 1),
(1857, 119, 'Mohale\'s Hoek', 'MH', 1),
(1858, 119, 'Mokhotlong', 'MK', 1),
(1859, 119, 'Qacha\'s Nek', 'QN', 1),
(1860, 119, 'Quthing', 'QT', 1),
(1861, 119, 'Thaba-Tseka', 'TT', 1),
(1862, 120, 'Bomi', 'BI', 1),
(1863, 120, 'Bong', 'BG', 1),
(1864, 120, 'Grand Bassa', 'GB', 1),
(1865, 120, 'Grand Cape Mount', 'CM', 1),
(1866, 120, 'Grand Gedeh', 'GG', 1),
(1867, 120, 'Grand Kru', 'GK', 1),
(1868, 120, 'Lofa', 'LO', 1),
(1869, 120, 'Margibi', 'MG', 1),
(1870, 120, 'Maryland', 'ML', 1),
(1871, 120, 'Montserrado', 'MS', 1),
(1872, 120, 'Nimba', 'NB', 1),
(1873, 120, 'River Cess', 'RC', 1),
(1874, 120, 'Sinoe', 'SN', 1),
(1875, 121, 'Ajdabiya', 'AJ', 1),
(1876, 121, 'Al \'Aziziyah', 'AZ', 1),
(1877, 121, 'Al Fatih', 'FA', 1),
(1878, 121, 'Al Jabal al Akhdar', 'JA', 1),
(1879, 121, 'Al Jufrah', 'JU', 1),
(1880, 121, 'Al Khums', 'KH', 1),
(1881, 121, 'Al Kufrah', 'KU', 1),
(1882, 121, 'An Nuqat al Khams', 'NK', 1),
(1883, 121, 'Ash Shati\'', 'AS', 1),
(1884, 121, 'Awbari', 'AW', 1),
(1885, 121, 'Az Zawiyah', 'ZA', 1),
(1886, 121, 'Banghazi', 'BA', 1),
(1887, 121, 'Darnah', 'DA', 1),
(1888, 121, 'Ghadamis', 'GD', 1),
(1889, 121, 'Gharyan', 'GY', 1),
(1890, 121, 'Misratah', 'MI', 1),
(1891, 121, 'Murzuq', 'MZ', 1),
(1892, 121, 'Sabha', 'SB', 1),
(1893, 121, 'Sawfajjin', 'SW', 1),
(1894, 121, 'Surt', 'SU', 1),
(1895, 121, 'Tarabulus (Tripoli)', 'TL', 1),
(1896, 121, 'Tarhunah', 'TH', 1),
(1897, 121, 'Tubruq', 'TU', 1),
(1898, 121, 'Yafran', 'YA', 1),
(1899, 121, 'Zlitan', 'ZL', 1),
(1900, 122, 'Vaduz', 'V', 1),
(1901, 122, 'Schaan', 'A', 1),
(1902, 122, 'Balzers', 'B', 1),
(1903, 122, 'Triesen', 'N', 1),
(1904, 122, 'Eschen', 'E', 1),
(1905, 122, 'Mauren', 'M', 1),
(1906, 122, 'Triesenberg', 'T', 1),
(1907, 122, 'Ruggell', 'R', 1),
(1908, 122, 'Gamprin', 'G', 1),
(1909, 122, 'Schellenberg', 'L', 1),
(1910, 122, 'Planken', 'P', 1),
(1911, 123, 'Alytus', 'AL', 1),
(1912, 123, 'Kaunas', 'KA', 1),
(1913, 123, 'Klaipeda', 'KL', 1),
(1914, 123, 'Marijampole', 'MA', 1),
(1915, 123, 'Panevezys', 'PA', 1),
(1916, 123, 'Siauliai', 'SI', 1),
(1917, 123, 'Taurage', 'TA', 1),
(1918, 123, 'Telsiai', 'TE', 1),
(1919, 123, 'Utena', 'UT', 1),
(1920, 123, 'Vilnius', 'VI', 1),
(1921, 124, 'Diekirch', 'DD', 1),
(1922, 124, 'Clervaux', 'DC', 1),
(1923, 124, 'Redange', 'DR', 1),
(1924, 124, 'Vianden', 'DV', 1),
(1925, 124, 'Wiltz', 'DW', 1),
(1926, 124, 'Grevenmacher', 'GG', 1),
(1927, 124, 'Echternach', 'GE', 1),
(1928, 124, 'Remich', 'GR', 1),
(1929, 124, 'Luxembourg', 'LL', 1),
(1930, 124, 'Capellen', 'LC', 1),
(1931, 124, 'Esch-sur-Alzette', 'LE', 1),
(1932, 124, 'Mersch', 'LM', 1),
(1933, 125, 'Our Lady Fatima Parish', 'OLF', 1),
(1934, 125, 'St. Anthony Parish', 'ANT', 1),
(1935, 125, 'St. Lazarus Parish', 'LAZ', 1),
(1936, 125, 'Cathedral Parish', 'CAT', 1),
(1937, 125, 'St. Lawrence Parish', 'LAW', 1),
(1938, 127, 'Antananarivo', 'AN', 1),
(1939, 127, 'Antsiranana', 'AS', 1),
(1940, 127, 'Fianarantsoa', 'FN', 1),
(1941, 127, 'Mahajanga', 'MJ', 1),
(1942, 127, 'Toamasina', 'TM', 1),
(1943, 127, 'Toliara', 'TL', 1),
(1944, 128, 'Balaka', 'BLK', 1),
(1945, 128, 'Blantyre', 'BLT', 1),
(1946, 128, 'Chikwawa', 'CKW', 1),
(1947, 128, 'Chiradzulu', 'CRD', 1),
(1948, 128, 'Chitipa', 'CTP', 1),
(1949, 128, 'Dedza', 'DDZ', 1),
(1950, 128, 'Dowa', 'DWA', 1),
(1951, 128, 'Karonga', 'KRG', 1),
(1952, 128, 'Kasungu', 'KSG', 1),
(1953, 128, 'Likoma', 'LKM', 1),
(1954, 128, 'Lilongwe', 'LLG', 1),
(1955, 128, 'Machinga', 'MCG', 1),
(1956, 128, 'Mangochi', 'MGC', 1),
(1957, 128, 'Mchinji', 'MCH', 1),
(1958, 128, 'Mulanje', 'MLJ', 1),
(1959, 128, 'Mwanza', 'MWZ', 1),
(1960, 128, 'Mzimba', 'MZM', 1),
(1961, 128, 'Ntcheu', 'NTU', 1),
(1962, 128, 'Nkhata Bay', 'NKB', 1),
(1963, 128, 'Nkhotakota', 'NKH', 1),
(1964, 128, 'Nsanje', 'NSJ', 1),
(1965, 128, 'Ntchisi', 'NTI', 1),
(1966, 128, 'Phalombe', 'PHL', 1),
(1967, 128, 'Rumphi', 'RMP', 1),
(1968, 128, 'Salima', 'SLM', 1),
(1969, 128, 'Thyolo', 'THY', 1),
(1970, 128, 'Zomba', 'ZBA', 1),
(1971, 129, 'Johor', 'MY-01', 1),
(1972, 129, 'Kedah', 'MY-02', 1),
(1973, 129, 'Kelantan', 'MY-03', 1),
(1974, 129, 'Labuan', 'MY-15', 1),
(1975, 129, 'Melaka', 'MY-04', 1),
(1976, 129, 'Negeri Sembilan', 'MY-05', 1),
(1977, 129, 'Pahang', 'MY-06', 1),
(1978, 129, 'Perak', 'MY-08', 1),
(1979, 129, 'Perlis', 'MY-09', 1),
(1980, 129, 'Pulau Pinang', 'MY-07', 1),
(1981, 129, 'Sabah', 'MY-12', 1),
(1982, 129, 'Sarawak', 'MY-13', 1),
(1983, 129, 'Selangor', 'MY-10', 1),
(1984, 129, 'Terengganu', 'MY-11', 1),
(1985, 129, 'Kuala Lumpur', 'MY-14', 1),
(4035, 129, 'Putrajaya', 'MY-16', 1),
(1986, 130, 'Thiladhunmathi Uthuru', 'THU', 1),
(1987, 130, 'Thiladhunmathi Dhekunu', 'THD', 1),
(1988, 130, 'Miladhunmadulu Uthuru', 'MLU', 1),
(1989, 130, 'Miladhunmadulu Dhekunu', 'MLD', 1),
(1990, 130, 'Maalhosmadulu Uthuru', 'MAU', 1),
(1991, 130, 'Maalhosmadulu Dhekunu', 'MAD', 1),
(1992, 130, 'Faadhippolhu', 'FAA', 1),
(1993, 130, 'Male Atoll', 'MAA', 1),
(1994, 130, 'Ari Atoll Uthuru', 'AAU', 1),
(1995, 130, 'Ari Atoll Dheknu', 'AAD', 1),
(1996, 130, 'Felidhe Atoll', 'FEA', 1),
(1997, 130, 'Mulaku Atoll', 'MUA', 1),
(1998, 130, 'Nilandhe Atoll Uthuru', 'NAU', 1),
(1999, 130, 'Nilandhe Atoll Dhekunu', 'NAD', 1),
(2000, 130, 'Kolhumadulu', 'KLH', 1),
(2001, 130, 'Hadhdhunmathi', 'HDH', 1),
(2002, 130, 'Huvadhu Atoll Uthuru', 'HAU', 1),
(2003, 130, 'Huvadhu Atoll Dhekunu', 'HAD', 1),
(2004, 130, 'Fua Mulaku', 'FMU', 1),
(2005, 130, 'Addu', 'ADD', 1),
(2006, 131, 'Gao', 'GA', 1),
(2007, 131, 'Kayes', 'KY', 1),
(2008, 131, 'Kidal', 'KD', 1),
(2009, 131, 'Koulikoro', 'KL', 1),
(2010, 131, 'Mopti', 'MP', 1),
(2011, 131, 'Segou', 'SG', 1),
(2012, 131, 'Sikasso', 'SK', 1),
(2013, 131, 'Tombouctou', 'TB', 1),
(2014, 131, 'Bamako Capital District', 'CD', 1),
(2015, 132, 'Attard', 'ATT', 1),
(2016, 132, 'Balzan', 'BAL', 1),
(2017, 132, 'Birgu', 'BGU', 1),
(2018, 132, 'Birkirkara', 'BKK', 1),
(2019, 132, 'Birzebbuga', 'BRZ', 1),
(2020, 132, 'Bormla', 'BOR', 1),
(2021, 132, 'Dingli', 'DIN', 1),
(2022, 132, 'Fgura', 'FGU', 1),
(2023, 132, 'Floriana', 'FLO', 1),
(2024, 132, 'Gudja', 'GDJ', 1),
(2025, 132, 'Gzira', 'GZR', 1),
(2026, 132, 'Gargur', 'GRG', 1),
(2027, 132, 'Gaxaq', 'GXQ', 1),
(2028, 132, 'Hamrun', 'HMR', 1),
(2029, 132, 'Iklin', 'IKL', 1),
(2030, 132, 'Isla', 'ISL', 1),
(2031, 132, 'Kalkara', 'KLK', 1),
(2032, 132, 'Kirkop', 'KRK', 1),
(2033, 132, 'Lija', 'LIJ', 1),
(2034, 132, 'Luqa', 'LUQ', 1),
(2035, 132, 'Marsa', 'MRS', 1),
(2036, 132, 'Marsaskala', 'MKL', 1),
(2037, 132, 'Marsaxlokk', 'MXL', 1),
(2038, 132, 'Mdina', 'MDN', 1),
(2039, 132, 'Melliea', 'MEL', 1),
(2040, 132, 'Mgarr', 'MGR', 1),
(2041, 132, 'Mosta', 'MST', 1),
(2042, 132, 'Mqabba', 'MQA', 1),
(2043, 132, 'Msida', 'MSI', 1),
(2044, 132, 'Mtarfa', 'MTF', 1),
(2045, 132, 'Naxxar', 'NAX', 1),
(2046, 132, 'Paola', 'PAO', 1),
(2047, 132, 'Pembroke', 'PEM', 1),
(2048, 132, 'Pieta', 'PIE', 1),
(2049, 132, 'Qormi', 'QOR', 1),
(2050, 132, 'Qrendi', 'QRE', 1),
(2051, 132, 'Rabat', 'RAB', 1),
(2052, 132, 'Safi', 'SAF', 1),
(2053, 132, 'San Giljan', 'SGI', 1),
(2054, 132, 'Santa Lucija', 'SLU', 1),
(2055, 132, 'San Pawl il-Bahar', 'SPB', 1),
(2056, 132, 'San Gwann', 'SGW', 1),
(2057, 132, 'Santa Venera', 'SVE', 1),
(2058, 132, 'Siggiewi', 'SIG', 1),
(2059, 132, 'Sliema', 'SLM', 1),
(2060, 132, 'Swieqi', 'SWQ', 1),
(2061, 132, 'Ta Xbiex', 'TXB', 1),
(2062, 132, 'Tarxien', 'TRX', 1),
(2063, 132, 'Valletta', 'VLT', 1),
(2064, 132, 'Xgajra', 'XGJ', 1),
(2065, 132, 'Zabbar', 'ZBR', 1),
(2066, 132, 'Zebbug', 'ZBG', 1),
(2067, 132, 'Zejtun', 'ZJT', 1),
(2068, 132, 'Zurrieq', 'ZRQ', 1),
(2069, 132, 'Fontana', 'FNT', 1),
(2070, 132, 'Ghajnsielem', 'GHJ', 1),
(2071, 132, 'Gharb', 'GHR', 1),
(2072, 132, 'Ghasri', 'GHS', 1),
(2073, 132, 'Kercem', 'KRC', 1),
(2074, 132, 'Munxar', 'MUN', 1),
(2075, 132, 'Nadur', 'NAD', 1),
(2076, 132, 'Qala', 'QAL', 1),
(2077, 132, 'Victoria', 'VIC', 1),
(2078, 132, 'San Lawrenz', 'SLA', 1),
(2079, 132, 'Sannat', 'SNT', 1),
(2080, 132, 'Xagra', 'ZAG', 1),
(2081, 132, 'Xewkija', 'XEW', 1),
(2082, 132, 'Zebbug', 'ZEB', 1),
(2083, 133, 'Ailinginae', 'ALG', 1),
(2084, 133, 'Ailinglaplap', 'ALL', 1),
(2085, 133, 'Ailuk', 'ALK', 1),
(2086, 133, 'Arno', 'ARN', 1),
(2087, 133, 'Aur', 'AUR', 1),
(2088, 133, 'Bikar', 'BKR', 1),
(2089, 133, 'Bikini', 'BKN', 1),
(2090, 133, 'Bokak', 'BKK', 1),
(2091, 133, 'Ebon', 'EBN', 1),
(2092, 133, 'Enewetak', 'ENT', 1),
(2093, 133, 'Erikub', 'EKB', 1),
(2094, 133, 'Jabat', 'JBT', 1),
(2095, 133, 'Jaluit', 'JLT', 1),
(2096, 133, 'Jemo', 'JEM', 1),
(2097, 133, 'Kili', 'KIL', 1),
(2098, 133, 'Kwajalein', 'KWJ', 1),
(2099, 133, 'Lae', 'LAE', 1),
(2100, 133, 'Lib', 'LIB', 1),
(2101, 133, 'Likiep', 'LKP', 1),
(2102, 133, 'Majuro', 'MJR', 1),
(2103, 133, 'Maloelap', 'MLP', 1),
(2104, 133, 'Mejit', 'MJT', 1),
(2105, 133, 'Mili', 'MIL', 1),
(2106, 133, 'Namorik', 'NMK', 1),
(2107, 133, 'Namu', 'NAM', 1),
(2108, 133, 'Rongelap', 'RGL', 1),
(2109, 133, 'Rongrik', 'RGK', 1),
(2110, 133, 'Toke', 'TOK', 1),
(2111, 133, 'Ujae', 'UJA', 1),
(2112, 133, 'Ujelang', 'UJL', 1),
(2113, 133, 'Utirik', 'UTK', 1),
(2114, 133, 'Wotho', 'WTH', 1),
(2115, 133, 'Wotje', 'WTJ', 1),
(2116, 135, 'Adrar', 'AD', 1),
(2117, 135, 'Assaba', 'AS', 1),
(2118, 135, 'Brakna', 'BR', 1),
(2119, 135, 'Dakhlet Nouadhibou', 'DN', 1),
(2120, 135, 'Gorgol', 'GO', 1),
(2121, 135, 'Guidimaka', 'GM', 1),
(2122, 135, 'Hodh Ech Chargui', 'HC', 1),
(2123, 135, 'Hodh El Gharbi', 'HG', 1),
(2124, 135, 'Inchiri', 'IN', 1),
(2125, 135, 'Tagant', 'TA', 1),
(2126, 135, 'Tiris Zemmour', 'TZ', 1),
(2127, 135, 'Trarza', 'TR', 1),
(2128, 135, 'Nouakchott', 'NO', 1),
(2129, 136, 'Beau Bassin-Rose Hill', 'BR', 1),
(2130, 136, 'Curepipe', 'CU', 1),
(2131, 136, 'Port Louis', 'PU', 1),
(2132, 136, 'Quatre Bornes', 'QB', 1),
(2133, 136, 'Vacoas-Phoenix', 'VP', 1),
(2134, 136, 'Agalega Islands', 'AG', 1),
(2135, 136, 'Cargados Carajos Shoals (Saint Brandon Islands)', 'CC', 1),
(2136, 136, 'Rodrigues', 'RO', 1),
(2137, 136, 'Black River', 'BL', 1),
(2138, 136, 'Flacq', 'FL', 1),
(2139, 136, 'Grand Port', 'GP', 1),
(2140, 136, 'Moka', 'MO', 1),
(2141, 136, 'Pamplemousses', 'PA', 1),
(2142, 136, 'Plaines Wilhems', 'PW', 1),
(2143, 136, 'Port Louis', 'PL', 1),
(2144, 136, 'Riviere du Rempart', 'RR', 1),
(2145, 136, 'Savanne', 'SA', 1),
(2146, 138, 'Baja California Norte', 'BN', 1),
(2147, 138, 'Baja California Sur', 'BS', 1),
(2148, 138, 'Campeche', 'CA', 1),
(2149, 138, 'Chiapas', 'CI', 1),
(2150, 138, 'Chihuahua', 'CH', 1),
(2151, 138, 'Coahuila de Zaragoza', 'CZ', 1),
(2152, 138, 'Colima', 'CL', 1),
(2153, 138, 'Distrito Federal', 'DF', 1),
(2154, 138, 'Durango', 'DU', 1),
(2155, 138, 'Guanajuato', 'GA', 1),
(2156, 138, 'Guerrero', 'GE', 1),
(2157, 138, 'Hidalgo', 'HI', 1),
(2158, 138, 'Jalisco', 'JA', 1),
(2159, 138, 'Mexico', 'ME', 1),
(2160, 138, 'Michoacan de Ocampo', 'MI', 1),
(2161, 138, 'Morelos', 'MO', 1),
(2162, 138, 'Nayarit', 'NA', 1),
(2163, 138, 'Nuevo Leon', 'NL', 1),
(2164, 138, 'Oaxaca', 'OA', 1),
(2165, 138, 'Puebla', 'PU', 1),
(2166, 138, 'Queretaro de Arteaga', 'QA', 1),
(2167, 138, 'Quintana Roo', 'QR', 1),
(2168, 138, 'San Luis Potosi', 'SA', 1),
(2169, 138, 'Sinaloa', 'SI', 1),
(2170, 138, 'Sonora', 'SO', 1),
(2171, 138, 'Tabasco', 'TB', 1),
(2172, 138, 'Tamaulipas', 'TM', 1),
(2173, 138, 'Tlaxcala', 'TL', 1),
(2174, 138, 'Veracruz-Llave', 'VE', 1),
(2175, 138, 'Yucatan', 'YU', 1),
(2176, 138, 'Zacatecas', 'ZA', 1),
(2177, 139, 'Chuuk', 'C', 1),
(2178, 139, 'Kosrae', 'K', 1),
(2179, 139, 'Pohnpei', 'P', 1),
(2180, 139, 'Yap', 'Y', 1),
(2181, 140, 'Gagauzia', 'GA', 1),
(2182, 140, 'Chisinau', 'CU', 1),
(2183, 140, 'Balti', 'BA', 1),
(2184, 140, 'Cahul', 'CA', 1),
(2185, 140, 'Edinet', 'ED', 1),
(2186, 140, 'Lapusna', 'LA', 1),
(2187, 140, 'Orhei', 'OR', 1),
(2188, 140, 'Soroca', 'SO', 1),
(2189, 140, 'Tighina', 'TI', 1),
(2190, 140, 'Ungheni', 'UN', 1),
(2191, 140, 'St‚nga Nistrului', 'SN', 1),
(2192, 141, 'Fontvieille', 'FV', 1),
(2193, 141, 'La Condamine', 'LC', 1),
(2194, 141, 'Monaco-Ville', 'MV', 1),
(2195, 141, 'Monte-Carlo', 'MC', 1),
(2196, 142, 'Ulanbaatar', '1', 1),
(2197, 142, 'Orhon', '035', 1),
(2198, 142, 'Darhan uul', '037', 1),
(2199, 142, 'Hentiy', '039', 1),
(2200, 142, 'Hovsgol', '041', 1),
(2201, 142, 'Hovd', '043', 1),
(2202, 142, 'Uvs', '046', 1),
(2203, 142, 'Tov', '047', 1),
(2204, 142, 'Selenge', '049', 1),
(2205, 142, 'Suhbaatar', '051', 1),
(2206, 142, 'Omnogovi', '053', 1),
(2207, 142, 'Ovorhangay', '055', 1),
(2208, 142, 'Dzavhan', '057', 1),
(2209, 142, 'DundgovL', '059', 1),
(2210, 142, 'Dornod', '061', 1),
(2211, 142, 'Dornogov', '063', 1),
(2212, 142, 'Govi-Sumber', '064', 1),
(2213, 142, 'Govi-Altay', '065', 1),
(2214, 142, 'Bulgan', '067', 1),
(2215, 142, 'Bayanhongor', '069', 1),
(2216, 142, 'Bayan-Olgiy', '071', 1),
(2217, 142, 'Arhangay', '073', 1),
(2218, 143, 'Saint Anthony', 'A', 1),
(2219, 143, 'Saint Georges', 'G', 1),
(2220, 143, 'Saint Peter', 'P', 1),
(2221, 144, 'Agadir', 'AGD', 1),
(2222, 144, 'Al Hoceima', 'HOC', 1),
(2223, 144, 'Azilal', 'AZI', 1),
(2224, 144, 'Beni Mellal', 'BME', 1),
(2225, 144, 'Ben Slimane', 'BSL', 1),
(2226, 144, 'Boulemane', 'BLM', 1),
(2227, 144, 'Casablanca', 'CBL', 1),
(2228, 144, 'Chaouen', 'CHA', 1),
(2229, 144, 'El Jadida', 'EJA', 1),
(2230, 144, 'El Kelaa des Sraghna', 'EKS', 1),
(2231, 144, 'Er Rachidia', 'ERA', 1),
(2232, 144, 'Essaouira', 'ESS', 1),
(2233, 144, 'Fes', 'FES', 1),
(2234, 144, 'Figuig', 'FIG', 1),
(2235, 144, 'Guelmim', 'GLM', 1),
(2236, 144, 'Ifrane', 'IFR', 1),
(2237, 144, 'Kenitra', 'KEN', 1),
(2238, 144, 'Khemisset', 'KHM', 1),
(2239, 144, 'Khenifra', 'KHN', 1),
(2240, 144, 'Khouribga', 'KHO', 1),
(2241, 144, 'Laayoune', 'LYN', 1),
(2242, 144, 'Larache', 'LAR', 1),
(2243, 144, 'Marrakech', 'MRK', 1),
(2244, 144, 'Meknes', 'MKN', 1),
(2245, 144, 'Nador', 'NAD', 1),
(2246, 144, 'Ouarzazate', 'ORZ', 1),
(2247, 144, 'Oujda', 'OUJ', 1),
(2248, 144, 'Rabat-Sale', 'RSA', 1),
(2249, 144, 'Safi', 'SAF', 1),
(2250, 144, 'Settat', 'SET', 1),
(2251, 144, 'Sidi Kacem', 'SKA', 1),
(2252, 144, 'Tangier', 'TGR', 1),
(2253, 144, 'Tan-Tan', 'TAN', 1),
(2254, 144, 'Taounate', 'TAO', 1),
(2255, 144, 'Taroudannt', 'TRD', 1),
(2256, 144, 'Tata', 'TAT', 1),
(2257, 144, 'Taza', 'TAZ', 1),
(2258, 144, 'Tetouan', 'TET', 1),
(2259, 144, 'Tiznit', 'TIZ', 1),
(2260, 144, 'Ad Dakhla', 'ADK', 1),
(2261, 144, 'Boujdour', 'BJD', 1),
(2262, 144, 'Es Smara', 'ESM', 1),
(2263, 145, 'Cabo Delgado', 'CD', 1),
(2264, 145, 'Gaza', 'GZ', 1),
(2265, 145, 'Inhambane', 'IN', 1),
(2266, 145, 'Manica', 'MN', 1),
(2267, 145, 'Maputo (city)', 'MC', 1),
(2268, 145, 'Maputo', 'MP', 1),
(2269, 145, 'Nampula', 'NA', 1),
(2270, 145, 'Niassa', 'NI', 1),
(2271, 145, 'Sofala', 'SO', 1),
(2272, 145, 'Tete', 'TE', 1),
(2273, 145, 'Zambezia', 'ZA', 1),
(2274, 146, 'Ayeyarwady', 'AY', 1),
(2275, 146, 'Bago', 'BG', 1),
(2276, 146, 'Magway', 'MG', 1),
(2277, 146, 'Mandalay', 'MD', 1),
(2278, 146, 'Sagaing', 'SG', 1),
(2279, 146, 'Tanintharyi', 'TN', 1),
(2280, 146, 'Yangon', 'YG', 1),
(2281, 146, 'Chin State', 'CH', 1),
(2282, 146, 'Kachin State', 'KC', 1),
(2283, 146, 'Kayah State', 'KH', 1),
(2284, 146, 'Kayin State', 'KN', 1),
(2285, 146, 'Mon State', 'MN', 1),
(2286, 146, 'Rakhine State', 'RK', 1),
(2287, 146, 'Shan State', 'SH', 1),
(2288, 147, 'Caprivi', 'CA', 1),
(2289, 147, 'Erongo', 'ER', 1),
(2290, 147, 'Hardap', 'HA', 1),
(2291, 147, 'Karas', 'KR', 1),
(2292, 147, 'Kavango', 'KV', 1),
(2293, 147, 'Khomas', 'KH', 1),
(2294, 147, 'Kunene', 'KU', 1),
(2295, 147, 'Ohangwena', 'OW', 1),
(2296, 147, 'Omaheke', 'OK', 1),
(2297, 147, 'Omusati', 'OT', 1),
(2298, 147, 'Oshana', 'ON', 1),
(2299, 147, 'Oshikoto', 'OO', 1),
(2300, 147, 'Otjozondjupa', 'OJ', 1),
(2301, 148, 'Aiwo', 'AO', 1),
(2302, 148, 'Anabar', 'AA', 1),
(2303, 148, 'Anetan', 'AT', 1),
(2304, 148, 'Anibare', 'AI', 1),
(2305, 148, 'Baiti', 'BA', 1),
(2306, 148, 'Boe', 'BO', 1),
(2307, 148, 'Buada', 'BU', 1),
(2308, 148, 'Denigomodu', 'DE', 1),
(2309, 148, 'Ewa', 'EW', 1),
(2310, 148, 'Ijuw', 'IJ', 1),
(2311, 148, 'Meneng', 'ME', 1),
(2312, 148, 'Nibok', 'NI', 1),
(2313, 148, 'Uaboe', 'UA', 1),
(2314, 148, 'Yaren', 'YA', 1),
(2315, 149, 'Bagmati', 'BA', 1),
(2316, 149, 'Bheri', 'BH', 1),
(2317, 149, 'Dhawalagiri', 'DH', 1),
(2318, 149, 'Gandaki', 'GA', 1),
(2319, 149, 'Janakpur', 'JA', 1),
(2320, 149, 'Karnali', 'KA', 1),
(2321, 149, 'Kosi', 'KO', 1),
(2322, 149, 'Lumbini', 'LU', 1),
(2323, 149, 'Mahakali', 'MA', 1),
(2324, 149, 'Mechi', 'ME', 1),
(2325, 149, 'Narayani', 'NA', 1),
(2326, 149, 'Rapti', 'RA', 1),
(2327, 149, 'Sagarmatha', 'SA', 1),
(2328, 149, 'Seti', 'SE', 1),
(2329, 150, 'Drenthe', 'DR', 1),
(2330, 150, 'Flevoland', 'FL', 1),
(2331, 150, 'Friesland', 'FR', 1),
(2332, 150, 'Gelderland', 'GE', 1),
(2333, 150, 'Groningen', 'GR', 1),
(2334, 150, 'Limburg', 'LI', 1),
(2335, 150, 'Noord Brabant', 'NB', 1),
(2336, 150, 'Noord Holland', 'NH', 1),
(2337, 150, 'Overijssel', 'OV', 1),
(2338, 150, 'Utrecht', 'UT', 1),
(2339, 150, 'Zeeland', 'ZE', 1),
(2340, 150, 'Zuid Holland', 'ZH', 1),
(2341, 152, 'Iles Loyaute', 'L', 1),
(2342, 152, 'Nord', 'N', 1),
(2343, 152, 'Sud', 'S', 1),
(2344, 153, 'Auckland', 'AUK', 1),
(2345, 153, 'Bay of Plenty', 'BOP', 1),
(2346, 153, 'Canterbury', 'CAN', 1),
(2347, 153, 'Coromandel', 'COR', 1),
(2348, 153, 'Gisborne', 'GIS', 1),
(2349, 153, 'Fiordland', 'FIO', 1),
(2350, 153, 'Hawke\'s Bay', 'HKB', 1),
(2351, 153, 'Marlborough', 'MBH', 1),
(2352, 153, 'Manawatu-Wanganui', 'MWT', 1),
(2353, 153, 'Mt Cook-Mackenzie', 'MCM', 1),
(2354, 153, 'Nelson', 'NSN', 1),
(2355, 153, 'Northland', 'NTL', 1),
(2356, 153, 'Otago', 'OTA', 1),
(2357, 153, 'Southland', 'STL', 1),
(2358, 153, 'Taranaki', 'TKI', 1),
(2359, 153, 'Wellington', 'WGN', 1),
(2360, 153, 'Waikato', 'WKO', 1),
(2361, 153, 'Wairarapa', 'WAI', 1),
(2362, 153, 'West Coast', 'WTC', 1),
(2363, 154, 'Atlantico Norte', 'AN', 1),
(2364, 154, 'Atlantico Sur', 'AS', 1),
(2365, 154, 'Boaco', 'BO', 1),
(2366, 154, 'Carazo', 'CA', 1),
(2367, 154, 'Chinandega', 'CI', 1),
(2368, 154, 'Chontales', 'CO', 1),
(2369, 154, 'Esteli', 'ES', 1),
(2370, 154, 'Granada', 'GR', 1),
(2371, 154, 'Jinotega', 'JI', 1),
(2372, 154, 'Leon', 'LE', 1),
(2373, 154, 'Madriz', 'MD', 1),
(2374, 154, 'Managua', 'MN', 1),
(2375, 154, 'Masaya', 'MS', 1),
(2376, 154, 'Matagalpa', 'MT', 1),
(2377, 154, 'Nuevo Segovia', 'NS', 1),
(2378, 154, 'Rio San Juan', 'RS', 1),
(2379, 154, 'Rivas', 'RI', 1),
(2380, 155, 'Agadez', 'AG', 1),
(2381, 155, 'Diffa', 'DF', 1),
(2382, 155, 'Dosso', 'DS', 1),
(2383, 155, 'Maradi', 'MA', 1),
(2384, 155, 'Niamey', 'NM', 1),
(2385, 155, 'Tahoua', 'TH', 1),
(2386, 155, 'Tillaberi', 'TL', 1),
(2387, 155, 'Zinder', 'ZD', 1),
(2388, 156, 'Abia', 'AB', 1),
(2389, 156, 'Abuja Federal Capital Territory', 'CT', 1),
(2390, 156, 'Adamawa', 'AD', 1),
(2391, 156, 'Akwa Ibom', 'AK', 1),
(2392, 156, 'Anambra', 'AN', 1),
(2393, 156, 'Bauchi', 'BC', 1),
(2394, 156, 'Bayelsa', 'BY', 1),
(2395, 156, 'Benue', 'BN', 1),
(2396, 156, 'Borno', 'BO', 1),
(2397, 156, 'Cross River', 'CR', 1),
(2398, 156, 'Delta', 'DE', 1),
(2399, 156, 'Ebonyi', 'EB', 1),
(2400, 156, 'Edo', 'ED', 1),
(2401, 156, 'Ekiti', 'EK', 1),
(2402, 156, 'Enugu', 'EN', 1),
(2403, 156, 'Gombe', 'GO', 1),
(2404, 156, 'Imo', 'IM', 1),
(2405, 156, 'Jigawa', 'JI', 1),
(2406, 156, 'Kaduna', 'KD', 1),
(2407, 156, 'Kano', 'KN', 1),
(2408, 156, 'Katsina', 'KT', 1),
(2409, 156, 'Kebbi', 'KE', 1),
(2410, 156, 'Kogi', 'KO', 1),
(2411, 156, 'Kwara', 'KW', 1),
(2412, 156, 'Lagos', 'LA', 1),
(2413, 156, 'Nassarawa', 'NA', 1),
(2414, 156, 'Niger', 'NI', 1),
(2415, 156, 'Ogun', 'OG', 1),
(2416, 156, 'Ondo', 'ONG', 1),
(2417, 156, 'Osun', 'OS', 1),
(2418, 156, 'Oyo', 'OY', 1),
(2419, 156, 'Plateau', 'PL', 1),
(2420, 156, 'Rivers', 'RI', 1),
(2421, 156, 'Sokoto', 'SO', 1),
(2422, 156, 'Taraba', 'TA', 1),
(2423, 156, 'Yobe', 'YO', 1),
(2424, 156, 'Zamfara', 'ZA', 1),
(2425, 159, 'Northern Islands', 'N', 1),
(2426, 159, 'Rota', 'R', 1),
(2427, 159, 'Saipan', 'S', 1),
(2428, 159, 'Tinian', 'T', 1),
(2429, 160, 'Akershus', 'AK', 1),
(2430, 160, 'Aust-Agder', 'AA', 1),
(2431, 160, 'Buskerud', 'BU', 1),
(2432, 160, 'Finnmark', 'FM', 1),
(2433, 160, 'Hedmark', 'HM', 1),
(2434, 160, 'Hordaland', 'HL', 1),
(2435, 160, 'More og Romdal', 'MR', 1),
(2436, 160, 'Nord-Trondelag', 'NT', 1),
(2437, 160, 'Nordland', 'NL', 1),
(2438, 160, 'Ostfold', 'OF', 1),
(2439, 160, 'Oppland', 'OP', 1),
(2440, 160, 'Oslo', 'OL', 1),
(2441, 160, 'Rogaland', 'RL', 1),
(2442, 160, 'Sor-Trondelag', 'ST', 1),
(2443, 160, 'Sogn og Fjordane', 'SJ', 1),
(2444, 160, 'Svalbard', 'SV', 1),
(2445, 160, 'Telemark', 'TM', 1),
(2446, 160, 'Troms', 'TR', 1),
(2447, 160, 'Vest-Agder', 'VA', 1),
(2448, 160, 'Vestfold', 'VF', 1),
(2449, 161, 'Ad Dakhiliyah', 'DA', 1),
(2450, 161, 'Al Batinah', 'BA', 1),
(2451, 161, 'Al Wusta', 'WU', 1),
(2452, 161, 'Ash Sharqiyah', 'SH', 1),
(2453, 161, 'Az Zahirah', 'ZA', 1),
(2454, 161, 'Masqat', 'MA', 1),
(2455, 161, 'Musandam', 'MU', 1),
(2456, 161, 'Zufar', 'ZU', 1),
(2457, 162, 'Balochistan', 'B', 1),
(2458, 162, 'Federally Administered Tribal Areas', 'T', 1),
(2459, 162, 'Islamabad Capital Territory', 'I', 1),
(2460, 162, 'North-West Frontier', 'N', 1),
(2461, 162, 'Punjab', 'P', 1),
(2462, 162, 'Sindh', 'S', 1),
(2463, 163, 'Aimeliik', 'AM', 1),
(2464, 163, 'Airai', 'AR', 1),
(2465, 163, 'Angaur', 'AN', 1),
(2466, 163, 'Hatohobei', 'HA', 1),
(2467, 163, 'Kayangel', 'KA', 1),
(2468, 163, 'Koror', 'KO', 1),
(2469, 163, 'Melekeok', 'ME', 1),
(2470, 163, 'Ngaraard', 'NA', 1),
(2471, 163, 'Ngarchelong', 'NG', 1),
(2472, 163, 'Ngardmau', 'ND', 1),
(2473, 163, 'Ngatpang', 'NT', 1),
(2474, 163, 'Ngchesar', 'NC', 1),
(2475, 163, 'Ngeremlengui', 'NR', 1),
(2476, 163, 'Ngiwal', 'NW', 1),
(2477, 163, 'Peleliu', 'PE', 1),
(2478, 163, 'Sonsorol', 'SO', 1),
(2479, 164, 'Bocas del Toro', 'BT', 1),
(2480, 164, 'Chiriqui', 'CH', 1),
(2481, 164, 'Cocle', 'CC', 1),
(2482, 164, 'Colon', 'CL', 1),
(2483, 164, 'Darien', 'DA', 1),
(2484, 164, 'Herrera', 'HE', 1),
(2485, 164, 'Los Santos', 'LS', 1),
(2486, 164, 'Panama', 'PA', 1),
(2487, 164, 'San Blas', 'SB', 1),
(2488, 164, 'Veraguas', 'VG', 1),
(2489, 165, 'Bougainville', 'BV', 1),
(2490, 165, 'Central', 'CE', 1),
(2491, 165, 'Chimbu', 'CH', 1),
(2492, 165, 'Eastern Highlands', 'EH', 1),
(2493, 165, 'East New Britain', 'EB', 1),
(2494, 165, 'East Sepik', 'ES', 1),
(2495, 165, 'Enga', 'EN', 1),
(2496, 165, 'Gulf', 'GU', 1),
(2497, 165, 'Madang', 'MD', 1),
(2498, 165, 'Manus', 'MN', 1),
(2499, 165, 'Milne Bay', 'MB', 1),
(2500, 165, 'Morobe', 'MR', 1),
(2501, 165, 'National Capital', 'NC', 1),
(2502, 165, 'New Ireland', 'NI', 1),
(2503, 165, 'Northern', 'NO', 1),
(2504, 165, 'Sandaun', 'SA', 1),
(2505, 165, 'Southern Highlands', 'SH', 1),
(2506, 165, 'Western', 'WE', 1),
(2507, 165, 'Western Highlands', 'WH', 1),
(2508, 165, 'West New Britain', 'WB', 1),
(2509, 166, 'Alto Paraguay', 'AG', 1),
(2510, 166, 'Alto Parana', 'AN', 1),
(2511, 166, 'Amambay', 'AM', 1),
(2512, 166, 'Asuncion', 'AS', 1),
(2513, 166, 'Boqueron', 'BO', 1),
(2514, 166, 'Caaguazu', 'CG', 1),
(2515, 166, 'Caazapa', 'CZ', 1),
(2516, 166, 'Canindeyu', 'CN', 1),
(2517, 166, 'Central', 'CE', 1),
(2518, 166, 'Concepcion', 'CC', 1),
(2519, 166, 'Cordillera', 'CD', 1),
(2520, 166, 'Guaira', 'GU', 1),
(2521, 166, 'Itapua', 'IT', 1),
(2522, 166, 'Misiones', 'MI', 1),
(2523, 166, 'Neembucu', 'NE', 1),
(2524, 166, 'Paraguari', 'PA', 1),
(2525, 166, 'Presidente Hayes', 'PH', 1),
(2526, 166, 'San Pedro', 'SP', 1),
(2527, 167, 'Amazonas', 'AM', 1),
(2528, 167, 'Ancash', 'AN', 1),
(2529, 167, 'Apurimac', 'AP', 1),
(2530, 167, 'Arequipa', 'AR', 1),
(2531, 167, 'Ayacucho', 'AY', 1),
(2532, 167, 'Cajamarca', 'CJ', 1),
(2533, 167, 'Callao', 'CL', 1),
(2534, 167, 'Cusco', 'CU', 1),
(2535, 167, 'Huancavelica', 'HV', 1),
(2536, 167, 'Huanuco', 'HO', 1),
(2537, 167, 'Ica', 'IC', 1),
(2538, 167, 'Junin', 'JU', 1),
(2539, 167, 'La Libertad', 'LD', 1),
(2540, 167, 'Lambayeque', 'LY', 1),
(2541, 167, 'Lima', 'LI', 1),
(2542, 167, 'Loreto', 'LO', 1),
(2543, 167, 'Madre de Dios', 'MD', 1),
(2544, 167, 'Moquegua', 'MO', 1),
(2545, 167, 'Pasco', 'PA', 1),
(2546, 167, 'Piura', 'PI', 1),
(2547, 167, 'Puno', 'PU', 1),
(2548, 167, 'San Martin', 'SM', 1),
(2549, 167, 'Tacna', 'TA', 1),
(2550, 167, 'Tumbes', 'TU', 1),
(2551, 167, 'Ucayali', 'UC', 1),
(2552, 168, 'Abra', 'ABR', 1),
(2553, 168, 'Agusan del Norte', 'ANO', 1),
(2554, 168, 'Agusan del Sur', 'ASU', 1),
(2555, 168, 'Aklan', 'AKL', 1),
(2556, 168, 'Albay', 'ALB', 1),
(2557, 168, 'Antique', 'ANT', 1),
(2558, 168, 'Apayao', 'APY', 1),
(2559, 168, 'Aurora', 'AUR', 1),
(2560, 168, 'Basilan', 'BAS', 1),
(2561, 168, 'Bataan', 'BTA', 1),
(2562, 168, 'Batanes', 'BTE', 1),
(2563, 168, 'Batangas', 'BTG', 1),
(2564, 168, 'Biliran', 'BLR', 1),
(2565, 168, 'Benguet', 'BEN', 1),
(2566, 168, 'Bohol', 'BOL', 1),
(2567, 168, 'Bukidnon', 'BUK', 1),
(2568, 168, 'Bulacan', 'BUL', 1),
(2569, 168, 'Cagayan', 'CAG', 1),
(2570, 168, 'Camarines Norte', 'CNO', 1),
(2571, 168, 'Camarines Sur', 'CSU', 1),
(2572, 168, 'Camiguin', 'CAM', 1),
(2573, 168, 'Capiz', 'CAP', 1),
(2574, 168, 'Catanduanes', 'CAT', 1),
(2575, 168, 'Cavite', 'CAV', 1),
(2576, 168, 'Cebu', 'CEB', 1),
(2577, 168, 'Compostela', 'CMP', 1),
(2578, 168, 'Davao del Norte', 'DNO', 1),
(2579, 168, 'Davao del Sur', 'DSU', 1),
(2580, 168, 'Davao Oriental', 'DOR', 1),
(2581, 168, 'Eastern Samar', 'ESA', 1),
(2582, 168, 'Guimaras', 'GUI', 1),
(2583, 168, 'Ifugao', 'IFU', 1),
(2584, 168, 'Ilocos Norte', 'INO', 1),
(2585, 168, 'Ilocos Sur', 'ISU', 1),
(2586, 168, 'Iloilo', 'ILO', 1),
(2587, 168, 'Isabela', 'ISA', 1),
(2588, 168, 'Kalinga', 'KAL', 1),
(2589, 168, 'Laguna', 'LAG', 1),
(2590, 168, 'Lanao del Norte', 'LNO', 1),
(2591, 168, 'Lanao del Sur', 'LSU', 1),
(2592, 168, 'La Union', 'UNI', 1),
(2593, 168, 'Leyte', 'LEY', 1),
(2594, 168, 'Maguindanao', 'MAG', 1),
(2595, 168, 'Marinduque', 'MRN', 1),
(2596, 168, 'Masbate', 'MSB', 1),
(2597, 168, 'Mindoro Occidental', 'MIC', 1),
(2598, 168, 'Mindoro Oriental', 'MIR', 1),
(2599, 168, 'Misamis Occidental', 'MSC', 1),
(2600, 168, 'Misamis Oriental', 'MOR', 1),
(2601, 168, 'Mountain', 'MOP', 1),
(2602, 168, 'Negros Occidental', 'NOC', 1),
(2603, 168, 'Negros Oriental', 'NOR', 1),
(2604, 168, 'North Cotabato', 'NCT', 1),
(2605, 168, 'Northern Samar', 'NSM', 1),
(2606, 168, 'Nueva Ecija', 'NEC', 1),
(2607, 168, 'Nueva Vizcaya', 'NVZ', 1),
(2608, 168, 'Palawan', 'PLW', 1),
(2609, 168, 'Pampanga', 'PMP', 1),
(2610, 168, 'Pangasinan', 'PNG', 1),
(2611, 168, 'Quezon', 'QZN', 1),
(2612, 168, 'Quirino', 'QRN', 1),
(2613, 168, 'Rizal', 'RIZ', 1),
(2614, 168, 'Romblon', 'ROM', 1),
(2615, 168, 'Samar', 'SMR', 1),
(2616, 168, 'Sarangani', 'SRG', 1),
(2617, 168, 'Siquijor', 'SQJ', 1),
(2618, 168, 'Sorsogon', 'SRS', 1),
(2619, 168, 'South Cotabato', 'SCO', 1),
(2620, 168, 'Southern Leyte', 'SLE', 1),
(2621, 168, 'Sultan Kudarat', 'SKU', 1),
(2622, 168, 'Sulu', 'SLU', 1),
(2623, 168, 'Surigao del Norte', 'SNO', 1),
(2624, 168, 'Surigao del Sur', 'SSU', 1),
(2625, 168, 'Tarlac', 'TAR', 1),
(2626, 168, 'Tawi-Tawi', 'TAW', 1),
(2627, 168, 'Zambales', 'ZBL', 1),
(2628, 168, 'Zamboanga del Norte', 'ZNO', 1),
(2629, 168, 'Zamboanga del Sur', 'ZSU', 1),
(2630, 168, 'Zamboanga Sibugay', 'ZSI', 1),
(2631, 170, 'Dolnoslaskie', 'DO', 1),
(2632, 170, 'Kujawsko-Pomorskie', 'KP', 1),
(2633, 170, 'Lodzkie', 'LO', 1),
(2634, 170, 'Lubelskie', 'LL', 1),
(2635, 170, 'Lubuskie', 'LU', 1),
(2636, 170, 'Malopolskie', 'ML', 1),
(2637, 170, 'Mazowieckie', 'MZ', 1),
(2638, 170, 'Opolskie', 'OP', 1),
(2639, 170, 'Podkarpackie', 'PP', 1),
(2640, 170, 'Podlaskie', 'PL', 1),
(2641, 170, 'Pomorskie', 'PM', 1),
(2642, 170, 'Slaskie', 'SL', 1),
(2643, 170, 'Swietokrzyskie', 'SW', 1),
(2644, 170, 'Warminsko-Mazurskie', 'WM', 1),
(2645, 170, 'Wielkopolskie', 'WP', 1),
(2646, 170, 'Zachodniopomorskie', 'ZA', 1),
(2647, 198, 'Saint Pierre', 'P', 1),
(2648, 198, 'Miquelon', 'M', 1),
(2649, 171, 'A&ccedil;ores', 'AC', 1),
(2650, 171, 'Aveiro', 'AV', 1),
(2651, 171, 'Beja', 'BE', 1),
(2652, 171, 'Braga', 'BR', 1),
(2653, 171, 'Bragan&ccedil;a', 'BA', 1),
(2654, 171, 'Castelo Branco', 'CB', 1),
(2655, 171, 'Coimbra', 'CO', 1),
(2656, 171, '&Eacute;vora', 'EV', 1),
(2657, 171, 'Faro', 'FA', 1),
(2658, 171, 'Guarda', 'GU', 1),
(2659, 171, 'Leiria', 'LE', 1),
(2660, 171, 'Lisboa', 'LI', 1),
(2661, 171, 'Madeira', 'ME', 1),
(2662, 171, 'Portalegre', 'PO', 1),
(2663, 171, 'Porto', 'PR', 1),
(2664, 171, 'Santar&eacute;m', 'SA', 1),
(2665, 171, 'Set&uacute;bal', 'SE', 1),
(2666, 171, 'Viana do Castelo', 'VC', 1),
(2667, 171, 'Vila Real', 'VR', 1),
(2668, 171, 'Viseu', 'VI', 1),
(2669, 173, 'Ad Dawhah', 'DW', 1),
(2670, 173, 'Al Ghuwayriyah', 'GW', 1),
(2671, 173, 'Al Jumayliyah', 'JM', 1),
(2672, 173, 'Al Khawr', 'KR', 1),
(2673, 173, 'Al Wakrah', 'WK', 1),
(2674, 173, 'Ar Rayyan', 'RN', 1),
(2675, 173, 'Jarayan al Batinah', 'JB', 1),
(2676, 173, 'Madinat ash Shamal', 'MS', 1),
(2677, 173, 'Umm Sa\'id', 'UD', 1),
(2678, 173, 'Umm Salal', 'UL', 1),
(2679, 175, 'Alba', 'AB', 1),
(2680, 175, 'Arad', 'AR', 1),
(2681, 175, 'Arges', 'AG', 1),
(2682, 175, 'Bacau', 'BC', 1),
(2683, 175, 'Bihor', 'BH', 1),
(2684, 175, 'Bistrita-Nasaud', 'BN', 1),
(2685, 175, 'Botosani', 'BT', 1),
(2686, 175, 'Brasov', 'BV', 1),
(2687, 175, 'Braila', 'BR', 1),
(2688, 175, 'Bucuresti', 'B', 1),
(2689, 175, 'Buzau', 'BZ', 1),
(2690, 175, 'Caras-Severin', 'CS', 1),
(2691, 175, 'Calarasi', 'CL', 1),
(2692, 175, 'Cluj', 'CJ', 1),
(2693, 175, 'Constanta', 'CT', 1),
(2694, 175, 'Covasna', 'CV', 1),
(2695, 175, 'Dimbovita', 'DB', 1),
(2696, 175, 'Dolj', 'DJ', 1),
(2697, 175, 'Galati', 'GL', 1),
(2698, 175, 'Giurgiu', 'GR', 1),
(2699, 175, 'Gorj', 'GJ', 1),
(2700, 175, 'Harghita', 'HR', 1),
(2701, 175, 'Hunedoara', 'HD', 1),
(2702, 175, 'Ialomita', 'IL', 1),
(2703, 175, 'Iasi', 'IS', 1),
(2704, 175, 'Ilfov', 'IF', 1),
(2705, 175, 'Maramures', 'MM', 1),
(2706, 175, 'Mehedinti', 'MH', 1),
(2707, 175, 'Mures', 'MS', 1),
(2708, 175, 'Neamt', 'NT', 1),
(2709, 175, 'Olt', 'OT', 1),
(2710, 175, 'Prahova', 'PH', 1),
(2711, 175, 'Satu-Mare', 'SM', 1),
(2712, 175, 'Salaj', 'SJ', 1),
(2713, 175, 'Sibiu', 'SB', 1),
(2714, 175, 'Suceava', 'SV', 1),
(2715, 175, 'Teleorman', 'TR', 1),
(2716, 175, 'Timis', 'TM', 1),
(2717, 175, 'Tulcea', 'TL', 1),
(2718, 175, 'Vaslui', 'VS', 1),
(2719, 175, 'Valcea', 'VL', 1),
(2720, 175, 'Vrancea', 'VN', 1),
(2721, 176, 'Abakan', 'AB', 1),
(2722, 176, 'Aginskoye', 'AG', 1),
(2723, 176, 'Anadyr', 'AN', 1),
(2724, 176, 'Arkahangelsk', 'AR', 1),
(2725, 176, 'Astrakhan', 'AS', 1),
(2726, 176, 'Barnaul', 'BA', 1),
(2727, 176, 'Belgorod', 'BE', 1),
(2728, 176, 'Birobidzhan', 'BI', 1),
(2729, 176, 'Blagoveshchensk', 'BL', 1),
(2730, 176, 'Bryansk', 'BR', 1),
(2731, 176, 'Cheboksary', 'CH', 1),
(2732, 176, 'Chelyabinsk', 'CL', 1),
(2733, 176, 'Cherkessk', 'CR', 1),
(2734, 176, 'Chita', 'CI', 1),
(2735, 176, 'Dudinka', 'DU', 1),
(2736, 176, 'Elista', 'EL', 1),
(2737, 176, 'Gomo-Altaysk', 'GO', 1),
(2738, 176, 'Gorno-Altaysk', 'GA', 1),
(2739, 176, 'Groznyy', 'GR', 1),
(2740, 176, 'Irkutsk', 'IR', 1),
(2741, 176, 'Ivanovo', 'IV', 1),
(2742, 176, 'Izhevsk', 'IZ', 1),
(2743, 176, 'Kalinigrad', 'KA', 1),
(2744, 176, 'Kaluga', 'KL', 1),
(2745, 176, 'Kasnodar', 'KS', 1),
(2746, 176, 'Kazan', 'KZ', 1),
(2747, 176, 'Kemerovo', 'KE', 1),
(2748, 176, 'Khabarovsk', 'KH', 1),
(2749, 176, 'Khanty-Mansiysk', 'KM', 1),
(2750, 176, 'Kostroma', 'KO', 1),
(2751, 176, 'Krasnodar', 'KR', 1),
(2752, 176, 'Krasnoyarsk', 'KN', 1),
(2753, 176, 'Kudymkar', 'KU', 1),
(2754, 176, 'Kurgan', 'KG', 1),
(2755, 176, 'Kursk', 'KK', 1),
(2756, 176, 'Kyzyl', 'KY', 1),
(2757, 176, 'Lipetsk', 'LI', 1),
(2758, 176, 'Magadan', 'MA', 1),
(2759, 176, 'Makhachkala', 'MK', 1),
(2760, 176, 'Maykop', 'MY', 1),
(2761, 176, 'Moscow', 'MO', 1),
(2762, 176, 'Murmansk', 'MU', 1),
(2763, 176, 'Nalchik', 'NA', 1),
(2764, 176, 'Naryan Mar', 'NR', 1),
(2765, 176, 'Nazran', 'NZ', 1),
(2766, 176, 'Nizhniy Novgorod', 'NI', 1),
(2767, 176, 'Novgorod', 'NO', 1),
(2768, 176, 'Novosibirsk', 'NV', 1),
(2769, 176, 'Omsk', 'OM', 1),
(2770, 176, 'Orel', 'OR', 1),
(2771, 176, 'Orenburg', 'OE', 1),
(2772, 176, 'Palana', 'PA', 1),
(2773, 176, 'Penza', 'PE', 1),
(2774, 176, 'Perm', 'PR', 1),
(2775, 176, 'Petropavlovsk-Kamchatskiy', 'PK', 1),
(2776, 176, 'Petrozavodsk', 'PT', 1),
(2777, 176, 'Pskov', 'PS', 1),
(2778, 176, 'Rostov-na-Donu', 'RO', 1),
(2779, 176, 'Ryazan', 'RY', 1),
(2780, 176, 'Salekhard', 'SL', 1),
(2781, 176, 'Samara', 'SA', 1),
(2782, 176, 'Saransk', 'SR', 1),
(2783, 176, 'Saratov', 'SV', 1),
(2784, 176, 'Smolensk', 'SM', 1),
(2785, 176, 'St. Petersburg', 'SP', 1),
(2786, 176, 'Stavropol', 'ST', 1),
(2787, 176, 'Syktyvkar', 'SY', 1),
(2788, 176, 'Tambov', 'TA', 1),
(2789, 176, 'Tomsk', 'TO', 1),
(2790, 176, 'Tula', 'TU', 1),
(2791, 176, 'Tura', 'TR', 1),
(2792, 176, 'Tver', 'TV', 1),
(2793, 176, 'Tyumen', 'TY', 1),
(2794, 176, 'Ufa', 'UF', 1),
(2795, 176, 'Ul\'yanovsk', 'UL', 1),
(2796, 176, 'Ulan-Ude', 'UU', 1),
(2797, 176, 'Ust\'-Ordynskiy', 'US', 1),
(2798, 176, 'Vladikavkaz', 'VL', 1),
(2799, 176, 'Vladimir', 'VA', 1),
(2800, 176, 'Vladivostok', 'VV', 1),
(2801, 176, 'Volgograd', 'VG', 1),
(2802, 176, 'Vologda', 'VD', 1),
(2803, 176, 'Voronezh', 'VO', 1),
(2804, 176, 'Vyatka', 'VY', 1),
(2805, 176, 'Yakutsk', 'YA', 1),
(2806, 176, 'Yaroslavl', 'YR', 1),
(2807, 176, 'Yekaterinburg', 'YE', 1),
(2808, 176, 'Yoshkar-Ola', 'YO', 1),
(2809, 177, 'Butare', 'BU', 1),
(2810, 177, 'Byumba', 'BY', 1),
(2811, 177, 'Cyangugu', 'CY', 1),
(2812, 177, 'Gikongoro', 'GK', 1),
(2813, 177, 'Gisenyi', 'GS', 1),
(2814, 177, 'Gitarama', 'GT', 1),
(2815, 177, 'Kibungo', 'KG', 1),
(2816, 177, 'Kibuye', 'KY', 1),
(2817, 177, 'Kigali Rurale', 'KR', 1),
(2818, 177, 'Kigali-ville', 'KV', 1),
(2819, 177, 'Ruhengeri', 'RU', 1),
(2820, 177, 'Umutara', 'UM', 1),
(2821, 178, 'Christ Church Nichola Town', 'CCN', 1),
(2822, 178, 'Saint Anne Sandy Point', 'SAS', 1),
(2823, 178, 'Saint George Basseterre', 'SGB', 1),
(2824, 178, 'Saint George Gingerland', 'SGG', 1),
(2825, 178, 'Saint James Windward', 'SJW', 1),
(2826, 178, 'Saint John Capesterre', 'SJC', 1),
(2827, 178, 'Saint John Figtree', 'SJF', 1),
(2828, 178, 'Saint Mary Cayon', 'SMC', 1),
(2829, 178, 'Saint Paul Capesterre', 'CAP', 1),
(2830, 178, 'Saint Paul Charlestown', 'CHA', 1),
(2831, 178, 'Saint Peter Basseterre', 'SPB', 1),
(2832, 178, 'Saint Thomas Lowland', 'STL', 1),
(2833, 178, 'Saint Thomas Middle Island', 'STM', 1),
(2834, 178, 'Trinity Palmetto Point', 'TPP', 1),
(2835, 179, 'Anse-la-Raye', 'AR', 1),
(2836, 179, 'Castries', 'CA', 1),
(2837, 179, 'Choiseul', 'CH', 1),
(2838, 179, 'Dauphin', 'DA', 1),
(2839, 179, 'Dennery', 'DE', 1),
(2840, 179, 'Gros-Islet', 'GI', 1),
(2841, 179, 'Laborie', 'LA', 1),
(2842, 179, 'Micoud', 'MI', 1),
(2843, 179, 'Praslin', 'PR', 1),
(2844, 179, 'Soufriere', 'SO', 1),
(2845, 179, 'Vieux-Fort', 'VF', 1),
(2846, 180, 'Charlotte', 'C', 1),
(2847, 180, 'Grenadines', 'R', 1),
(2848, 180, 'Saint Andrew', 'A', 1),
(2849, 180, 'Saint David', 'D', 1),
(2850, 180, 'Saint George', 'G', 1),
(2851, 180, 'Saint Patrick', 'P', 1),
(2852, 181, 'A\'ana', 'AN', 1),
(2853, 181, 'Aiga-i-le-Tai', 'AI', 1),
(2854, 181, 'Atua', 'AT', 1),
(2855, 181, 'Fa\'asaleleaga', 'FA', 1),
(2856, 181, 'Gaga\'emauga', 'GE', 1),
(2857, 181, 'Gagaifomauga', 'GF', 1),
(2858, 181, 'Palauli', 'PA', 1),
(2859, 181, 'Satupa\'itea', 'SA', 1),
(2860, 181, 'Tuamasaga', 'TU', 1),
(2861, 181, 'Va\'a-o-Fonoti', 'VF', 1),
(2862, 181, 'Vaisigano', 'VS', 1),
(2863, 182, 'Acquaviva', 'AC', 1),
(2864, 182, 'Borgo Maggiore', 'BM', 1),
(2865, 182, 'Chiesanuova', 'CH', 1),
(2866, 182, 'Domagnano', 'DO', 1),
(2867, 182, 'Faetano', 'FA', 1),
(2868, 182, 'Fiorentino', 'FI', 1),
(2869, 182, 'Montegiardino', 'MO', 1),
(2870, 182, 'Citta di San Marino', 'SM', 1),
(2871, 182, 'Serravalle', 'SE', 1),
(2872, 183, 'Sao Tome', 'S', 1),
(2873, 183, 'Principe', 'P', 1),
(2874, 184, 'Al Bahah', 'BH', 1),
(2875, 184, 'Al Hudud ash Shamaliyah', 'HS', 1),
(2876, 184, 'Al Jawf', 'JF', 1),
(2877, 184, 'Al Madinah', 'MD', 1),
(2878, 184, 'Al Qasim', 'QS', 1),
(2879, 184, 'Ar Riyad', 'RD', 1),
(2880, 184, 'Ash Sharqiyah (Eastern)', 'AQ', 1),
(2881, 184, '\'Asir', 'AS', 1),
(2882, 184, 'Ha\'il', 'HL', 1),
(2883, 184, 'Jizan', 'JZ', 1),
(2884, 184, 'Makkah', 'ML', 1),
(2885, 184, 'Najran', 'NR', 1),
(2886, 184, 'Tabuk', 'TB', 1),
(2887, 185, 'Dakar', 'DA', 1),
(2888, 185, 'Diourbel', 'DI', 1),
(2889, 185, 'Fatick', 'FA', 1),
(2890, 185, 'Kaolack', 'KA', 1),
(2891, 185, 'Kolda', 'KO', 1),
(2892, 185, 'Louga', 'LO', 1),
(2893, 185, 'Matam', 'MA', 1),
(2894, 185, 'Saint-Louis', 'SL', 1),
(2895, 185, 'Tambacounda', 'TA', 1),
(2896, 185, 'Thies', 'TH', 1),
(2897, 185, 'Ziguinchor', 'ZI', 1),
(2898, 186, 'Anse aux Pins', 'AP', 1),
(2899, 186, 'Anse Boileau', 'AB', 1),
(2900, 186, 'Anse Etoile', 'AE', 1),
(2901, 186, 'Anse Louis', 'AL', 1),
(2902, 186, 'Anse Royale', 'AR', 1),
(2903, 186, 'Baie Lazare', 'BL', 1),
(2904, 186, 'Baie Sainte Anne', 'BS', 1),
(2905, 186, 'Beau Vallon', 'BV', 1),
(2906, 186, 'Bel Air', 'BA', 1),
(2907, 186, 'Bel Ombre', 'BO', 1),
(2908, 186, 'Cascade', 'CA', 1),
(2909, 186, 'Glacis', 'GL', 1),
(2910, 186, 'Grand\' Anse (on Mahe)', 'GM', 1),
(2911, 186, 'Grand\' Anse (on Praslin)', 'GP', 1),
(2912, 186, 'La Digue', 'DG', 1),
(2913, 186, 'La Riviere Anglaise', 'RA', 1),
(2914, 186, 'Mont Buxton', 'MB', 1),
(2915, 186, 'Mont Fleuri', 'MF', 1),
(2916, 186, 'Plaisance', 'PL', 1),
(2917, 186, 'Pointe La Rue', 'PR', 1),
(2918, 186, 'Port Glaud', 'PG', 1),
(2919, 186, 'Saint Louis', 'SL', 1),
(2920, 186, 'Takamaka', 'TA', 1),
(2921, 187, 'Eastern', 'E', 1),
(2922, 187, 'Northern', 'N', 1),
(2923, 187, 'Southern', 'S', 1),
(2924, 187, 'Western', 'W', 1),
(2925, 189, 'Banskobystrický', 'BA', 1),
(2926, 189, 'Bratislavský', 'BR', 1),
(2927, 189, 'Košický', 'KO', 1),
(2928, 189, 'Nitriansky', 'NI', 1),
(2929, 189, 'Prešovský', 'PR', 1),
(2930, 189, 'Trenčiansky', 'TC', 1),
(2931, 189, 'Trnavský', 'TV', 1),
(2932, 189, 'Žilinský', 'ZI', 1),
(2933, 191, 'Central', 'CE', 1),
(2934, 191, 'Choiseul', 'CH', 1),
(2935, 191, 'Guadalcanal', 'GC', 1),
(2936, 191, 'Honiara', 'HO', 1),
(2937, 191, 'Isabel', 'IS', 1),
(2938, 191, 'Makira', 'MK', 1),
(2939, 191, 'Malaita', 'ML', 1),
(2940, 191, 'Rennell and Bellona', 'RB', 1),
(2941, 191, 'Temotu', 'TM', 1),
(2942, 191, 'Western', 'WE', 1),
(2943, 192, 'Awdal', 'AW', 1),
(2944, 192, 'Bakool', 'BK', 1),
(2945, 192, 'Banaadir', 'BN', 1),
(2946, 192, 'Bari', 'BR', 1),
(2947, 192, 'Bay', 'BY', 1),
(2948, 192, 'Galguduud', 'GA', 1),
(2949, 192, 'Gedo', 'GE', 1),
(2950, 192, 'Hiiraan', 'HI', 1),
(2951, 192, 'Jubbada Dhexe', 'JD', 1),
(2952, 192, 'Jubbada Hoose', 'JH', 1),
(2953, 192, 'Mudug', 'MU', 1),
(2954, 192, 'Nugaal', 'NU', 1),
(2955, 192, 'Sanaag', 'SA', 1),
(2956, 192, 'Shabeellaha Dhexe', 'SD', 1),
(2957, 192, 'Shabeellaha Hoose', 'SH', 1),
(2958, 192, 'Sool', 'SL', 1),
(2959, 192, 'Togdheer', 'TO', 1),
(2960, 192, 'Woqooyi Galbeed', 'WG', 1),
(2961, 193, 'Eastern Cape', 'EC', 1),
(2962, 193, 'Free State', 'FS', 1),
(2963, 193, 'Gauteng', 'GT', 1),
(2964, 193, 'KwaZulu-Natal', 'KN', 1),
(2965, 193, 'Limpopo', 'LP', 1),
(2966, 193, 'Mpumalanga', 'MP', 1),
(2967, 193, 'North West', 'NW', 1),
(2968, 193, 'Northern Cape', 'NC', 1),
(2969, 193, 'Western Cape', 'WC', 1),
(2970, 195, 'La Coru&ntilde;a', 'CA', 1),
(2971, 195, '&Aacute;lava', 'AL', 1),
(2972, 195, 'Albacete', 'AB', 1),
(2973, 195, 'Alicante', 'AC', 1),
(2974, 195, 'Almeria', 'AM', 1),
(2975, 195, 'Asturias', 'AS', 1),
(2976, 195, '&Aacute;vila', 'AV', 1),
(2977, 195, 'Badajoz', 'BJ', 1),
(2978, 195, 'Baleares', 'IB', 1),
(2979, 195, 'Barcelona', 'BA', 1),
(2980, 195, 'Burgos', 'BU', 1),
(2981, 195, 'C&aacute;ceres', 'CC', 1),
(2982, 195, 'C&aacute;diz', 'CZ', 1),
(2983, 195, 'Cantabria', 'CT', 1),
(2984, 195, 'Castell&oacute;n', 'CL', 1),
(2985, 195, 'Ceuta', 'CE', 1),
(2986, 195, 'Ciudad Real', 'CR', 1),
(2987, 195, 'C&oacute;rdoba', 'CD', 1),
(2988, 195, 'Cuenca', 'CU', 1),
(2989, 195, 'Girona', 'GI', 1),
(2990, 195, 'Granada', 'GD', 1),
(2991, 195, 'Guadalajara', 'GJ', 1),
(2992, 195, 'Guip&uacute;zcoa', 'GP', 1),
(2993, 195, 'Huelva', 'HL', 1),
(2994, 195, 'Huesca', 'HS', 1),
(2995, 195, 'Ja&eacute;n', 'JN', 1),
(2996, 195, 'La Rioja', 'RJ', 1),
(2997, 195, 'Las Palmas', 'PM', 1),
(2998, 195, 'Leon', 'LE', 1),
(2999, 195, 'Lleida', 'LL', 1),
(3000, 195, 'Lugo', 'LG', 1),
(3001, 195, 'Madrid', 'MD', 1),
(3002, 195, 'Malaga', 'MA', 1),
(3003, 195, 'Melilla', 'ML', 1),
(3004, 195, 'Murcia', 'MU', 1),
(3005, 195, 'Navarra', 'NV', 1),
(3006, 195, 'Ourense', 'OU', 1),
(3007, 195, 'Palencia', 'PL', 1),
(3008, 195, 'Pontevedra', 'PO', 1),
(3009, 195, 'Salamanca', 'SL', 1),
(3010, 195, 'Santa Cruz de Tenerife', 'SC', 1),
(3011, 195, 'Segovia', 'SG', 1),
(3012, 195, 'Sevilla', 'SV', 1),
(3013, 195, 'Soria', 'SO', 1),
(3014, 195, 'Tarragona', 'TA', 1),
(3015, 195, 'Teruel', 'TE', 1),
(3016, 195, 'Toledo', 'TO', 1),
(3017, 195, 'Valencia', 'VC', 1),
(3018, 195, 'Valladolid', 'VD', 1),
(3019, 195, 'Vizcaya', 'VZ', 1),
(3020, 195, 'Zamora', 'ZM', 1),
(3021, 195, 'Zaragoza', 'ZR', 1),
(3022, 196, 'Central', 'CE', 1),
(3023, 196, 'Eastern', 'EA', 1),
(3024, 196, 'North Central', 'NC', 1),
(3025, 196, 'Northern', 'NO', 1),
(3026, 196, 'North Western', 'NW', 1),
(3027, 196, 'Sabaragamuwa', 'SA', 1),
(3028, 196, 'Southern', 'SO', 1),
(3029, 196, 'Uva', 'UV', 1),
(3030, 196, 'Western', 'WE', 1),
(3032, 197, 'Saint Helena', 'S', 1),
(3034, 199, 'A\'ali an Nil', 'ANL', 1),
(3035, 199, 'Al Bahr al Ahmar', 'BAM', 1),
(3036, 199, 'Al Buhayrat', 'BRT', 1),
(3037, 199, 'Al Jazirah', 'JZR', 1),
(3038, 199, 'Al Khartum', 'KRT', 1),
(3039, 199, 'Al Qadarif', 'QDR', 1),
(3040, 199, 'Al Wahdah', 'WDH', 1),
(3041, 199, 'An Nil al Abyad', 'ANB', 1),
(3042, 199, 'An Nil al Azraq', 'ANZ', 1),
(3043, 199, 'Ash Shamaliyah', 'ASH', 1),
(3044, 199, 'Bahr al Jabal', 'BJA', 1),
(3045, 199, 'Gharb al Istiwa\'iyah', 'GIS', 1),
(3046, 199, 'Gharb Bahr al Ghazal', 'GBG', 1),
(3047, 199, 'Gharb Darfur', 'GDA', 1),
(3048, 199, 'Gharb Kurdufan', 'GKU', 1),
(3049, 199, 'Janub Darfur', 'JDA', 1),
(3050, 199, 'Janub Kurdufan', 'JKU', 1),
(3051, 199, 'Junqali', 'JQL', 1),
(3052, 199, 'Kassala', 'KSL', 1),
(3053, 199, 'Nahr an Nil', 'NNL', 1),
(3054, 199, 'Shamal Bahr al Ghazal', 'SBG', 1),
(3055, 199, 'Shamal Darfur', 'SDA', 1),
(3056, 199, 'Shamal Kurdufan', 'SKU', 1),
(3057, 199, 'Sharq al Istiwa\'iyah', 'SIS', 1),
(3058, 199, 'Sinnar', 'SNR', 1),
(3059, 199, 'Warab', 'WRB', 1),
(3060, 200, 'Brokopondo', 'BR', 1),
(3061, 200, 'Commewijne', 'CM', 1),
(3062, 200, 'Coronie', 'CR', 1),
(3063, 200, 'Marowijne', 'MA', 1),
(3064, 200, 'Nickerie', 'NI', 1),
(3065, 200, 'Para', 'PA', 1),
(3066, 200, 'Paramaribo', 'PM', 1),
(3067, 200, 'Saramacca', 'SA', 1),
(3068, 200, 'Sipaliwini', 'SI', 1),
(3069, 200, 'Wanica', 'WA', 1),
(3070, 202, 'Hhohho', 'H', 1),
(3071, 202, 'Lubombo', 'L', 1),
(3072, 202, 'Manzini', 'M', 1),
(3073, 202, 'Shishelweni', 'S', 1),
(3074, 203, 'Blekinge', 'K', 1),
(3075, 203, 'Dalarna', 'W', 1),
(3076, 203, 'G&auml;vleborg', 'X', 1),
(3077, 203, 'Gotland', 'I', 1),
(3078, 203, 'Halland', 'N', 1),
(3079, 203, 'J&auml;mtland', 'Z', 1),
(3080, 203, 'J&ouml;nk&ouml;ping', 'F', 1),
(3081, 203, 'Kalmar', 'H', 1),
(3082, 203, 'Kronoberg', 'G', 1),
(3083, 203, 'Norrbotten', 'BD', 1),
(3084, 203, '&Ouml;rebro', 'T', 1),
(3085, 203, '&Ouml;sterg&ouml;tland', 'E', 1),
(3086, 203, 'Sk&aring;ne', 'M', 1),
(3087, 203, 'S&ouml;dermanland', 'D', 1),
(3088, 203, 'Stockholm', 'AB', 1),
(3089, 203, 'Uppsala', 'C', 1),
(3090, 203, 'V&auml;rmland', 'S', 1),
(3091, 203, 'V&auml;sterbotten', 'AC', 1),
(3092, 203, 'V&auml;sternorrland', 'Y', 1),
(3093, 203, 'V&auml;stmanland', 'U', 1),
(3094, 203, 'V&auml;stra G&ouml;taland', 'O', 1),
(3095, 204, 'Aargau', 'AG', 1),
(3096, 204, 'Appenzell Ausserrhoden', 'AR', 1),
(3097, 204, 'Appenzell Innerrhoden', 'AI', 1),
(3098, 204, 'Basel-Stadt', 'BS', 1),
(3099, 204, 'Basel-Landschaft', 'BL', 1),
(3100, 204, 'Bern', 'BE', 1),
(3101, 204, 'Fribourg', 'FR', 1),
(3102, 204, 'Gen&egrave;ve', 'GE', 1),
(3103, 204, 'Glarus', 'GL', 1),
(3104, 204, 'Graub&uuml;nden', 'GR', 1),
(3105, 204, 'Jura', 'JU', 1),
(3106, 204, 'Luzern', 'LU', 1),
(3107, 204, 'Neuch&acirc;tel', 'NE', 1),
(3108, 204, 'Nidwald', 'NW', 1),
(3109, 204, 'Obwald', 'OW', 1),
(3110, 204, 'St. Gallen', 'SG', 1),
(3111, 204, 'Schaffhausen', 'SH', 1),
(3112, 204, 'Schwyz', 'SZ', 1),
(3113, 204, 'Solothurn', 'SO', 1),
(3114, 204, 'Thurgau', 'TG', 1),
(3115, 204, 'Ticino', 'TI', 1),
(3116, 204, 'Uri', 'UR', 1),
(3117, 204, 'Valais', 'VS', 1),
(3118, 204, 'Vaud', 'VD', 1),
(3119, 204, 'Zug', 'ZG', 1),
(3120, 204, 'Z&uuml;rich', 'ZH', 1),
(3121, 205, 'Al Hasakah', 'HA', 1),
(3122, 205, 'Al Ladhiqiyah', 'LA', 1),
(3123, 205, 'Al Qunaytirah', 'QU', 1),
(3124, 205, 'Ar Raqqah', 'RQ', 1),
(3125, 205, 'As Suwayda', 'SU', 1),
(3126, 205, 'Dara', 'DA', 1),
(3127, 205, 'Dayr az Zawr', 'DZ', 1),
(3128, 205, 'Dimashq', 'DI', 1),
(3129, 205, 'Halab', 'HL', 1),
(3130, 205, 'Hamah', 'HM', 1),
(3131, 205, 'Hims', 'HI', 1),
(3132, 205, 'Idlib', 'ID', 1);
INSERT INTO `oc_zone` (`zone_id`, `country_id`, `name`, `code`, `status`) VALUES
(3133, 205, 'Rif Dimashq', 'RD', 1),
(3134, 205, 'Tartus', 'TA', 1),
(3135, 206, 'Chang-hua', 'CH', 1),
(3136, 206, 'Chia-i', 'CI', 1),
(3137, 206, 'Hsin-chu', 'HS', 1),
(3138, 206, 'Hua-lien', 'HL', 1),
(3139, 206, 'I-lan', 'IL', 1),
(3140, 206, 'Kao-hsiung county', 'KH', 1),
(3141, 206, 'Kin-men', 'KM', 1),
(3142, 206, 'Lien-chiang', 'LC', 1),
(3143, 206, 'Miao-li', 'ML', 1),
(3144, 206, 'Nan-t\'ou', 'NT', 1),
(3145, 206, 'P\'eng-hu', 'PH', 1),
(3146, 206, 'P\'ing-tung', 'PT', 1),
(3147, 206, 'T\'ai-chung', 'TG', 1),
(3148, 206, 'T\'ai-nan', 'TA', 1),
(3149, 206, 'T\'ai-pei county', 'TP', 1),
(3150, 206, 'T\'ai-tung', 'TT', 1),
(3151, 206, 'T\'ao-yuan', 'TY', 1),
(3152, 206, 'Yun-lin', 'YL', 1),
(3153, 206, 'Chia-i city', 'CC', 1),
(3154, 206, 'Chi-lung', 'CL', 1),
(3155, 206, 'Hsin-chu', 'HC', 1),
(3156, 206, 'T\'ai-chung', 'TH', 1),
(3157, 206, 'T\'ai-nan', 'TN', 1),
(3158, 206, 'Kao-hsiung city', 'KC', 1),
(3159, 206, 'T\'ai-pei city', 'TC', 1),
(3160, 207, 'Gorno-Badakhstan', 'GB', 1),
(3161, 207, 'Khatlon', 'KT', 1),
(3162, 207, 'Sughd', 'SU', 1),
(3163, 208, 'Arusha', 'AR', 1),
(3164, 208, 'Dar es Salaam', 'DS', 1),
(3165, 208, 'Dodoma', 'DO', 1),
(3166, 208, 'Iringa', 'IR', 1),
(3167, 208, 'Kagera', 'KA', 1),
(3168, 208, 'Kigoma', 'KI', 1),
(3169, 208, 'Kilimanjaro', 'KJ', 1),
(3170, 208, 'Lindi', 'LN', 1),
(3171, 208, 'Manyara', 'MY', 1),
(3172, 208, 'Mara', 'MR', 1),
(3173, 208, 'Mbeya', 'MB', 1),
(3174, 208, 'Morogoro', 'MO', 1),
(3175, 208, 'Mtwara', 'MT', 1),
(3176, 208, 'Mwanza', 'MW', 1),
(3177, 208, 'Pemba North', 'PN', 1),
(3178, 208, 'Pemba South', 'PS', 1),
(3179, 208, 'Pwani', 'PW', 1),
(3180, 208, 'Rukwa', 'RK', 1),
(3181, 208, 'Ruvuma', 'RV', 1),
(3182, 208, 'Shinyanga', 'SH', 1),
(3183, 208, 'Singida', 'SI', 1),
(3184, 208, 'Tabora', 'TB', 1),
(3185, 208, 'Tanga', 'TN', 1),
(3186, 208, 'Zanzibar Central/South', 'ZC', 1),
(3187, 208, 'Zanzibar North', 'ZN', 1),
(3188, 208, 'Zanzibar Urban/West', 'ZU', 1),
(3189, 209, 'Amnat Charoen', 'Amnat Charoen', 1),
(3190, 209, 'Ang Thong', 'Ang Thong', 1),
(3191, 209, 'Ayutthaya', 'Ayutthaya', 1),
(3192, 209, 'Bangkok', 'Bangkok', 1),
(3193, 209, 'Buriram', 'Buriram', 1),
(3194, 209, 'Chachoengsao', 'Chachoengsao', 1),
(3195, 209, 'Chai Nat', 'Chai Nat', 1),
(3196, 209, 'Chaiyaphum', 'Chaiyaphum', 1),
(3197, 209, 'Chanthaburi', 'Chanthaburi', 1),
(3198, 209, 'Chiang Mai', 'Chiang Mai', 1),
(3199, 209, 'Chiang Rai', 'Chiang Rai', 1),
(3200, 209, 'Chon Buri', 'Chon Buri', 1),
(3201, 209, 'Chumphon', 'Chumphon', 1),
(3202, 209, 'Kalasin', 'Kalasin', 1),
(3203, 209, 'Kamphaeng Phet', 'Kamphaeng Phet', 1),
(3204, 209, 'Kanchanaburi', 'Kanchanaburi', 1),
(3205, 209, 'Khon Kaen', 'Khon Kaen', 1),
(3206, 209, 'Krabi', 'Krabi', 1),
(3207, 209, 'Lampang', 'Lampang', 1),
(3208, 209, 'Lamphun', 'Lamphun', 1),
(3209, 209, 'Loei', 'Loei', 1),
(3210, 209, 'Lop Buri', 'Lop Buri', 1),
(3211, 209, 'Mae Hong Son', 'Mae Hong Son', 1),
(3212, 209, 'Maha Sarakham', 'Maha Sarakham', 1),
(3213, 209, 'Mukdahan', 'Mukdahan', 1),
(3214, 209, 'Nakhon Nayok', 'Nakhon Nayok', 1),
(3215, 209, 'Nakhon Pathom', 'Nakhon Pathom', 1),
(3216, 209, 'Nakhon Phanom', 'Nakhon Phanom', 1),
(3217, 209, 'Nakhon Ratchasima', 'Nakhon Ratchasima', 1),
(3218, 209, 'Nakhon Sawan', 'Nakhon Sawan', 1),
(3219, 209, 'Nakhon Si Thammarat', 'Nakhon Si Thammarat', 1),
(3220, 209, 'Nan', 'Nan', 1),
(3221, 209, 'Narathiwat', 'Narathiwat', 1),
(3222, 209, 'Nong Bua Lamphu', 'Nong Bua Lamphu', 1),
(3223, 209, 'Nong Khai', 'Nong Khai', 1),
(3224, 209, 'Nonthaburi', 'Nonthaburi', 1),
(3225, 209, 'Pathum Thani', 'Pathum Thani', 1),
(3226, 209, 'Pattani', 'Pattani', 1),
(3227, 209, 'Phangnga', 'Phangnga', 1),
(3228, 209, 'Phatthalung', 'Phatthalung', 1),
(3229, 209, 'Phayao', 'Phayao', 1),
(3230, 209, 'Phetchabun', 'Phetchabun', 1),
(3231, 209, 'Phetchaburi', 'Phetchaburi', 1),
(3232, 209, 'Phichit', 'Phichit', 1),
(3233, 209, 'Phitsanulok', 'Phitsanulok', 1),
(3234, 209, 'Phrae', 'Phrae', 1),
(3235, 209, 'Phuket', 'Phuket', 1),
(3236, 209, 'Prachin Buri', 'Prachin Buri', 1),
(3237, 209, 'Prachuap Khiri Khan', 'Prachuap Khiri Khan', 1),
(3238, 209, 'Ranong', 'Ranong', 1),
(3239, 209, 'Ratchaburi', 'Ratchaburi', 1),
(3240, 209, 'Rayong', 'Rayong', 1),
(3241, 209, 'Roi Et', 'Roi Et', 1),
(3242, 209, 'Sa Kaeo', 'Sa Kaeo', 1),
(3243, 209, 'Sakon Nakhon', 'Sakon Nakhon', 1),
(3244, 209, 'Samut Prakan', 'Samut Prakan', 1),
(3245, 209, 'Samut Sakhon', 'Samut Sakhon', 1),
(3246, 209, 'Samut Songkhram', 'Samut Songkhram', 1),
(3247, 209, 'Sara Buri', 'Sara Buri', 1),
(3248, 209, 'Satun', 'Satun', 1),
(3249, 209, 'Sing Buri', 'Sing Buri', 1),
(3250, 209, 'Sisaket', 'Sisaket', 1),
(3251, 209, 'Songkhla', 'Songkhla', 1),
(3252, 209, 'Sukhothai', 'Sukhothai', 1),
(3253, 209, 'Suphan Buri', 'Suphan Buri', 1),
(3254, 209, 'Surat Thani', 'Surat Thani', 1),
(3255, 209, 'Surin', 'Surin', 1),
(3256, 209, 'Tak', 'Tak', 1),
(3257, 209, 'Trang', 'Trang', 1),
(3258, 209, 'Trat', 'Trat', 1),
(3259, 209, 'Ubon Ratchathani', 'Ubon Ratchathani', 1),
(3260, 209, 'Udon Thani', 'Udon Thani', 1),
(3261, 209, 'Uthai Thani', 'Uthai Thani', 1),
(3262, 209, 'Uttaradit', 'Uttaradit', 1),
(3263, 209, 'Yala', 'Yala', 1),
(3264, 209, 'Yasothon', 'Yasothon', 1),
(3265, 210, 'Kara', 'K', 1),
(3266, 210, 'Plateaux', 'P', 1),
(3267, 210, 'Savanes', 'S', 1),
(3268, 210, 'Centrale', 'C', 1),
(3269, 210, 'Maritime', 'M', 1),
(3270, 211, 'Atafu', 'A', 1),
(3271, 211, 'Fakaofo', 'F', 1),
(3272, 211, 'Nukunonu', 'N', 1),
(3273, 212, 'Ha\'apai', 'H', 1),
(3274, 212, 'Tongatapu', 'T', 1),
(3275, 212, 'Vava\'u', 'V', 1),
(3276, 213, 'Couva/Tabaquite/Talparo', 'CT', 1),
(3277, 213, 'Diego Martin', 'DM', 1),
(3278, 213, 'Mayaro/Rio Claro', 'MR', 1),
(3279, 213, 'Penal/Debe', 'PD', 1),
(3280, 213, 'Princes Town', 'PT', 1),
(3281, 213, 'Sangre Grande', 'SG', 1),
(3282, 213, 'San Juan/Laventille', 'SL', 1),
(3283, 213, 'Siparia', 'SI', 1),
(3284, 213, 'Tunapuna/Piarco', 'TP', 1),
(3285, 213, 'Port of Spain', 'PS', 1),
(3286, 213, 'San Fernando', 'SF', 1),
(3287, 213, 'Arima', 'AR', 1),
(3288, 213, 'Point Fortin', 'PF', 1),
(3289, 213, 'Chaguanas', 'CH', 1),
(3290, 213, 'Tobago', 'TO', 1),
(3291, 214, 'Ariana', 'AR', 1),
(3292, 214, 'Beja', 'BJ', 1),
(3293, 214, 'Ben Arous', 'BA', 1),
(3294, 214, 'Bizerte', 'BI', 1),
(3295, 214, 'Gabes', 'GB', 1),
(3296, 214, 'Gafsa', 'GF', 1),
(3297, 214, 'Jendouba', 'JE', 1),
(3298, 214, 'Kairouan', 'KR', 1),
(3299, 214, 'Kasserine', 'KS', 1),
(3300, 214, 'Kebili', 'KB', 1),
(3301, 214, 'Kef', 'KF', 1),
(3302, 214, 'Mahdia', 'MH', 1),
(3303, 214, 'Manouba', 'MN', 1),
(3304, 214, 'Medenine', 'ME', 1),
(3305, 214, 'Monastir', 'MO', 1),
(3306, 214, 'Nabeul', 'NA', 1),
(3307, 214, 'Sfax', 'SF', 1),
(3308, 214, 'Sidi', 'SD', 1),
(3309, 214, 'Siliana', 'SL', 1),
(3310, 214, 'Sousse', 'SO', 1),
(3311, 214, 'Tataouine', 'TA', 1),
(3312, 214, 'Tozeur', 'TO', 1),
(3313, 214, 'Tunis', 'TU', 1),
(3314, 214, 'Zaghouan', 'ZA', 1),
(3315, 215, 'Adana', 'ADA', 1),
(3316, 215, 'Adıyaman', 'ADI', 1),
(3317, 215, 'Afyonkarahisar', 'AFY', 1),
(3318, 215, 'Ağrı', 'AGR', 1),
(3319, 215, 'Aksaray', 'AKS', 1),
(3320, 215, 'Amasya', 'AMA', 1),
(3321, 215, 'Ankara', 'ANK', 1),
(3322, 215, 'Antalya', 'ANT', 1),
(3323, 215, 'Ardahan', 'ARD', 1),
(3324, 215, 'Artvin', 'ART', 1),
(3325, 215, 'Aydın', 'AYI', 1),
(3326, 215, 'Balıkesir', 'BAL', 1),
(3327, 215, 'Bartın', 'BAR', 1),
(3328, 215, 'Batman', 'BAT', 1),
(3329, 215, 'Bayburt', 'BAY', 1),
(3330, 215, 'Bilecik', 'BIL', 1),
(3331, 215, 'Bingöl', 'BIN', 1),
(3332, 215, 'Bitlis', 'BIT', 1),
(3333, 215, 'Bolu', 'BOL', 1),
(3334, 215, 'Burdur', 'BRD', 1),
(3335, 215, 'Bursa', 'BRS', 1),
(3336, 215, 'Çanakkale', 'CKL', 1),
(3337, 215, 'Çankırı', 'CKR', 1),
(3338, 215, 'Çorum', 'COR', 1),
(3339, 215, 'Denizli', 'DEN', 1),
(3340, 215, 'Diyarbakır', 'DIY', 1),
(3341, 215, 'Düzce', 'DUZ', 1),
(3342, 215, 'Edirne', 'EDI', 1),
(3343, 215, 'Elazığ', 'ELA', 1),
(3344, 215, 'Erzincan', 'EZC', 1),
(3345, 215, 'Erzurum', 'EZR', 1),
(3346, 215, 'Eskişehir', 'ESK', 1),
(3347, 215, 'Gaziantep', 'GAZ', 1),
(3348, 215, 'Giresun', 'GIR', 1),
(3349, 215, 'Gümüşhane', 'GMS', 1),
(3350, 215, 'Hakkari', 'HKR', 1),
(3351, 215, 'Hatay', 'HTY', 1),
(3352, 215, 'Iğdır', 'IGD', 1),
(3353, 215, 'Isparta', 'ISP', 1),
(3354, 215, 'İstanbul', 'IST', 1),
(3355, 215, 'İzmir', 'IZM', 1),
(3356, 215, 'Kahramanmaraş', 'KAH', 1),
(3357, 215, 'Karabük', 'KRB', 1),
(3358, 215, 'Karaman', 'KRM', 1),
(3359, 215, 'Kars', 'KRS', 1),
(3360, 215, 'Kastamonu', 'KAS', 1),
(3361, 215, 'Kayseri', 'KAY', 1),
(3362, 215, 'Kilis', 'KLS', 1),
(3363, 215, 'Kırıkkale', 'KRK', 1),
(3364, 215, 'Kırklareli', 'KLR', 1),
(3365, 215, 'Kırşehir', 'KRH', 1),
(3366, 215, 'Kocaeli', 'KOC', 1),
(3367, 215, 'Konya', 'KON', 1),
(3368, 215, 'Kütahya', 'KUT', 1),
(3369, 215, 'Malatya', 'MAL', 1),
(3370, 215, 'Manisa', 'MAN', 1),
(3371, 215, 'Mardin', 'MAR', 1),
(3372, 215, 'Mersin', 'MER', 1),
(3373, 215, 'Muğla', 'MUG', 1),
(3374, 215, 'Muş', 'MUS', 1),
(3375, 215, 'Nevşehir', 'NEV', 1),
(3376, 215, 'Niğde', 'NIG', 1),
(3377, 215, 'Ordu', 'ORD', 1),
(3378, 215, 'Osmaniye', 'OSM', 1),
(3379, 215, 'Rize', 'RIZ', 1),
(3380, 215, 'Sakarya', 'SAK', 1),
(3381, 215, 'Samsun', 'SAM', 1),
(3382, 215, 'Şanlıurfa', 'SAN', 1),
(3383, 215, 'Siirt', 'SII', 1),
(3384, 215, 'Sinop', 'SIN', 1),
(3385, 215, 'Şırnak', 'SIR', 1),
(3386, 215, 'Sivas', 'SIV', 1),
(3387, 215, 'Tekirdağ', 'TEL', 1),
(3388, 215, 'Tokat', 'TOK', 1),
(3389, 215, 'Trabzon', 'TRA', 1),
(3390, 215, 'Tunceli', 'TUN', 1),
(3391, 215, 'Uşak', 'USK', 1),
(3392, 215, 'Van', 'VAN', 1),
(3393, 215, 'Yalova', 'YAL', 1),
(3394, 215, 'Yozgat', 'YOZ', 1),
(3395, 215, 'Zonguldak', 'ZON', 1),
(3396, 216, 'Ahal Welayaty', 'A', 1),
(3397, 216, 'Balkan Welayaty', 'B', 1),
(3398, 216, 'Dashhowuz Welayaty', 'D', 1),
(3399, 216, 'Lebap Welayaty', 'L', 1),
(3400, 216, 'Mary Welayaty', 'M', 1),
(3401, 217, 'Ambergris Cays', 'AC', 1),
(3402, 217, 'Dellis Cay', 'DC', 1),
(3403, 217, 'French Cay', 'FC', 1),
(3404, 217, 'Little Water Cay', 'LW', 1),
(3405, 217, 'Parrot Cay', 'RC', 1),
(3406, 217, 'Pine Cay', 'PN', 1),
(3407, 217, 'Salt Cay', 'SL', 1),
(3408, 217, 'Grand Turk', 'GT', 1),
(3409, 217, 'South Caicos', 'SC', 1),
(3410, 217, 'East Caicos', 'EC', 1),
(3411, 217, 'Middle Caicos', 'MC', 1),
(3412, 217, 'North Caicos', 'NC', 1),
(3413, 217, 'Providenciales', 'PR', 1),
(3414, 217, 'West Caicos', 'WC', 1),
(3415, 218, 'Nanumanga', 'NMG', 1),
(3416, 218, 'Niulakita', 'NLK', 1),
(3417, 218, 'Niutao', 'NTO', 1),
(3418, 218, 'Funafuti', 'FUN', 1),
(3419, 218, 'Nanumea', 'NME', 1),
(3420, 218, 'Nui', 'NUI', 1),
(3421, 218, 'Nukufetau', 'NFT', 1),
(3422, 218, 'Nukulaelae', 'NLL', 1),
(3423, 218, 'Vaitupu', 'VAI', 1),
(3424, 219, 'Kalangala', 'KAL', 1),
(3425, 219, 'Kampala', 'KMP', 1),
(3426, 219, 'Kayunga', 'KAY', 1),
(3427, 219, 'Kiboga', 'KIB', 1),
(3428, 219, 'Luwero', 'LUW', 1),
(3429, 219, 'Masaka', 'MAS', 1),
(3430, 219, 'Mpigi', 'MPI', 1),
(3431, 219, 'Mubende', 'MUB', 1),
(3432, 219, 'Mukono', 'MUK', 1),
(3433, 219, 'Nakasongola', 'NKS', 1),
(3434, 219, 'Rakai', 'RAK', 1),
(3435, 219, 'Sembabule', 'SEM', 1),
(3436, 219, 'Wakiso', 'WAK', 1),
(3437, 219, 'Bugiri', 'BUG', 1),
(3438, 219, 'Busia', 'BUS', 1),
(3439, 219, 'Iganga', 'IGA', 1),
(3440, 219, 'Jinja', 'JIN', 1),
(3441, 219, 'Kaberamaido', 'KAB', 1),
(3442, 219, 'Kamuli', 'KML', 1),
(3443, 219, 'Kapchorwa', 'KPC', 1),
(3444, 219, 'Katakwi', 'KTK', 1),
(3445, 219, 'Kumi', 'KUM', 1),
(3446, 219, 'Mayuge', 'MAY', 1),
(3447, 219, 'Mbale', 'MBA', 1),
(3448, 219, 'Pallisa', 'PAL', 1),
(3449, 219, 'Sironko', 'SIR', 1),
(3450, 219, 'Soroti', 'SOR', 1),
(3451, 219, 'Tororo', 'TOR', 1),
(3452, 219, 'Adjumani', 'ADJ', 1),
(3453, 219, 'Apac', 'APC', 1),
(3454, 219, 'Arua', 'ARU', 1),
(3455, 219, 'Gulu', 'GUL', 1),
(3456, 219, 'Kitgum', 'KIT', 1),
(3457, 219, 'Kotido', 'KOT', 1),
(3458, 219, 'Lira', 'LIR', 1),
(3459, 219, 'Moroto', 'MRT', 1),
(3460, 219, 'Moyo', 'MOY', 1),
(3461, 219, 'Nakapiripirit', 'NAK', 1),
(3462, 219, 'Nebbi', 'NEB', 1),
(3463, 219, 'Pader', 'PAD', 1),
(3464, 219, 'Yumbe', 'YUM', 1),
(3465, 219, 'Bundibugyo', 'BUN', 1),
(3466, 219, 'Bushenyi', 'BSH', 1),
(3467, 219, 'Hoima', 'HOI', 1),
(3468, 219, 'Kabale', 'KBL', 1),
(3469, 219, 'Kabarole', 'KAR', 1),
(3470, 219, 'Kamwenge', 'KAM', 1),
(3471, 219, 'Kanungu', 'KAN', 1),
(3472, 219, 'Kasese', 'KAS', 1),
(3473, 219, 'Kibaale', 'KBA', 1),
(3474, 219, 'Kisoro', 'KIS', 1),
(3475, 219, 'Kyenjojo', 'KYE', 1),
(3476, 219, 'Masindi', 'MSN', 1),
(3477, 219, 'Mbarara', 'MBR', 1),
(3478, 219, 'Ntungamo', 'NTU', 1),
(3479, 219, 'Rukungiri', 'RUK', 1),
(3480, 220, 'Cherkas\'ka Oblast\'', '71', 1),
(3481, 220, 'Chernihivs\'ka Oblast\'', '74', 1),
(3482, 220, 'Chernivets\'ka Oblast\'', '77', 1),
(3483, 220, 'Crimea', '43', 1),
(3484, 220, 'Dnipropetrovs\'ka Oblast\'', '12', 1),
(3485, 220, 'Donets\'ka Oblast\'', '14', 1),
(3486, 220, 'Ivano-Frankivs\'ka Oblast\'', '26', 1),
(3487, 220, 'Khersons\'ka Oblast\'', '65', 1),
(3488, 220, 'Khmel\'nyts\'ka Oblast\'', '68', 1),
(3489, 220, 'Kirovohrads\'ka Oblast\'', '35', 1),
(3490, 220, 'Kyiv', '30', 1),
(3491, 220, 'Kyivs\'ka Oblast\'', '32', 1),
(3492, 220, 'Luhans\'ka Oblast\'', '09', 1),
(3493, 220, 'L\'vivs\'ka Oblast\'', '46', 1),
(3494, 220, 'Mykolayivs\'ka Oblast\'', '48', 1),
(3495, 220, 'Odes\'ka Oblast\'', '51', 1),
(3496, 220, 'Poltavs\'ka Oblast\'', '53', 1),
(3497, 220, 'Rivnens\'ka Oblast\'', '56', 1),
(3498, 220, 'Sevastopol\'', '40', 1),
(3499, 220, 'Sums\'ka Oblast\'', '59', 1),
(3500, 220, 'Ternopil\'s\'ka Oblast\'', '61', 1),
(3501, 220, 'Vinnyts\'ka Oblast\'', '05', 1),
(3502, 220, 'Volyns\'ka Oblast\'', '07', 1),
(3503, 220, 'Zakarpats\'ka Oblast\'', '21', 1),
(3504, 220, 'Zaporiz\'ka Oblast\'', '23', 1),
(3505, 220, 'Zhytomyrs\'ka oblast\'', '18', 1),
(3506, 221, 'Abu Dhabi', 'ADH', 1),
(3507, 221, '\'Ajman', 'AJ', 1),
(3508, 221, 'Al Fujayrah', 'FU', 1),
(3509, 221, 'Ash Shariqah', 'SH', 1),
(3510, 221, 'Dubai', 'DU', 1),
(3511, 221, 'R\'as al Khaymah', 'RK', 1),
(3512, 221, 'Umm al Qaywayn', 'UQ', 1),
(3513, 222, 'Aberdeen', 'ABN', 1),
(3514, 222, 'Aberdeenshire', 'ABNS', 1),
(3515, 222, 'Anglesey', 'ANG', 1),
(3516, 222, 'Angus', 'AGS', 1),
(3517, 222, 'Argyll and Bute', 'ARY', 1),
(3518, 222, 'Bedfordshire', 'BEDS', 1),
(3519, 222, 'Berkshire', 'BERKS', 1),
(3520, 222, 'Blaenau Gwent', 'BLA', 1),
(3521, 222, 'Bridgend', 'BRI', 1),
(3522, 222, 'Bristol', 'BSTL', 1),
(3523, 222, 'Buckinghamshire', 'BUCKS', 1),
(3524, 222, 'Caerphilly', 'CAE', 1),
(3525, 222, 'Cambridgeshire', 'CAMBS', 1),
(3526, 222, 'Cardiff', 'CDF', 1),
(3527, 222, 'Carmarthenshire', 'CARM', 1),
(3528, 222, 'Ceredigion', 'CDGN', 1),
(3529, 222, 'Cheshire', 'CHES', 1),
(3530, 222, 'Clackmannanshire', 'CLACK', 1),
(3531, 222, 'Conwy', 'CON', 1),
(3532, 222, 'Cornwall', 'CORN', 1),
(3533, 222, 'Denbighshire', 'DNBG', 1),
(3534, 222, 'Derbyshire', 'DERBY', 1),
(3535, 222, 'Devon', 'DVN', 1),
(3536, 222, 'Dorset', 'DOR', 1),
(3537, 222, 'Dumfries and Galloway', 'DGL', 1),
(3538, 222, 'Dundee', 'DUND', 1),
(3539, 222, 'Durham', 'DHM', 1),
(3540, 222, 'East Ayrshire', 'ARYE', 1),
(3541, 222, 'East Dunbartonshire', 'DUNBE', 1),
(3542, 222, 'East Lothian', 'LOTE', 1),
(3543, 222, 'East Renfrewshire', 'RENE', 1),
(3544, 222, 'East Riding of Yorkshire', 'ERYS', 1),
(3545, 222, 'East Sussex', 'SXE', 1),
(3546, 222, 'Edinburgh', 'EDIN', 1),
(3547, 222, 'Essex', 'ESX', 1),
(3548, 222, 'Falkirk', 'FALK', 1),
(3549, 222, 'Fife', 'FFE', 1),
(3550, 222, 'Flintshire', 'FLINT', 1),
(3551, 222, 'Glasgow', 'GLAS', 1),
(3552, 222, 'Gloucestershire', 'GLOS', 1),
(3553, 222, 'Greater London', 'LDN', 1),
(3554, 222, 'Greater Manchester', 'MCH', 1),
(3555, 222, 'Gwynedd', 'GDD', 1),
(3556, 222, 'Hampshire', 'HANTS', 1),
(3557, 222, 'Herefordshire', 'HWR', 1),
(3558, 222, 'Hertfordshire', 'HERTS', 1),
(3559, 222, 'Highlands', 'HLD', 1),
(3560, 222, 'Inverclyde', 'IVER', 1),
(3561, 222, 'Isle of Wight', 'IOW', 1),
(3562, 222, 'Kent', 'KNT', 1),
(3563, 222, 'Lancashire', 'LANCS', 1),
(3564, 222, 'Leicestershire', 'LEICS', 1),
(3565, 222, 'Lincolnshire', 'LINCS', 1),
(3566, 222, 'Merseyside', 'MSY', 1),
(3567, 222, 'Merthyr Tydfil', 'MERT', 1),
(3568, 222, 'Midlothian', 'MLOT', 1),
(3569, 222, 'Monmouthshire', 'MMOUTH', 1),
(3570, 222, 'Moray', 'MORAY', 1),
(3571, 222, 'Neath Port Talbot', 'NPRTAL', 1),
(3572, 222, 'Newport', 'NEWPT', 1),
(3573, 222, 'Norfolk', 'NOR', 1),
(3574, 222, 'North Ayrshire', 'ARYN', 1),
(3575, 222, 'North Lanarkshire', 'LANN', 1),
(3576, 222, 'North Yorkshire', 'YSN', 1),
(3577, 222, 'Northamptonshire', 'NHM', 1),
(3578, 222, 'Northumberland', 'NLD', 1),
(3579, 222, 'Nottinghamshire', 'NOT', 1),
(3580, 222, 'Orkney Islands', 'ORK', 1),
(3581, 222, 'Oxfordshire', 'OFE', 1),
(3582, 222, 'Pembrokeshire', 'PEM', 1),
(3583, 222, 'Perth and Kinross', 'PERTH', 1),
(3584, 222, 'Powys', 'PWS', 1),
(3585, 222, 'Renfrewshire', 'REN', 1),
(3586, 222, 'Rhondda Cynon Taff', 'RHON', 1),
(3587, 222, 'Rutland', 'RUT', 1),
(3588, 222, 'Scottish Borders', 'BOR', 1),
(3589, 222, 'Shetland Islands', 'SHET', 1),
(3590, 222, 'Shropshire', 'SPE', 1),
(3591, 222, 'Somerset', 'SOM', 1),
(3592, 222, 'South Ayrshire', 'ARYS', 1),
(3593, 222, 'South Lanarkshire', 'LANS', 1),
(3594, 222, 'South Yorkshire', 'YSS', 1),
(3595, 222, 'Staffordshire', 'SFD', 1),
(3596, 222, 'Stirling', 'STIR', 1),
(3597, 222, 'Suffolk', 'SFK', 1),
(3598, 222, 'Surrey', 'SRY', 1),
(3599, 222, 'Swansea', 'SWAN', 1),
(3600, 222, 'Torfaen', 'TORF', 1),
(3601, 222, 'Tyne and Wear', 'TWR', 1),
(3602, 222, 'Vale of Glamorgan', 'VGLAM', 1),
(3603, 222, 'Warwickshire', 'WARKS', 1),
(3604, 222, 'West Dunbartonshire', 'WDUN', 1),
(3605, 222, 'West Lothian', 'WLOT', 1),
(3606, 222, 'West Midlands', 'WMD', 1),
(3607, 222, 'West Sussex', 'SXW', 1),
(3608, 222, 'West Yorkshire', 'YSW', 1),
(3609, 222, 'Western Isles', 'WIL', 1),
(3610, 222, 'Wiltshire', 'WLT', 1),
(3611, 222, 'Worcestershire', 'WORCS', 1),
(3612, 222, 'Wrexham', 'WRX', 1),
(3613, 223, 'Alabama', 'AL', 1),
(3614, 223, 'Alaska', 'AK', 1),
(3615, 223, 'American Samoa', 'AS', 1),
(3616, 223, 'Arizona', 'AZ', 1),
(3617, 223, 'Arkansas', 'AR', 1),
(3618, 223, 'Armed Forces Africa', 'AF', 1),
(3619, 223, 'Armed Forces Americas', 'AA', 1),
(3620, 223, 'Armed Forces Canada', 'AC', 1),
(3621, 223, 'Armed Forces Europe', 'AE', 1),
(3622, 223, 'Armed Forces Middle East', 'AM', 1),
(3623, 223, 'Armed Forces Pacific', 'AP', 1),
(3624, 223, 'California', 'CA', 1),
(3625, 223, 'Colorado', 'CO', 1),
(3626, 223, 'Connecticut', 'CT', 1),
(3627, 223, 'Delaware', 'DE', 1),
(3628, 223, 'District of Columbia', 'DC', 1),
(3629, 223, 'Federated States Of Micronesia', 'FM', 1),
(3630, 223, 'Florida', 'FL', 1),
(3631, 223, 'Georgia', 'GA', 1),
(3632, 223, 'Guam', 'GU', 1),
(3633, 223, 'Hawaii', 'HI', 1),
(3634, 223, 'Idaho', 'ID', 1),
(3635, 223, 'Illinois', 'IL', 1),
(3636, 223, 'Indiana', 'IN', 1),
(3637, 223, 'Iowa', 'IA', 1),
(3638, 223, 'Kansas', 'KS', 1),
(3639, 223, 'Kentucky', 'KY', 1),
(3640, 223, 'Louisiana', 'LA', 1),
(3641, 223, 'Maine', 'ME', 1),
(3642, 223, 'Marshall Islands', 'MH', 1),
(3643, 223, 'Maryland', 'MD', 1),
(3644, 223, 'Massachusetts', 'MA', 1),
(3645, 223, 'Michigan', 'MI', 1),
(3646, 223, 'Minnesota', 'MN', 1),
(3647, 223, 'Mississippi', 'MS', 1),
(3648, 223, 'Missouri', 'MO', 1),
(3649, 223, 'Montana', 'MT', 1),
(3650, 223, 'Nebraska', 'NE', 1),
(3651, 223, 'Nevada', 'NV', 1),
(3652, 223, 'New Hampshire', 'NH', 1),
(3653, 223, 'New Jersey', 'NJ', 1),
(3654, 223, 'New Mexico', 'NM', 1),
(3655, 223, 'New York', 'NY', 1),
(3656, 223, 'North Carolina', 'NC', 1),
(3657, 223, 'North Dakota', 'ND', 1),
(3658, 223, 'Northern Mariana Islands', 'MP', 1),
(3659, 223, 'Ohio', 'OH', 1),
(3660, 223, 'Oklahoma', 'OK', 1),
(3661, 223, 'Oregon', 'OR', 1),
(3662, 223, 'Palau', 'PW', 1),
(3663, 223, 'Pennsylvania', 'PA', 1),
(3664, 223, 'Puerto Rico', 'PR', 1),
(3665, 223, 'Rhode Island', 'RI', 1),
(3666, 223, 'South Carolina', 'SC', 1),
(3667, 223, 'South Dakota', 'SD', 1),
(3668, 223, 'Tennessee', 'TN', 1),
(3669, 223, 'Texas', 'TX', 1),
(3670, 223, 'Utah', 'UT', 1),
(3671, 223, 'Vermont', 'VT', 1),
(3672, 223, 'Virgin Islands', 'VI', 1),
(3673, 223, 'Virginia', 'VA', 1),
(3674, 223, 'Washington', 'WA', 1),
(3675, 223, 'West Virginia', 'WV', 1),
(3676, 223, 'Wisconsin', 'WI', 1),
(3677, 223, 'Wyoming', 'WY', 1),
(3678, 224, 'Baker Island', 'BI', 1),
(3679, 224, 'Howland Island', 'HI', 1),
(3680, 224, 'Jarvis Island', 'JI', 1),
(3681, 224, 'Johnston Atoll', 'JA', 1),
(3682, 224, 'Kingman Reef', 'KR', 1),
(3683, 224, 'Midway Atoll', 'MA', 1),
(3684, 224, 'Navassa Island', 'NI', 1),
(3685, 224, 'Palmyra Atoll', 'PA', 1),
(3686, 224, 'Wake Island', 'WI', 1),
(3687, 225, 'Artigas', 'AR', 1),
(3688, 225, 'Canelones', 'CA', 1),
(3689, 225, 'Cerro Largo', 'CL', 1),
(3690, 225, 'Colonia', 'CO', 1),
(3691, 225, 'Durazno', 'DU', 1),
(3692, 225, 'Flores', 'FS', 1),
(3693, 225, 'Florida', 'FA', 1),
(3694, 225, 'Lavalleja', 'LA', 1),
(3695, 225, 'Maldonado', 'MA', 1),
(3696, 225, 'Montevideo', 'MO', 1),
(3697, 225, 'Paysandu', 'PA', 1),
(3698, 225, 'Rio Negro', 'RN', 1),
(3699, 225, 'Rivera', 'RV', 1),
(3700, 225, 'Rocha', 'RO', 1),
(3701, 225, 'Salto', 'SL', 1),
(3702, 225, 'San Jose', 'SJ', 1),
(3703, 225, 'Soriano', 'SO', 1),
(3704, 225, 'Tacuarembo', 'TA', 1),
(3705, 225, 'Treinta y Tres', 'TT', 1),
(3706, 226, 'Andijon', 'AN', 1),
(3707, 226, 'Buxoro', 'BU', 1),
(3708, 226, 'Farg\'ona', 'FA', 1),
(3709, 226, 'Jizzax', 'JI', 1),
(3710, 226, 'Namangan', 'NG', 1),
(3711, 226, 'Navoiy', 'NW', 1),
(3712, 226, 'Qashqadaryo', 'QA', 1),
(3713, 226, 'Qoraqalpog\'iston Republikasi', 'QR', 1),
(3714, 226, 'Samarqand', 'SA', 1),
(3715, 226, 'Sirdaryo', 'SI', 1),
(3716, 226, 'Surxondaryo', 'SU', 1),
(3717, 226, 'Toshkent City', 'TK', 1),
(3718, 226, 'Toshkent Region', 'TO', 1),
(3719, 226, 'Xorazm', 'XO', 1),
(3720, 227, 'Malampa', 'MA', 1),
(3721, 227, 'Penama', 'PE', 1),
(3722, 227, 'Sanma', 'SA', 1),
(3723, 227, 'Shefa', 'SH', 1),
(3724, 227, 'Tafea', 'TA', 1),
(3725, 227, 'Torba', 'TO', 1),
(3726, 229, 'Amazonas', 'AM', 1),
(3727, 229, 'Anzoategui', 'AN', 1),
(3728, 229, 'Apure', 'AP', 1),
(3729, 229, 'Aragua', 'AR', 1),
(3730, 229, 'Barinas', 'BA', 1),
(3731, 229, 'Bolivar', 'BO', 1),
(3732, 229, 'Carabobo', 'CA', 1),
(3733, 229, 'Cojedes', 'CO', 1),
(3734, 229, 'Delta Amacuro', 'DA', 1),
(3735, 229, 'Dependencias Federales', 'DF', 1),
(3736, 229, 'Distrito Federal', 'DI', 1),
(3737, 229, 'Falcon', 'FA', 1),
(3738, 229, 'Guarico', 'GU', 1),
(3739, 229, 'Lara', 'LA', 1),
(3740, 229, 'Merida', 'ME', 1),
(3741, 229, 'Miranda', 'MI', 1),
(3742, 229, 'Monagas', 'MO', 1),
(3743, 229, 'Nueva Esparta', 'NE', 1),
(3744, 229, 'Portuguesa', 'PO', 1),
(3745, 229, 'Sucre', 'SU', 1),
(3746, 229, 'Tachira', 'TA', 1),
(3747, 229, 'Trujillo', 'TR', 1),
(3748, 229, 'Vargas', 'VA', 1),
(3749, 229, 'Yaracuy', 'YA', 1),
(3750, 229, 'Zulia', 'ZU', 1),
(3751, 230, 'An Giang', 'AG', 1),
(3752, 230, 'Bac Giang', 'BG', 1),
(3753, 230, 'Bac Kan', 'BK', 1),
(3754, 230, 'Bac Lieu', 'BL', 1),
(3755, 230, 'Bac Ninh', 'BC', 1),
(3756, 230, 'Ba Ria-Vung Tau', 'BR', 1),
(3757, 230, 'Ben Tre', 'BN', 1),
(3758, 230, 'Binh Dinh', 'BH', 1),
(3759, 230, 'Binh Duong', 'BU', 1),
(3760, 230, 'Binh Phuoc', 'BP', 1),
(3761, 230, 'Binh Thuan', 'BT', 1),
(3762, 230, 'Cà Mau', 'CM', 1),
(3763, 230, 'Cần Thơ', 'CT', 1),
(3764, 230, 'Cao Bằng', 'CB', 1),
(3765, 230, 'Dak Lak', 'DL', 1),
(3766, 230, 'Dak Nong', 'DG', 1),
(3767, 230, 'Đà Nẵng', 'DN', 1),
(3768, 230, 'Điện Biên', 'DB', 1),
(3769, 230, 'Đồng Nai', 'DI', 1),
(3770, 230, 'Đồng Tháp', 'DT', 1),
(3771, 230, 'Gia Lai', 'GL', 1),
(3772, 230, 'Hà Giang', 'HG', 1),
(3773, 230, 'Hải Dương', 'HD', 1),
(3774, 230, 'Hải Phòng', 'HP', 1),
(3775, 230, 'Hà Nam', 'HM', 1),
(3776, 230, 'Hà Nội', 'HI', 1),
(3777, 230, 'Hà Tây', 'HT', 1),
(3778, 230, 'Hà Tĩnh', 'HH', 1),
(3779, 230, 'Hòa Bình', 'HB', 1),
(3780, 230, 'Hồ Chí Minh', 'HC', 1),
(3781, 230, 'Hậu Giang', 'HU', 1),
(3782, 230, 'Hung Yen', 'HY', 1),
(3783, 232, 'Saint Croix', 'C', 1),
(3784, 232, 'Saint John', 'J', 1),
(3785, 232, 'Saint Thomas', 'T', 1),
(3786, 233, 'Alo', 'A', 1),
(3787, 233, 'Sigave', 'S', 1),
(3788, 233, 'Wallis', 'W', 1),
(3789, 235, 'Abyan', 'AB', 1),
(3790, 235, 'Adan', 'AD', 1),
(3791, 235, 'Amran', 'AM', 1),
(3792, 235, 'Al Bayda', 'BA', 1),
(3793, 235, 'Ad Dali', 'DA', 1),
(3794, 235, 'Dhamar', 'DH', 1),
(3795, 235, 'Hadramawt', 'HD', 1),
(3796, 235, 'Hajjah', 'HJ', 1),
(3797, 235, 'Al Hudaydah', 'HU', 1),
(3798, 235, 'Ibb', 'IB', 1),
(3799, 235, 'Al Jawf', 'JA', 1),
(3800, 235, 'Lahij', 'LA', 1),
(3801, 235, 'Ma\'rib', 'MA', 1),
(3802, 235, 'Al Mahrah', 'MR', 1),
(3803, 235, 'Al Mahwit', 'MW', 1),
(3804, 235, 'Sa\'dah', 'SD', 1),
(3805, 235, 'San\'a', 'SN', 1),
(3806, 235, 'Shabwah', 'SH', 1),
(3807, 235, 'Ta\'izz', 'TA', 1),
(3812, 237, 'Bas-Congo', 'BC', 1),
(3813, 237, 'Bandundu', 'BN', 1),
(3814, 237, 'Equateur', 'EQ', 1),
(3815, 237, 'Katanga', 'KA', 1),
(3816, 237, 'Kasai-Oriental', 'KE', 1),
(3817, 237, 'Kinshasa', 'KN', 1),
(3818, 237, 'Kasai-Occidental', 'KW', 1),
(3819, 237, 'Maniema', 'MA', 1),
(3820, 237, 'Nord-Kivu', 'NK', 1),
(3821, 237, 'Orientale', 'OR', 1),
(3822, 237, 'Sud-Kivu', 'SK', 1),
(3823, 238, 'Central', 'CE', 1),
(3824, 238, 'Copperbelt', 'CB', 1),
(3825, 238, 'Eastern', 'EA', 1),
(3826, 238, 'Luapula', 'LP', 1),
(3827, 238, 'Lusaka', 'LK', 1),
(3828, 238, 'Northern', 'NO', 1),
(3829, 238, 'North-Western', 'NW', 1),
(3830, 238, 'Southern', 'SO', 1),
(3831, 238, 'Western', 'WE', 1),
(3832, 239, 'Bulawayo', 'BU', 1),
(3833, 239, 'Harare', 'HA', 1),
(3834, 239, 'Manicaland', 'ML', 1),
(3835, 239, 'Mashonaland Central', 'MC', 1),
(3836, 239, 'Mashonaland East', 'ME', 1),
(3837, 239, 'Mashonaland West', 'MW', 1),
(3838, 239, 'Masvingo', 'MV', 1),
(3839, 239, 'Matabeleland North', 'MN', 1),
(3840, 239, 'Matabeleland South', 'MS', 1),
(3841, 239, 'Midlands', 'MD', 1),
(3861, 105, 'Campobasso', 'CB', 1),
(3862, 105, 'Carbonia-Iglesias', 'CI', 1),
(3863, 105, 'Caserta', 'CE', 1),
(3864, 105, 'Catania', 'CT', 1),
(3865, 105, 'Catanzaro', 'CZ', 1),
(3866, 105, 'Chieti', 'CH', 1),
(3867, 105, 'Como', 'CO', 1),
(3868, 105, 'Cosenza', 'CS', 1),
(3869, 105, 'Cremona', 'CR', 1),
(3870, 105, 'Crotone', 'KR', 1),
(3871, 105, 'Cuneo', 'CN', 1),
(3872, 105, 'Enna', 'EN', 1),
(3873, 105, 'Ferrara', 'FE', 1),
(3874, 105, 'Firenze', 'FI', 1),
(3875, 105, 'Foggia', 'FG', 1),
(3876, 105, 'Forli-Cesena', 'FC', 1),
(3877, 105, 'Frosinone', 'FR', 1),
(3878, 105, 'Genova', 'GE', 1),
(3879, 105, 'Gorizia', 'GO', 1),
(3880, 105, 'Grosseto', 'GR', 1),
(3881, 105, 'Imperia', 'IM', 1),
(3882, 105, 'Isernia', 'IS', 1),
(3883, 105, 'L&#39;Aquila', 'AQ', 1),
(3884, 105, 'La Spezia', 'SP', 1),
(3885, 105, 'Latina', 'LT', 1),
(3886, 105, 'Lecce', 'LE', 1),
(3887, 105, 'Lecco', 'LC', 1),
(3888, 105, 'Livorno', 'LI', 1),
(3889, 105, 'Lodi', 'LO', 1),
(3890, 105, 'Lucca', 'LU', 1),
(3891, 105, 'Macerata', 'MC', 1),
(3892, 105, 'Mantova', 'MN', 1),
(3893, 105, 'Massa-Carrara', 'MS', 1),
(3894, 105, 'Matera', 'MT', 1),
(3895, 105, 'Medio Campidano', 'VS', 1),
(3896, 105, 'Messina', 'ME', 1),
(3897, 105, 'Milano', 'MI', 1),
(3898, 105, 'Modena', 'MO', 1),
(3899, 105, 'Napoli', 'NA', 1),
(3900, 105, 'Novara', 'NO', 1),
(3901, 105, 'Nuoro', 'NU', 1),
(3902, 105, 'Ogliastra', 'OG', 1),
(3903, 105, 'Olbia-Tempio', 'OT', 1),
(3904, 105, 'Oristano', 'OR', 1),
(3905, 105, 'Padova', 'PD', 1),
(3906, 105, 'Palermo', 'PA', 1),
(3907, 105, 'Parma', 'PR', 1),
(3908, 105, 'Pavia', 'PV', 1),
(3909, 105, 'Perugia', 'PG', 1),
(3910, 105, 'Pesaro e Urbino', 'PU', 1),
(3911, 105, 'Pescara', 'PE', 1),
(3912, 105, 'Piacenza', 'PC', 1),
(3913, 105, 'Pisa', 'PI', 1),
(3914, 105, 'Pistoia', 'PT', 1),
(3915, 105, 'Pordenone', 'PN', 1),
(3916, 105, 'Potenza', 'PZ', 1),
(3917, 105, 'Prato', 'PO', 1),
(3918, 105, 'Ragusa', 'RG', 1),
(3919, 105, 'Ravenna', 'RA', 1),
(3920, 105, 'Reggio Calabria', 'RC', 1),
(3921, 105, 'Reggio Emilia', 'RE', 1),
(3922, 105, 'Rieti', 'RI', 1),
(3923, 105, 'Rimini', 'RN', 1),
(3924, 105, 'Roma', 'RM', 1),
(3925, 105, 'Rovigo', 'RO', 1),
(3926, 105, 'Salerno', 'SA', 1),
(3927, 105, 'Sassari', 'SS', 1),
(3928, 105, 'Savona', 'SV', 1),
(3929, 105, 'Siena', 'SI', 1),
(3930, 105, 'Siracusa', 'SR', 1),
(3931, 105, 'Sondrio', 'SO', 1),
(3932, 105, 'Taranto', 'TA', 1),
(3933, 105, 'Teramo', 'TE', 1),
(3934, 105, 'Terni', 'TR', 1),
(3935, 105, 'Torino', 'TO', 1),
(3936, 105, 'Trapani', 'TP', 1),
(3937, 105, 'Trento', 'TN', 1),
(3938, 105, 'Treviso', 'TV', 1),
(3939, 105, 'Trieste', 'TS', 1),
(3940, 105, 'Udine', 'UD', 1),
(3941, 105, 'Varese', 'VA', 1),
(3942, 105, 'Venezia', 'VE', 1),
(3943, 105, 'Verbano-Cusio-Ossola', 'VB', 1),
(3944, 105, 'Vercelli', 'VC', 1),
(3945, 105, 'Verona', 'VR', 1),
(3946, 105, 'Vibo Valentia', 'VV', 1),
(3947, 105, 'Vicenza', 'VI', 1),
(3948, 105, 'Viterbo', 'VT', 1),
(3949, 222, 'County Antrim', 'ANT', 1),
(3950, 222, 'County Armagh', 'ARM', 1),
(3951, 222, 'County Down', 'DOW', 1),
(3952, 222, 'County Fermanagh', 'FER', 1),
(3953, 222, 'County Londonderry', 'LDY', 1),
(3954, 222, 'County Tyrone', 'TYR', 1),
(3955, 222, 'Cumbria', 'CMA', 1),
(3956, 190, 'Pomurska', '1', 1),
(3957, 190, 'Podravska', '2', 1),
(3958, 190, 'Koroška', '3', 1),
(3959, 190, 'Savinjska', '4', 1),
(3960, 190, 'Zasavska', '5', 1),
(3961, 190, 'Spodnjeposavska', '6', 1),
(3962, 190, 'Jugovzhodna Slovenija', '7', 1),
(3963, 190, 'Osrednjeslovenska', '8', 1),
(3964, 190, 'Gorenjska', '9', 1),
(3965, 190, 'Notranjsko-kraška', '10', 1),
(3966, 190, 'Goriška', '11', 1),
(3967, 190, 'Obalno-kraška', '12', 1),
(3968, 33, 'Ruse', '', 1),
(3969, 101, 'Alborz', 'ALB', 1),
(3970, 21, 'Brussels-Capital Region', 'BRU', 1),
(3971, 138, 'Aguascalientes', 'AG', 1),
(3973, 242, 'Andrijevica', '01', 1),
(3974, 242, 'Bar', '02', 1),
(3975, 242, 'Berane', '03', 1),
(3976, 242, 'Bijelo Polje', '04', 1),
(3977, 242, 'Budva', '05', 1),
(3978, 242, 'Cetinje', '06', 1),
(3979, 242, 'Danilovgrad', '07', 1),
(3980, 242, 'Herceg-Novi', '08', 1),
(3981, 242, 'Kolašin', '09', 1),
(3982, 242, 'Kotor', '10', 1),
(3983, 242, 'Mojkovac', '11', 1),
(3984, 242, 'Nikšić', '12', 1),
(3985, 242, 'Plav', '13', 1),
(3986, 242, 'Pljevlja', '14', 1),
(3987, 242, 'Plužine', '15', 1),
(3988, 242, 'Podgorica', '16', 1),
(3989, 242, 'Rožaje', '17', 1),
(3990, 242, 'Šavnik', '18', 1),
(3991, 242, 'Tivat', '19', 1),
(3992, 242, 'Ulcinj', '20', 1),
(3993, 242, 'Žabljak', '21', 1),
(3994, 243, 'Belgrade', '00', 1),
(3995, 243, 'North Bačka', '01', 1),
(3996, 243, 'Central Banat', '02', 1),
(3997, 243, 'North Banat', '03', 1),
(3998, 243, 'South Banat', '04', 1),
(3999, 243, 'West Bačka', '05', 1),
(4000, 243, 'South Bačka', '06', 1),
(4001, 243, 'Srem', '07', 1),
(4002, 243, 'Mačva', '08', 1),
(4003, 243, 'Kolubara', '09', 1),
(4004, 243, 'Podunavlje', '10', 1),
(4005, 243, 'Braničevo', '11', 1),
(4006, 243, 'Šumadija', '12', 1),
(4007, 243, 'Pomoravlje', '13', 1),
(4008, 243, 'Bor', '14', 1),
(4009, 243, 'Zaječar', '15', 1),
(4010, 243, 'Zlatibor', '16', 1),
(4011, 243, 'Moravica', '17', 1),
(4012, 243, 'Raška', '18', 1),
(4013, 243, 'Rasina', '19', 1),
(4014, 243, 'Nišava', '20', 1),
(4015, 243, 'Toplica', '21', 1),
(4016, 243, 'Pirot', '22', 1),
(4017, 243, 'Jablanica', '23', 1),
(4018, 243, 'Pčinja', '24', 1),
(4020, 245, 'Bonaire', 'BO', 1),
(4021, 245, 'Saba', 'SA', 1),
(4022, 245, 'Sint Eustatius', 'SE', 1),
(4023, 248, 'Central Equatoria', 'EC', 1),
(4024, 248, 'Eastern Equatoria', 'EE', 1),
(4025, 248, 'Jonglei', 'JG', 1),
(4026, 248, 'Lakes', 'LK', 1),
(4027, 248, 'Northern Bahr el-Ghazal', 'BN', 1),
(4028, 248, 'Unity', 'UY', 1),
(4029, 248, 'Upper Nile', 'NU', 1),
(4030, 248, 'Warrap', 'WR', 1),
(4031, 248, 'Western Bahr el-Ghazal', 'BW', 1),
(4032, 248, 'Western Equatoria', 'EW', 1),
(4036, 117, 'Ainaži, Salacgrīvas novads', '0661405', 1),
(4037, 117, 'Aizkraukle, Aizkraukles novads', '0320201', 1),
(4038, 117, 'Aizkraukles novads', '0320200', 1),
(4039, 117, 'Aizpute, Aizputes novads', '0640605', 1),
(4040, 117, 'Aizputes novads', '0640600', 1),
(4041, 117, 'Aknīste, Aknīstes novads', '0560805', 1),
(4042, 117, 'Aknīstes novads', '0560800', 1),
(4043, 117, 'Aloja, Alojas novads', '0661007', 1),
(4044, 117, 'Alojas novads', '0661000', 1),
(4045, 117, 'Alsungas novads', '0624200', 1),
(4046, 117, 'Alūksne, Alūksnes novads', '0360201', 1),
(4047, 117, 'Alūksnes novads', '0360200', 1),
(4048, 117, 'Amatas novads', '0424701', 1),
(4049, 117, 'Ape, Apes novads', '0360805', 1),
(4050, 117, 'Apes novads', '0360800', 1),
(4051, 117, 'Auce, Auces novads', '0460805', 1),
(4052, 117, 'Auces novads', '0460800', 1),
(4053, 117, 'Ādažu novads', '0804400', 1),
(4054, 117, 'Babītes novads', '0804900', 1),
(4055, 117, 'Baldone, Baldones novads', '0800605', 1),
(4056, 117, 'Baldones novads', '0800600', 1),
(4057, 117, 'Baloži, Ķekavas novads', '0800807', 1),
(4058, 117, 'Baltinavas novads', '0384400', 1),
(4059, 117, 'Balvi, Balvu novads', '0380201', 1),
(4060, 117, 'Balvu novads', '0380200', 1),
(4061, 117, 'Bauska, Bauskas novads', '0400201', 1),
(4062, 117, 'Bauskas novads', '0400200', 1),
(4063, 117, 'Beverīnas novads', '0964700', 1),
(4064, 117, 'Brocēni, Brocēnu novads', '0840605', 1),
(4065, 117, 'Brocēnu novads', '0840601', 1),
(4066, 117, 'Burtnieku novads', '0967101', 1),
(4067, 117, 'Carnikavas novads', '0805200', 1),
(4068, 117, 'Cesvaine, Cesvaines novads', '0700807', 1),
(4069, 117, 'Cesvaines novads', '0700800', 1),
(4070, 117, 'Cēsis, Cēsu novads', '0420201', 1),
(4071, 117, 'Cēsu novads', '0420200', 1),
(4072, 117, 'Ciblas novads', '0684901', 1),
(4073, 117, 'Dagda, Dagdas novads', '0601009', 1),
(4074, 117, 'Dagdas novads', '0601000', 1),
(4075, 117, 'Daugavpils', '0050000', 1),
(4076, 117, 'Daugavpils novads', '0440200', 1),
(4077, 117, 'Dobele, Dobeles novads', '0460201', 1),
(4078, 117, 'Dobeles novads', '0460200', 1),
(4079, 117, 'Dundagas novads', '0885100', 1),
(4080, 117, 'Durbe, Durbes novads', '0640807', 1),
(4081, 117, 'Durbes novads', '0640801', 1),
(4082, 117, 'Engures novads', '0905100', 1),
(4083, 117, 'Ērgļu novads', '0705500', 1),
(4084, 117, 'Garkalnes novads', '0806000', 1),
(4085, 117, 'Grobiņa, Grobiņas novads', '0641009', 1),
(4086, 117, 'Grobiņas novads', '0641000', 1),
(4087, 117, 'Gulbene, Gulbenes novads', '0500201', 1),
(4088, 117, 'Gulbenes novads', '0500200', 1),
(4089, 117, 'Iecavas novads', '0406400', 1),
(4090, 117, 'Ikšķile, Ikšķiles novads', '0740605', 1),
(4091, 117, 'Ikšķiles novads', '0740600', 1),
(4092, 117, 'Ilūkste, Ilūkstes novads', '0440807', 1),
(4093, 117, 'Ilūkstes novads', '0440801', 1),
(4094, 117, 'Inčukalna novads', '0801800', 1),
(4095, 117, 'Jaunjelgava, Jaunjelgavas novads', '0321007', 1),
(4096, 117, 'Jaunjelgavas novads', '0321000', 1),
(4097, 117, 'Jaunpiebalgas novads', '0425700', 1),
(4098, 117, 'Jaunpils novads', '0905700', 1),
(4099, 117, 'Jelgava', '0090000', 1),
(4100, 117, 'Jelgavas novads', '0540200', 1),
(4101, 117, 'Jēkabpils', '0110000', 1),
(4102, 117, 'Jēkabpils novads', '0560200', 1),
(4103, 117, 'Jūrmala', '0130000', 1),
(4104, 117, 'Kalnciems, Jelgavas novads', '0540211', 1),
(4105, 117, 'Kandava, Kandavas novads', '0901211', 1),
(4106, 117, 'Kandavas novads', '0901201', 1),
(4107, 117, 'Kārsava, Kārsavas novads', '0681009', 1),
(4108, 117, 'Kārsavas novads', '0681000', 1),
(4109, 117, 'Kocēnu novads ,bij. Valmieras)', '0960200', 1),
(4110, 117, 'Kokneses novads', '0326100', 1),
(4111, 117, 'Krāslava, Krāslavas novads', '0600201', 1),
(4112, 117, 'Krāslavas novads', '0600202', 1),
(4113, 117, 'Krimuldas novads', '0806900', 1),
(4114, 117, 'Krustpils novads', '0566900', 1),
(4115, 117, 'Kuldīga, Kuldīgas novads', '0620201', 1),
(4116, 117, 'Kuldīgas novads', '0620200', 1),
(4117, 117, 'Ķeguma novads', '0741001', 1),
(4118, 117, 'Ķegums, Ķeguma novads', '0741009', 1),
(4119, 117, 'Ķekavas novads', '0800800', 1),
(4120, 117, 'Lielvārde, Lielvārdes novads', '0741413', 1),
(4121, 117, 'Lielvārdes novads', '0741401', 1),
(4122, 117, 'Liepāja', '0170000', 1),
(4123, 117, 'Limbaži, Limbažu novads', '0660201', 1),
(4124, 117, 'Limbažu novads', '0660200', 1),
(4125, 117, 'Līgatne, Līgatnes novads', '0421211', 1),
(4126, 117, 'Līgatnes novads', '0421200', 1),
(4127, 117, 'Līvāni, Līvānu novads', '0761211', 1),
(4128, 117, 'Līvānu novads', '0761201', 1),
(4129, 117, 'Lubāna, Lubānas novads', '0701413', 1),
(4130, 117, 'Lubānas novads', '0701400', 1),
(4131, 117, 'Ludza, Ludzas novads', '0680201', 1),
(4132, 117, 'Ludzas novads', '0680200', 1),
(4133, 117, 'Madona, Madonas novads', '0700201', 1),
(4134, 117, 'Madonas novads', '0700200', 1),
(4135, 117, 'Mazsalaca, Mazsalacas novads', '0961011', 1),
(4136, 117, 'Mazsalacas novads', '0961000', 1),
(4137, 117, 'Mālpils novads', '0807400', 1),
(4138, 117, 'Mārupes novads', '0807600', 1),
(4139, 117, 'Mērsraga novads', '0887600', 1),
(4140, 117, 'Naukšēnu novads', '0967300', 1),
(4141, 117, 'Neretas novads', '0327100', 1),
(4142, 117, 'Nīcas novads', '0647900', 1),
(4143, 117, 'Ogre, Ogres novads', '0740201', 1),
(4144, 117, 'Ogres novads', '0740202', 1),
(4145, 117, 'Olaine, Olaines novads', '0801009', 1),
(4146, 117, 'Olaines novads', '0801000', 1),
(4147, 117, 'Ozolnieku novads', '0546701', 1),
(4148, 117, 'Pārgaujas novads', '0427500', 1),
(4149, 117, 'Pāvilosta, Pāvilostas novads', '0641413', 1),
(4150, 117, 'Pāvilostas novads', '0641401', 1),
(4151, 117, 'Piltene, Ventspils novads', '0980213', 1),
(4152, 117, 'Pļaviņas, Pļaviņu novads', '0321413', 1),
(4153, 117, 'Pļaviņu novads', '0321400', 1),
(4154, 117, 'Preiļi, Preiļu novads', '0760201', 1),
(4155, 117, 'Preiļu novads', '0760202', 1),
(4156, 117, 'Priekule, Priekules novads', '0641615', 1),
(4157, 117, 'Priekules novads', '0641600', 1),
(4158, 117, 'Priekuļu novads', '0427300', 1),
(4159, 117, 'Raunas novads', '0427700', 1),
(4160, 117, 'Rēzekne', '0210000', 1),
(4161, 117, 'Rēzeknes novads', '0780200', 1),
(4162, 117, 'Riebiņu novads', '0766300', 1),
(4163, 117, 'Rīga', '0010000', 1),
(4164, 117, 'Rojas novads', '0888300', 1),
(4165, 117, 'Ropažu novads', '0808400', 1),
(4166, 117, 'Rucavas novads', '0648500', 1),
(4167, 117, 'Rugāju novads', '0387500', 1),
(4168, 117, 'Rundāles novads', '0407700', 1),
(4169, 117, 'Rūjiena, Rūjienas novads', '0961615', 1),
(4170, 117, 'Rūjienas novads', '0961600', 1),
(4171, 117, 'Sabile, Talsu novads', '0880213', 1),
(4172, 117, 'Salacgrīva, Salacgrīvas novads', '0661415', 1),
(4173, 117, 'Salacgrīvas novads', '0661400', 1),
(4174, 117, 'Salas novads', '0568700', 1),
(4175, 117, 'Salaspils novads', '0801200', 1),
(4176, 117, 'Salaspils, Salaspils novads', '0801211', 1),
(4177, 117, 'Saldus novads', '0840200', 1),
(4178, 117, 'Saldus, Saldus novads', '0840201', 1),
(4179, 117, 'Saulkrasti, Saulkrastu novads', '0801413', 1),
(4180, 117, 'Saulkrastu novads', '0801400', 1),
(4181, 117, 'Seda, Strenču novads', '0941813', 1),
(4182, 117, 'Sējas novads', '0809200', 1),
(4183, 117, 'Sigulda, Siguldas novads', '0801615', 1),
(4184, 117, 'Siguldas novads', '0801601', 1),
(4185, 117, 'Skrīveru novads', '0328200', 1),
(4186, 117, 'Skrunda, Skrundas novads', '0621209', 1),
(4187, 117, 'Skrundas novads', '0621200', 1),
(4188, 117, 'Smiltene, Smiltenes novads', '0941615', 1),
(4189, 117, 'Smiltenes novads', '0941600', 1),
(4190, 117, 'Staicele, Alojas novads', '0661017', 1),
(4191, 117, 'Stende, Talsu novads', '0880215', 1),
(4192, 117, 'Stopiņu novads', '0809600', 1),
(4193, 117, 'Strenči, Strenču novads', '0941817', 1),
(4194, 117, 'Strenču novads', '0941800', 1),
(4195, 117, 'Subate, Ilūkstes novads', '0440815', 1),
(4196, 117, 'Talsi, Talsu novads', '0880201', 1),
(4197, 117, 'Talsu novads', '0880200', 1),
(4198, 117, 'Tērvetes novads', '0468900', 1),
(4199, 117, 'Tukuma novads', '0900200', 1),
(4200, 117, 'Tukums, Tukuma novads', '0900201', 1),
(4201, 117, 'Vaiņodes novads', '0649300', 1),
(4202, 117, 'Valdemārpils, Talsu novads', '0880217', 1),
(4203, 117, 'Valka, Valkas novads', '0940201', 1),
(4204, 117, 'Valkas novads', '0940200', 1),
(4205, 117, 'Valmiera', '0250000', 1),
(4206, 117, 'Vangaži, Inčukalna novads', '0801817', 1),
(4207, 117, 'Varakļāni, Varakļānu novads', '0701817', 1),
(4208, 117, 'Varakļānu novads', '0701800', 1),
(4209, 117, 'Vārkavas novads', '0769101', 1),
(4210, 117, 'Vecpiebalgas novads', '0429300', 1),
(4211, 117, 'Vecumnieku novads', '0409500', 1),
(4212, 117, 'Ventspils', '0270000', 1),
(4213, 117, 'Ventspils novads', '0980200', 1),
(4214, 117, 'Viesīte, Viesītes novads', '0561815', 1),
(4215, 117, 'Viesītes novads', '0561800', 1),
(4216, 117, 'Viļaka, Viļakas novads', '0381615', 1),
(4217, 117, 'Viļakas novads', '0381600', 1),
(4218, 117, 'Viļāni, Viļānu novads', '0781817', 1),
(4219, 117, 'Viļānu novads', '0781800', 1),
(4220, 117, 'Zilupe, Zilupes novads', '0681817', 1),
(4221, 117, 'Zilupes novads', '0681801', 1),
(4222, 43, 'Arica y Parinacota', 'AP', 1),
(4223, 43, 'Los Rios', 'LR', 1),
(4224, 220, 'Kharkivs\'ka Oblast\'', '63', 1),
(4225, 118, 'Beirut', 'LB-BR', 1),
(4226, 118, 'Bekaa', 'LB-BE', 1),
(4227, 118, 'Mount Lebanon', 'LB-ML', 1),
(4228, 118, 'Nabatieh', 'LB-NB', 1),
(4229, 118, 'North', 'LB-NR', 1),
(4230, 118, 'South', 'LB-ST', 1),
(4231, 230, 'Khánh Hòa', '70000', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_zone_to_geo_zone`
--

CREATE TABLE `oc_zone_to_geo_zone` (
  `zone_to_geo_zone_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL DEFAULT '0',
  `geo_zone_id` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_zone_to_geo_zone`
--

INSERT INTO `oc_zone_to_geo_zone` (`zone_to_geo_zone_id`, `country_id`, `zone_id`, `geo_zone_id`, `date_added`, `date_modified`) VALUES
(281, 230, 3780, 4, '2015-12-17 15:41:53', '0000-00-00 00:00:00'),
(313, 230, 0, 5, '2015-12-17 15:42:38', '0000-00-00 00:00:00'),
(312, 230, 3782, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(311, 230, 3779, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(310, 230, 3781, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(309, 230, 3774, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(308, 230, 3773, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(307, 230, 3778, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(306, 230, 3777, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(305, 230, 3776, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(304, 230, 3775, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(303, 230, 3772, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(302, 230, 3771, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(301, 230, 3770, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(300, 230, 3769, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(299, 230, 3768, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(298, 230, 3766, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(297, 230, 3765, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(296, 230, 3767, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(295, 230, 3764, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(294, 230, 3763, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(293, 230, 3762, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(292, 230, 3761, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(291, 230, 3760, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(290, 230, 3759, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(289, 230, 3758, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(288, 230, 3756, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(287, 230, 3751, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(286, 230, 3752, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(285, 230, 3753, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(284, 230, 3754, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(283, 230, 3755, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00'),
(282, 230, 3757, 3, '2015-12-17 15:42:02', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `oc_address`
--
ALTER TABLE `oc_address`
  ADD PRIMARY KEY (`address_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `oc_affiliate`
--
ALTER TABLE `oc_affiliate`
  ADD PRIMARY KEY (`affiliate_id`);

--
-- Indexes for table `oc_affiliate_activity`
--
ALTER TABLE `oc_affiliate_activity`
  ADD PRIMARY KEY (`activity_id`);

--
-- Indexes for table `oc_affiliate_login`
--
ALTER TABLE `oc_affiliate_login`
  ADD PRIMARY KEY (`affiliate_login_id`),
  ADD KEY `email` (`email`),
  ADD KEY `ip` (`ip`);

--
-- Indexes for table `oc_affiliate_transaction`
--
ALTER TABLE `oc_affiliate_transaction`
  ADD PRIMARY KEY (`affiliate_transaction_id`);

--
-- Indexes for table `oc_api`
--
ALTER TABLE `oc_api`
  ADD PRIMARY KEY (`api_id`);

--
-- Indexes for table `oc_attribute`
--
ALTER TABLE `oc_attribute`
  ADD PRIMARY KEY (`attribute_id`);

--
-- Indexes for table `oc_attribute_description`
--
ALTER TABLE `oc_attribute_description`
  ADD PRIMARY KEY (`attribute_id`,`language_id`);

--
-- Indexes for table `oc_attribute_group`
--
ALTER TABLE `oc_attribute_group`
  ADD PRIMARY KEY (`attribute_group_id`);

--
-- Indexes for table `oc_attribute_group_description`
--
ALTER TABLE `oc_attribute_group_description`
  ADD PRIMARY KEY (`attribute_group_id`,`language_id`);

--
-- Indexes for table `oc_attribute_relative`
--
ALTER TABLE `oc_attribute_relative`
  ADD PRIMARY KEY (`relative_ID`);

--
-- Indexes for table `oc_banner`
--
ALTER TABLE `oc_banner`
  ADD PRIMARY KEY (`banner_id`);

--
-- Indexes for table `oc_banner_image`
--
ALTER TABLE `oc_banner_image`
  ADD PRIMARY KEY (`banner_image_id`);

--
-- Indexes for table `oc_banner_image_description`
--
ALTER TABLE `oc_banner_image_description`
  ADD PRIMARY KEY (`banner_image_id`,`language_id`);

--
-- Indexes for table `oc_category`
--
ALTER TABLE `oc_category`
  ADD PRIMARY KEY (`category_id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `oc_category_description`
--
ALTER TABLE `oc_category_description`
  ADD PRIMARY KEY (`category_id`,`language_id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `oc_category_filter`
--
ALTER TABLE `oc_category_filter`
  ADD PRIMARY KEY (`category_id`,`filter_id`);

--
-- Indexes for table `oc_category_path`
--
ALTER TABLE `oc_category_path`
  ADD PRIMARY KEY (`category_id`,`path_id`);

--
-- Indexes for table `oc_category_to_layout`
--
ALTER TABLE `oc_category_to_layout`
  ADD PRIMARY KEY (`category_id`,`store_id`);

--
-- Indexes for table `oc_category_to_store`
--
ALTER TABLE `oc_category_to_store`
  ADD PRIMARY KEY (`category_id`,`store_id`);

--
-- Indexes for table `oc_country`
--
ALTER TABLE `oc_country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `oc_coupon`
--
ALTER TABLE `oc_coupon`
  ADD PRIMARY KEY (`coupon_id`);

--
-- Indexes for table `oc_coupon_category`
--
ALTER TABLE `oc_coupon_category`
  ADD PRIMARY KEY (`coupon_id`,`category_id`);

--
-- Indexes for table `oc_coupon_history`
--
ALTER TABLE `oc_coupon_history`
  ADD PRIMARY KEY (`coupon_history_id`);

--
-- Indexes for table `oc_coupon_product`
--
ALTER TABLE `oc_coupon_product`
  ADD PRIMARY KEY (`coupon_product_id`);

--
-- Indexes for table `oc_currency`
--
ALTER TABLE `oc_currency`
  ADD PRIMARY KEY (`currency_id`);

--
-- Indexes for table `oc_customer`
--
ALTER TABLE `oc_customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `oc_customer_activity`
--
ALTER TABLE `oc_customer_activity`
  ADD PRIMARY KEY (`activity_id`);

--
-- Indexes for table `oc_customer_ban_ip`
--
ALTER TABLE `oc_customer_ban_ip`
  ADD PRIMARY KEY (`customer_ban_ip_id`),
  ADD KEY `ip` (`ip`);

--
-- Indexes for table `oc_customer_group`
--
ALTER TABLE `oc_customer_group`
  ADD PRIMARY KEY (`customer_group_id`);

--
-- Indexes for table `oc_customer_group_description`
--
ALTER TABLE `oc_customer_group_description`
  ADD PRIMARY KEY (`customer_group_id`,`language_id`);

--
-- Indexes for table `oc_customer_history`
--
ALTER TABLE `oc_customer_history`
  ADD PRIMARY KEY (`customer_history_id`);

--
-- Indexes for table `oc_customer_ip`
--
ALTER TABLE `oc_customer_ip`
  ADD PRIMARY KEY (`customer_ip_id`),
  ADD KEY `ip` (`ip`);

--
-- Indexes for table `oc_customer_login`
--
ALTER TABLE `oc_customer_login`
  ADD PRIMARY KEY (`customer_login_id`),
  ADD KEY `email` (`email`),
  ADD KEY `ip` (`ip`);

--
-- Indexes for table `oc_customer_online`
--
ALTER TABLE `oc_customer_online`
  ADD PRIMARY KEY (`ip`);

--
-- Indexes for table `oc_customer_reward`
--
ALTER TABLE `oc_customer_reward`
  ADD PRIMARY KEY (`customer_reward_id`);

--
-- Indexes for table `oc_customer_transaction`
--
ALTER TABLE `oc_customer_transaction`
  ADD PRIMARY KEY (`customer_transaction_id`);

--
-- Indexes for table `oc_custom_field`
--
ALTER TABLE `oc_custom_field`
  ADD PRIMARY KEY (`custom_field_id`);

--
-- Indexes for table `oc_custom_field_customer_group`
--
ALTER TABLE `oc_custom_field_customer_group`
  ADD PRIMARY KEY (`custom_field_id`,`customer_group_id`);

--
-- Indexes for table `oc_custom_field_description`
--
ALTER TABLE `oc_custom_field_description`
  ADD PRIMARY KEY (`custom_field_id`,`language_id`);

--
-- Indexes for table `oc_custom_field_value`
--
ALTER TABLE `oc_custom_field_value`
  ADD PRIMARY KEY (`custom_field_value_id`);

--
-- Indexes for table `oc_custom_field_value_description`
--
ALTER TABLE `oc_custom_field_value_description`
  ADD PRIMARY KEY (`custom_field_value_id`,`language_id`);

--
-- Indexes for table `oc_download`
--
ALTER TABLE `oc_download`
  ADD PRIMARY KEY (`download_id`);

--
-- Indexes for table `oc_download_description`
--
ALTER TABLE `oc_download_description`
  ADD PRIMARY KEY (`download_id`,`language_id`);

--
-- Indexes for table `oc_event`
--
ALTER TABLE `oc_event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `oc_extension`
--
ALTER TABLE `oc_extension`
  ADD PRIMARY KEY (`extension_id`);

--
-- Indexes for table `oc_filter`
--
ALTER TABLE `oc_filter`
  ADD PRIMARY KEY (`filter_id`);

--
-- Indexes for table `oc_filter_description`
--
ALTER TABLE `oc_filter_description`
  ADD PRIMARY KEY (`filter_id`,`language_id`);

--
-- Indexes for table `oc_filter_group`
--
ALTER TABLE `oc_filter_group`
  ADD PRIMARY KEY (`filter_group_id`);

--
-- Indexes for table `oc_filter_group_description`
--
ALTER TABLE `oc_filter_group_description`
  ADD PRIMARY KEY (`filter_group_id`,`language_id`);

--
-- Indexes for table `oc_fraudlabspro`
--
ALTER TABLE `oc_fraudlabspro`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `oc_geo_zone`
--
ALTER TABLE `oc_geo_zone`
  ADD PRIMARY KEY (`geo_zone_id`);

--
-- Indexes for table `oc_globalpay_order`
--
ALTER TABLE `oc_globalpay_order`
  ADD PRIMARY KEY (`globalpay_order_id`);

--
-- Indexes for table `oc_globalpay_order_transaction`
--
ALTER TABLE `oc_globalpay_order_transaction`
  ADD PRIMARY KEY (`globalpay_order_transaction_id`);

--
-- Indexes for table `oc_globalpay_remote_order`
--
ALTER TABLE `oc_globalpay_remote_order`
  ADD PRIMARY KEY (`globalpay_remote_order_id`);

--
-- Indexes for table `oc_globalpay_remote_order_transaction`
--
ALTER TABLE `oc_globalpay_remote_order_transaction`
  ADD PRIMARY KEY (`globalpay_remote_order_transaction_id`);

--
-- Indexes for table `oc_information`
--
ALTER TABLE `oc_information`
  ADD PRIMARY KEY (`information_id`);

--
-- Indexes for table `oc_information_description`
--
ALTER TABLE `oc_information_description`
  ADD PRIMARY KEY (`information_id`,`language_id`);

--
-- Indexes for table `oc_information_to_layout`
--
ALTER TABLE `oc_information_to_layout`
  ADD PRIMARY KEY (`information_id`,`store_id`);

--
-- Indexes for table `oc_information_to_store`
--
ALTER TABLE `oc_information_to_store`
  ADD PRIMARY KEY (`information_id`,`store_id`);

--
-- Indexes for table `oc_language`
--
ALTER TABLE `oc_language`
  ADD PRIMARY KEY (`language_id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `oc_layout`
--
ALTER TABLE `oc_layout`
  ADD PRIMARY KEY (`layout_id`);

--
-- Indexes for table `oc_layout_module`
--
ALTER TABLE `oc_layout_module`
  ADD PRIMARY KEY (`layout_module_id`);

--
-- Indexes for table `oc_layout_route`
--
ALTER TABLE `oc_layout_route`
  ADD PRIMARY KEY (`layout_route_id`);

--
-- Indexes for table `oc_length_class`
--
ALTER TABLE `oc_length_class`
  ADD PRIMARY KEY (`length_class_id`);

--
-- Indexes for table `oc_length_class_description`
--
ALTER TABLE `oc_length_class_description`
  ADD PRIMARY KEY (`length_class_id`,`language_id`);

--
-- Indexes for table `oc_location`
--
ALTER TABLE `oc_location`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `oc_manufacturer`
--
ALTER TABLE `oc_manufacturer`
  ADD PRIMARY KEY (`manufacturer_id`);

--
-- Indexes for table `oc_manufacturer_to_store`
--
ALTER TABLE `oc_manufacturer_to_store`
  ADD PRIMARY KEY (`manufacturer_id`,`store_id`);

--
-- Indexes for table `oc_marketing`
--
ALTER TABLE `oc_marketing`
  ADD PRIMARY KEY (`marketing_id`);

--
-- Indexes for table `oc_menu`
--
ALTER TABLE `oc_menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `oc_menu_group`
--
ALTER TABLE `oc_menu_group`
  ADD PRIMARY KEY (`menu_group_id`,`menu_id`);

--
-- Indexes for table `oc_menu_group_description`
--
ALTER TABLE `oc_menu_group_description`
  ADD PRIMARY KEY (`menu_group_id`,`language_id`);

--
-- Indexes for table `oc_modification`
--
ALTER TABLE `oc_modification`
  ADD PRIMARY KEY (`modification_id`);

--
-- Indexes for table `oc_module`
--
ALTER TABLE `oc_module`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `oc_newsletter`
--
ALTER TABLE `oc_newsletter`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `oc_openbay_faq`
--
ALTER TABLE `oc_openbay_faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oc_option`
--
ALTER TABLE `oc_option`
  ADD PRIMARY KEY (`option_id`);

--
-- Indexes for table `oc_option_description`
--
ALTER TABLE `oc_option_description`
  ADD PRIMARY KEY (`option_id`,`language_id`);

--
-- Indexes for table `oc_option_value`
--
ALTER TABLE `oc_option_value`
  ADD PRIMARY KEY (`option_value_id`);

--
-- Indexes for table `oc_option_value_description`
--
ALTER TABLE `oc_option_value_description`
  ADD PRIMARY KEY (`option_value_id`,`language_id`);

--
-- Indexes for table `oc_order`
--
ALTER TABLE `oc_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `oc_order_custom_field`
--
ALTER TABLE `oc_order_custom_field`
  ADD PRIMARY KEY (`order_custom_field_id`);

--
-- Indexes for table `oc_order_history`
--
ALTER TABLE `oc_order_history`
  ADD PRIMARY KEY (`order_history_id`);

--
-- Indexes for table `oc_order_option`
--
ALTER TABLE `oc_order_option`
  ADD PRIMARY KEY (`order_option_id`);

--
-- Indexes for table `oc_order_product`
--
ALTER TABLE `oc_order_product`
  ADD PRIMARY KEY (`order_product_id`);

--
-- Indexes for table `oc_order_recurring`
--
ALTER TABLE `oc_order_recurring`
  ADD PRIMARY KEY (`order_recurring_id`);

--
-- Indexes for table `oc_order_recurring_transaction`
--
ALTER TABLE `oc_order_recurring_transaction`
  ADD PRIMARY KEY (`order_recurring_transaction_id`);

--
-- Indexes for table `oc_order_status`
--
ALTER TABLE `oc_order_status`
  ADD PRIMARY KEY (`order_status_id`,`language_id`);

--
-- Indexes for table `oc_order_total`
--
ALTER TABLE `oc_order_total`
  ADD PRIMARY KEY (`order_total_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `oc_order_voucher`
--
ALTER TABLE `oc_order_voucher`
  ADD PRIMARY KEY (`order_voucher_id`);

--
-- Indexes for table `oc_product`
--
ALTER TABLE `oc_product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `oc_product_attribute`
--
ALTER TABLE `oc_product_attribute`
  ADD PRIMARY KEY (`product_id`,`attribute_id`,`language_id`);

--
-- Indexes for table `oc_product_description`
--
ALTER TABLE `oc_product_description`
  ADD PRIMARY KEY (`product_id`,`language_id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `oc_product_discount`
--
ALTER TABLE `oc_product_discount`
  ADD PRIMARY KEY (`product_discount_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `oc_product_filter`
--
ALTER TABLE `oc_product_filter`
  ADD PRIMARY KEY (`product_id`,`filter_id`);

--
-- Indexes for table `oc_product_image`
--
ALTER TABLE `oc_product_image`
  ADD PRIMARY KEY (`product_image_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `oc_product_option`
--
ALTER TABLE `oc_product_option`
  ADD PRIMARY KEY (`product_option_id`);

--
-- Indexes for table `oc_product_option_value`
--
ALTER TABLE `oc_product_option_value`
  ADD PRIMARY KEY (`product_option_value_id`);

--
-- Indexes for table `oc_product_parent`
--
ALTER TABLE `oc_product_parent`
  ADD PRIMARY KEY (`relative_ID`);

--
-- Indexes for table `oc_product_recurring`
--
ALTER TABLE `oc_product_recurring`
  ADD PRIMARY KEY (`product_id`,`recurring_id`,`customer_group_id`);

--
-- Indexes for table `oc_product_related`
--
ALTER TABLE `oc_product_related`
  ADD PRIMARY KEY (`product_id`,`related_id`);

--
-- Indexes for table `oc_product_relative`
--
ALTER TABLE `oc_product_relative`
  ADD PRIMARY KEY (`product_parent_ID`);

--
-- Indexes for table `oc_product_reward`
--
ALTER TABLE `oc_product_reward`
  ADD PRIMARY KEY (`product_reward_id`);

--
-- Indexes for table `oc_product_special`
--
ALTER TABLE `oc_product_special`
  ADD PRIMARY KEY (`product_special_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `oc_product_to_category`
--
ALTER TABLE `oc_product_to_category`
  ADD PRIMARY KEY (`product_id`,`category_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `oc_product_to_download`
--
ALTER TABLE `oc_product_to_download`
  ADD PRIMARY KEY (`product_id`,`download_id`);

--
-- Indexes for table `oc_product_to_layout`
--
ALTER TABLE `oc_product_to_layout`
  ADD PRIMARY KEY (`product_id`,`store_id`);

--
-- Indexes for table `oc_product_to_store`
--
ALTER TABLE `oc_product_to_store`
  ADD PRIMARY KEY (`product_id`,`store_id`);

--
-- Indexes for table `oc_realex_order`
--
ALTER TABLE `oc_realex_order`
  ADD PRIMARY KEY (`realex_order_id`);

--
-- Indexes for table `oc_realex_order_transaction`
--
ALTER TABLE `oc_realex_order_transaction`
  ADD PRIMARY KEY (`realex_order_transaction_id`);

--
-- Indexes for table `oc_recurring`
--
ALTER TABLE `oc_recurring`
  ADD PRIMARY KEY (`recurring_id`);

--
-- Indexes for table `oc_recurring_description`
--
ALTER TABLE `oc_recurring_description`
  ADD PRIMARY KEY (`recurring_id`,`language_id`);

--
-- Indexes for table `oc_return`
--
ALTER TABLE `oc_return`
  ADD PRIMARY KEY (`return_id`);

--
-- Indexes for table `oc_return_action`
--
ALTER TABLE `oc_return_action`
  ADD PRIMARY KEY (`return_action_id`,`language_id`);

--
-- Indexes for table `oc_return_history`
--
ALTER TABLE `oc_return_history`
  ADD PRIMARY KEY (`return_history_id`);

--
-- Indexes for table `oc_return_reason`
--
ALTER TABLE `oc_return_reason`
  ADD PRIMARY KEY (`return_reason_id`,`language_id`);

--
-- Indexes for table `oc_return_status`
--
ALTER TABLE `oc_return_status`
  ADD PRIMARY KEY (`return_status_id`,`language_id`);

--
-- Indexes for table `oc_review`
--
ALTER TABLE `oc_review`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `oc_revslider_attachment_images`
--
ALTER TABLE `oc_revslider_attachment_images`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `oc_revslider_css`
--
ALTER TABLE `oc_revslider_css`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oc_revslider_layer_animations`
--
ALTER TABLE `oc_revslider_layer_animations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oc_revslider_settings`
--
ALTER TABLE `oc_revslider_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oc_revslider_sliders`
--
ALTER TABLE `oc_revslider_sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oc_revslider_slides`
--
ALTER TABLE `oc_revslider_slides`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oc_revslider_static_slides`
--
ALTER TABLE `oc_revslider_static_slides`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oc_setting`
--
ALTER TABLE `oc_setting`
  ADD PRIMARY KEY (`setting_id`);

--
-- Indexes for table `oc_stock_status`
--
ALTER TABLE `oc_stock_status`
  ADD PRIMARY KEY (`stock_status_id`,`language_id`);

--
-- Indexes for table `oc_store`
--
ALTER TABLE `oc_store`
  ADD PRIMARY KEY (`store_id`);

--
-- Indexes for table `oc_tax_class`
--
ALTER TABLE `oc_tax_class`
  ADD PRIMARY KEY (`tax_class_id`);

--
-- Indexes for table `oc_tax_rate`
--
ALTER TABLE `oc_tax_rate`
  ADD PRIMARY KEY (`tax_rate_id`);

--
-- Indexes for table `oc_tax_rate_to_customer_group`
--
ALTER TABLE `oc_tax_rate_to_customer_group`
  ADD PRIMARY KEY (`tax_rate_id`,`customer_group_id`);

--
-- Indexes for table `oc_tax_rule`
--
ALTER TABLE `oc_tax_rule`
  ADD PRIMARY KEY (`tax_rule_id`);

--
-- Indexes for table `oc_upload`
--
ALTER TABLE `oc_upload`
  ADD PRIMARY KEY (`upload_id`);

--
-- Indexes for table `oc_url_alias`
--
ALTER TABLE `oc_url_alias`
  ADD PRIMARY KEY (`url_alias_id`),
  ADD KEY `query` (`query`),
  ADD KEY `keyword` (`keyword`);

--
-- Indexes for table `oc_user`
--
ALTER TABLE `oc_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `oc_user_group`
--
ALTER TABLE `oc_user_group`
  ADD PRIMARY KEY (`user_group_id`);

--
-- Indexes for table `oc_voucher`
--
ALTER TABLE `oc_voucher`
  ADD PRIMARY KEY (`voucher_id`);

--
-- Indexes for table `oc_voucher_history`
--
ALTER TABLE `oc_voucher_history`
  ADD PRIMARY KEY (`voucher_history_id`);

--
-- Indexes for table `oc_voucher_theme`
--
ALTER TABLE `oc_voucher_theme`
  ADD PRIMARY KEY (`voucher_theme_id`);

--
-- Indexes for table `oc_voucher_theme_description`
--
ALTER TABLE `oc_voucher_theme_description`
  ADD PRIMARY KEY (`voucher_theme_id`,`language_id`);

--
-- Indexes for table `oc_weight_class`
--
ALTER TABLE `oc_weight_class`
  ADD PRIMARY KEY (`weight_class_id`);

--
-- Indexes for table `oc_weight_class_description`
--
ALTER TABLE `oc_weight_class_description`
  ADD PRIMARY KEY (`weight_class_id`,`language_id`);

--
-- Indexes for table `oc_zone`
--
ALTER TABLE `oc_zone`
  ADD PRIMARY KEY (`zone_id`);

--
-- Indexes for table `oc_zone_to_geo_zone`
--
ALTER TABLE `oc_zone_to_geo_zone`
  ADD PRIMARY KEY (`zone_to_geo_zone_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `oc_address`
--
ALTER TABLE `oc_address`
  MODIFY `address_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `oc_affiliate`
--
ALTER TABLE `oc_affiliate`
  MODIFY `affiliate_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_affiliate_activity`
--
ALTER TABLE `oc_affiliate_activity`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_affiliate_login`
--
ALTER TABLE `oc_affiliate_login`
  MODIFY `affiliate_login_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_affiliate_transaction`
--
ALTER TABLE `oc_affiliate_transaction`
  MODIFY `affiliate_transaction_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_api`
--
ALTER TABLE `oc_api`
  MODIFY `api_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `oc_attribute`
--
ALTER TABLE `oc_attribute`
  MODIFY `attribute_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `oc_attribute_group`
--
ALTER TABLE `oc_attribute_group`
  MODIFY `attribute_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `oc_attribute_relative`
--
ALTER TABLE `oc_attribute_relative`
  MODIFY `relative_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `oc_banner`
--
ALTER TABLE `oc_banner`
  MODIFY `banner_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `oc_banner_image`
--
ALTER TABLE `oc_banner_image`
  MODIFY `banner_image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=189;
--
-- AUTO_INCREMENT for table `oc_category`
--
ALTER TABLE `oc_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;
--
-- AUTO_INCREMENT for table `oc_country`
--
ALTER TABLE `oc_country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=258;
--
-- AUTO_INCREMENT for table `oc_coupon`
--
ALTER TABLE `oc_coupon`
  MODIFY `coupon_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `oc_coupon_history`
--
ALTER TABLE `oc_coupon_history`
  MODIFY `coupon_history_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_coupon_product`
--
ALTER TABLE `oc_coupon_product`
  MODIFY `coupon_product_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_currency`
--
ALTER TABLE `oc_currency`
  MODIFY `currency_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `oc_customer`
--
ALTER TABLE `oc_customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `oc_customer_activity`
--
ALTER TABLE `oc_customer_activity`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT for table `oc_customer_ban_ip`
--
ALTER TABLE `oc_customer_ban_ip`
  MODIFY `customer_ban_ip_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_customer_group`
--
ALTER TABLE `oc_customer_group`
  MODIFY `customer_group_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_customer_history`
--
ALTER TABLE `oc_customer_history`
  MODIFY `customer_history_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_customer_ip`
--
ALTER TABLE `oc_customer_ip`
  MODIFY `customer_ip_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `oc_customer_login`
--
ALTER TABLE `oc_customer_login`
  MODIFY `customer_login_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_customer_reward`
--
ALTER TABLE `oc_customer_reward`
  MODIFY `customer_reward_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_customer_transaction`
--
ALTER TABLE `oc_customer_transaction`
  MODIFY `customer_transaction_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_custom_field`
--
ALTER TABLE `oc_custom_field`
  MODIFY `custom_field_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_custom_field_value`
--
ALTER TABLE `oc_custom_field_value`
  MODIFY `custom_field_value_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_download`
--
ALTER TABLE `oc_download`
  MODIFY `download_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_event`
--
ALTER TABLE `oc_event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `oc_extension`
--
ALTER TABLE `oc_extension`
  MODIFY `extension_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=619;
--
-- AUTO_INCREMENT for table `oc_filter`
--
ALTER TABLE `oc_filter`
  MODIFY `filter_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_filter_group`
--
ALTER TABLE `oc_filter_group`
  MODIFY `filter_group_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_geo_zone`
--
ALTER TABLE `oc_geo_zone`
  MODIFY `geo_zone_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `oc_globalpay_order`
--
ALTER TABLE `oc_globalpay_order`
  MODIFY `globalpay_order_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_globalpay_order_transaction`
--
ALTER TABLE `oc_globalpay_order_transaction`
  MODIFY `globalpay_order_transaction_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_globalpay_remote_order`
--
ALTER TABLE `oc_globalpay_remote_order`
  MODIFY `globalpay_remote_order_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_globalpay_remote_order_transaction`
--
ALTER TABLE `oc_globalpay_remote_order_transaction`
  MODIFY `globalpay_remote_order_transaction_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_information`
--
ALTER TABLE `oc_information`
  MODIFY `information_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `oc_language`
--
ALTER TABLE `oc_language`
  MODIFY `language_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `oc_layout`
--
ALTER TABLE `oc_layout`
  MODIFY `layout_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `oc_layout_module`
--
ALTER TABLE `oc_layout_module`
  MODIFY `layout_module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1396;
--
-- AUTO_INCREMENT for table `oc_layout_route`
--
ALTER TABLE `oc_layout_route`
  MODIFY `layout_route_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT for table `oc_length_class`
--
ALTER TABLE `oc_length_class`
  MODIFY `length_class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `oc_length_class_description`
--
ALTER TABLE `oc_length_class_description`
  MODIFY `length_class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `oc_location`
--
ALTER TABLE `oc_location`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `oc_manufacturer`
--
ALTER TABLE `oc_manufacturer`
  MODIFY `manufacturer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `oc_marketing`
--
ALTER TABLE `oc_marketing`
  MODIFY `marketing_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `oc_menu`
--
ALTER TABLE `oc_menu`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `oc_menu_group`
--
ALTER TABLE `oc_menu_group`
  MODIFY `menu_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=277;
--
-- AUTO_INCREMENT for table `oc_modification`
--
ALTER TABLE `oc_modification`
  MODIFY `modification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT for table `oc_module`
--
ALTER TABLE `oc_module`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;
--
-- AUTO_INCREMENT for table `oc_newsletter`
--
ALTER TABLE `oc_newsletter`
  MODIFY `news_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_openbay_faq`
--
ALTER TABLE `oc_openbay_faq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_option`
--
ALTER TABLE `oc_option`
  MODIFY `option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `oc_option_value`
--
ALTER TABLE `oc_option_value`
  MODIFY `option_value_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT for table `oc_order`
--
ALTER TABLE `oc_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT for table `oc_order_custom_field`
--
ALTER TABLE `oc_order_custom_field`
  MODIFY `order_custom_field_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_order_history`
--
ALTER TABLE `oc_order_history`
  MODIFY `order_history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;
--
-- AUTO_INCREMENT for table `oc_order_option`
--
ALTER TABLE `oc_order_option`
  MODIFY `order_option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `oc_order_product`
--
ALTER TABLE `oc_order_product`
  MODIFY `order_product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=843;
--
-- AUTO_INCREMENT for table `oc_order_recurring`
--
ALTER TABLE `oc_order_recurring`
  MODIFY `order_recurring_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_order_recurring_transaction`
--
ALTER TABLE `oc_order_recurring_transaction`
  MODIFY `order_recurring_transaction_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_order_status`
--
ALTER TABLE `oc_order_status`
  MODIFY `order_status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `oc_order_total`
--
ALTER TABLE `oc_order_total`
  MODIFY `order_total_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2354;
--
-- AUTO_INCREMENT for table `oc_order_voucher`
--
ALTER TABLE `oc_order_voucher`
  MODIFY `order_voucher_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_product`
--
ALTER TABLE `oc_product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=374;
--
-- AUTO_INCREMENT for table `oc_product_discount`
--
ALTER TABLE `oc_product_discount`
  MODIFY `product_discount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=446;
--
-- AUTO_INCREMENT for table `oc_product_image`
--
ALTER TABLE `oc_product_image`
  MODIFY `product_image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3454;
--
-- AUTO_INCREMENT for table `oc_product_option`
--
ALTER TABLE `oc_product_option`
  MODIFY `product_option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=337;
--
-- AUTO_INCREMENT for table `oc_product_option_value`
--
ALTER TABLE `oc_product_option_value`
  MODIFY `product_option_value_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=343;
--
-- AUTO_INCREMENT for table `oc_product_parent`
--
ALTER TABLE `oc_product_parent`
  MODIFY `relative_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `oc_product_relative`
--
ALTER TABLE `oc_product_relative`
  MODIFY `product_parent_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `oc_product_reward`
--
ALTER TABLE `oc_product_reward`
  MODIFY `product_reward_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=560;
--
-- AUTO_INCREMENT for table `oc_product_special`
--
ALTER TABLE `oc_product_special`
  MODIFY `product_special_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=518;
--
-- AUTO_INCREMENT for table `oc_realex_order`
--
ALTER TABLE `oc_realex_order`
  MODIFY `realex_order_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_realex_order_transaction`
--
ALTER TABLE `oc_realex_order_transaction`
  MODIFY `realex_order_transaction_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_recurring`
--
ALTER TABLE `oc_recurring`
  MODIFY `recurring_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `oc_return`
--
ALTER TABLE `oc_return`
  MODIFY `return_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_return_action`
--
ALTER TABLE `oc_return_action`
  MODIFY `return_action_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_return_history`
--
ALTER TABLE `oc_return_history`
  MODIFY `return_history_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_return_reason`
--
ALTER TABLE `oc_return_reason`
  MODIFY `return_reason_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_return_status`
--
ALTER TABLE `oc_return_status`
  MODIFY `return_status_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_review`
--
ALTER TABLE `oc_review`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `oc_revslider_attachment_images`
--
ALTER TABLE `oc_revslider_attachment_images`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `oc_revslider_css`
--
ALTER TABLE `oc_revslider_css`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `oc_revslider_layer_animations`
--
ALTER TABLE `oc_revslider_layer_animations`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_revslider_settings`
--
ALTER TABLE `oc_revslider_settings`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_revslider_sliders`
--
ALTER TABLE `oc_revslider_sliders`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `oc_revslider_slides`
--
ALTER TABLE `oc_revslider_slides`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `oc_revslider_static_slides`
--
ALTER TABLE `oc_revslider_static_slides`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_setting`
--
ALTER TABLE `oc_setting`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10355;
--
-- AUTO_INCREMENT for table `oc_stock_status`
--
ALTER TABLE `oc_stock_status`
  MODIFY `stock_status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `oc_store`
--
ALTER TABLE `oc_store`
  MODIFY `store_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_tax_class`
--
ALTER TABLE `oc_tax_class`
  MODIFY `tax_class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `oc_tax_rate`
--
ALTER TABLE `oc_tax_rate`
  MODIFY `tax_rate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;
--
-- AUTO_INCREMENT for table `oc_tax_rule`
--
ALTER TABLE `oc_tax_rule`
  MODIFY `tax_rule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;
--
-- AUTO_INCREMENT for table `oc_upload`
--
ALTER TABLE `oc_upload`
  MODIFY `upload_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_url_alias`
--
ALTER TABLE `oc_url_alias`
  MODIFY `url_alias_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1477;
--
-- AUTO_INCREMENT for table `oc_user`
--
ALTER TABLE `oc_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `oc_user_group`
--
ALTER TABLE `oc_user_group`
  MODIFY `user_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `oc_voucher`
--
ALTER TABLE `oc_voucher`
  MODIFY `voucher_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_voucher_history`
--
ALTER TABLE `oc_voucher_history`
  MODIFY `voucher_history_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_voucher_theme`
--
ALTER TABLE `oc_voucher_theme`
  MODIFY `voucher_theme_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `oc_weight_class`
--
ALTER TABLE `oc_weight_class`
  MODIFY `weight_class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `oc_weight_class_description`
--
ALTER TABLE `oc_weight_class_description`
  MODIFY `weight_class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `oc_zone`
--
ALTER TABLE `oc_zone`
  MODIFY `zone_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4232;
--
-- AUTO_INCREMENT for table `oc_zone_to_geo_zone`
--
ALTER TABLE `oc_zone_to_geo_zone`
  MODIFY `zone_to_geo_zone_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=314;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
