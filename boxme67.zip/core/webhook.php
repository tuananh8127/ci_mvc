<?php
    define('CLIENT_SECRET', 'N2ZkZWZlYzI4Mjc0YzA0M2U4OTM5NGM4ZDFmYjIyYTE=');
    function verify_webhook($data, $checksum_token, $refesh_token){
        $calculated_checksum = base64_encode(hash_hmac('sha256', $data, CLIENT_SECRET . $refesh_token, false));
        echo "calculated_checksum - " .$calculated_checksum;
        echo "<br/>CLIENT_SECRET . : ". CLIENT_SECRET . $refesh_token . "<br/>"; 
        return ($checksum_token == $calculated_checksum);
    }  


	$headers 		= getallheaders();

    $checksum_token = $headers['HTTP_X_SHIPCHUNG_CHECKSUM'];
	$refesh_token 	= $headers['HTTP_X_SHIPCHUNG_REFESH_TOKEN'];

    $data = file_get_contents('php://input');  

    $verified = verify_webhook($data, $checksum_token, $refesh_token);
    echo '<br/>Webhook verified: '.var_export($verified, true); //check error.log to see result

    
?>



