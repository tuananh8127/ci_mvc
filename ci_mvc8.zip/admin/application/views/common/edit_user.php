<?php $this->load->view('common/header'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  <!-- Left side column. contains the logo and sidebar -->
<?php $this->load->view('common/menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        General Form Elements
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
           <h1 class="box-title"><?php echo lang('edit_user_heading');?></h1>
           <p><?php echo lang('edit_user_subheading');?></p>
            </div>
              <?php echo form_open(uri_string());?>
              <div class="box-body">
                <div class="form-group">
                <?php echo lang('edit_user_fname_label', 'first_name'); ?>
                <?php echo form_input($first_name); ?>
                </div>

                <div class="form-group">
                <?php echo lang('edit_user_lname_label', 'last_name'); ?>
                <?php echo form_input($last_name); ?>
                </div>

                <div class="form-group">
                <?php echo lang('edit_user_company_label', 'company'); ?>
                <?php echo form_input($company); ?>
                </div>

                <div class="form-group">
                <?php echo lang('edit_user_phone_label', 'phone'); ?>
                <?php echo form_input($phone); ?>
                </div>

                <div class="form-group">
                <?php echo lang('edit_user_password_label', 'password'); ?>
                <?php echo form_input($password); ?>
                </div>

                 <div class="form-group">
                <?php echo lang('edit_user_password_confirm_label', 'password_confirm'); ?>
                <?php echo form_input($password_confirm); ?>
                </div>
              
                <div class="form-group">
                  <label for="exampleInputFile">File input</label>
                  <input type="file" id="exampleInputFile">

                  <p class="help-block">Example block-level help text here.</p>
                </div>
                
             
              <!-- /.box-body -->
            <?php  if ($this->ion_auth->is_admin()) : ?>
                 <h3><?php echo lang('edit_user_groups_heading') ?></h3>
                <?php foreach($groups as $group): ?>
                   <label class="checkbox">
              <?php
                  $gID=$group['id'];
                  $checked = null;
                  $item = null;
                  foreach($currentGroups as $grp) {
                      if ($gID == $grp->id) {
                          $checked= ' checked="checked"';
                      break;
                      }
                  }
              ?>
              <input type="checkbox" name="groups[]" value="<?php echo $group['id'];?>"<?php echo $checked;?>>
              <?php echo htmlspecialchars($group['name'],ENT_QUOTES,'UTF-8');?>
              </label>
              <?php endforeach; ?>
             <?php endif; ?>
               <?php echo form_hidden('id', $user->id);?>
               <?php echo form_hidden($csrf); ?>
                </div>
              <div class="box-footer">
               <p><?php echo form_submit('submit', lang('edit_user_submit_btn'), array('class'=>'btn btn-primary submit'));?></p>
              </div>
              <?php echo form_close();?>
          </div>
        </div>
        <!--/.col (left) -->
        <!-- right column -->
        
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

</div>
<!-- ./wrapper -->
<?php $this->load->view('common/footer'); ?>
