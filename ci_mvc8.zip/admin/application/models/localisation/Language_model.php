<?php 
class Language_model extends CI_Model {
	public function __construct(){
		parent::__construct();
	}
	public function index(){
		
	}
	public function getAll($where = NULL){
		if(isset($where)){
			$this->db->where($where);
		}
		 $this->db->order_by('language_name', 'ASC');
		$query = $this->db->get('ci_languages');
		if ($query->num_rows() > 0){
			return $query->result();
		}
		return FALSE;
	}
	public function getById(){



	}	
	public function createLanguage($data){

		if($data['default'] == '1'){
			$this->db->where('language_default', '1');
			$this->db->update('ci_languages', array('default' => '0'));
		} 
		return $this->db->insert('ci_languages', $data);

	}
	public function getByIdLanguage($language_id = NULL){

				if(isset($language_id) && is_int($language_id)) {
					$this->db->where('language_id', $language_id);
					$query = $this->db->get('ci_languages');
					if($query->num_rows() == 1){
						return $query->row();
					}
				}
				return FALSE;

	}

	public function updateLanguage($language_id, $data){

		if($data['language_default'] == '1') {
			$this->db->where('language_default', '1');
			$this->db->update('ci_languages', array('language_default'=> '0'));
		}
		$this->db->where('language_id', $language);
		return $this->db->update('ci_languages', $data);
	}

	public function deleteLanguage($language_id){
		$this->db->where('language_id', $language_id);
		$this->db->delete('ci_languages');

		// return $this->db->delete('ci_languages', array('id' => $language_id));
	}
}