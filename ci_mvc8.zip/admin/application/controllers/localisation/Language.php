<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Language extends Admin_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('localisation/Language_model');

		$this->load->database();
		$this->load->library(array('ion_auth', 'form_validation'));
		$this->load->helper(array('url', 'language'));


		

	}
	public function index(){
		$data['heading_title'] = 'Manage Language';
 		$data['users'] = $this->ion_auth->users()->result();
			foreach ($data['users'] as $k => $user)
			{
				$data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}
		$data['languages'] = $this->Language_model->getAll();
		$this->load->view('localisation/index', $data);
	}
	public function  createLanguage(){

		$data['heading_title'] = 'Manage Language';
 		$data['users'] = $this->ion_auth->users()->result();
			foreach ($data['users'] as $k => $user)
			{
				$data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}
		$this->form_validation->set_rules('language_name', 'Language name', 'trim|required|is_unique[ci_languages.language_name]');
		$this->form_validation->set_rules('language_slug', 'language_slug', 'trim|alpha_dash|required');
		// $this->form_validation->set_rules('language_slug', 'Language slug', 'trim|alpha_dash|required|is_inique[ci_languages.language_slug]');
		$this->form_validation->set_rules('language_directory', 'Language directory', 'trim|required');
		$this->form_validation->set_rules('language_code', 'Language code', 'trim|alpha_dash|required|is_unique[ci_languages.language_code]');
		$this->form_validation->set_rules('defalut', 'Default', 'trim|in_list[0,1]');

		/// if else validation create ///
		if ($this->form_validation->run()== FALSE){
			$this->load->view('localisation/create_language', $data);
		} else {
			$new_language = array(
				'language_name' => $this->input->post('language_name'),
				'language_slug' => $this->input->post('language_slug'),
				'language_directory' => $this->input->post('language_directory'),
				'language_code' => $this->input->post('language_code'),
				'language_default'  => $this->input->post('language_default'),
				);

			 $this->session->flashdata('message', 'Language create success');
			if (!$this->Language_model->createLanguage($new_language)) {
			 $this->session->flashdata('message', 'Language create error');
			}
			redirect('localisation/language', 'refresh');
		}
		
	}



	public function updateLanguage($language_id = NULL){
		$data['heading_title'] = 'Manage Language';
 		$data['users'] = $this->ion_auth->users()->result();
			foreach ($data['users'] as $k => $user)
			{
				$data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}
		$this->form_validation->set_rules('language_name', 'Language name', 'trim|required|is_unique[ci_languages.language_name]');

		$this->form_validation->set_rules('language_slug', 'Language slug', 'trim|alpha_dash|required|is_inique[ci_languages.language_slug]');
		$this->form_validation->set_rules('language_directory', 'Language directory', 'trim|required');
		$this->form_validation->set_rules('language_code', 'Language code', 'trim|alpha_dash|required|is_unique[ci_languages.language_code]');
		$this->form_validation->set_rules('defalut', 'Default', 'trim|in_list[0,1]');

		$this->form_validation->set_rules('language_id', 'Language id', 'trim|integer');

		$language_id = isset($language_id) ? (int) $language_id : (int) $this->input->post('language_id');

		if($this->form_validation->run()== FALSE) {
			$language  = $this->Language_model->getByIdLanguage($language_id);
		
			if ($language == FALSE) {
				$data['language'] = $language;
				$this->load->view('localisation/update_language' , $data);
			} else {
				$this->session->set_flashdata('message', 'The id language dont exit');
				redirect('localisation/language', 'refresh');
			}

		} else {
			$new_data = array (
				  'language_name' => $this->input->post('language_name'),
			      'slug' => $this->input->post('language_slug'),
			      'language_directory' => $this->input->post('language_directory'),
			      'language_code' => $this->input->post('language_code'),
			      'language_default' => $this->input->post('language_default'),

				);
			$this->session->flashdata('message', 'Language data success ok');

			if (!$this->Language_model->updateLanguage($language_id, $new_data)){
				$this->session->flashdata('message', 'Dont update language errors');
			}
			redirect('localisation/language');
		}


	}
	public function deleteLanguage($language_id){

		if($this->Language_model->deleteLanguage($language_id)=== FALSE) {
			$data['message']  = $this->session->set_flashdata('messate', 'dont delete language');
		} else {
			$data['message'] = $this->session->set_flashdata('message', 'ok success');
			redirect('localisation/language');
		}

	}

// public function delete($language_id)
// {
//   if(($language = $this->language_model->get_by_id($language_id)) && $language->default == '1')
//   {
//     $this->session->set_flashdata('message','I can\'t delete a default language. First set another default language.');
//   }
//   elseif($this->language_model->delete($language_id) === FALSE)
//   {
//     $this->session->set_flashdata('message', 'There was an error in deleting the language');
//   }
//   else
//   {
//     $this->session->set_flashdata('message', 'Language deleted successfuly');
//   }
//   redirect('admin/languages','refresh');
// }

	public function editLanguage($language_id){

	}

}
