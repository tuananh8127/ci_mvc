<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboard extends Admin_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->library(array('ion_auth','form_validation'));
		$this->load->helper(array('url','language'));

		if(!$this->ion_auth->logged_in()){
			redirect('common/login', 'refresh');
		}
		

	}
	public function index ($page= 'dashboard'){
		$file_path = APPPATH.'controllers/header.php';
		$data['heading_title'] = 'Hello dashboard';
		 if ( ! file_exists(APPPATH.'views/common/'.$page.'.php'))
        {
                show_404();
        }
		else {
			$data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$data['users'] = $this->ion_auth->users()->result();
			foreach ($data['users'] as $k => $user)
			{
				$data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}
			$this->load->view('common/dashboard', $data);
			
		}

	}
}