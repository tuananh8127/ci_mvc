<?php 
$lang['text_logout'] = 'Logout';

