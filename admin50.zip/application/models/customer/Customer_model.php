<?php 
class Customer_model extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
		$this->table = 'ci_customer';
	}
	public function index(){
		
	}
	public function getAll($where = NULL){
		if(isset($where)){
			$this->db->where($where);
		}
		 $this->db->order_by('customer', 'ASC');
		$query = $this->db->get($this->table);
		if ($query->num_rows() > 0){
			return $query->result();
		}
		return FALSE;
	}

	public function createCustomer($data){

		if($data['default'] == '1'){
			$this->db->where('customer_id');
			$this->db->update($this->table, array('default' => '0'));
		} 
		return $this->db->insert($this->table, $data);

	}
	public function getByIdCustomer($customer_id = NULL){

		if (isset($customer_id) && is_int($customer_id)) {
			$this->db->where('customer_id', $customer_id);
			$query = $this->db->get($this->table);
			if($query->num_rows() == 1){
				return $query->row();
			}
		} 
			return FALSE;

	}
	public function updateCustomer($customer_id, $data) {
		$this->db->where('customer_id', $customer_id);
		$this->db->update($this->table, $data);
	}
	
	public function deleteCustomer($customer_id){
		$this->db->where('customer_id', $customer_id);
		$this->db->delete($this->table);
	}
}