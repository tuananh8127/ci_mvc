<?php 
class Appchat_model extends CI_Model{
	public function __construct(){
		parent::__construct();
		$this->load->database();
		$this->table = 'ci_appchat';
	}
	public function index(){

	}
	public function getAlll($where = null){
		if(isset($where)) {
			$this->db->where($where);
		}
		$this->db->order_by('username', 'ASC');
		$query = $this->db->get($this->table);
		if($query->num_rows() >0){
			return $query->row();
		}	
		return false;

	}
	public function getById($appchat_id = null){

		if(isset($appchat_id) && is_int($appchat_id)){
			$this->db->where('appchat_id', $appchat_id);
			$query = $this->db->get($this->table);
			if($query->num_rows() == 1) {
				return $query->row();
			}
		}
		return false;


	}
	public function update($appchat_id, $data){
			
			$this->db->where('appchat_id', $appchat_id);
			$this->db->insert($this->table, $data);

	}
}