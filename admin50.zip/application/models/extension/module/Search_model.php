<?php 
class Search_model extends CI_Model{
    public function __construct(){
        parent::__construct();
        $this->table = 'ci_customer';
    }
    public function getAll($where = NULL){
		if(isset($where)){
			$this->db->where($where);
		}
		 $this->db->order_by('customer', 'ASC');
		$query = $this->db->get($this->table);
		if ($query->num_rows() > 0){
			return $query->result();
		}
		return FALSE;
	}
}