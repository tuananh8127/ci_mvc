<?php
class Category_model extends CI_Model{
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	public function index(){

	}
	public function getAll($limit =1000,$offset = 0, $col = 'name', $order= 'asc'){

		$category = $this->db->dbprefix('category');
		$category_description = $this->db->dbprefix('category_description');
		$query = $this->db->query("
			SELECT * FROM ".$category."
			STRAIGHT_JOIN ".$category_description."
			ON ".$category.".category_id = ".$category_description.".category_id
			WHERE status= 1
			ORDER BY ".$col." ".$order."
			LIMIT ".$offset.", ".$limit."
			");
		var_dump($query);
		return $query;
//STRAIGHT_JOIN được dự định như là một chỉ dẫn để optimizer truy vấn MySQL rằng các bảng cần phải được phối từ trái sang phải theo thứ tự chúng được liệt kê trong truy vấn.
	}
	public function getId(){

	}
	public function edit(){

	}
	public function update(){
		
	}
}