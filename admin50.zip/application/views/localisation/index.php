<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> Data Tables
       <small>advanced tables</small>
      </h1>
      <div class="row">
            <div class="col-lg-4">
            <a  href="<?php echo base_url('localisation/language/createLanguage'); ?>" type="button" class="btn btn-success">Create New +</a>
            </div>
        </div>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Language</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"><?php echo $heading_title; ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <div class=""><?php if(isset($message)){ echo $message; } ?></div>
              <table id="example2" class="table table-bordered table-hover">
             
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Tên ngôn ngữ</th>
                  <th>Url</th>
                  <th>Engine version</th>
                  <th>Code</th>
                  <th>Language Default</th>
                  <th>Edit language</th>
                  <th>Delete language</th>
                </tr>
                </thead>
                 <?php if(!empty($languages)) { ?>
                <tbody>
                <?php foreach($languages as $lang) { ?>
                <tr>
                
                  <td><?php echo $lang->language_id; ?></td>
        					<td><?php echo $lang->language_name; ?></td>
        					<td><?php echo $lang->language_slug; ?></td>
        					<td><?php echo $lang->language_directory; ?></td>
        					<td><?php echo $lang->language_code; ?></td>
        					<td><?php  echo ($lang->language_default == '1') ? 'Default' : 'Not default';
          echo '</td>'; ?></td>
          <td>
          <a href="<?php echo base_url('localisation/language/updateLanguage/'.$lang->language_id); ?>"><i class="fa fa-edit"></i>Edit</a></td>
          <td><a href="<?php echo base_url('localisation/language/deleteLanguage/'.$lang->language_id); ?>" class="btn btn-danger btn-xs" onclick="return delete_ms();">Delete</a></td>
          </td>
          
          </tr>
          <?php } ?>
          </tbody>
          <?php } ?>
          </table>
          </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
	<script>
 function delete_ms(){ return confirm('Bạn có Chắc chắn muốn xóa'); }

  </script>