<!DOCTYPE html>
<html ng-app=MostlikerApp> <!-- Module name mostlikers app --> 
  <head>
    <script src="http://code.angularjs.org/1.2.0-rc.3/angular.min.js"></script>
  </head>
  <body ng-controller="demoCtrl">
  <div>      
  <div style="width:600px; margin-left:50px; float:left;">
    <h2>Simple search filter with angularjs and php</h2>
      <div>Demo <a href="">Tutorial Link</a>
       - mostlikers blog
   
      </div>
    <table>
        <tr>
            <td align="right">Search :</td>
            <td><input ng-model="query[queryBy]" /></td>
        </tr>
    </table>
    <hr>
    <div>
        <table>
            <tr>
                <th>S.No</th>
                <th>Title</th>
            </tr>
            <tr ng-repeat="article in articles | filter:query">
                <td>{{$index + 1}}</td>
                <td><a target="_blank" href="{{article.link}}">{{article.name}}</a></td>
            </tr>
        </table>
    </div>
   </div>
   <div style="width:300px; margin-right:150px; float:right;">

<!-- my own ads -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:600px"
     data-ad-client="ca-pub-9665679251236729"
     data-ad-slot="2240887024"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></br>

<!-- my own ads -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:600px"
     data-ad-client="ca-pub-9665679251236729"
     data-ad-slot="2240887024"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
   </div>
   </div>
  </body>
</html>
  

<script type="text/javascript">
 var MostlikerApp = angular.module("MostlikerApp",[]); // Module name mostlikers app
  MostlikerApp.controller("demoCtrl",function($scope){ // controller name 
    $scope.query = {}
    $scope.queryBy = '$'
    $scope.articles = <?php echo $my_demos; ?>; //  JSON Data
    $scope.orderProp="name";                
  });   
</script>



<script type="text/javascript">
 var employeeApp = angular.module("EmployeeApp",[]);
  employeeApp.controller("empCtrl",function($scope){
    $scope.query = {}
    $scope.queryBy = '$'
    $scope.employees = [
      {
        "name" : "Mahesh Pachangane",
        "company" : "Syntel India Pvt. Ltd",
        "designation" : "Associate"
      },
      {
        "name" : "Brijesh Shah",
        "company" : "Britanica Software Ltd.",
        "designation" : "Software Engineer"
      }
    ];
    $scope.orderProp="name";                
  });

</script>