

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Widgets
        <small>Preview page</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Widgets</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

   
      <!-- /.row -->

      <!-- =========================================================== -->


      <!-- /.row -->

      <!-- =========================================================== -->


   
      <!-- /.row -->

      <!-- =========================================================== -->

      <div id="notif"></div>
      <div class="row">
    
        <div class="col-md-12">
          
          <div class="box box-success direct-chat direct-chat-success">
            <div class="box-header with-border">
              <h3 class="box-title">Direct Chat</h3>
              <div id="ohsnap"></div>

              <div class="box-tools pull-right">
                <span data-toggle="tooltip" title="3 New Messages" class="badge bg-green">3</span>
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-toggle="tooltip" title="Contacts" data-widget="chat-pane-toggle">
                  <i class="fa fa-comments"></i></button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <!-- Conversations are loaded here -->
              <div class="direct-chat-messages">
                <!-- Message. Default to the left -->
                <div class="direct-chat-msg">
                  <div class="direct-chat-info clearfix">
                    <span class="direct-chat-name pull-left">Alexander Pierce</span>
                    <span class="direct-chat-timestamp pull-right">23 Jan 2:00 pm</span>
                  </div>
                  <!-- /.direct-chat-info -->
                  <img class="direct-chat-img" src="<?php echo base_url() ?>public/dist/img/user1-128x128.jpg" alt="Message User Image"><!-- /.direct-chat-img -->
                  <div class="direct-chat-text">
                    Is this template really for free? That's unbelievable!
                  </div>
                  <!-- /.direct-chat-text -->
                </div>
                <!-- /.direct-chat-msg -->

                <!-- Message to the right -->
                <div class="direct-chat-msg right">
                  <div class="direct-chat-info clearfix">
                    <span class="direct-chat-name pull-right">Sarah Bullock</span>
                    <span class="direct-chat-timestamp pull-left">23 Jan 2:05 pm</span>
                  </div>
                  <!-- /.direct-chat-info -->
                  <img class="direct-chat-img" src="<?php echo base_url() ?>public/dist/img/user3-128x128.jpg" alt="Message User Image"><!-- /.direct-chat-img -->
                  <div class="direct-chat-text">
                    You better believe it!
                  </div>
                  <!-- /.direct-chat-text -->
                </div>
                <!-- /.direct-chat-msg -->
              </div>
              <!--/.direct-chat-messages-->

              <!-- Contacts are loaded here -->
              <div class="direct-chat-contacts">
                <ul class="contacts-list">
                  <li>
                    <a href="#">
                      <img class="contacts-list-img" src="<?php echo base_url() ?>public/dist/img/user1-128x128.jpg" alt="User Image">

                      <div class="contacts-list-info">
                            <span class="contacts-list-name">
                              Count Dracula
                              <small class="contacts-list-date pull-right">2/28/2015</small>
                            </span>
                        <span class="contacts-list-msg">How have you been? I was...</span>
                      </div>
                      <!-- /.contacts-list-info -->
                    </a>
                  </li>
                  <!-- End Contact Item -->
                </ul>
                <!-- /.contatcts-list -->
              </div>
              <!-- /.direct-chat-pane -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <form action="#" method="post">
                <div class="input-group">
                  <input type="text" name="message" id="message" placeholder="Type Message ..." class="form-control">
                      <span class="input-group-btn">
                        <button type="submit" class="btn btn-success btn-flat" id="submit_ajax">Send</button>
                      </span>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<script>

$(document).ready(function(){

    $('#submit_ajax').click(function(lick){

      var dataString = {
        message: $('#message').val(),
      }
      $.ajax({
        url: "<?php echo base_url('extension/module/appchat/sendMessage'); ?>",
        data: dataString,
        type: 'POST',
        dataType: 'json',
        cache: false,
        success: function(data){

          if(data.success == true){
            // $('#notif').html(data.messages);
             ohSnap(data.messages, {color: 'green'});
             $('#ohsnap .alert-red').hide();
          } else if (data.success == false){
          
                // $("#notif").html(data.messages);
                ohSnap(data.messages, {color: 'red'});
                 $('#ohsnap .alert-green').hide();
          }
        }, error: function(xhr, status, error) {
          alert('error');
        }

      })


      lick.preventDefault();
    });

});

</script>
  
  <style>
#ohsnap .alert {
  padding: 15px;
  margin-bottom: 20px;
  border: 1px solid #eed3d7;
  border-radius: 4px;
  position: absolute;
  bottom: 0px;
  right: 21px;
  /* Each alert has its own width */
  float: right;
  clear: right;
  background-color: white;
}

#ohsnap .alert-red {
  color: white;
  background-color: #DA4453;
}
#ohsnap .alert-green {
  color: white;
  background-color: #37BC9B;
}
#ohsnap .alert-blue {
  color: white;
  background-color: #4A89DC;
}
#ohsnap .alert-yellow {
  color: white;
  background-color: #F6BB42;
}
#ohsnap .alert-orange {
  color:white;
  background-color: #E9573F;
}
  </style>

  /* ALERTS */
/* inspired by Twitter Bootstrap */

