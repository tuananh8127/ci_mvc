  <div class="wrapper">
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Customer
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">User profile</li>
      </ol>
    </section>
    <section class="content">

      <div class="row">

        <div class="col-md-12">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
             <li class="active"><a href="#settings"  data-toggle="tab">Settings</a></li>
             
            </ul>
            <div class="tab-content">
            <div class="active tab-pane" id="settings">
            <?php echo form_open_multipart(); ?>
                <div class="form-horizontal">
                <div class="form-group">
                    <label for="customer" class="col-sm-2 control-label">Customer</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="customer" name="customer" value="<?php echo $newcustomer ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="las" class="col-sm-2 control-label">Lastname</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo $lastname; ?>">
                    </div>
                  </div>
                  
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Firstname</label>

                    <div class="col-sm-10">
                      <input type="text" name="firstname" value="<?php echo $firstname; ?>" class="form-control" id="firstname">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-sm-2 control-label">Email</label>
                    <div class="col-sm-10">
                      <input type="email" name="email" value="<?php echo $email; ?>" class="form-control" id="inputEmail">
                    </div>
                  </div>
                 <div class="form-group">
                    <label for="telephone" class="col-sm-2 control-label">Telephone</label>
                    <div class="col-sm-10">
                      <input type="text" name="telephone" value="<?php echo $telephone; ?>" class="form-control" id="telephone">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="gender" class="col-sm-2 control-label">Gender</label>
                    <div class="col-sm-10">
                      <input type="text" name="gender" value="<?php echo $gender; ?>" class="form-control" id="gender">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="address" class="col-sm-2 control-label">Address</label>
                    <div class="col-sm-10">
                      <input type="text" name="address" value="<?php echo $address; ?>" class="form-control" id="address">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputExperience" class="col-sm-2 control-label">Locale</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="locale" value="<?php echo $locale; ?>" id="locale">
                    </div>
                  </div>
         
                   <div class="form-group">
                    <label for="inputExperience" class="col-sm-2 control-label">Image</label>
                    <div class="col-sm-10">
                      <img class="image-responsive" src ='<?php echo base_url(); ?>image/catalog/<?php echo $picture_url; ?>'>
                      <input type="file" id="picture_url" name="picture_url">
                  </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger">Submit</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
        </section>
</div>
</div>
