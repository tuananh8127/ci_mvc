


<div class="wrapper">
  <!-- Left side column. contains the logo and sidebar -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <section class="content-header">
      
      <h1>
        General Form Elements
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
      </ol>
      <div class="ajax-content">
            </div>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
         

            <h1><?php echo lang('create_user_heading');?></h1>
            <p><?php echo lang('create_user_subheading');?></p>
            <div id="infoMessage"><?php echo $message;?></div>
            </div>
            <?php echo form_open();?>
              <div class="box-body">
              <div class="form-group">
                <lable for="Customer">Customer</lable>
               <input name="customer" id="customer" class="form-control">
              </div>
              <div class="form-group">
                <lable for="Lastname">Lastname</lable>
               <input name="lastname" id="lastname" class="form-control">
              </div>

                <div class="form-group">
                <lable for="firstname">Firstname</lable>
               <input name="firstname" id="firstname" class="form-control">
              </div>

              <div class="form-group">
                <lable for="email">Email</lable>
               <input name="email" id="email" class="form-control">
              </div>
              <div class="form-group">
                <lable for="telephone">Telephone</lable>
               <input name="telephone" id="telephone" class="form-control">
              </div>
                <div class="form-group">
                <lable for="Gender">Gender</lable>
               <input name="gender" id="gender" class="form-control">
              </div>
               <div class="form-group">
                <lable for="address">Address</lable>
               <input name="address" id="address" class="form-control">
              </div>

                <div class="form-group">
                <lable for="locale">Locale</lable>
               <input name="locale" id="locale" class="form-control">
              </div>

              <div class="box-footer">
              <p> <i class="fa fa-spin fa-refresh"></i>&nbsp;<input type="submit" name="submit" value="Create User" id="submit_ajax" class="ajax btn btn-info" title="Ajax Request">
            </p>
                        </div>

                
                


              
                
                
          </div>
          </div>
        </div>
        <!--/.col (left) -->
        <!-- right column -->
       
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<!-- ./wrapper -->


<script type="text/javascript">
  // To make Pace works on Ajax calls

  $('.ajax').click(function(){
  
    var form_data =  {
      first_name: $('#first_name').val(),
      last_name: $('#last_name').val(),
      company: $('#company').val(),
      email: $('#email').val(),
      phone: $('#phone').val(),
      password: $('#password').val(),
      password_confirm: $('#password_confirm').val()
    }
    var text_notification = '<?php echo $message; ?>'
      $.ajax({
          url: '<?php echo base_url('common/login/create_user'); ?>',
          type: 'POST',
          data: form_data,
          cache:  false,
          success: function(json){
               if (json == 'ok'){

                 $('.ajax-content').html('<div class="alert alert-success">' + text_notification + '<i class="fa fa-check-circle"></i>' + '<button type="button" class="close" data-dismiss="alert">' + '×' + '</button>' + '</div>' );
                $('.ajax-content').fadeIn('slow').delay(6000).fadeOut('slow');


               } else {
                $('.ajax-content').html('<div class="alert alert-danger">' + '<i class="fa fa-check-circle"></i>' + '<button type="button" class="close" data-dismiss="alert">' + text_notification +  '×' + '</button>' + '</div>' ).fadeIn().delay(6000);
                $('.ajax-content').fadeIn('slow').delay(6000).fadeOut('slow');
               }
          }
      });
  }); 

  $(document).ajaxStart(function() { Pace.restart(); });
    $('.ajax').click(function(){
        $.ajax({url: '#', success: function(result){
            // $('.ajax-content').html('<hr>Ajax Request Completed !');
        }});
    });
</script>
