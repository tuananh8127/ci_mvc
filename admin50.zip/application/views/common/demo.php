<?php  foreach ($users as $user) : ?>
	<?php var_dump($user); ?>
<?php endforeach; ?>