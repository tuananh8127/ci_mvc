<?php 
class Icon extends MY_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->library(array('form_validation'));
		$this->load->helper(array('url', 'language'));
	}
	public function index(){

		$data['heading_title'] = 'Icon';

		$this->load->view('common/header', $data);
		$this->load->view('design/icon', $data);
		$this->load->view('common/footer');
	}
}