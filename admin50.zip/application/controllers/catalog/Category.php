<?php 
class Category extends MY_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('catalog/category_model');
		$this->category_model->getAll();
	}
	public function index(){
		
		$this->category_model->getAll();

	}
	public function getAll(){
		$data['perpage'] = $config['perpage'];
		
	}
	public function edit(){

	}
	public function update(){
		
	}
}