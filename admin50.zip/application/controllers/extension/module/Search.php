<?php 
class Search extends MY_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('extension/module/search_model');
    }
    public function index(){
       $data = $this->search_model->getAll();

       $json_data = array ();
       foreach ($data as $customers) {
           $json_array['customer'] = $customers->customer;
           $json_array['customers'] = $customers->customer_id;
           array_push($json_data, $json_array);
       } 

        $my_search = json_encode($json_data,JSON_PRETTY_PRINT);
        $this->load->view('extension/module/search');
    }
    
}