<?php 
class Appchat extends MY_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('extension/module/appchat_model');
		$this->load->helper('url');
	}
	public function index(){
		$data['heading_title'] = 'Hello appchat';


		
		$this->load->view('common./header');
		$this->load->view('common/menu');
		$this->load->view('extension/module/appchat');
		$this->load->view('common/footer');
	}


	public function sendMessage(){
		

		$this->form_validation->set_rules('message', 'message', 'required');

		$appchat_id = isset($appchat_id) ? (int) $appchat_id : (int) $this->input->post('appchat_id');

		$data = array(
			'message' => $this->input->post('message'),
			);
		if($this->form_validation->run() == false){
			$data['success'] = false;
			$data['messages'] = validation_errors();
		} else {
			$this->appchat_model->update($appchat_id, $data);
			$data['success'] = true;
			$data['messages'] = 'Message sent  SUCCESS...';
		}

		echo json_encode($data);
	}

	
		
}