<?php 
class Header extends MY_Controller {
	public function __construct(){
		parent::__construct();

	}
	public function index($page = "header"){
		$data['heading_title'] = 'Admin';
		if(!file_exists('views/common/'.$page.'.php')){
			show_404();
		}
		else {
			$this->load->view('common/header', $data);
			
		}
		if(!$this->ion_auth->logged_in()){
			redirect('common/login', 'refresh');
		}
		if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == TRUE){
			redirect('common/dashboard', 'refresh');
		} else {
			redirect('common/login', 'refresh');
		}
	}
}