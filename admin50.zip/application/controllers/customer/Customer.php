<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Customer extends MY_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('customer/customer_model');
		$this->load->helper(array('url', 'language'));
	}
	public function index(){
		$data['heading_title'] = 'Manage Customer';
		$data['customers'] = $this->customer_model->getAll();
		$this->load->view('common/header', $data);
		$this->load->view('customer/profile', $data);
		$this->load->view('common/footer');
	}
	
	public function  createCustomer(){

		$data['heading_title'] = 'Add Customer';
		$this->form_validation->set_rules('customer', 'Customer', 'trim|required');
		$this->form_validation->set_rules('lastname', 'Lastname', 'required');
		$this->form_validation->set_rules('firstname', 'firstname', 'required');
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('gender', 'Gender', 'required');
		$this->form_validation->set_rules('telephone', 'telephone', 'required');
		$this->form_validation->set_rules('address', 'address', 'required');
		$this->form_validation->set_rules('locale','Locale','required');
		
		if ($this->form_validation->run()== FALSE){
			$data['message'] = 'Errors validation form';
			$this->load->view('common/header', $data);
			$this->load->view('common/menu');
			$this->load->view('customer/create', $data);
			$this->load->view('common/footer');
		} else {
			$new_customer = array(
				'customer' => $this->input->post('customer'),
				'lastname' => $this->input->post('lastname'),
				'firstname' => $this->input->post('firstname'),
				'email' 	=> $this->input->post('email'),
				'gender'	=> $this->input->post('gender'),
				'telephone' => $this->input->post('telephone'),
				'address' 	=> $this->input->post('address'),
				'locale'	=> $this->input->post('locale')
				);

			 $this->session->flashdata('message', 'customer create success');
			if (!$this->customer_model->createCustomer($new_customer)) {
			 $this->session->flashdata('message', 'customer create error');
			}
			redirect('customer/customer', 'refresh');
		}
		
	}



	public function updateCustomer($customer_id = NULL){
		$this->form_validation->set_rules('customer', 'customer', 'required');
		$this->form_validation->set_rules('lastname', 'lastname', 'required');
		$this->form_validation->set_rules('firstname', 'firstname', 'required');
		$this->form_validation->set_rules('gender', 'gender', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('telephone', 'Telephone', 'required');
		$this->form_validation->set_rules('address', 'Address', 'required');
		$this->form_validation->set_rules('locale', 'Locale', 'required');

		$customer_id = isset($customer_id) ? (int) $customer_id : (int) $this->input->post('customer_id');
		$data = array (

			'customer' => $this->input->post('customer'),
			'lastname' => $this->input->post('lastname'),
			'firstname' => $this->input->post('firstname'),
			'gender' => $this->input->post('gender'),
			'email' => $this->input->post('email'),
			'telephone' => $this->input->post('telephone'),
			'address' => $this->input->post('address'),
			'locale' => $this->input->post('locale'),
			'picture_url' => $this->input->post('picture_url')
			);

		if($this->form_validation->run() == FALSE ){
			$data['heading_title'] = "Edit customer";
			$getCustomer = $this->customer_model->getByIdCustomer($customer_id);
			$data['newcustomer']   = $getCustomer->customer;
			$data['lastname']      = $getCustomer->lastname;
			$data['firstname']     = $getCustomer->firstname;
			$data['gender']        = $getCustomer->gender;
			$data['email']         = $getCustomer->email;
			$data['telephone'] 	   = $getCustomer->telephone;
			$data['address']       = $getCustomer->address;
			$data['locale']        = $getCustomer->locale;
			$data['picture_url']   = $getCustomer->picture_url;
 
				$this->session->set_flashdata('message', 'dont update customer');
				$this->load->view('common/header', $data);
				$this->load->view('common/menu');
				$this->load->view('customer/edit', $data);
				$this->load->view('common/footer');
		
		} else {
			$this->customer_model->updateCustomer($customer_id, $data);
			$this->session->flashdata('message', 'update sucess');
			$getCustomer = $this->customer_model->getByIdCustomer($customer_id);
			$data['newcustomer']   = $getCustomer->customer;
			$data['lastname']      = $getCustomer->lastname;
			$data['firstname']     = $getCustomer->firstname;
			$data['gender']        = $getCustomer->gender;
			$data['email']         = $getCustomer->email;
			$data['telephone'] 	   = $getCustomer->telephone;
			$data['address']       = $getCustomer->address;
			$data['locale']        = $getCustomer->locale;
			$data['picture_url']   = $getCustomer->picture_url;
			
			$this->load->view('common/header', $data);
			$this->load->view('common/menu');
			$this->load->view('customer/edit', $data);
			$this->load->view('common/footer');
		}

		$this->uploadImage();

	}
	public function do_upload(){
		$this->load->helper(array('form', 'url'));
		$this->load->helper('form');
		$data = array('msg' => "Upload File");
		$config['upload_path'] = 'image/';
		$config['allowed_types'] = 'gif|jpg|png';	
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		$data['upload_data'] = '';
		$data['picture_url']   = $this->upload->do_upload('picture_url');
		if (!$this->upload->do_upload('userfile')) {
			$data = array('msg' => $this->upload->display_errors());
		} else { 
			$data = array('msg' => "Upload success!");
      $data['upload_data'] = $this->upload->data();
		}
		$this->load->view('customer/upload', $data);
	}
	public function uploadImage(){
		$this->load->helper(array('form', 'url'));
		$this->load->helper('form');
		$data = array('msg' => "Upload File");
		$config['upload_path'] = 'image/catalog/';
		$config['allowed_types'] = 'gif|jpg|png';	
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		$data['upload_data'] = '';
		if (!$this->upload->do_upload('picture_url')) {
			$data = array('msg' => $this->upload->display_errors());
		} else { 
			$data = array('msg' => "Upload success!");
      $data['upload_data'] = $this->upload->data();
		}
		
	}
	public function deleteCustomer($customer_id){

		if($this->customer_model->deleteCustomer($customer_id)=== FALSE) {
			$data['message']  = $this->session->set_flashdata('messate', 'dont delete Customer');
		} else {
			$data['message'] = $this->session->set_flashdata('message', 'ok success');
			redirect('customer/customer');
		}

	}

// public function delete($language_id)
// {
//   if(($language = $this->language_model->get_by_id($language_id)) && $language->default == '1')
//   {
//     $this->session->set_flashdata('message','I can\'t delete a default language. First set another default language.');
//   }
//   elseif($this->language_model->delete($language_id) === FALSE)
//   {
//     $this->session->set_flashdata('message', 'There was an error in deleting the language');
//   }
//   else
//   {
//     $this->session->set_flashdata('message', 'Language deleted successfuly');
//   }
//   redirect('admin/languages','refresh');
// }

	public function editCustomer($customer_id){

	}

}
